const assert = require('assert/strict');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = process.argv[2];
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, {
    value:'',textContent:'',innerHTML:'',disabled:false,required:false,
    classList:{add(){},remove(){}},addEventListener(){},reset(){},
    querySelector(){return element('submit');}
  });
  return elements.get(id);
}
const context={
  document:{addEventListener(){},getElementById:element},
  window:{addEventListener(){},location:{pathname:'/'},POS_CURRENT_USER:{is_admin:true}},
  FormData:class {},AbortController,console,setTimeout,clearTimeout,setInterval,clearInterval
};
vm.createContext(context);
for (const name of ['common','products','price_lists']) {
  vm.runInContext(fs.readFileSync(path.join(root,'app/static/js',name+'.js'),'utf8'),context);
}
context.showToast=()=>{};
let resets=0;
element('priceImportForm').reset=()=>{resets++;};
async function main() {
  context.fetch=async()=>({ok:true,status:200,json:async()=>({ok:true,created:0,updated:1,skipped:0,stock_preserved:1})});
  await context.importPrices({preventDefault(){}});
  assert.ok(element('importResult').innerHTML.includes('Se conservaron las existencias actuales de 1'));
  assert.equal(element('submit').disabled,false);
  assert.equal(resets,1);
  console.log('OK: importación informa existencias conservadas y libera el botón');

  element('importResult').innerHTML='';
  context.fetch=async()=>({ok:false,status:401,json:async()=>({error:'Sesión revocada',login_required:true})});
  await context.importPrices({preventDefault(){}});
  assert.equal(context.window.location.href,'/login');
  assert.equal(element('importResult').innerHTML,'');
  assert.equal(resets,1);
  assert.equal(element('submit').disabled,false);
  context.window.location.href='';
  await assert.rejects(context.apiProductForm('/api/products/1','PUT',{}));
  assert.equal(context.window.location.href,'/login');
  console.log('OK: importación y edición rechazan sesión revocada sin mostrar un guardado exitoso');
}
main().catch(error=>{console.error(error);process.exit(1);});
