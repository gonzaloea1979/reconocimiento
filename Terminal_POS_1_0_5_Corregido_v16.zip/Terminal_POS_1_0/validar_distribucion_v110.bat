@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
echo Validacion de distribucion V110-RC1 (solo lectura; no usa base comercial).
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" tests\test_v110_release_safety.py
) else (
    py -3.12 tests\test_v110_release_safety.py
    if errorlevel 1 py -3 tests\test_v110_release_safety.py
)
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo ERROR: No aprobar distribucion V110.
pause
exit /b %RC%
