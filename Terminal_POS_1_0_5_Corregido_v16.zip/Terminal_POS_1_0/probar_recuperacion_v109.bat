@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
title Terminal POS V109 - Respaldos y recuperacion
set "PYCMD=python"
if exist ".venv\Scripts\python.exe" set "PYCMD=.venv\Scripts\python.exe"
echo Validacion de respaldos y restauracion con datos ficticios temporales.
echo NO se abre ni modifica instance\pos.db.
echo.
"%PYCMD%" tests\test_v109_backup_recovery.py
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo ERROR: validacion V109 fallida. Copia el mensaje completo.
if "%RC%"=="0" echo OK: validacion V109 completada.
pause
exit /b %RC%
