#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
python3 preparar_entorno.py
exec .venv/bin/python run.py
