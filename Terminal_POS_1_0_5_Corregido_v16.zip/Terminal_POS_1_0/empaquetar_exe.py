"""Crear el ZIP solo después de verificar la salida, sin publicar ZIP parcial."""
from pathlib import Path
import os
import sys
import tempfile
import zipfile
from verificar_exe_compilado import verify_distribution


def package_distribution(root, destination):
    root = verify_distribution(root).resolve()
    destination = Path(destination).resolve()
    if destination == root or root in destination.parents:
        raise ValueError('El ZIP de salida debe estar fuera de la carpeta a comprimir.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(prefix='.pos_package_', suffix='.tmp', dir=destination.parent)
    os.close(descriptor)
    temporary = Path(name)
    try:
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(root.rglob('*')):
                if path.is_file():
                    archive.write(path, path.relative_to(root))
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise ValueError('El ZIP generado no aprobo la verificacion CRC.')
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)
    return destination


if __name__ == '__main__':
    try:
        output = package_distribution(sys.argv[1], sys.argv[2])
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        print('ERROR: no se pudo crear el ZIP:', exc)
        raise SystemExit(1)
    print('OK: ZIP verificado:', output)
