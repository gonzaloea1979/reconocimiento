@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
title Terminal POS V107 - Ventas concurrentes de 2 usuarios
echo Prueba HTTP real con dos sesiones independientes y base temporal.
echo NO abre ni modifica instance\pos.db.
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" tests\test_v107_two_user_http_sales.py
) else (
    py -3.12 tests\test_v107_two_user_http_sales.py
    if errorlevel 1 python tests\test_v107_two_user_http_sales.py
)
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo Revisar error: la prueba no fue aprobada.
pause
exit /b %RC%
