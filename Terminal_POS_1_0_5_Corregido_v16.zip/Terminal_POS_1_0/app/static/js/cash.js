async function loadCash(){ const data=await api('/api/cash/status'); if(!data.open){ cashStatus.innerHTML='<strong>Caja cerrada</strong><small>Abrí caja para controlar movimientos diarios.</small>'; cashMovements.innerHTML='<tr><td colspan="5" class="empty-state">No hay caja abierta</td></tr>'; return; } const s=data.session; cashStatus.innerHTML=`<strong>Caja abierta #${Number(s.id)}</strong><small>Apertura: ${escapeHTML(s.opened_at_formatted)}</small><div class="cash-kpis"><span>Inicial ${formatMoney(s.initial_amount)}</span><span>Efectivo esperado ${formatMoney(s.expected_amount)}</span></div>`; cashMovements.innerHTML=data.movements.length?data.movements.map(m=>`<tr><td>${escapeHTML(m.created_at_formatted)}</td><td>${escapeHTML(m.movement_type)}</td><td>${escapeHTML(m.payment_method)}</td><td>${formatMoney(m.amount)}</td><td>${escapeHTML(m.description||'')}</td></tr>`).join(''):'<tr><td colspan="5" class="empty-state">Sin movimientos</td></tr>'; }
async function openCash(){ try{ await api('/api/cash/open',{method:'POST',body:JSON.stringify({initial_amount:cashAmount.value,notes:cashNotes.value})}); showToast('Caja abierta'); loadCash(); }catch(e){showToast(e.message,true);} }
function addCashMovement() {
  return withOperationLock('cash-movement', '#cashMovementSaveBtn', async () => {
    try {
      await postOperation('/api/cash/movement', {
        movement_type: cashMovementType.value,
        amount: cashMovementAmount.value,
        description: cashMovementDescription.value
      });
      showToast('Movimiento guardado');
      cashMovementAmount.value = 0;
      cashMovementDescription.value = '';
      await loadCash();
    } catch (e) {
      showToast(e.message, true);
    }
  });
}
async function closeCash(){ try{ const r=await api('/api/cash/close',{method:'POST',body:JSON.stringify({closing_amount:cashAmount.value,password:securityPasswordOrEmpty('cashPassword'),notes:cashNotes.value})}); showToast(`Caja cerrada. Diferencia: ${formatMoney(r.difference)}`); cashPassword.value=''; loadCash(); }catch(e){showToast(e.message,true);} }
document.addEventListener('DOMContentLoaded',()=>{ markAdminBypassUI(); });
document.addEventListener('DOMContentLoaded',loadCash);
