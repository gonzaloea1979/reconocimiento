async function loadDashboard() {
  try {
    const data = await api('/api/dashboard');
    document.getElementById('dailySales').textContent = formatMoney(data.daily_sales);
    document.getElementById('monthlySales').textContent = formatMoney(data.monthly_sales);
    setTextIfExists('dailyTickets', data.daily_ticket_count ?? 0);
    setTextIfExists('lowStockCount', data.stock_control_enabled ? (data.low_stock_count ?? 0) : 'Desactivado');
    const stockLabel = document.querySelector('.alert-kpi span');
    if (stockLabel) stockLabel.textContent = data.stock_control_enabled ? 'Bajo stock' : 'Control de stock';
    setTextIfExists('expiringCount', data.expiring_count ?? (data.expiring_products || []).length);

    renderRank('topProducts', data.top_products, 'top');
    renderRank('leastProducts', data.least_products, 'least');
    renderExpiring(data.expiring_products);
  } catch (err) {
    showToast(err.message, true);
  }
}

function setTextIfExists(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

function renderRank(id, rows, type = '') {
  const el = document.getElementById(id);
  el.className = 'rank-list dashboard-scroll-list';
  if (!rows.length) {
    el.className = 'rank-list dashboard-scroll-list empty-state';
    el.textContent = 'Sin datos todavía';
    return;
  }
  const typeClass = type === 'top' ? 'rank-top' : type === 'least' ? 'rank-least' : '';
  const badgeText = type === 'top' ? 'Más vendido' : type === 'least' ? 'Menos vendido' : '';
  el.innerHTML = rows.map((r, i) => `
    <div class="rank-item ${typeClass}">
      <div class="rank-main">
        <span class="rank-position">${i + 1}</span>
        <div>
          <strong title="${escapeHTML(r.name)}">${escapeHTML(r.name)}</strong>
          <span>${r.qty} unidades</span>
        </div>
      </div>
      <div class="rank-side">
        <strong>${formatMoney(r.amount)}</strong>
        <em>${badgeText}</em>
      </div>
    </div>
  `).join('');
}

function expiryLabel(level) {
  if (level === 'red') return 'Crítico';
  if (level === 'orange') return 'Atención';
  return 'Próximo';
}

function renderExpiring(rows) {
  const el = document.getElementById('expiringProducts');
  el.className = 'expiry-grid dashboard-scroll-list';
  if (!rows.length) {
    el.className = 'expiry-grid dashboard-scroll-list empty-state';
    el.textContent = 'Sin vencimientos próximos';
    return;
  }
  el.innerHTML = rows.map(r => `
    <div class="expiry-item ${r.level}">
      <div class="expiry-main">
        <span class="expiry-dot ${r.level}" aria-hidden="true"></span>
        <div>
          <strong title="${escapeHTML(r.name)}">${escapeHTML(r.name)}</strong>
          <span>${escapeHTML(r.barcode || 'Sin código')}</span>
        </div>
      </div>
      <div class="expiry-meta">
        <strong>${r.days_left} días</strong>
        <span>${r.expiry_date_formatted || formatDateAR(r.expiry_date)}</span>
        <em>${expiryLabel(r.level)}</em>
      </div>
    </div>
  `).join('');
}


// V19: reloj LED de siete segmentos; SVG local, sin fuentes ni conexiones externas.
const CLOCK_SEGMENTS = {
  a: '9,3 31,3 27,7 13,7',
  b: '33,5 37,9 37,30 33,34 30,30 30,10',
  c: '33,38 37,42 37,63 33,67 30,62 30,42',
  d: '13,65 27,65 31,69 9,69',
  e: '7,38 10,42 10,62 6,67 3,63 3,42',
  f: '7,5 10,10 10,30 7,34 3,30 3,9',
  g: '10,36 14,33 27,33 30,36 27,39 14,39'
};
const CLOCK_NUMBERS = ['abcdef', 'bc', 'abged', 'abgcd', 'fgbc', 'afgcd', 'afgecd', 'abc', 'abcdefg', 'abfgcd'];
function clockDigit(value) {
  const enabled = CLOCK_NUMBERS[Number(value)] || '';
  const segments = Object.entries(CLOCK_SEGMENTS).map(([name, points]) =>
    `<polygon class="led-segment ${enabled.includes(name) ? 'lit' : ''}" points="${points}"/>`
  ).join('');
  return `<svg class="led-digit" viewBox="0 0 40 72" aria-hidden="true" focusable="false">${segments}</svg>`;
}
function clockColon() {
  return '<svg class="led-colon" viewBox="0 0 14 72" aria-hidden="true" focusable="false"><circle cx="7" cy="24" r="4.5"/><circle cx="7" cy="49" r="4.5"/></svg>';
}
function updateDashboardClock() {
  const timeElement = document.getElementById('dashboardClockTime');
  const dateElement = document.getElementById('dashboardClockDate');
  if (!timeElement || !dateElement) return;
  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  const time = `${hours}:${minutes}:${seconds}`;
  // No inserta datos externos; solo los caracteres numéricos del reloj local.
  timeElement.innerHTML = [...time].map(c => c === ':' ? clockColon() : clockDigit(c)).join('');
  timeElement.setAttribute('aria-label', `Hora actual: ${time}`);
  dateElement.textContent = new Intl.DateTimeFormat('es-AR', {
    weekday: 'long', day: '2-digit', month: 'long', year: 'numeric'
  }).format(now);
}

document.addEventListener('DOMContentLoaded', () => {
  updateDashboardClock();
  const clockInterval = window.setInterval(updateDashboardClock, 1000);
  window.addEventListener('pagehide', () => window.clearInterval(clockInterval), { once: true });
  loadDashboard();
});
