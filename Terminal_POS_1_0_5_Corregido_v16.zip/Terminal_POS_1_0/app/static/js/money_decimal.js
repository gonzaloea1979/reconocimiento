/* Cálculos monetarios de vista previa con punto fijo decimal.
 * Mantiene la vista previa de Productos y Compras alineada con el cálculo Decimal del servidor.
 * No sustituye la validación final del servidor.
 */
(function (global) {
  'use strict';

  const SCALE = 1000000n;
  const CENT = SCALE / 100n;

  // Expande notación científica usando únicamente texto; evita convertir primero
  // a Number y perder precisión decimal en importes como 2.675e0.
  function expandScientificNotation(raw) {
    const match = String(raw).match(/^([+-]?)(\d+)(?:\.(\d*))?[eE]([+-]?\d+)$/);
    if (!match) return String(raw);
    const exponent = Number(match[4]);
    if (!Number.isSafeInteger(exponent) || Math.abs(exponent) > 100) {
      throw new TypeError('Importe fuera de rango');
    }
    const sign = match[1] || '';
    const digits = match[2] + (match[3] || '');
    const decimalPosition = match[2].length + exponent;
    if (decimalPosition <= 0) return sign + '0.' + '0'.repeat(-decimalPosition) + digits;
    if (decimalPosition >= digits.length) return sign + digits + '0'.repeat(decimalPosition - digits.length);
    return sign + digits.slice(0, decimalPosition) + '.' + digits.slice(decimalPosition);
  }

  function toScaled(value) {
    let raw = String(value ?? '0').trim().replace(',', '.');
    if (!raw) raw = '0';
    raw = expandScientificNotation(raw);
    if (!/^[+-]?\d+(?:\.\d*)?$/.test(raw)) {
      const numeric = Number(raw);
      if (!Number.isFinite(numeric)) throw new TypeError('Importe no válido');
      raw = expandScientificNotation(String(numeric));
    }
    const negative = raw.startsWith('-');
    raw = raw.replace(/^[+-]/, '');
    const parts = raw.split('.');
    const whole = parts[0] || '0';
    const fraction = parts[1] || '';
    let fraction6 = fraction.slice(0, 6).padEnd(6, '0');
    let scaled = BigInt(whole) * SCALE + BigInt(fraction6 || '0');
    if (fraction.length > 6 && Number(fraction[6]) >= 5) scaled += 1n;
    return negative ? -scaled : scaled;
  }

  // Normaliza directamente a centavos desde el texto decimal original.
  // Evita que un recorte previo a seis decimales convierta, por ejemplo,
  // 1.0049999 en 1.005000 y luego en 1.01, mientras el servidor obtiene 1.00.
  function toCentsScaled(value) {
    let raw = String(value ?? '0').trim().replace(',', '.');
    if (!raw) raw = '0';
    raw = expandScientificNotation(raw);
    if (!/^[+-]?\d+(?:\.\d*)?$/.test(raw)) {
      const numeric = Number(raw);
      if (!Number.isFinite(numeric)) throw new TypeError('Importe no válido');
      raw = expandScientificNotation(String(numeric));
    }
    const negative = raw.startsWith('-');
    raw = raw.replace(/^[+-]/, '');
    const parts = raw.split('.');
    const whole = parts[0] || '0';
    const fraction = parts[1] || '';
    let cents = BigInt(whole) * 100n + BigInt((fraction.slice(0, 2).padEnd(2, '0')) || '0');
    if (fraction.length > 2 && Number(fraction[2]) >= 5) cents += 1n;
    const scaled = cents * CENT;
    return negative ? -scaled : scaled;
  }

  function divideHalfUp(numerator, denominator) {
    if (denominator <= 0n) throw new TypeError('Divisor no válido');
    const negative = numerator < 0n;
    const absolute = negative ? -numerator : numerator;
    let quotient = absolute / denominator;
    const remainder = absolute % denominator;
    if (remainder * 2n >= denominator) quotient += 1n;
    return negative ? -quotient : quotient;
  }

  function roundCents(valueScaled) {
    return divideHalfUp(valueScaled, CENT) * CENT;
  }

  function applyRoundingScaled(valueScaled, mode, multiple) {
    const multipleScaled = toCentsScaled(multiple || 1);
    if (!mode || mode === 'none' || multipleScaled <= 0n) return valueScaled;
    const negative = valueScaled < 0n;
    const value = negative ? -valueScaled : valueScaled;
    let steps = value / multipleScaled;
    const remainder = value % multipleScaled;
    if (mode === 'up' && remainder !== 0n) steps += 1n;
    else if (mode !== 'down' && mode !== 'up' && remainder * 2n >= multipleScaled) steps += 1n;
    const result = steps * multipleScaled;
    return negative ? -result : result;
  }

  function asNumber(valueScaled) {
    return Number(valueScaled) / Number(SCALE);
  }

  function calculatePriceValues(cost, iva, gross, margin, mode, multiple) {
    const costScaled = toCentsScaled(cost || 0);
    const ivaScaled = toCentsScaled(iva || 0);
    const grossScaled = toCentsScaled(gross || 0);
    const marginScaled = toCentsScaled(margin || 0);
    const divisor = 100n * SCALE;
    const totalCostRaw = costScaled
      + divideHalfUp(costScaled * ivaScaled, divisor)
      + divideHalfUp(costScaled * grossScaled, divisor);
    const saleRaw = totalCostRaw + divideHalfUp(totalCostRaw * marginScaled, divisor);
    const saleRounded = applyRoundingScaled(saleRaw, mode || 'none', multiple || 1);
    return {
      totalCost: asNumber(roundCents(totalCostRaw)),
      rawSale: asNumber(roundCents(saleRaw)),
      salePrice: asNumber(roundCents(saleRounded)),
    };
  }

  function roundPrice(value, mode, multiple) {
    if (!mode || mode === 'none') return asNumber(toCentsScaled(value || 0));
    return asNumber(roundCents(applyRoundingScaled(toScaled(value || 0), mode, multiple || 1)));
  }

  function lineTotal(unitPrice, quantity) {
    // El servidor normaliza precio y cantidad a dos decimales antes de
    // multiplicar y redondear cada renglón, no solo el total del carrito.
    const product = divideHalfUp(toCentsScaled(unitPrice) * toCentsScaled(quantity), SCALE);
    return asNumber(roundCents(product));
  }

  function sumAmounts(values) {
    let total = 0n;
    for (const value of values) total += toCentsScaled(value);
    return asNumber(total);
  }

  global.POSMoneyDecimal = Object.freeze({ calculatePriceValues, roundPrice, lineTotal, sumAmounts });
})(typeof window !== 'undefined' ? window : globalThis);
