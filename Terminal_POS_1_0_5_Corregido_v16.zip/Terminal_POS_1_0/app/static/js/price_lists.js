function renderImportResult(data) {
  const box = document.getElementById('importResult');
  box.classList.remove('hidden', 'error');
  box.innerHTML = `
    <h2>Importación finalizada</h2>
    <div class="result-metrics">
      <div><strong>${data.created}</strong><span>Productos nuevos</span></div>
      <div><strong>${data.updated}</strong><span>Productos actualizados</span></div>
      <div><strong>${data.skipped}</strong><span>Filas vacías omitidas</span></div>
    </div>
    ${Number(data.stock_preserved) > 0 ? `<p>Se conservaron las existencias actuales de ${Number(data.stock_preserved)} producto(s).</p>` : ''}
  `;
}

function renderImportError(error, details = []) {
  const box = document.getElementById('importResult');
  box.classList.remove('hidden');
  box.classList.add('error');
  box.innerHTML = `
    <h2>No se pudo importar</h2>
    <p>${escapeHTML(error)}</p>
    ${details.length ? `<ul>${details.map(d => `<li>${escapeHTML(d)}</li>`).join('')}</ul>` : ''}
  `;
}

async function importPrices(event) {
  event.preventDefault();
  const form = document.getElementById('priceImportForm');
  const passInput = document.getElementById('priceImportPassword');
  if (currentUserIsAdmin() && passInput) {
    passInput.required = false;
    passInput.value = '';
  }
  const formData = new FormData(form);
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  button.textContent = 'Importando...';

  try {
    const res = await fetch('/api/prices/import', { method: 'POST', body: formData });
    const data = await res.json().catch(() => ({}));
    if (res.status === 401 && data.login_required) {
      window.location.href = '/login';
      return;
    }
    if (!res.ok) throw data;
    renderImportResult(data);
    showToast('Lista de precios importada correctamente');
    form.reset();
    document.getElementById('priceFileLabel').textContent = 'Elegir archivo .xls';
  } catch (err) {
    renderImportError(err.error || 'Ocurrió un error al importar', err.details || []);
    showToast(err.error || 'No se pudo importar', true);
  } finally {
    button.disabled = false;
    button.textContent = 'Importar y actualizar precios';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  markAdminBypassUI();
  const passInput = document.getElementById('priceImportPassword');
  if (currentUserIsAdmin() && passInput) {
    passInput.required = false;
    passInput.placeholder = 'No requerida para administrador';
  }
  document.getElementById('priceImportForm').addEventListener('submit', importPrices);
  document.getElementById('priceFile').addEventListener('change', event => {
    const file = event.target.files && event.target.files[0];
    document.getElementById('priceFileLabel').textContent = file ? file.name : 'Elegir archivo .xls';
  });
});
