function todayISO(){return new Date().toISOString().slice(0,10)}
function monthStartISO(){const d=new Date();d.setDate(1);return d.toISOString().slice(0,10)}
function reportItem(title, subtitle){return `<div class="advanced-item"><strong>${escapeHTML(title)}</strong><span>${escapeHTML(subtitle)}</span></div>`}
async function loadReports(){
  const from=reportFrom.value||monthStartISO();
  const to=reportTo.value||todayISO();
  reportFrom.value=from; reportTo.value=to;
  const data=await api(`/api/reports?from=${from}&to=${to}`);
  reportTotal.textContent=formatMoney(data.summary.total_sales);
  reportCount.textContent=data.summary.sales_count;
  reportProfit.textContent=formatMoney(data.summary.estimated_profit);
  reportDebt.textContent=formatMoney(data.summary.clients_debt);
  if (window.reportAvgTicket) reportAvgTicket.textContent=formatMoney(data.summary.avg_ticket);
  if (window.reportStockValue) reportStockValue.textContent=data.stock_control_enabled ? formatMoney(data.summary.stock_sale_value) : 'Desactivado';
  reportPayments.innerHTML=data.by_payment.length?data.by_payment.map(p=>reportItem(p.payment_method,`${p.count} ventas · ${formatMoney(p.total)}`)).join(''):'<div class="empty-state">Sin datos</div>';
  reportTop.innerHTML=data.top_products.length?data.top_products.map(p=>reportItem(p.name,`${p.qty} u. · ${formatMoney(p.total)}`)).join(''):'<div class="empty-state">Sin datos</div>';
  if (window.reportLeast) reportLeast.innerHTML=data.least_products?.length?data.least_products.map(p=>reportItem(p.name,`${p.qty} u. · ${formatMoney(p.total)}`)).join(''):'<div class="empty-state">Sin datos</div>';
  if (window.reportLowStock) reportLowStock.innerHTML=!data.stock_control_enabled?'<div class="empty-state">Control de stock desactivado</div>':(data.low_products?.length?data.low_products.map(p=>reportItem(p.name,`Stock ${p.stock} · mínimo ${p.min_stock}`)).join(''):'<div class="empty-state">Sin stock bajo</div>');
  if (window.reportDebtors) reportDebtors.innerHTML=data.debtors?.length?data.debtors.map(c=>reportItem(c.name,`${c.phone||'Sin teléfono'} · saldo ${formatMoney(c.balance)}`)).join(''):'<div class="empty-state">Sin deuda</div>';
  if (window.reportRecentSales) reportRecentSales.innerHTML=data.recent_sales?.length?data.recent_sales.map(s=>reportItem(`${s.ticket_number} · ${formatMoney(s.total)}`,`${s.created_at_formatted} · ${s.payment_method}${s.client_name?' · '+s.client_name:''}`)).join(''):'<div class="empty-state">Sin ventas</div>';
}
function exportReports(){ const from=reportFrom.value||monthStartISO(); const to=reportTo.value||todayISO(); window.location.href=`/api/reports/export?from=${from}&to=${to}`; }
function exportReportsPdf(){ const from=reportFrom.value||monthStartISO(); const to=reportTo.value||todayISO(); window.location.href=`/api/reports/export-pdf?from=${from}&to=${to}`; }
document.addEventListener('DOMContentLoaded',loadReports);

// ===================== Etiquetas de productos =====================
let labelItems = [];
let labelSearchTimer = null;
let labelSearchController = null;
let labelSearchRequestVersion = 0;
let labelLastResults = [];
let labelSearchOpen = false;
let labelActiveIndex = -1;
let labelsScanner = null;

const LABEL_FONT_CONFIG = {
  Helvetica: { css: 'Arial, Helvetica, sans-serif', label: 'Helvetica / Arial' },
  Times: { css: 'Georgia, "Times New Roman", serif', label: 'Times / Serif' },
  Courier: { css: '"Courier New", Courier, monospace', label: 'Courier / Monoespaciada' },
};

const LABEL_A4_MM = {
  width: 210,
  height: 297,
  margin: 8,
  gap: 2,
  innerPadding: 3,
};

function labelElement(id) {
  return document.getElementById(id);
}

function labelEscape(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function labelNumberValue(id, fallback, min, max) {
  const input = labelElement(id);
  const value = Number(input?.value || fallback);
  const clean = Number.isFinite(value) ? value : fallback;
  return Math.max(min, Math.min(max, clean));
}

function labelCopiesValue() {
  return Math.floor(labelNumberValue('labelCopiesInput', 1, 1, 999));
}

function labelsPerSheetValue() {
  return Math.floor(labelNumberValue('labelsPerSheet', 24, 1, 80));
}

function labelNameFontSizeValue() {
  return labelNumberValue('labelNameFontSize', 10, 6, 28);
}

function labelPriceFontSizeValue() {
  return labelNumberValue('labelPriceFontSize', 18, 8, 42);
}

function labelFontFamilyValue() {
  const selected = labelElement('labelFontFamily')?.value || 'Helvetica';
  return LABEL_FONT_CONFIG[selected] ? selected : 'Helvetica';
}

function labelShowGuidesValue() {
  return labelElement('labelShowGuides')?.value !== '0';
}

function bestLabelGridPreview(labelsPerSheet) {
  const total = Math.max(1, Math.min(80, Math.floor(Number(labelsPerSheet || 24))));
  const targetRatio = 1.65;
  let best = null;
  for (let rows = 1; rows <= total; rows += 1) {
    const cols = Math.ceil(total / rows);
    const capacity = rows * cols;
    if (capacity < total || capacity > total + Math.max(4, Math.floor(total / 5))) continue;
    const usableW = LABEL_A4_MM.width - (LABEL_A4_MM.margin * 2);
    const usableH = LABEL_A4_MM.height - (LABEL_A4_MM.margin * 2);
    const labelW = usableW / cols;
    const labelH = usableH / rows;
    const ratio = labelW / labelH;
    const exactPenalty = capacity === total ? 0 : 2 + ((capacity - total) * 0.2);
    const skinnyPenalty = ratio >= 0.72 && ratio <= 3.2 ? 0 : 1.5;
    const score = Math.abs(ratio - targetRatio) + exactPenalty + skinnyPenalty;
    const candidate = { score, cols, rows, capacity };
    if (!best || candidate.score < best.score || (candidate.score === best.score && candidate.capacity < best.capacity)) {
      best = candidate;
    }
  }
  return best || { cols: 3, rows: 8, capacity: 24 };
}

function labelPreviewLayout(labelsPerSheet) {
  const grid = bestLabelGridPreview(labelsPerSheet);
  const printableCells = Math.max(1, Math.min(labelsPerSheet, grid.capacity));
  const labelW = (LABEL_A4_MM.width - (2 * LABEL_A4_MM.margin) - (LABEL_A4_MM.gap * (grid.cols - 1))) / grid.cols;
  const labelH = (LABEL_A4_MM.height - (2 * LABEL_A4_MM.margin) - (LABEL_A4_MM.gap * (grid.rows - 1))) / grid.rows;
  return { ...grid, printableCells, labelW, labelH };
}

function labelPtToPreviewPx(points, previewWidth) {
  const mmScale = (previewWidth || 420) / LABEL_A4_MM.width;
  return Math.max(4, points * (25.4 / 72) * mmScale);
}

function labelMmToPreviewPx(mm, previewWidth) {
  const mmScale = (previewWidth || 420) / LABEL_A4_MM.width;
  return mm * mmScale;
}

function sampleLabelItemsForPreview(printableCells) {
  const expanded = [];
  labelItems.forEach(item => {
    const qty = Math.max(1, Math.min(999, Math.floor(Number(item.quantity || 1))));
    for (let i = 0; i < qty && expanded.length < printableCells; i += 1) expanded.push(item);
  });
  if (!expanded.length) {
    expanded.push({ name: 'NOMBRE PRODUCTO', sale_price: 1234.56, barcode: '7790000000000' });
    expanded.push({ name: 'OTRO PRODUCTO', sale_price: 2500, barcode: '7790000000001' });
  }
  while (expanded.length < printableCells) expanded.push(null);
  return expanded.slice(0, printableCells);
}

function updateLabelA4Preview() {
  const preview = labelElement('labelA4Preview');
  if (!preview) return;

  const labelsPerSheet = labelsPerSheetValue();
  const layout = labelPreviewLayout(labelsPerSheet);
  const fontKey = labelFontFamilyValue();
  const fontCss = LABEL_FONT_CONFIG[fontKey].css;
  const showGuides = labelShowGuidesValue();
  const items = sampleLabelItemsForPreview(layout.printableCells);
  const previewWidth = preview.clientWidth || 420;

  const maxNamePt = Math.max(6.5, Math.min(28, layout.labelH * 0.28));
  const maxPricePt = Math.max(8, Math.min(42, layout.labelH * 0.48));
  const namePt = Math.min(labelNameFontSizeValue(), maxNamePt);
  const pricePt = Math.min(labelPriceFontSizeValue(), maxPricePt);
  const codePt = Math.max(5.2, Math.min(7.4, layout.labelH * 0.11));

  preview.style.gridTemplateColumns = `repeat(${layout.cols}, 1fr)`;
  preview.style.gridTemplateRows = `repeat(${layout.rows}, 1fr)`;
  preview.style.padding = `${labelMmToPreviewPx(LABEL_A4_MM.margin, previewWidth)}px`;
  preview.style.gap = `${labelMmToPreviewPx(LABEL_A4_MM.gap, previewWidth)}px`;
  preview.style.setProperty('--label-preview-inner-pad', `${labelMmToPreviewPx(LABEL_A4_MM.innerPadding, previewWidth)}px`);
  preview.style.setProperty('--label-preview-radius', `${labelMmToPreviewPx(2, previewWidth)}px`);
  preview.style.setProperty('--label-preview-name-size', `${labelPtToPreviewPx(namePt, previewWidth)}px`);
  preview.style.setProperty('--label-preview-price-size', `${labelPtToPreviewPx(pricePt, previewWidth)}px`);
  preview.style.setProperty('--label-preview-code-size', `${labelPtToPreviewPx(codePt, previewWidth)}px`);
  preview.style.setProperty('--label-preview-price-gap', `${labelMmToPreviewPx(1.2, previewWidth)}px`);
  preview.classList.toggle('no-guides', !showGuides);

  preview.innerHTML = Array.from({ length: layout.capacity }, (_, index) => {
    const printable = index < layout.printableCells;
    const item = printable ? items[index] : null;
    const extraClass = printable ? '' : ' unused';
    if (!item) return `<div class="label-preview-cell empty${extraClass}" title="Celda vacía"></div>`;
    return `
      <div class="label-preview-cell" style="font-family:${fontCss}" title="${layout.labelW.toFixed(1)} x ${layout.labelH.toFixed(1)} mm">
        <strong>${labelEscape(String(item.name || '').toUpperCase())}</strong>
        <b>${formatMoney(item.sale_price)}</b>
        <span>${labelEscape(item.barcode || 'Sin código')}</span>
      </div>
    `;
  }).join('');
}

function updateLabelSheetInfo() {
  const n = labelsPerSheetValue();
  const layout = labelPreviewLayout(n);
  const info = labelElement('labelSheetInfo');
  if (info) {
    info.textContent = `${n} etiqueta${n === 1 ? '' : 's'} por hoja A4 · ${layout.cols} columnas x ${layout.rows} filas · cada etiqueta ${layout.labelW.toFixed(1)} x ${layout.labelH.toFixed(1)} mm`;
  }
  updateLabelA4Preview();
}

function renderLabelItems() {
  const list = labelElement('labelSelectedList');
  const totalEl = labelElement('labelsTotalCount');
  if (!list) return;
  const total = labelItems.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
  if (totalEl) totalEl.textContent = String(total);

  if (!labelItems.length) {
    list.innerHTML = '<div class="empty-state">Todavía no agregaste productos para imprimir.</div>';
    updateLabelA4Preview();
    return;
  }

  list.innerHTML = labelItems.map((item, index) => `
    <div class="label-selected-item">
      <div>
        <strong title="${labelEscape(item.name)}">${labelEscape(item.name)}</strong>
        <span>${labelEscape(item.barcode || 'Sin código')} · ${formatMoney(item.sale_price)}</span>
      </div>
      <label>Cant.
        <input type="number" min="1" max="999" step="1" value="${item.quantity}" onchange="updateLabelItemQty(${index}, this.value)">
      </label>
      <button class="small-button danger" type="button" onclick="removeLabelItem(${index})">Quitar</button>
    </div>
  `).join('');
  updateLabelA4Preview();
}

function addProductToLabels(product) {
  const qty = labelCopiesValue();
  const existing = labelItems.find(item => Number(item.product_id) === Number(product.id));
  if (existing) {
    existing.quantity = Math.max(1, Math.min(999, Number(existing.quantity || 0) + qty));
  } else {
    labelItems.push({
      product_id: product.id,
      barcode: product.barcode || '',
      name: product.name,
      sale_price: Number(product.sale_price || 0),
      quantity: qty,
    });
  }
  renderLabelItems();
  showToast('Producto agregado a etiquetas');
}

function updateLabelItemQty(index, value) {
  if (!labelItems[index]) return;
  const qty = Math.max(1, Math.min(999, Math.floor(Number(value || 1))));
  labelItems[index].quantity = Number.isFinite(qty) ? qty : 1;
  renderLabelItems();
}

function removeLabelItem(index) {
  labelItems.splice(index, 1);
  renderLabelItems();
}

function clearLabelItems() {
  labelItems = [];
  renderLabelItems();
}

function labelSearchContainer() {
  return labelElement('labelSearchResults');
}

function setLabelSearchOpen(open, focusIndex = null) {
  const container = labelSearchContainer();
  if (!container) return;
  labelSearchOpen = Boolean(open);
  container.classList.toggle('is-open', labelSearchOpen);
  container.classList.toggle('is-collapsed', !labelSearchOpen);
  container.setAttribute('aria-expanded', labelSearchOpen ? 'true' : 'false');
  if (!labelSearchOpen) {
    labelActiveIndex = -1;
    updateLabelSearchActiveOption();
    return;
  }
  if (focusIndex !== null) {
    focusLabelSearchOption(focusIndex);
  }
}

function updateLabelSearchActiveOption() {
  const container = labelSearchContainer();
  if (!container) return;
  container.querySelectorAll('.label-search-option').forEach((button, index) => {
    const active = index === labelActiveIndex;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-selected', active ? 'true' : 'false');
  });
}

function focusLabelSearchOption(index) {
  if (!labelLastResults.length) return;
  const safeIndex = Math.max(0, Math.min(labelLastResults.length - 1, index));
  const container = labelSearchContainer();
  labelActiveIndex = safeIndex;
  updateLabelSearchActiveOption();
  const button = container?.querySelector(`.label-search-option[data-label-index="${safeIndex}"]`);
  if (button) {
    button.focus();
    button.scrollIntoView({ block: 'nearest' });
  }
}

function selectLabelSearchProduct(index) {
  const product = labelLastResults[index];
  if (!product) return;
  addProductToLabels(product);
  const input = labelElement('labelProductSearch');
  if (input) {
    input.focus();
    input.select();
  }
  setLabelSearchOpen(true);
}

function moveLabelSearchFocus(delta) {
  if (!labelLastResults.length) return;
  const nextIndex = labelActiveIndex < 0
    ? (delta > 0 ? 0 : labelLastResults.length - 1)
    : (labelActiveIndex + delta + labelLastResults.length) % labelLastResults.length;
  focusLabelSearchOption(nextIndex);
}

function renderLabelSearchResults(products, openResults = labelSearchOpen) {
  const container = labelSearchContainer();
  if (!container) return;
  labelLastResults = products || [];
  window.labelLastResults = labelLastResults;
  labelActiveIndex = -1;
  container.setAttribute('role', 'listbox');
  container.setAttribute('aria-label', 'Productos encontrados para etiquetas');

  if (!labelLastResults.length) {
    container.innerHTML = '<div class="empty-state">No hay productos para mostrar. Escribí un nombre o código y presioná Enter.</div>';
    setLabelSearchOpen(openResults);
    return;
  }

  container.innerHTML = labelLastResults.map((p, index) => `
    <button class="label-search-option" type="button" role="option" aria-selected="false" data-label-index="${index}">
      <span><strong>${labelEscape(p.name)}</strong><small>${labelEscape(p.barcode || 'Sin código')} · Stock ${labelEscape(p.stock)}</small></span>
      <b>${formatMoney(p.sale_price)}</b>
    </button>
  `).join('');

  container.querySelectorAll('.label-search-option').forEach(button => {
    button.addEventListener('click', () => selectLabelSearchProduct(Number(button.dataset.labelIndex)));
    button.addEventListener('focus', () => {
      labelActiveIndex = Number(button.dataset.labelIndex);
      updateLabelSearchActiveOption();
    });
    button.addEventListener('keydown', event => {
      if (event.key === 'ArrowDown') {
        event.preventDefault();
        moveLabelSearchFocus(1);
      } else if (event.key === 'ArrowUp') {
        event.preventDefault();
        moveLabelSearchFocus(-1);
      } else if (event.key === 'Enter') {
        event.preventDefault();
        selectLabelSearchProduct(Number(button.dataset.labelIndex));
      } else if (event.key === 'Escape') {
        event.preventDefault();
        setLabelSearchOpen(false);
        labelElement('labelProductSearch')?.focus();
      }
    });
  });

  setLabelSearchOpen(openResults);
}

async function searchProductsForLabels(options = {}) {
  const input = labelElement('labelProductSearch');
  const q = (input?.value || '').trim();
  const { open = true, focusFirst = false } = options;
  if (labelSearchController) labelSearchController.abort();
  const requestVersion = ++labelSearchRequestVersion;
  if (!q) {
    renderLabelSearchResults([], false);
    return [];
  }
  const controller = new AbortController();
  labelSearchController = controller;
  try {
    const products = await api(`/api/product-lookup?q=${encodeURIComponent(q)}`, { signal: controller.signal });
    if (requestVersion !== labelSearchRequestVersion || (input && input.value.trim() !== q)) return [];
    renderLabelSearchResults(products, open);
    if (focusFirst && products.length) focusLabelSearchOption(0);
    return products;
  } catch (err) {
    if (err.name !== 'AbortError' && requestVersion === labelSearchRequestVersion) showToast(err.message, true);
    return [];
  } finally {
    if (labelSearchController === controller) labelSearchController = null;
  }
}


async function addProductToLabelsByBarcode(code) {
  const raw = String(code || '').trim();
  if (!raw) return;
  try {
    const products = await api(`/api/product-lookup?q=${encodeURIComponent(raw)}`);
    const exact = (products || []).find(p => String(p.barcode || '').trim() === raw) || (products || [])[0];
    if (!exact) {
      showToast(`No encontré producto con código ${raw}.`, true);
      const input = labelElement('labelProductSearch');
      if (input) {
        input.value = raw;
        input.focus();
        input.select();
      }
      return;
    }
    addProductToLabels(exact);
    showToast(`Etiqueta agregada: ${exact.name}`);
  } catch (err) {
    showToast(err.message || 'No se pudo buscar el producto escaneado.', true);
  }
}

function labelsTabVisible() {
  const tab = document.getElementById('reportsLabelsTab');
  return tab && !tab.classList.contains('hidden');
}

function openLabelsScanner() {
  if (!labelsScanner && window.POSBarcodeScanner) {
    labelsScanner = new POSBarcodeScanner({
      contextLabel: 'etiqueta',
      onDetected: async code => {
        await addProductToLabelsByBarcode(code);
      },
    });
  }
  if (!labelsScanner) {
    showToast('El lector por cámara no está disponible. Podés escribir el código manualmente.', true);
    return;
  }
  labelsScanner.openAndStart();
}

async function openLabelsPdf(openForPrint = false) {
  if (!labelItems.length) {
    showToast('Agregá al menos un producto para imprimir etiquetas.', true);
    return;
  }
  const payload = {
    labels_per_sheet: labelsPerSheetValue(),
    show_guides: labelShowGuidesValue(),
    font_family: labelFontFamilyValue(),
    name_font_size: labelNameFontSizeValue(),
    price_font_size: labelPriceFontSizeValue(),
    items: labelItems.map(item => ({ product_id: item.product_id, quantity: item.quantity })),
  };

  try {
    if (openForPrint) {
      // En escritorio imprimimos desde Python/Windows. Evita window.open(blob),
      // que puede fallar o intentar abrir un navegador externo desde WebView2.
      const result = await api('/api/product-labels/pdf-file', {
        method: 'POST',
        body: JSON.stringify({ ...payload, print: true }),
      });
      if (result.printed) {
        showToast(`Etiquetas guardadas e impresión enviada: ${result.filename}`);
      } else {
        showToast(result.print_message || `PDF guardado: ${result.filename}`, true);
      }
      return;
    }

    const res = await fetch('/api/product-labels/pdf', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || 'No se pudo generar el PDF de etiquetas');
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const filename = `etiquetas_productos_${new Date().toISOString().slice(0,10)}.pdf`;
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    showToast('PDF de etiquetas generado.');
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (err) {
    showToast(err.message, true);
  }
}

function initProductLabelsTab() {
  const searchInput = labelElement('labelProductSearch');
  if (!searchInput) return;
  renderLabelItems();
  renderLabelSearchResults([], false);
  updateLabelSheetInfo();
  searchInput.setAttribute('aria-controls', 'labelSearchResults');
  searchInput.setAttribute('aria-haspopup', 'listbox');
  searchInput.addEventListener('input', () => {
    clearTimeout(labelSearchTimer);
    if (labelSearchController) labelSearchController.abort();
    labelSearchController = null;
    labelSearchRequestVersion += 1;
    labelSearchTimer = setTimeout(() => searchProductsForLabels({ open: true, focusFirst: false }), 220);
  });
  searchInput.addEventListener('keydown', async (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      clearTimeout(labelSearchTimer);
      await searchProductsForLabels({ open: true, focusFirst: true });
    } else if (event.key === 'ArrowDown') {
      event.preventDefault();
      if (!labelLastResults.length) {
        await searchProductsForLabels({ open: true, focusFirst: true });
      } else {
        setLabelSearchOpen(true);
        focusLabelSearchOption(labelActiveIndex >= 0 ? labelActiveIndex : 0);
      }
    } else if (event.key === 'Escape') {
      setLabelSearchOpen(false);
    }
  });
  document.addEventListener('click', event => {
    const container = labelSearchContainer();
    if (!container || !searchInput) return;
    if (!container.contains(event.target) && event.target !== searchInput) {
      setLabelSearchOpen(false);
    }
  });
  labelElement('openLabelsBarcodeScannerBtn')?.addEventListener('click', openLabelsScanner);
  document.addEventListener('keydown', event => {
    if ((event.key === 'Insert' || event.code === 'Insert') && labelsTabVisible()) {
      const scannerModal = document.getElementById('barcodeScannerModal');
      if (scannerModal && !scannerModal.classList.contains('hidden')) return;
      event.preventDefault();
      openLabelsScanner();
    }
  });
  ['labelsPerSheet', 'labelShowGuides', 'labelFontFamily', 'labelNameFontSize', 'labelPriceFontSize'].forEach(id => {
    labelElement(id)?.addEventListener('input', updateLabelSheetInfo);
    labelElement(id)?.addEventListener('change', updateLabelSheetInfo);
  });
  const preview = labelElement('labelA4Preview');
  if (preview && 'ResizeObserver' in window) {
    new ResizeObserver(() => updateLabelA4Preview()).observe(preview);
  }
}

window.openLabelsScanner = openLabelsScanner;
window.updateLabelA4Preview = updateLabelA4Preview;
document.addEventListener('DOMContentLoaded', initProductLabelsTab);
