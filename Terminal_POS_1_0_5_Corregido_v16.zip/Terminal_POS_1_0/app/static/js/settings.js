function byId(id) {
  return document.getElementById(id);
}

function setValue(id, value) {
  const el = byId(id);
  if (el) el.value = value ?? '';
}

function setChecked(id, value) {
  const el = byId(id);
  if (el) el.checked = !!value;
}

function setSettingsStatus(message, isError = false) {
  const status = byId('settingsStatus');
  if (!status) return;
  status.textContent = message || '';
  status.classList.toggle('error', !!isError);
  status.classList.toggle('ok', !!message && !isError);
}

function renderLogoPreview(settings) {
  const preview = byId('logoPreview');
  if (!preview) return;
  if (settings && settings.logo_url) {
    preview.innerHTML = `<img src="${escapeHTML(settings.logo_url)}?v=${Date.now()}" alt="Logo actual">`;
  } else {
    preview.innerHTML = '<span>Sin logo</span>';
  }
}

function updateSidebarBrand(settings) {
  if (!settings) return;
  const brand = document.querySelector('.brand');
  if (!brand) return;

  const nameEl = brand.querySelector('strong');
  const subEl = brand.querySelector('span');
  if (nameEl) nameEl.textContent = settings.business_name || 'POS Local';
  if (subEl) subEl.textContent = settings.business_address || 'Terminal punto de venta';

  const currentImg = brand.querySelector('.brand-logo-img');
  const currentDot = brand.querySelector('.brand-dot');
  const logoUrl = settings.logo_url || '';

  if (logoUrl) {
    if (currentImg) {
      currentImg.src = `${logoUrl}?v=${Date.now()}`;
    } else {
      const img = document.createElement('img');
      img.className = 'brand-logo-img';
      img.alt = 'Logo del negocio';
      img.src = `${logoUrl}?v=${Date.now()}`;
      if (currentDot) currentDot.replaceWith(img);
      else brand.prepend(img);
    }
  } else if (currentImg) {
    const dot = document.createElement('div');
    dot.className = 'brand-dot';
    currentImg.replaceWith(dot);
  }
}

async function loadSettings() {
  try {
    setSettingsStatus('Cargando configuración...');
    const data = await api(`/api/settings?ts=${Date.now()}`, { cache: 'no-store' });
    setValue('businessName', data.business_name || 'POS Local');
    setValue('businessCuit', data.business_cuit);
    setValue('businessAddress', data.business_address);
    setValue('businessPhone', data.business_phone);
    setValue('businessEmail', data.business_email);
    setValue('ticketFooter', data.ticket_footer);
    setValue('productRoundingMode', data.product_rounding_mode || 'none');
    setValue('productRoundingMultiple', data.product_rounding_multiple || '1');
    setValue('stockControlEnabled', data.stock_control_enabled ?? '1');
    setChecked('removeLogo', false);
    renderLogoPreview(data);
    setSettingsStatus('');
  } catch (err) {
    setSettingsStatus(err.message, true);
    showToast(err.message, true);
  }
}

function previewSelectedLogo(file) {
  if (!file) return;
  const maxSize = 50 * 1024 * 1024;
  if (file.size > maxSize) {
    const logoInput = byId('logoInput');
    if (logoInput) logoInput.value = '';
    throw new Error('El logo es demasiado pesado. El máximo permitido es 50 MB.');
  }
  const reader = new FileReader();
  reader.onload = event => {
    const preview = byId('logoPreview');
    if (preview) preview.innerHTML = `<img src="${event.target.result}" alt="Logo seleccionado">`;
  };
  reader.readAsDataURL(file);
}

function validateSettingsForm() {
  const name = (byId('businessName')?.value || '').trim();
  if (!name) {
    byId('businessName')?.focus();
    throw new Error('Ingresá el nombre del negocio.');
  }
}

async function saveSettings(event) {
  event.preventDefault();
  byId('createBackupBtn')?.addEventListener('click', createBackupNow);
  byId('refreshBackupBtn')?.addEventListener('click', loadBackups);
  const form = byId('settingsForm');
  const saveButton = byId('saveSettingsButton');
  if (!form) return;

  try {
    validateSettingsForm();
    const formData = new FormData(form);
    if (saveButton) {
      saveButton.disabled = true;
      saveButton.dataset.originalText = saveButton.textContent;
      saveButton.textContent = 'Guardando...';
    }
    setSettingsStatus('Guardando configuración...');

    const response = await fetch('/api/settings', {
      method: 'POST',
      body: formData,
      cache: 'no-store',
      credentials: 'same-origin'
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.ok) throw new Error(data.error || 'No se pudo guardar la configuración');

    showToast('Configuración guardada correctamente');
    setSettingsStatus('Configuración guardada correctamente');
    const logoInput = byId('logoInput');
    if (logoInput) logoInput.value = '';
    setChecked('removeLogo', false);
    window.POS_SETTINGS = data.settings || window.POS_SETTINGS || {};
    renderLogoPreview(data.settings || {});
    updateSidebarBrand(data.settings || {});
  } catch (err) {
    setSettingsStatus(err.message, true);
    showToast(err.message, true);
  } finally {
    if (saveButton) {
      saveButton.disabled = false;
      saveButton.textContent = saveButton.dataset.originalText || 'Guardar configuración';
    }
  }
}


async function loadBackups() {
  const list = byId('backupList');
  if (!list) return;
  try {
    const rows = await api('/api/backup/list');
    list.innerHTML = rows.length ? rows.map(row => `
      <div class="advanced-item backup-item">
        <strong>${escapeHTML(row.filename)}</strong>
        <span>${escapeHTML(row.created_at_formatted)} · ${(Number(row.size_bytes)/1024).toFixed(1)} KB</span>
        <a class="tiny-button" href="/api/backup/download/${encodeURIComponent(row.filename)}">Descargar</a>
      </div>
    `).join('') : '<div class="empty-state">Todavía no hay backups creados.</div>';
  } catch (err) {
    list.innerHTML = `<div class="empty-state error-text">${escapeHTML(err.message)}</div>`;
  }
}

async function createBackupNow() {
  const btn = byId('createBackupBtn');
  try {
    if (btn) { btn.disabled = true; btn.dataset.originalText = btn.textContent; btn.textContent = 'Creando...'; }
    const payload = { password: securityPasswordOrEmpty('backupPassword') };
    const data = await api('/api/backup/create', { method: 'POST', body: JSON.stringify(payload) });
    showToast(`Backup creado: ${data.filename}`);
    await loadBackups();
  } catch (err) {
    showToast(err.message, true);
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = btn.dataset.originalText || 'Crear backup ahora'; }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  markAdminBypassUI();
  loadSettings();
  loadBackups();
  byId('createBackupBtn')?.addEventListener('click', createBackupNow);
  byId('refreshBackupBtn')?.addEventListener('click', loadBackups);
  const form = byId('settingsForm');
  if (form) form.addEventListener('submit', saveSettings);

  const logoInput = byId('logoInput');
  if (logoInput) {
    logoInput.addEventListener('change', event => {
      const file = event.target.files && event.target.files[0];
      if (file) {
        try {
          setChecked('removeLogo', false);
          previewSelectedLogo(file);
        } catch (err) {
          setSettingsStatus(err.message, true);
          showToast(err.message, true);
        }
      }
    });
  }

  const removeLogo = byId('removeLogo');
  if (removeLogo) {
    removeLogo.addEventListener('change', event => {
      if (event.target.checked) {
        const logoInput = byId('logoInput');
        if (logoInput) logoInput.value = '';
        const preview = byId('logoPreview');
        if (preview) preview.innerHTML = '<span>Logo marcado para quitar</span>';
      } else {
        renderLogoPreview(window.POS_SETTINGS || {});
      }
    });
  }
});

function activateConfigTab(tabName, updateHash = true) {
  const selected = tabName || 'business';
  document.querySelectorAll('[data-config-tab]').forEach(btn => {
    const isActive = btn.dataset.configTab === selected;
    btn.classList.toggle('active', isActive);
    btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
  });
  document.querySelectorAll('[data-config-panel]').forEach(panel => {
    const isActive = panel.dataset.configPanel === selected;
    panel.classList.toggle('active', isActive);
    panel.hidden = !isActive;
  });
  if (updateHash) {
    const hashMap = { business: 'negocio', ticket: 'ticket', users: 'usuarios' };
    history.replaceState(null, '', `#${hashMap[selected] || 'negocio'}`);
  }
}

function initConfigTabs() {
  document.querySelectorAll('[data-config-tab]').forEach(btn => {
    btn.addEventListener('click', () => activateConfigTab(btn.dataset.configTab));
  });

  const hash = (window.location.hash || '').replace('#', '').toLowerCase();
  const initial = hash === 'ticket' ? 'ticket' : (hash === 'usuarios' || hash === 'users') ? 'users' : 'business';
  activateConfigTab(initial, false);
}

document.addEventListener('DOMContentLoaded', initConfigTabs);
