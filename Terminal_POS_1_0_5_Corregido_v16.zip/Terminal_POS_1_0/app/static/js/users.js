let loadedUsers = [];
let editingUserId = null;

function userBadge(role) {
  const cls = role === 'Administrador' ? 'admin' : role === 'Supervisor' ? 'supervisor' : 'cashier';
  return `<span class="role-badge ${cls}">${escapeHTML(role)}</span>`;
}

function renderUsers() {
  const tbody = document.getElementById('usersTableBody');
  const count = document.getElementById('usersCount');
  count.textContent = `${loadedUsers.length} usuario${loadedUsers.length === 1 ? '' : 's'}`;

  if (!loadedUsers.length) {
    tbody.innerHTML = '<tr><td colspan="5" class="muted-cell">No hay usuarios cargados</td></tr>';
    return;
  }

  tbody.innerHTML = loadedUsers.map(user => `
    <tr class="${user.is_active ? '' : 'disabled-row'}">
      <td><strong>${escapeHTML(user.username)}</strong></td>
      <td>${escapeHTML(user.full_name || '-')}</td>
      <td>${userBadge(user.role)}</td>
      <td>${user.is_active ? '<span class="status-pill ok">Activo</span>' : '<span class="status-pill off">Inactivo</span>'}</td>
      <td class="table-actions compact-actions">
        <button class="tiny-button" type="button" onclick="editUser(${user.id})">Editar</button>
        <button class="tiny-button danger" type="button" onclick="deleteUser(${user.id})">Eliminar</button>
      </td>
    </tr>
  `).join('');
}

function resetUserForm() {
  editingUserId = null;
  document.getElementById('userFormTitle').textContent = 'Nuevo usuario';
  document.getElementById('userId').value = '';
  document.getElementById('username').value = '';
  document.getElementById('fullName').value = '';
  document.getElementById('userRole').value = 'Cajero';
  document.getElementById('userPassword').value = '';
  document.getElementById('userPassword').placeholder = 'Obligatoria al crear';
  document.getElementById('userActive').checked = true;
  document.getElementById('userSecurityPassword').value = '';
  if (currentUserIsAdmin()) document.getElementById('userSecurityPassword').placeholder = 'No requerida para administrador';
  document.getElementById('username').focus();
}

function editUser(id) {
  const user = loadedUsers.find(item => item.id === id);
  if (!user) return;
  editingUserId = id;
  document.getElementById('userFormTitle').textContent = `Editar usuario: ${user.username}`;
  document.getElementById('userId').value = user.id;
  document.getElementById('username').value = user.username;
  document.getElementById('fullName').value = user.full_name || '';
  document.getElementById('userRole').value = user.role || 'Cajero';
  document.getElementById('userPassword').value = '';
  document.getElementById('userPassword').placeholder = 'Dejar vacío para no cambiar';
  document.getElementById('userActive').checked = Boolean(user.is_active);
  document.getElementById('userSecurityPassword').value = '';
  if (currentUserIsAdmin()) {
    document.getElementById('username').focus();
  } else {
    document.getElementById('userSecurityPassword').focus();
  }
}

async function deleteUser(id) {
  const user = loadedUsers.find(item => item.id === id);
  if (!user) return;
  let securityPassword = '';
  if (!currentUserIsAdmin()) {
    securityPassword = prompt(`Ingresá la clave de seguridad para eliminar el usuario ${user.username}`);
    if (securityPassword === null) return;
  }

  try {
    await api(`/api/users/${id}`, {
      method: 'DELETE',
      body: JSON.stringify({ security_password: securityPassword })
    });
    showToast('Usuario eliminado');
    if (editingUserId === id) resetUserForm();
    await loadUsers();
  } catch (err) {
    showToast(err.message, true);
  }
}

function getUserPayload() {
  return {
    username: document.getElementById('username').value.trim(),
    full_name: document.getElementById('fullName').value.trim(),
    role: document.getElementById('userRole').value,
    user_password: document.getElementById('userPassword').value,
    is_active: document.getElementById('userActive').checked,
    security_password: document.getElementById('userSecurityPassword').value,
  };
}

function saveUser(event) {
  event.preventDefault();
  return withOperationLock('user-save', '#userForm button[type="submit"]', () => saveUserOnce(event));
}

async function saveUserOnce(event) {
  event.preventDefault();
  const payload = getUserPayload();
  if (!payload.security_password && !currentUserIsAdmin()) {
    showToast('Ingresá la clave de seguridad para guardar', true);
    document.getElementById('userSecurityPassword').focus();
    return;
  }

  try {
    const url = editingUserId ? `/api/users/${editingUserId}` : '/api/users';
    const method = editingUserId ? 'PUT' : 'POST';
    await postOperation(url, payload, {method, persist:false, allowRecord:true});
    showToast(editingUserId ? 'Usuario actualizado' : 'Usuario creado');
    resetUserForm();
    await loadUsers();
  } catch (err) {
    showToast(err.message, true);
  }
}

async function loadUsers() {
  try {
    loadedUsers = await api('/api/users');
    renderUsers();
  } catch (err) {
    showToast(err.message, true);
  }
}

async function loadSystemKeys() {
  try {
    const keys = await api('/api/system-keys');
    document.getElementById('defaultCashierName').value = keys.default_cashier_name || 'admin';
    document.getElementById('baseLoginUsername').value = keys.login_username || 'admin';
    document.getElementById('systemSecurityPassword').value = '';
    document.getElementById('newAccessPassword').value = '';
    document.getElementById('newSecurityPassword').value = '';
  } catch (err) {
    showToast(err.message, true);
  }
}

async function saveSystemKeys(event) {
  event.preventDefault();
  const payload = {
    default_cashier_name: document.getElementById('defaultCashierName').value.trim(),
    login_username: document.getElementById('baseLoginUsername').value.trim(),
    security_password: document.getElementById('systemSecurityPassword').value,
    new_access_password: document.getElementById('newAccessPassword').value,
    new_security_password: document.getElementById('newSecurityPassword').value,
  };

  if (!payload.security_password && !currentUserIsAdmin()) {
    showToast('Ingresá la clave de seguridad actual', true);
    document.getElementById('systemSecurityPassword').focus();
    return;
  }

  try {
    const data = await api('/api/system-keys', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    showToast('Claves del sistema actualizadas');
    window.POS_SETTINGS = data.settings || window.POS_SETTINGS;
    await loadSystemKeys();
  } catch (err) {
    showToast(err.message, true);
  }
}

async function loadUsersModule() {
  await Promise.all([loadUsers(), loadSystemKeys()]);
}

document.addEventListener('DOMContentLoaded', () => {
  markAdminBypassUI();
  if (currentUserIsAdmin()) {
    const securityFields = ['userSecurityPassword', 'systemSecurityPassword'];
    securityFields.forEach(id => {
      const el = document.getElementById(id);
      if (el) { el.required = false; el.placeholder = 'No requerida para administrador'; }
    });
  }
  document.getElementById('userForm').addEventListener('submit', saveUser);
  document.getElementById('systemKeysForm').addEventListener('submit', saveSystemKeys);
  loadUsersModule();
});
