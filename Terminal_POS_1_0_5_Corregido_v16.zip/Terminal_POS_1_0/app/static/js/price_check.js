let priceProducts = [];
let priceIndex = 0;
let clearTimer = null;
let countdownTimer = null;
let liveSearchTimer = null;
let lastQuery = '';
let notFoundTimer = null;
let notFoundInterval = null;
let notFoundToken = 0;

function getPriceElements() {
  return {
    input: document.getElementById('priceSearch'),
    list: document.getElementById('priceSelectList'),
    result: document.getElementById('priceResult'),
    notFoundModal: document.getElementById('priceNotFoundModal'),
    notFoundCountdown: document.getElementById('priceNotFoundCountdown'),
    notFoundCode: document.getElementById('priceNotFoundCode'),
  };
}

function hidePriceList() {
  const { list } = getPriceElements();
  list.classList.add('hidden');
}

function hidePriceNotFound() {
  clearTimeout(notFoundTimer);
  clearInterval(notFoundInterval);
  notFoundTimer = null;
  notFoundInterval = null;
  const { notFoundModal } = getPriceElements();
  if (notFoundModal) notFoundModal.classList.add('hidden');
}

function showPriceNotFound(query, seconds = 3) {
  const { input, result, notFoundModal, notFoundCountdown, notFoundCode } = getPriceElements();
  hidePriceList();
  clearTimeout(clearTimer);
  clearInterval(countdownTimer);
  hidePriceNotFound();

  const token = ++notFoundToken;
  let remaining = seconds;

  result.classList.add('idle');
  result.innerHTML = `
    <span>Esperando producto</span>
    <strong>—</strong>
    <small>El código ingresado no existe. Escaneá otro código o esperá la limpieza automática.</small>
  `;

  if (notFoundCode) notFoundCode.textContent = query ? `Código: ${query}` : 'Código no encontrado';
  if (notFoundCountdown) notFoundCountdown.textContent = String(remaining);
  if (notFoundModal) notFoundModal.classList.remove('hidden');

  // Deja el lector listo para el próximo código mientras la ventana sigue visible.
  input.value = '';
  input.focus();

  notFoundInterval = setInterval(() => {
    if (token !== notFoundToken) return;
    remaining -= 1;
    if (notFoundCountdown) notFoundCountdown.textContent = String(Math.max(remaining, 0));
    if (remaining <= 0) clearInterval(notFoundInterval);
  }, 1000);

  notFoundTimer = setTimeout(() => {
    if (token !== notFoundToken) return;
    hidePriceNotFound();
    resetPriceResult();
  }, seconds * 1000);
}

function renderPriceList(products, activeIndex = 0) {
  const { list } = getPriceElements();
  priceProducts = products || [];
  priceIndex = Math.max(0, Math.min(activeIndex, Math.max(priceProducts.length - 1, 0)));
  list.classList.remove('hidden');
  renderSelectableList(list, priceProducts, priceIndex, showPriceProduct);
  ensureActiveVisible();
}

async function loadPriceMatches(query, forceList = false) {
  const normalizedQuery = (query || '').trim();
  lastQuery = normalizedQuery;

  let products;
  if (!normalizedQuery) {
    products = await api('/api/products');
  } else {
    products = await api(`/api/product-lookup?q=${encodeURIComponent(normalizedQuery)}`);
  }

  if (normalizedQuery && products.length === 0 && !forceList) {
    showPriceNotFound(normalizedQuery, 3);
    return;
  }

  // Si se escanea un código de barra exacto y el lector manda Enter,
  // mostramos directamente el precio. Si hay varias coincidencias o se fuerza lista,
  // mostramos el selector navegable.
  const exactBarcode = normalizedQuery && products.length === 1 && String(products[0].barcode || '') === normalizedQuery;
  if (exactBarcode && !forceList) {
    showPriceProduct(products[0]);
    return;
  }

  renderPriceList(products, 0);
}

async function searchPriceProduct(query) {
  await loadPriceMatches(query, false);
}

function startCountdown(seconds = 5) {
  clearTimeout(clearTimer);
  clearInterval(countdownTimer);

  let remaining = seconds;
  updateCountdown(remaining);

  countdownTimer = setInterval(() => {
    remaining -= 1;
    updateCountdown(remaining);
    if (remaining <= 0) {
      clearInterval(countdownTimer);
    }
  }, 1000);

  clearTimer = setTimeout(resetPriceResult, seconds * 1000);
}

function updateCountdown(remaining) {
  const countdown = document.getElementById('priceCountdown');
  if (!countdown) return;
  countdown.textContent = `Se limpia en ${remaining} segundo${remaining === 1 ? '' : 's'}`;
}

function showPriceProduct(product) {
  const { input, result } = getPriceElements();
  hidePriceNotFound();
  hidePriceList();
  result.classList.remove('idle');
  result.innerHTML = `
    <span>${escapeHTML(product.name)}</span>
    <strong>${formatMoney(product.sale_price)}</strong>
    <small>${escapeHTML(product.barcode || 'Sin código')} · Stock ${escapeHTML(product.stock)}</small>
    <div id="priceCountdown" class="price-countdown">Se limpia en 5 segundos</div>
  `;
  input.value = '';
  input.focus();
  beep();
  startCountdown(5);
}

function resetPriceResult() {
  clearTimeout(clearTimer);
  clearInterval(countdownTimer);
  hidePriceList();
  const { result, input } = getPriceElements();
  result.classList.add('idle');
  result.innerHTML = `
    <span>Esperando producto</span>
    <strong>—</strong>
    <small>Buscá por código de barra o nombre. Enter muestra la lista y las flechas navegan.</small>
  `;
  input.focus();
}

function movePrice(delta) {
  const { list } = getPriceElements();
  if (list.classList.contains('hidden') || !priceProducts.length) return;
  priceIndex = Math.max(0, Math.min(priceProducts.length - 1, priceIndex + delta));
  renderSelectableList(list, priceProducts, priceIndex, showPriceProduct);
  ensureActiveVisible();
}

function ensureActiveVisible() {
  const { list } = getPriceElements();
  const active = list.querySelector('.select-option.active');
  if (active) {
    active.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }
}

function selectActivePriceProduct() {
  if (!priceProducts.length) return false;
  const product = priceProducts[priceIndex];
  if (!product) return false;
  showPriceProduct(product);
  return true;
}

function scheduleLivePriceSearch() {
  const { input } = getPriceElements();
  const query = input.value.trim();
  clearTimeout(liveSearchTimer);

  if (!query) {
    hidePriceList();
    priceProducts = [];
    priceIndex = 0;
    return;
  }

  liveSearchTimer = setTimeout(async () => {
    try {
      const products = await api(`/api/product-lookup?q=${encodeURIComponent(query)}`);
      // Evita que una respuesta vieja pise una búsqueda más nueva.
      if (input.value.trim() !== query) return;
      renderPriceList(products, 0);
    } catch (err) {
      showToast(err.message, true);
    }
  }, 220);
}

document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('priceSearch');
  resetPriceResult();

  input.addEventListener('input', () => {
    // Si el operador escanea/escribe otro código mientras está el aviso, se cancela la cuenta anterior.
    hidePriceNotFound();
    scheduleLivePriceSearch();
  });

  input.addEventListener('keydown', async e => {
    const listVisible = !document.getElementById('priceSelectList').classList.contains('hidden');

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (!listVisible && input.value.trim()) {
        try { await loadPriceMatches(input.value.trim(), true); }
        catch (err) { showToast(err.message, true); }
      } else {
        movePrice(1);
      }
      return;
    }

    if (e.key === 'ArrowUp') {
      e.preventDefault();
      movePrice(-1);
      return;
    }

    if (e.key === 'Enter') {
      e.preventDefault();
      try {
        if (listVisible && priceProducts.length) {
          selectActivePriceProduct();
        } else {
          await searchPriceProduct(input.value.trim());
        }
      } catch (err) {
        showToast(err.message, true);
      }
      return;
    }

    if (e.key === 'Escape') {
      hidePriceList();
      return;
    }
  });
});
