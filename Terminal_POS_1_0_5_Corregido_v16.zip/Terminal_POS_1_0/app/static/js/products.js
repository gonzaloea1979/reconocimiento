
async function loadProductSuppliers() {
  const select = document.getElementById('productSupplier');
  if (!select) return;
  try {
    const suppliers = await api('/api/suppliers');
    const current = select.value;
    select.innerHTML = '<option value="">Sin proveedor</option>' + suppliers.map(s => `<option value="${s.id}">${escapeHTML(s.name)}</option>`).join('');
    select.value = current;
  } catch (err) {}
}

let productsCache = [];
let selectProducts = [];
let selectIndex = 0;
let editSecurityPassword = '';
let pendingAuthAction = null;
let productScanner = null;
let productScannerTarget = 'search';
let productTableIndex = -1;
let productSearchTimer = null;
let productLoadController = null;
let productLoadVersion = 0;
let productPhotoObjectUrl = null;
let originalProductStock = null;

const fields = ['barcode', 'name', 'detail', 'costWithoutTax', 'ivaPercent', 'grossIncomePercent', 'marginPercent', 'roundingMode', 'roundingMultiple', 'stock', 'minStock', 'expiryDate'];

async function loadProducts(q = '') {
  const query = String(q || '').trim();
  const version = ++productLoadVersion;
  if (productLoadController) productLoadController.abort();
  const controller = new AbortController();
  productLoadController = controller;
  try {
    const result = await api('/api/products' + (query ? `?q=${encodeURIComponent(query)}` : ''), { signal: controller.signal });
    if (version !== productLoadVersion) return;
    const searchInput = document.getElementById('productSearch');
    if (searchInput && searchInput.value.trim() !== query) return;
    productsCache = result;
    renderProductsTable(productsCache);
    updateProductsCount(productsCache.length);
  } catch (err) {
    if (err.name !== 'AbortError' && version === productLoadVersion) showToast(err.message, true);
  } finally {
    if (productLoadController === controller) productLoadController = null;
  }
}

function updateProductsCount(count) {
  const el = document.getElementById('productsCount');
  if (el) el.textContent = `${count} ${count === 1 ? 'producto' : 'productos'}`;
}

function productPhotoThumb(p) {
  if (!p.photo_url) return '<div class="product-thumb-placeholder">📦</div>';
  return `<img class="product-thumb" src="${escapeHTML(p.photo_url)}" alt="Foto ${escapeHTML(p.name)}">`;
}

function setProductPhotoPreview(url = '') {
  if (productPhotoObjectUrl && productPhotoObjectUrl !== url) {
    URL.revokeObjectURL(productPhotoObjectUrl);
    productPhotoObjectUrl = null;
  }
  if (url && String(url).startsWith('blob:')) productPhotoObjectUrl = url;
  const preview = document.getElementById('productPhotoPreview');
  if (!preview) return;
  if (url) {
    preview.innerHTML = `<img src="${escapeHTML(url)}" alt="Foto del producto"><span>Foto cargada</span>`;
  } else {
    preview.innerHTML = '<span>Sin foto</span>';
  }
}

function renderProductsTable(rows) {
  const tbody = document.getElementById('productsTable');
  if (!rows.length) {
    productTableIndex = -1;
    tbody.innerHTML = '<tr><td colspan="10" class="empty-state">No hay productos cargados</td></tr>';
    return;
  }
  tbody.innerHTML = rows.map((p, index) => `
    <tr class="product-row" tabindex="0" data-product-id="${p.id}" data-product-index="${index}" aria-selected="false">
      <td>${productPhotoThumb(p)}</td>
      <td><span class="product-code-chip">${escapeHTML(p.barcode || '-')}</span></td>
      <td><strong>${escapeHTML(p.name)}</strong><small>${escapeHTML(p.detail || 'Sin detalle')}</small></td>
      <td>${formatMoney(p.total_cost)}</td>
      <td><span class="margin-chip">${p.margin_percent}%</span></td>
      <td class="sale-price-cell">${formatMoney(p.sale_price)}</td>
      <td class="${p.low_stock ? 'low-stock-cell' : ''}">${p.stock}</td>
      <td>${p.min_stock || 0}</td>
      <td>${formatDateAR(p.expiry_date)}</td>
      <td>
        <div class="action-row products-action-row">
          <button class="tiny-button edit" onclick="requestEditProduct(${p.id})">Editar</button>
          <button class="tiny-button delete" onclick="requestDeleteProduct(${p.id})">Eliminar</button>
        </div>
      </td>
    </tr>
  `).join('');
  selectProductTableRow(Math.min(Math.max(productTableIndex, 0), rows.length - 1), false);
}

function getProductTableRows() {
  return Array.from(document.querySelectorAll('#productsTable tr.product-row'));
}

function selectProductTableRow(index, focusRow = true) {
  const rows = getProductTableRows();
  if (!rows.length) {
    productTableIndex = -1;
    return false;
  }
  productTableIndex = Math.max(0, Math.min(rows.length - 1, Number(index) || 0));
  rows.forEach((row, rowIndex) => {
    const selected = rowIndex === productTableIndex;
    row.classList.toggle('keyboard-selected', selected);
    row.setAttribute('aria-selected', selected ? 'true' : 'false');
  });
  const selectedRow = rows[productTableIndex];
  if (focusRow && selectedRow) {
    selectedRow.focus({ preventScroll: true });
    try { selectedRow.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (err) {}
  }
  return true;
}

function moveProductTableSelection(delta) {
  const rows = getProductTableRows();
  if (!rows.length) return false;
  const current = productTableIndex < 0 ? (delta > 0 ? -1 : rows.length) : productTableIndex;
  return selectProductTableRow(current + delta, true);
}

function editSelectedProductFromTable() {
  const rows = getProductTableRows();
  const row = rows[productTableIndex];
  if (!row) return false;
  const id = row.dataset.productId;
  if (!id) return false;
  requestEditProduct(id);
  return true;
}

function focusProductTableFromSearch(direction = 1) {
  const rows = getProductTableRows();
  if (!rows.length) return false;
  selectProductTableRow(direction >= 0 ? 0 : rows.length - 1, true);
  return true;
}

function setupProductTableKeyboardNavigation() {
  const tbody = document.getElementById('productsTable');
  if (!tbody) return;

  tbody.addEventListener('click', event => {
    const row = event.target.closest('tr.product-row');
    if (!row) return;
    selectProductTableRow(Number(row.dataset.productIndex || 0), false);
  });

  tbody.addEventListener('focusin', event => {
    const row = event.target.closest('tr.product-row');
    if (!row) return;
    selectProductTableRow(Number(row.dataset.productIndex || 0), false);
  });

  tbody.addEventListener('keydown', event => {
    if (event.ctrlKey || event.altKey || event.shiftKey || event.metaKey) return;

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      event.stopPropagation();
      moveProductTableSelection(1);
      return;
    }

    if (event.key === 'ArrowUp') {
      event.preventDefault();
      event.stopPropagation();
      moveProductTableSelection(-1);
      return;
    }

    if (event.key === 'Home') {
      event.preventDefault();
      event.stopPropagation();
      selectProductTableRow(0, true);
      return;
    }

    if (event.key === 'End') {
      event.preventDefault();
      event.stopPropagation();
      selectProductTableRow(getProductTableRows().length - 1, true);
      return;
    }

    if (event.key === 'Enter') {
      const actionButton = event.target.closest('button');
      if (actionButton) return;
      event.preventDefault();
      event.stopPropagation();
      editSelectedProductFromTable();
    }
  });
}

function roundingModeText(mode) {
  return {
    none: 'Sin redondeo',
    nearest: 'Al más cercano',
    up: 'Siempre hacia arriba',
    down: 'Siempre hacia abajo',
  }[mode] || 'Sin redondeo';
}

function getGlobalRoundingSettings() {
  const settings = window.POS_SETTINGS || {};
  const mode = settings.product_rounding_mode || 'none';
  const multiple = settings.product_rounding_multiple || '1';
  return { mode, multiple };
}

function syncGlobalRoundingControls() {
  const { mode, multiple } = getGlobalRoundingSettings();
  const modeInput = document.getElementById('roundingMode');
  const multipleInput = document.getElementById('roundingMultiple');
  if (modeInput) modeInput.value = mode;
  if (multipleInput) multipleInput.value = multiple;
  const label = document.getElementById('globalRoundingLabel');
  if (label) {
    label.textContent = mode === 'none' ? 'Sin redondeo' : `${roundingModeText(mode)} a múltiplo de $${multiple}`;
  }
}

async function loadProductGeneralSettings() {
  try {
    const settings = await api(`/api/settings?ts=${Date.now()}`, { cache: 'no-store' });
    window.POS_SETTINGS = { ...(window.POS_SETTINGS || {}), ...settings };
  } catch (err) {}
  syncGlobalRoundingControls();
  calculatePreview();
}

function applySalePriceRounding(value) {
  const mode = document.getElementById('roundingMode')?.value || 'none';
  const multiple = document.getElementById('roundingMultiple')?.value || 1;
  return window.POSMoneyDecimal
    ? window.POSMoneyDecimal.roundPrice(value, mode, multiple)
    : value;
}

function calculatePreview() {
  const cost = document.getElementById('costWithoutTax').value || 0;
  const iva = document.getElementById('ivaPercent').value || 0;
  const gross = document.getElementById('grossIncomePercent').value || 0;
  const margin = document.getElementById('marginPercent').value || 0;
  const mode = document.getElementById('roundingMode')?.value || 'none';
  const multiple = document.getElementById('roundingMultiple')?.value || 1;
  const values = window.POSMoneyDecimal
    ? window.POSMoneyDecimal.calculatePriceValues(cost, iva, gross, margin, mode, multiple)
    : (() => {
        const totalCost = Number(cost) + Number(cost) * Number(iva) / 100 + Number(cost) * Number(gross) / 100;
        const rawSale = totalCost + totalCost * Number(margin) / 100;
        return { totalCost, rawSale, salePrice: applySalePriceRounding(rawSale) };
      })();
  document.getElementById('totalCost').value = values.totalCost.toFixed(2);
  const rawInput = document.getElementById('salePriceRaw');
  if (rawInput) rawInput.value = values.rawSale.toFixed(2);
  document.getElementById('salePrice').value = values.salePrice.toFixed(2);
}

function openNewProductModal() {
  originalProductStock = null;
  editSecurityPassword = '';
  document.getElementById('productModalTitle').textContent = 'Agregar producto';
  document.getElementById('productId').value = '';
  document.getElementById('productForm').reset();
  document.getElementById('adminPassword').value = '';
  document.getElementById('ivaPercent').value = 21;
  document.getElementById('grossIncomePercent').value = 0;
  document.getElementById('marginPercent').value = 30;
  syncGlobalRoundingControls();
  document.getElementById('stock').value = 0;
  document.getElementById('minStock').value = 0;
  document.getElementById('productSupplier').value = '';
  document.getElementById('productPhoto').value = '';
  setProductPhotoPreview('');
  calculatePreview();
  document.getElementById('productModal').classList.remove('hidden');
  setTimeout(() => document.getElementById('barcode').focus(), 100);
}

function closeProductModal() {
  originalProductStock = null;
  document.getElementById('productModal').classList.add('hidden');
  editSecurityPassword = '';
  document.getElementById('adminPassword').value = '';
}

function fillForm(p) {
  originalProductStock = p.stock ?? 0;
  document.getElementById('productId').value = p.id;
  document.getElementById('barcode').value = p.barcode || '';
  document.getElementById('name').value = p.name || '';
  document.getElementById('detail').value = p.detail || '';
  document.getElementById('costWithoutTax').value = p.cost_without_tax || 0;
  document.getElementById('ivaPercent').value = p.iva_percent || 0;
  document.getElementById('grossIncomePercent').value = p.gross_income_percent || 0;
  document.getElementById('marginPercent').value = p.margin_percent || 0;
  syncGlobalRoundingControls();
  document.getElementById('stock').value = p.stock || 0;
  document.getElementById('minStock').value = p.min_stock || 0;
  document.getElementById('productSupplier').value = p.supplier_id || '';
  document.getElementById('expiryDate').value = p.expiry_date ? formatDateAR(p.expiry_date) : '';
  document.getElementById('productPhoto').value = '';
  setProductPhotoPreview(p.photo_url || '');
  document.getElementById('adminPassword').value = editSecurityPassword;
  calculatePreview();
}

function openProductAuthModal({ title, message, acceptText = 'Autorizar', onAccept }) {
  if (currentUserIsAdmin()) {
    Promise.resolve(onAccept('')).catch(err => showToast(err.message, true));
    return;
  }
  pendingAuthAction = onAccept;
  document.getElementById('productAuthTitle').textContent = title;
  document.getElementById('productAuthMessage').textContent = message;
  document.getElementById('productAuthAccept').textContent = acceptText;
  document.getElementById('productAuthPassword').value = '';
  document.getElementById('productAuthModal').classList.remove('hidden');
  setTimeout(() => document.getElementById('productAuthPassword').focus(), 80);
}

function closeProductAuthModal() {
  pendingAuthAction = null;
  document.getElementById('productAuthModal').classList.add('hidden');
  document.getElementById('productAuthPassword').value = '';
}

async function handleProductAuthSubmit(event) {
  event.preventDefault();
  const passwordInput = document.getElementById('productAuthPassword');
  const password = passwordInput.value;
  if (!password && !currentUserIsAdmin()) {
    showToast('Ingresá la contraseña de seguridad', true);
    passwordInput.focus();
    return;
  }
  if (!pendingAuthAction) return;
  try {
    await pendingAuthAction(password);
    closeProductAuthModal();
  } catch (err) {
    showToast(err.message, true);
    passwordInput.select();
  }
}

async function verifyAdminPassword(password) {
  return api('/api/admin-check', { method: 'POST', body: JSON.stringify({ password }) });
}

function requestEditProduct(id) {
  openProductAuthModal({
    title: 'Autorizar edición',
    message: 'Ingresá la contraseña de seguridad antes de abrir la edición del producto.',
    acceptText: 'Editar',
    onAccept: async (password) => {
      await verifyAdminPassword(password);
      editSecurityPassword = password;
      const p = await api(`/api/products/${id}`);
      document.getElementById('productModalTitle').textContent = 'Editar producto';
      fillForm(p);
      document.getElementById('productModal').classList.remove('hidden');
      setTimeout(() => document.getElementById('name').focus(), 100);
    },
  });
}

function requestDeleteProduct(id) {
  const product = productsCache.find(p => Number(p.id) === Number(id));
  const productName = product ? product.name : 'este producto';
  openProductAuthModal({
    title: 'Autorizar eliminación',
    message: `Ingresá la contraseña para eliminar "${productName}". Esta acción no se puede deshacer.`,
    acceptText: 'Eliminar',
    onAccept: async (password) => {
      await api(`/api/products/${id}`, { method: 'DELETE', body: JSON.stringify({ password }) });
      showToast('Producto eliminado');
      loadProducts(document.getElementById('productSearch').value.trim());
    },
  });
}

// Compatibilidad por si quedó algún evento viejo en caché del navegador.
function editProduct(id) { requestEditProduct(id); }
function deleteProduct(id) { requestDeleteProduct(id); }

function collectForm() {
  const expiryInput = document.getElementById('expiryDate').value.trim();
  const normalizedExpiry = normalizeDateToISO(expiryInput);
  if (expiryInput && normalizedExpiry === null) {
    throw new Error('La fecha de vencimiento debe tener formato DD/MM/AAAA o DDMMAA. Ejemplo: 31/12/2026 o 200626');
  }
  const id = document.getElementById('productId').value;
  const password = id && !currentUserIsAdmin() ? (editSecurityPassword || document.getElementById('adminPassword').value) : '';
  if (id && !password && !currentUserIsAdmin()) {
    throw new Error('Para editar el producto primero tenés que autorizar con contraseña.');
  }

  const formData = new FormData();
  formData.append('barcode', document.getElementById('barcode').value.trim());
  formData.append('name', document.getElementById('name').value.trim());
  formData.append('detail', document.getElementById('detail').value.trim());
  formData.append('cost_without_tax', document.getElementById('costWithoutTax').value);
  formData.append('iva_percent', document.getElementById('ivaPercent').value);
  formData.append('gross_income_percent', document.getElementById('grossIncomePercent').value);
  formData.append('margin_percent', document.getElementById('marginPercent').value);
  formData.append('rounding_mode', document.getElementById('roundingMode').value);
  formData.append('rounding_multiple', document.getElementById('roundingMultiple').value);
  formData.append('stock', document.getElementById('stock').value);
  if (id && originalProductStock !== null) {
    formData.append('original_stock', String(originalProductStock));
  }
  formData.append('min_stock', document.getElementById('minStock').value);
  formData.append('supplier_id', document.getElementById('productSupplier').value);
  formData.append('expiry_date', normalizedExpiry);
  formData.append('password', password);

  const photoInput = document.getElementById('productPhoto');
  if (photoInput && photoInput.files && photoInput.files[0]) {
    formData.append('photo', photoInput.files[0]);
  }
  return formData;
}

async function apiProductForm(url, method, formData) {
  return postOperation(url, formData, {method, persist:false, allowRecord:true});
}

function saveProduct(event) {
  event.preventDefault();
  return withOperationLock('product-save', '#productForm button[type="submit"]', () => saveProductOnce(event));
}

async function saveProductOnce(event) {
  event.preventDefault();
  const id = document.getElementById('productId').value;
  try {
    const payload = collectForm();
    if (id) {
      await apiProductForm(`/api/products/${id}`, 'PUT', payload);
      showToast('Producto editado');
    } else {
      await apiProductForm('/api/products', 'POST', payload);
      showToast('Producto agregado');
    }
    closeProductModal();
    loadProducts(document.getElementById('productSearch').value.trim());
  } catch (err) {
    showToast(err.message, true);
  }
}

async function openSelectModal(query) {
  try {
    selectProducts = await api('/api/products' + (query ? `?q=${encodeURIComponent(query)}` : ''));
    selectIndex = 0;
    document.getElementById('selectModal').classList.remove('hidden');
    renderSelectableList(document.getElementById('selectList'), selectProducts, selectIndex, selectProductFromModal);
  } catch (err) {
    showToast(err.message, true);
  }
}

function closeSelectModal() {
  document.getElementById('selectModal').classList.add('hidden');
}

function selectProductFromModal(p) {
  closeSelectModal();
  requestEditProduct(p.id);
}

function moveSelect(delta) {
  if (document.getElementById('selectModal').classList.contains('hidden') || !selectProducts.length) return;
  selectIndex = Math.max(0, Math.min(selectProducts.length - 1, selectIndex + delta));
  renderSelectableList(document.getElementById('selectList'), selectProducts, selectIndex, selectProductFromModal);
}


function openProductScanner(target = 'search', autoStart = false) {
  productScannerTarget = target;
  if (autoStart && productScanner?.openAndStart) {
    productScanner.openAndStart();
  } else if (productScanner?.open) {
    productScanner.open(autoStart);
  } else {
    showToast('El escáner por cámara no está disponible en esta pantalla.', true);
  }
}

async function handleScannedProductCode(code) {
  if (productScannerTarget === 'barcode') {
    const barcodeInput = document.getElementById('barcode');
    if (barcodeInput) {
      barcodeInput.value = code;
      barcodeInput.focus();
    }
    showToast(`Código cargado: ${code}`);
    productScanner?.close();
    return;
  }
  const searchInput = document.getElementById('productSearch');
  if (searchInput) {
    searchInput.value = code;
    await loadProducts(code);
  }
  const matches = productsCache.filter(p => String(p.barcode || '') === String(code));
  if (matches.length === 1) {
    requestEditProduct(matches[0].id);
  } else {
    showToast(`Búsqueda por código: ${code}`);
  }
  productScanner?.close();
}


function setupProductVerticalNav() {
  const scrollArea = document.getElementById('productsScrollArea');
  const buttons = Array.from(document.querySelectorAll('.product-nav-button[data-product-scroll]'));
  if (!scrollArea || !buttons.length) return;

  function setActive(targetId) {
    buttons.forEach(btn => btn.classList.toggle('active', btn.dataset.productScroll === targetId));
  }

  buttons.forEach(button => {
    button.addEventListener('click', () => {
      const targetId = button.dataset.productScroll;
      const target = document.getElementById(targetId);
      if (!target) return;
      const offset = target.offsetTop - scrollArea.offsetTop;
      scrollArea.scrollTo({ top: Math.max(0, offset - 4), behavior: 'smooth' });
      setActive(targetId);
    });
  });

  scrollArea.addEventListener('scroll', () => {
    const sections = ['productsTop', 'productsSearchBlock', 'productsListBlock']
      .map(id => document.getElementById(id))
      .filter(Boolean);
    let current = sections[0]?.id || 'productsTop';
    for (const section of sections) {
      const top = section.offsetTop - scrollArea.offsetTop;
      if (scrollArea.scrollTop >= top - 30) current = section.id;
    }
    setActive(current);
  }, { passive: true });

  const navNew = document.getElementById('productNavNewBtn');
  if (navNew) navNew.addEventListener('click', openNewProductModal);
}

document.addEventListener('DOMContentLoaded', () => {
  markAdminBypassUI();
  if (currentUserIsAdmin()) {
    const toolbarPill = document.querySelector('.toolbar-pill');
    if (toolbarPill) toolbarPill.textContent = 'Administrador: edición directa';
  }
  syncGlobalRoundingControls();
  loadProductGeneralSettings();
  loadProductSuppliers();
  loadProducts();
  document.getElementById('newProductBtn').addEventListener('click', openNewProductModal);
  setupProductVerticalNav();
  setupProductTableKeyboardNavigation();
  if (window.POSBarcodeScanner) {
    productScanner = new POSBarcodeScanner({
      onDetected: handleScannedProductCode,
      onClose: () => {
        const target = productScannerTarget === 'barcode' ? document.getElementById('barcode') : document.getElementById('productSearch');
        target?.focus();
      },
    });
  }
  document.getElementById('openProductSearchScannerBtn')?.addEventListener('click', () => openProductScanner('search'));
  document.getElementById('openProductBarcodeScannerBtn')?.addEventListener('click', () => openProductScanner('barcode'));
  document.getElementById('productForm').addEventListener('submit', saveProduct);
  document.getElementById('productAuthForm').addEventListener('submit', handleProductAuthSubmit);
  ['costWithoutTax', 'ivaPercent', 'grossIncomePercent', 'marginPercent', 'roundingMode', 'roundingMultiple'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', calculatePreview);
  });
  document.getElementById('productPhoto').addEventListener('change', e => {
    const file = e.target.files && e.target.files[0];
    setProductPhotoPreview(file ? URL.createObjectURL(file) : '');
  });
  document.getElementById('productSearch').addEventListener('input', e => {
    clearTimeout(productSearchTimer);
    if (productLoadController) productLoadController.abort();
    productLoadVersion += 1;
    const query = e.target.value.trim();
    productSearchTimer = setTimeout(() => loadProducts(query), 180);
  });
  document.getElementById('productSearch').addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') {
      if (focusProductTableFromSearch(1)) {
        e.preventDefault();
        e.stopPropagation();
      }
      return;
    }
    if (e.key === 'ArrowUp') {
      if (focusProductTableFromSearch(-1)) {
        e.preventDefault();
        e.stopPropagation();
      }
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      openSelectModal(e.target.value.trim());
    }
  });
  document.addEventListener('keydown', e => {
    if (e.ctrlKey || e.altKey || e.shiftKey || e.metaKey) return;

    if (e.key === 'Insert' || e.code === 'Insert') {
      e.preventDefault();
      e.stopPropagation();
      const productModal = document.getElementById('productModal');
      const productModalOpen = productModal && !productModal.classList.contains('hidden');
      openProductScanner(productModalOpen ? 'barcode' : 'search', true);
      return;
    }

    if (e.key === 'Escape') {
      const scannerModal = document.getElementById('barcodeScannerModal');
      if (scannerModal && !scannerModal.classList.contains('hidden')) {
        productScanner?.close();
        return;
      }
      closeProductAuthModal();
      closeSelectModal();
      closeProductModal();
    }
    if (!document.getElementById('selectModal').classList.contains('hidden')) {
      if (e.key === 'ArrowDown') { e.preventDefault(); moveSelect(1); }
      if (e.key === 'ArrowUp') { e.preventDefault(); moveSelect(-1); }
      if (e.key === 'Enter' && selectProducts[selectIndex]) { e.preventDefault(); selectProductFromModal(selectProducts[selectIndex]); }
    }
  });
});
