async function loadStockModule() {
  const [alerts, products, movements] = await Promise.all([
    api('/api/stock/alerts?compact=1'), api('/api/products?compact=1'), api('/api/stock/movements')
  ]);
  const alertBox = document.getElementById('stockAlerts');
  alertBox.className = 'advanced-list';
  alertBox.innerHTML = alerts.length ? alerts.map(p => `<div class="advanced-item warning-item"><strong>${escapeHTML(p.name)}</strong><span>Stock ${escapeHTML(p.stock)} / mín. ${escapeHTML(p.min_stock)}</span></div>`).join('') : '<div class="empty-state">Sin alertas</div>';
  const sel = document.getElementById('stockProduct');
  sel.innerHTML = products.map(p => `<option value="${Number(p.id)}">${escapeHTML(p.name)} · Stock ${escapeHTML(p.stock)}</option>`).join('');
  renderMovements(movements);
}
function renderMovements(rows) {
  document.getElementById('stockMovements').innerHTML = rows.length ? rows.map(r => `<tr><td>${escapeHTML(r.created_at_formatted)}</td><td>${escapeHTML(r.product_name)}</td><td>${escapeHTML(r.movement_type)}</td><td>${escapeHTML(r.quantity)}</td><td>${escapeHTML(r.previous_stock)}</td><td>${escapeHTML(r.new_stock)}</td><td>${escapeHTML(r.reference || '')}</td></tr>`).join('') : '<tr><td colspan="7" class="empty-state">Sin movimientos</td></tr>';
}
async function adjustStock() {
  try {
    await api('/api/stock/adjust', {method:'POST', body: JSON.stringify({product_id: stockProduct.value, new_stock: stockNewValue.value, notes: stockNotes.value, password: securityPasswordOrEmpty('stockPassword')})});
    showToast('Stock ajustado');
    stockPassword.value=''; stockNotes.value='';
    loadStockModule();
  } catch(err) { showToast(err.message, true); }
}
document.addEventListener('DOMContentLoaded',()=>{ markAdminBypassUI(); });
document.addEventListener('DOMContentLoaded', loadStockModule);
