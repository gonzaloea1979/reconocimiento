function ticketBool(value) {
  return String(value ?? '1') === '1';
}

function ticketById(id) {
  return document.getElementById(id);
}

function setTicketControl(id, value) {
  const el = ticketById(id);
  if (!el) return;
  if (el.type === 'checkbox') {
    el.checked = ticketBool(value);
  } else {
    el.value = value ?? '';
  }
}

function getTicketControl(id) {
  const el = ticketById(id);
  if (!el) return '';
  if (el.type === 'checkbox') return el.checked ? '1' : '0';
  return el.value;
}

function setTicketDesignStatus(message, isError = false) {
  const status = ticketById('ticketDesignStatus');
  if (!status) return;
  status.textContent = message || '';
  status.classList.toggle('error', !!isError);
  status.classList.toggle('ok', !!message && !isError);
}

function ticketLogoUrl(settings = window.POS_SETTINGS || {}) {
  return settings.logo_url || '';
}

function renderTicketLogoPreview(settings = window.POS_SETTINGS || {}, localUrl = '') {
  const url = localUrl || ticketLogoUrl(settings);
  const logoBox = ticketById('ticketLogoPreview');
  const previewLogo = document.querySelector('.preview-logo');
  const versionedUrl = url && !url.startsWith('data:') ? `${url}?v=${Date.now()}` : url;

  if (logoBox) {
    logoBox.innerHTML = versionedUrl
      ? `<img src="${escapeHTML(versionedUrl)}" alt="Logo del ticket">`
      : '<span>Sin logo</span>';
  }

  if (previewLogo) {
    previewLogo.innerHTML = versionedUrl
      ? `<img src="${escapeHTML(versionedUrl)}" alt="Logo del ticket">`
      : 'LOGO';
    previewLogo.classList.toggle('has-image', !!versionedUrl);
  }
}

function updateTicketPreview() {
  const paper = ticketById('ticketPreviewPaper');
  if (!paper) return;

  const accent = getTicketControl('ticket_accent_color') || '#0F172A';
  const size = getTicketControl('ticket_pdf_size') || 'A5';
  const design = getTicketControl('ticket_design') || 'moderno';
  const fontScale = getTicketControl('ticket_font_scale') || 'normal';
  const title = getTicketControl('ticket_title') || 'TICKET DE COMPRA';
  const footer = getTicketControl('ticket_footer') || 'Gracias por su compra';

  paper.style.setProperty('--ticket-accent-preview', accent);
  paper.dataset.size = size;
  paper.dataset.design = design;
  paper.dataset.font = fontScale;

  const settings = window.POS_SETTINGS || {};
  const businessName = ticketById('previewBusinessName');
  const previewTitle = ticketById('previewTitle');
  const previewFooter = ticketById('previewFooter');
  if (businessName) businessName.textContent = settings.business_name || 'POS Local';
  if (previewTitle) previewTitle.textContent = title;
  if (previewFooter) previewFooter.textContent = footer;

  const showLogo = ticketById('ticket_show_logo')?.checked ?? true;
  const previewLogo = document.querySelector('.preview-logo');
  if (previewLogo) previewLogo.classList.toggle('hidden', !showLogo);
  if (businessName) businessName.classList.toggle('hidden', !(ticketById('ticket_show_business_name')?.checked ?? true));

  const businessParts = [];
  if (ticketById('ticket_show_cuit')?.checked) businessParts.push(settings.business_cuit || 'CUIT');
  if (ticketById('ticket_show_address')?.checked) businessParts.push(settings.business_address || 'Dirección');
  if (ticketById('ticket_show_phone')?.checked) businessParts.push(settings.business_phone || 'Teléfono');
  if (ticketById('ticket_show_email')?.checked) businessParts.push(settings.business_email || 'Email');
  const businessData = ticketById('previewBusinessData');
  if (businessData) {
    businessData.textContent = businessParts.join(' · ');
    businessData.classList.toggle('hidden', !businessParts.length);
  }

  ticketById('previewCashier')?.classList.toggle('hidden', !(ticketById('ticket_show_cashier')?.checked ?? true));
  ticketById('previewPayment')?.classList.toggle('hidden', !(ticketById('ticket_show_payment')?.checked ?? true));
  ticketById('previewReceived')?.classList.toggle('hidden', !(ticketById('ticket_show_received_change')?.checked ?? true));
  ticketById('previewFooter')?.classList.toggle('hidden', !(ticketById('ticket_show_footer')?.checked ?? true));
  const previewQr = ticketById('previewQr');
  const previewQrLabel = ticketById('previewQrLabel');
  const showQr = ticketById('ticket_show_qr')?.checked ?? false;
  if (previewQr) previewQr.classList.toggle('hidden', !showQr);
  if (previewQrLabel) previewQrLabel.textContent = getTicketControl('ticket_qr_label') || 'Escaneá para contactarnos';
}

async function loadTicketSettings() {
  const settings = await api('/api/ticket-settings');
  window.POS_SETTINGS = { ...(window.POS_SETTINGS || {}), ...settings };
  [
    'ticket_pdf_size', 'ticket_design', 'ticket_title', 'ticket_accent_color',
    'ticket_font_scale', 'ticket_margin_mm', 'ticket_logo_size_mm',
    'ticket_show_logo', 'ticket_show_business_name', 'ticket_show_cuit',
    'ticket_show_address', 'ticket_show_phone', 'ticket_show_email',
    'ticket_show_cashier', 'ticket_show_payment', 'ticket_show_received_change',
    'ticket_show_footer', 'ticket_show_qr', 'ticket_qr_label', 'ticket_qr_value', 'ticket_footer'
  ].forEach(key => setTicketControl(key, settings[key]));
  renderTicketLogoPreview(settings);
  updateTicketPreview();
}

async function saveTicketSettingsOnly() {
  const payload = {};
  [
    'ticket_pdf_size', 'ticket_design', 'ticket_title', 'ticket_accent_color',
    'ticket_font_scale', 'ticket_margin_mm', 'ticket_logo_size_mm',
    'ticket_show_logo', 'ticket_show_business_name', 'ticket_show_cuit',
    'ticket_show_address', 'ticket_show_phone', 'ticket_show_email',
    'ticket_show_cashier', 'ticket_show_payment', 'ticket_show_received_change',
    'ticket_show_footer', 'ticket_show_qr', 'ticket_qr_label', 'ticket_qr_value', 'ticket_footer'
  ].forEach(key => payload[key] = getTicketControl(key));

  const data = await api('/api/ticket-settings', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
  window.POS_SETTINGS = { ...(window.POS_SETTINGS || {}), ...(data.settings || {}) };
  return data.settings || {};
}

function addSettingsValue(formData, key, elementId, fallback = '') {
  const el = ticketById(elementId);
  const settings = window.POS_SETTINGS || {};
  formData.append(key, el ? (el.value || '') : (settings[key] ?? fallback));
}

async function saveTicketLogoIfNeeded() {
  const logoInput = ticketById('ticketLogoInput');
  const removeLogo = ticketById('ticketRemoveLogo');
  const file = logoInput?.files?.[0] || null;
  const shouldRemove = !!removeLogo?.checked;
  if (!file && !shouldRemove) return null;

  const settings = window.POS_SETTINGS || {};
  const formData = new FormData();
  addSettingsValue(formData, 'business_name', 'businessName', settings.business_name || 'POS Local');
  addSettingsValue(formData, 'business_cuit', 'businessCuit', settings.business_cuit || '');
  addSettingsValue(formData, 'business_address', 'businessAddress', settings.business_address || '');
  addSettingsValue(formData, 'business_phone', 'businessPhone', settings.business_phone || '');
  addSettingsValue(formData, 'business_email', 'businessEmail', settings.business_email || '');
  formData.append('ticket_footer', getTicketControl('ticket_footer') || settings.ticket_footer || '');
  addSettingsValue(formData, 'product_rounding_mode', 'productRoundingMode', settings.product_rounding_mode || 'none');
  addSettingsValue(formData, 'product_rounding_multiple', 'productRoundingMultiple', settings.product_rounding_multiple || '1');

  if (file) formData.append('logo', file);
  if (shouldRemove) formData.append('remove_logo', '1');

  const response = await fetch('/api/settings', {
    method: 'POST',
    body: formData,
    cache: 'no-store',
    credentials: 'same-origin'
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data.ok) throw new Error(data.error || 'No se pudo guardar el logo del ticket');

  if (logoInput) logoInput.value = '';
  if (removeLogo) removeLogo.checked = false;
  window.POS_SETTINGS = { ...(window.POS_SETTINGS || {}), ...(data.settings || {}) };

  if (typeof renderLogoPreview === 'function') renderLogoPreview(data.settings || {});
  if (typeof updateSidebarBrand === 'function') updateSidebarBrand(data.settings || {});
  renderTicketLogoPreview(data.settings || {});
  return data.settings || {};
}

async function saveTicketSettings() {
  const buttons = [ticketById('saveTicketDesignBtn'), ticketById('saveTicketDesignTopBtn')].filter(Boolean);
  try {
    buttons.forEach(btn => {
      btn.disabled = true;
      btn.dataset.originalText = btn.textContent;
      btn.textContent = 'Guardando...';
    });
    setTicketDesignStatus('Guardando cambios del ticket...');
    const settings = await saveTicketSettingsOnly();
    await saveTicketLogoIfNeeded();
    window.POS_SETTINGS = { ...(window.POS_SETTINGS || {}), ...settings };
    await loadTicketSettings();
    setTicketDesignStatus('Cambios guardados correctamente');
    showToast('Configuración de ticket guardada');
  } catch (err) {
    setTicketDesignStatus(err.message, true);
    showToast(err.message, true);
  } finally {
    buttons.forEach(btn => {
      btn.disabled = false;
      btn.textContent = btn.dataset.originalText || 'Guardar cambios';
    });
  }
}

function previewSelectedTicketLogo(file) {
  if (!file) return;
  const maxSize = 50 * 1024 * 1024;
  if (file.size > maxSize) {
    const logoInput = ticketById('ticketLogoInput');
    if (logoInput) logoInput.value = '';
    throw new Error('El logo es demasiado pesado. El máximo permitido es 50 MB.');
  }
  const reader = new FileReader();
  reader.onload = event => {
    renderTicketLogoPreview(window.POS_SETTINGS || {}, event.target.result);
    const removeLogo = ticketById('ticketRemoveLogo');
    if (removeLogo) removeLogo.checked = false;
    updateTicketPreview();
  };
  reader.readAsDataURL(file);
}

document.addEventListener('DOMContentLoaded', () => {
  loadTicketSettings().catch(err => showToast(err.message, true));

  [ticketById('saveTicketDesignBtn'), ticketById('saveTicketDesignTopBtn')].filter(Boolean).forEach(btn => {
    btn.addEventListener('click', saveTicketSettings);
  });

  document.querySelectorAll('.ticket-design-view input, .ticket-design-view select, .ticket-design-view textarea')
    .forEach(el => {
      el.addEventListener('input', updateTicketPreview);
      el.addEventListener('change', updateTicketPreview);
    });

  const ticketLogoInput = ticketById('ticketLogoInput');
  if (ticketLogoInput) {
    ticketLogoInput.addEventListener('change', event => {
      const file = event.target.files && event.target.files[0];
      if (file) {
        try {
          previewSelectedTicketLogo(file);
          setTicketDesignStatus('Logo listo para guardar');
        } catch (err) {
          setTicketDesignStatus(err.message, true);
          showToast(err.message, true);
        }
      }
    });
  }

  const removeLogo = ticketById('ticketRemoveLogo');
  if (removeLogo) {
    removeLogo.addEventListener('change', event => {
      if (event.target.checked) {
        const logoInput = ticketById('ticketLogoInput');
        if (logoInput) logoInput.value = '';
        renderTicketLogoPreview({}, '');
        setTicketDesignStatus('Logo marcado para quitar. Presioná Guardar cambios.');
      } else {
        renderTicketLogoPreview(window.POS_SETTINGS || {});
      }
      updateTicketPreview();
    });
  }
});
