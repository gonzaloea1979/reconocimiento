document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('firstSetupForm');
  const username = document.getElementById('setupUsername');
  const password = document.getElementById('setupPassword');
  const confirmPassword = document.getElementById('setupConfirmPassword');
  const submitButton = document.getElementById('setupSubmitButton');

  form.addEventListener('submit', async event => {
    event.preventDefault();
    const payload = {
      username: username.value.trim() || 'admin',
      password: password.value,
      confirm_password: confirmPassword.value,
    };

    if (payload.password !== payload.confirm_password) {
      showToast('Las contraseñas no coinciden', true);
      confirmPassword.focus();
      confirmPassword.select();
      return;
    }

    submitButton.disabled = true;
    submitButton.textContent = 'Creando administrador...';
    try {
      const data = await api('/api/first-setup', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      showToast('Administrador creado correctamente');
      setTimeout(() => {
        window.location.href = data.redirect || '/';
      }, 450);
    } catch (err) {
      showToast(err.message, true);
      submitButton.disabled = false;
      submitButton.textContent = 'Crear administrador e iniciar';
      password.focus();
      password.select();
    }
  });
});
