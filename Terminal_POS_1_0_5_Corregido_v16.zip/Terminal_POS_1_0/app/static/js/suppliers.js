let suppliers = [];
let supplierSearchTimer = null;
let supplierSearchController = null;
let supplierSearchVersion = 0;
function clearSupplierForm(){ supplierId.value=''; supplierName.value=''; supplierCuit.value=''; supplierPhone.value=''; supplierCategory.value=''; supplierAddress.value=''; supplierNotes.value=''; supplierPassword.value=''; supplierPasswordWrap.classList.add('hidden'); }
async function loadSuppliers(){
  const version = ++supplierSearchVersion;
  if (supplierSearchController) supplierSearchController.abort();
  const controller = new AbortController();
  supplierSearchController = controller;
  const query = supplierSearch.value.trim();
  try {
    const result = await api('/api/suppliers' + (query ? `?q=${encodeURIComponent(query)}` : ''), { signal: controller.signal });
    if (version !== supplierSearchVersion || supplierSearch.value.trim() !== query) return;
    suppliers = result;
    suppliersList.innerHTML = suppliers.length ? suppliers.map(s => `<div class="advanced-item" onclick="editSupplier(${Number(s.id)})"><strong>${escapeHTML(s.name)}</strong><span>${escapeHTML(s.phone||'')} ${s.category?'· '+escapeHTML(s.category):''}</span></div>`).join('') : '<div class="empty-state">Sin proveedores</div>';
  } catch (err) {
    if (err.name !== 'AbortError' && version === supplierSearchVersion) showToast(err.message, true);
  } finally {
    if (supplierSearchController === controller) supplierSearchController = null;
  }
}
function editSupplier(id){ const s=suppliers.find(x=>x.id===id); if(!s)return; supplierId.value=s.id; supplierName.value=s.name; supplierCuit.value=s.cuit; supplierPhone.value=s.phone; supplierCategory.value=s.category; supplierAddress.value=s.address; supplierNotes.value=s.notes; supplierPasswordWrap.classList.remove('hidden'); supplierName.focus(); }
async function saveSupplier(){ try{ const data={name:supplierName.value,cuit:supplierCuit.value,phone:supplierPhone.value,category:supplierCategory.value,address:supplierAddress.value,notes:supplierNotes.value,password:securityPasswordOrEmpty('supplierPassword')}; if(supplierId.value){ await api('/api/suppliers/'+supplierId.value,{method:'PUT',body:JSON.stringify(data)}); } else { await api('/api/suppliers',{method:'POST',body:JSON.stringify(data)}); } showToast('Proveedor guardado'); clearSupplierForm(); loadSuppliers(); }catch(e){showToast(e.message,true);} }
async function deleteSupplier(){ if(!supplierId.value) return showToast('Seleccioná un proveedor', true); try{ await api('/api/suppliers/'+supplierId.value,{method:'DELETE',body:JSON.stringify({password:securityPasswordOrEmpty('supplierPassword')})}); showToast('Proveedor eliminado'); clearSupplierForm(); loadSuppliers(); }catch(e){showToast(e.message,true);} }
document.addEventListener('DOMContentLoaded',()=>{ markAdminBypassUI(); });
document.addEventListener('DOMContentLoaded',()=>{ supplierSearch.addEventListener('input',()=>{
  clearTimeout(supplierSearchTimer);
  if (supplierSearchController) supplierSearchController.abort();
  supplierSearchVersion += 1;
  supplierSearchTimer=setTimeout(loadSuppliers,180);
}); loadSuppliers(); });
