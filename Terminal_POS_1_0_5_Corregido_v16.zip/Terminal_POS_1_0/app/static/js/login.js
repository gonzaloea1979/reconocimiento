document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('loginForm');
  const username = document.getElementById('loginUsername');
  const password = document.getElementById('loginPassword');

  form.addEventListener('submit', async event => {
    event.preventDefault();
    try {
      await api('/api/login', {
        method: 'POST',
        body: JSON.stringify({ username: username.value.trim(), password: password.value }),
      });
      window.location.href = '/';
    } catch (err) {
      showToast(err.message, true);
      password.focus();
      password.select();
    }
  });
});
