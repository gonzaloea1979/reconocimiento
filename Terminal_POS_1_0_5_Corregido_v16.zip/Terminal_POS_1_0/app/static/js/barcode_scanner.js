class POSBarcodeScanner {
  constructor({ onDetected, onClose, contextLabel } = {}) {
    this.onDetected = onDetected || (() => {});
    this.onClose = onClose || (() => {});
    this.contextLabel = contextLabel || 'producto';
    this.modal = document.getElementById('barcodeScannerModal');
    this.video = document.getElementById('barcodeScannerVideo');
    this.status = document.getElementById('barcodeScannerStatus');
    this.startBtn = document.getElementById('startBarcodeScannerBtn');
    this.stopBtn = document.getElementById('stopBarcodeScannerBtn');
    this.closeBtn = document.getElementById('closeBarcodeScannerBtn');
    this.deviceSelect = document.getElementById('barcodeScannerDevice');
    this.compatibilityInfo = document.getElementById('barcodeScannerCompatibility');
    this.stream = null;
    this.detector = null;
    this.running = false;
    this.lastCode = '';
    this.lastAt = 0;
    this.lastServerDecodeAt = 0;
    this.serverDecodeInFlight = false;
    this.detectorMode = 'none';
    this.devices = [];
    this.selectedDeviceId = localStorage.getItem('posPreferredCameraId') || '';
    this.scanFrameCount = 0;
    this.canvas = document.createElement('canvas');

    this.startBtn?.addEventListener('click', () => this.start());
    this.stopBtn?.addEventListener('click', () => this.stop(false));
    this.closeBtn?.addEventListener('click', () => this.close());
    this.deviceSelect?.addEventListener('change', () => {
      this.selectedDeviceId = this.deviceSelect.value || '';
      if (this.selectedDeviceId) localStorage.setItem('posPreferredCameraId', this.selectedDeviceId);
      if (this.running) this.restart();
    });
    this.modal?.addEventListener('click', event => {
      if (event.target === this.modal) this.close();
    });
    document.addEventListener('keydown', event => {
      if (event.key === 'Escape' && this.modal && !this.modal.classList.contains('hidden')) {
        event.preventDefault();
        this.close();
      }
    });
  }

  setStatus(message, isError = false) {
    if (!this.status) return;
    this.status.textContent = message;
    this.status.classList.toggle('error', Boolean(isError));
  }

  setCompatibility(message) {
    if (this.compatibilityInfo) this.compatibilityInfo.textContent = message;
  }

  explainMediaError(err) {
    const name = err?.name || '';
    if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
      return 'Permiso denegado. Permití el uso de la cámara en el navegador.';
    }
    if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
      return 'No se encontró ninguna cámara disponible.';
    }
    if (name === 'NotReadableError' || name === 'TrackStartError') {
      return 'La cámara está siendo usada por otro programa o no se pudo iniciar.';
    }
    if (name === 'OverconstrainedError' || name === 'ConstraintNotSatisfiedError') {
      return 'La cámara no soporta esa configuración. Probá con otra cámara.';
    }
    if (name === 'SecurityError') {
      return 'El navegador bloqueó la cámara por seguridad. Usá localhost o HTTPS.';
    }
    return `No se pudo iniciar la cámara: ${err?.message || err || 'error desconocido'}`;
  }

  async open(autoStart = false) {
    if (!this.modal) return;
    this.modal.classList.remove('hidden');
    this.modal.classList.add('show');
    this.modal.setAttribute('aria-hidden', 'false');
    this.setStatus(autoStart ? 'Activando cámara...' : 'Presioná iniciar para activar la cámara.');
    await this.refreshDevices(false);
    setTimeout(() => {
      if (autoStart) {
        this.start();
      } else {
        this.startBtn?.focus();
      }
    }, 80);
  }

  openAndStart() {
    this.open(true);
  }

  close() {
    this.stop(false);
    if (this.modal) {
      this.modal.classList.add('hidden');
      this.modal.classList.remove('show');
      this.modal.setAttribute('aria-hidden', 'true');
    }
    this.onClose();
  }

  async refreshDevices(afterPermission = false) {
    if (!navigator.mediaDevices?.enumerateDevices || !this.deviceSelect) return;
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      this.devices = devices.filter(device => device.kind === 'videoinput');
      const current = this.selectedDeviceId || this.deviceSelect.value || '';
      this.deviceSelect.innerHTML = '';
      const autoOption = document.createElement('option');
      autoOption.value = '';
      autoOption.textContent = 'Automática / trasera si existe';
      this.deviceSelect.appendChild(autoOption);
      this.devices.forEach((device, index) => {
        const option = document.createElement('option');
        option.value = device.deviceId;
        option.textContent = device.label || `Cámara ${index + 1}${afterPermission ? '' : ' (permitir para ver nombre)'}`;
        this.deviceSelect.appendChild(option);
      });
      if ([...this.deviceSelect.options].some(option => option.value === current)) {
        this.deviceSelect.value = current;
      } else {
        this.deviceSelect.value = '';
      }
    } catch (err) {
      // No interrumpe el lector; algunos navegadores no dan nombres hasta que se conceda permiso.
    }
  }

  getVideoConstraints() {
    const deviceId = this.deviceSelect?.value || this.selectedDeviceId || '';
    if (deviceId) {
      return {
        deviceId: { exact: deviceId },
        width: { ideal: 1280 },
        height: { ideal: 720 },
      };
    }
    return {
      facingMode: { ideal: 'environment' },
      width: { ideal: 1280 },
      height: { ideal: 720 },
    };
  }

  async setupDetector() {
    this.detector = null;
    this.detectorMode = 'server';
    if ('BarcodeDetector' in window) {
      try {
        const supported = typeof BarcodeDetector.getSupportedFormats === 'function'
          ? await BarcodeDetector.getSupportedFormats()
          : [];
        const preferred = ['ean_13', 'ean_8', 'code_128', 'code_39', 'code_93', 'upc_a', 'upc_e', 'itf', 'codabar', 'qr_code'];
        const formats = supported.length ? preferred.filter(format => supported.includes(format)) : preferred;
        if (formats.length) {
          this.detector = new BarcodeDetector({ formats });
          this.detectorMode = 'native+server';
          return;
        }
      } catch (err) {
        this.detector = null;
      }
    }
    this.detectorMode = 'server';
  }

  async start() {
    if (!this.video || this.running) return;
    if (!navigator.mediaDevices?.getUserMedia) {
      this.setStatus('Este navegador no permite abrir la cámara. Usá Chrome, Edge, Firefox actualizado o lector USB.', true);
      this.setCompatibility('getUserMedia no está disponible en este navegador.');
      return;
    }
    if (!window.isSecureContext && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
      this.setStatus('El navegador exige HTTPS o localhost para usar la cámara.', true);
      this.setCompatibility('Abrí el POS desde localhost, 127.0.0.1 o configurá HTTPS si entrás desde otro equipo/celular.');
      return;
    }
    try {
      await this.setupDetector();
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: this.getVideoConstraints(),
        audio: false,
      });
      this.video.srcObject = this.stream;
      await this.video.play();
      this.running = true;
      this.lastServerDecodeAt = 0;
      this.scanFrameCount = 0;
      await this.refreshDevices(true);
      const modeText = this.detectorMode === 'native+server'
        ? 'Detector nativo del navegador + respaldo local por servidor.'
        : 'Respaldo local por servidor/OpenCV. Puede tardar un poco más.';
      this.setCompatibility(modeText);
      this.setStatus('Cámara activa. Acercá el código, enfocá bien y mantenelo dentro del cuadro.');
      this.loop();
    } catch (err) {
      // Si play() o la enumeración de cámaras falla después de getUserMedia,
      // liberar igualmente el stream para no dejar la cámara encendida.
      this.stop(false);
      this.setStatus(this.explainMediaError(err), true);
      this.setCompatibility('También podés usar lector USB o escribir el código manualmente y presionar Enter.');
    }
  }

  async restart() {
    this.stop(false);
    await new Promise(resolve => setTimeout(resolve, 120));
    this.start();
  }

  stop(updateStatus = true) {
    this.running = false;
    this.serverDecodeInFlight = false;
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    if (this.video) this.video.srcObject = null;
    if (updateStatus) this.setStatus('Cámara detenida.');
  }

  async emitCode(raw) {
    const code = String(raw || '').trim();
    if (!code) return;
    const now = Date.now();
    if (code === this.lastCode && now - this.lastAt < 1400) return;
    this.lastCode = code;
    this.lastAt = now;
    this.setStatus(`Código detectado: ${code}`);
    try { beep?.(); } catch (err) {}
    await this.onDetected(code);
  }

  async detectWithNative() {
    if (!this.detector || !this.video || this.video.readyState < 2) return null;
    try {
      const codes = await this.detector.detect(this.video);
      if (codes && codes.length) return String(codes[0].rawValue || '').trim();
    } catch (err) {
      // Si un frame falla, seguimos con el respaldo por servidor.
    }
    return null;
  }

  captureFrameDataUrl() {
    if (!this.video || this.video.readyState < 2) return '';
    const width = this.video.videoWidth || 1280;
    const height = this.video.videoHeight || 720;
    if (!width || !height) return '';
    const maxW = 960;
    const scale = width > maxW ? maxW / width : 1;
    this.canvas.width = Math.max(320, Math.round(width * scale));
    this.canvas.height = Math.max(240, Math.round(height * scale));
    const ctx = this.canvas.getContext('2d', { willReadFrequently: true });
    ctx.drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height);
    return this.canvas.toDataURL('image/jpeg', 0.72);
  }

  async detectWithServer() {
    const now = Date.now();
    if (this.serverDecodeInFlight || now - this.lastServerDecodeAt < 420) return null;
    this.lastServerDecodeAt = now;
    const image = this.captureFrameDataUrl();
    if (!image) return null;
    this.serverDecodeInFlight = true;
    try {
      const res = await fetch('/api/barcode/decode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image }),
      });
      if (!res.ok) return null;
      const data = await res.json();
      if (data && data.code) return String(data.code).trim();
      if (data && data.available === false) {
        this.setCompatibility(data.error || 'Respaldo por servidor no disponible.');
      }
    } catch (err) {
      // Evita cortar el escaneo si el respaldo no responde.
    } finally {
      this.serverDecodeInFlight = false;
    }
    return null;
  }

  async loop() {
    if (!this.running || !this.video) return;
    this.scanFrameCount += 1;
    let code = await this.detectWithNative();
    if (!code) {
      code = await this.detectWithServer();
    }
    if (code) {
      await this.emitCode(code);
    }
    if (this.running) requestAnimationFrame(() => this.loop());
  }
}

window.POSBarcodeScanner = POSBarcodeScanner;
