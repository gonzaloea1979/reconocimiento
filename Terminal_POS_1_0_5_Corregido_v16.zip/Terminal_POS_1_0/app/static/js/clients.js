let clients=[];
let clientSearchTimer = null;
let clientSearchController = null;
let clientSearchVersion = 0;
function clearClientForm(){ clientId.value=''; clientName.value=''; clientDocument.value=''; clientPhone.value=''; clientAddress.value=''; clientNotes.value=''; clientBalance.value=0; clientBalance.readOnly=false; document.getElementById('clientBalanceLabel').textContent='Saldo inicial'; clientPassword.value=''; clientPasswordWrap.classList.add('hidden'); clientMovements.innerHTML='<tr><td colspan="4" class="empty-state">Seleccioná un cliente</td></tr>'; }
async function loadClients(){
  const version = ++clientSearchVersion;
  if (clientSearchController) clientSearchController.abort();
  const controller = new AbortController();
  clientSearchController = controller;
  const query = clientSearch.value.trim();
  try {
    const result = await api('/api/clients' + (query ? `?q=${encodeURIComponent(query)}` : ''), { signal: controller.signal });
    if (version !== clientSearchVersion || clientSearch.value.trim() !== query) return;
    clients = result;
    clientsList.innerHTML = clients.length ? clients.map(c => `<div class="advanced-item ${Number(c.balance)>0?'warning-item':''}" onclick="editClient(${Number(c.id)})"><strong>${escapeHTML(c.name)}</strong><span>${escapeHTML(c.phone||'')} · Saldo ${formatMoney(c.balance)}</span></div>`).join('') : '<div class="empty-state">Sin clientes</div>';
  } catch (err) {
    if (err.name !== 'AbortError' && version === clientSearchVersion) showToast(err.message, true);
  } finally {
    if (clientSearchController === controller) clientSearchController = null;
  }
}
async function editClient(id){ const c=clients.find(x=>x.id===id); if(!c)return; clientId.value=c.id; clientName.value=c.name; clientDocument.value=c.document; clientPhone.value=c.phone; clientAddress.value=c.address; clientNotes.value=c.notes; clientBalance.value=c.balance; clientBalance.readOnly=true; document.getElementById('clientBalanceLabel').textContent='Saldo actual'; clientPasswordWrap.classList.remove('hidden'); const mov=await api(`/api/clients/${id}/movements`); clientMovements.innerHTML=mov.length?mov.map(m=>`<tr><td>${escapeHTML(m.created_at_formatted)}</td><td>${escapeHTML(m.movement_type)}</td><td>${formatMoney(m.amount)}</td><td>${escapeHTML(m.description||'')}</td></tr>`).join(''):'<tr><td colspan="4" class="empty-state">Sin movimientos</td></tr>'; }
function saveClient(){ return withOperationLock('client-save', '[onclick="saveClient()"]', saveClientOnce); }
async function saveClientOnce(){ try{ const data={name:clientName.value,document:clientDocument.value,phone:clientPhone.value,address:clientAddress.value,notes:clientNotes.value,balance:clientBalance.value,password:securityPasswordOrEmpty('clientPassword')}; if(clientId.value){ await postOperation('/api/clients/'+clientId.value,data,{method:'PUT',persist:false,allowRecord:true}); } else { await postOperation('/api/clients',data,{persist:false,allowRecord:true}); } showToast('Cliente guardado'); clearClientForm(); loadClients(); }catch(e){showToast(e.message,true);} }
function registerClientPayment() {
  return withOperationLock('client-payment', '[onclick="registerClientPayment()"]', registerClientPaymentOnce);
}
async function registerClientPaymentOnce(){ if(!clientId.value)return showToast('Seleccioná un cliente',true); try{ await postOperation(`/api/clients/${clientId.value}/payment`,{amount:clientPaymentAmount.value,description:clientPaymentDescription.value}); showToast('Pago registrado'); clientPaymentAmount.value=0; await loadClients(); await editClient(Number(clientId.value)); }catch(e){showToast(e.message,true);} }
function exportClients(){ window.location.href='/api/clients/export'; }
function exportClientStatement(){ if(!clientId.value)return showToast('Seleccioná un cliente',true); window.location.href=`/api/clients/${clientId.value}/export`; }
document.addEventListener('DOMContentLoaded',()=>{ markAdminBypassUI(); });
document.addEventListener('DOMContentLoaded',()=>{ clientSearch.addEventListener('input',()=>{
  clearTimeout(clientSearchTimer);
  if (clientSearchController) clientSearchController.abort();
  clientSearchVersion += 1;
  clientSearchTimer=setTimeout(loadClients,180);
}); clearClientForm(); loadClients(); });
