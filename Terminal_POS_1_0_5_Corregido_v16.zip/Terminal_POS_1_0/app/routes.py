"""Punto de entrada de rutas HTTP. Los endpoints se registran por dominio.

No modificar URLs públicas: mantienen el Blueprint original.
"""
from .route_core import *
from .route_modules.auth import *
from .route_modules.pages import *
from .route_modules.settings import *
from .route_modules.users import *
from .route_modules.products import *
from .route_modules.prices import *
from .route_modules.sales import *
from .route_modules.suppliers import *
from .route_modules.stock import *
from .route_modules.purchases import *
from .route_modules.cash import *
from .route_modules.clients import *
from .route_modules.reports import *
from .route_modules.dashboard import *
