from pathlib import Path
import sys


def get_base_dir() -> Path:
    """Devuelve la carpeta de trabajo del sistema.

    En modo normal usa la carpeta del proyecto.
    En modo EXE usa la carpeta donde está TerminalPOS.exe para que base de datos,
    backups, tickets, logs y uploads queden afuera del ejecutable y sean persistentes.
    """
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


BASE_DIR = get_base_dir()
INSTANCE_DIR = BASE_DIR / 'instance'
BACKUP_DIR = BASE_DIR / 'backups'
DATABASE = INSTANCE_DIR / 'pos.db'
UPLOAD_DIR = BASE_DIR / 'app' / 'static' / 'uploads'
TICKET_DIR = BASE_DIR / 'TICKET'
# Límite amplio para permitir logos/fotos tomados desde celular.
# Luego el sistema optimiza las imágenes antes de guardarlas.
MAX_CONTENT_LENGTH = 50 * 1024 * 1024
