"""Generación de tickets y etiquetas; bibliotecas PDF cargadas al usarse."""
from io import BytesIO
import math
import os
import subprocess
from flask import current_app, session
from ..db import get_db, get_settings, public_settings
from .dates import format_datetime_ar
from .iterators import iter_repeated_items


def ar_currency(value):
    try:
        value = float(value or 0)
    except (TypeError, ValueError):
        value = 0.0
    formatted = f"$ {value:,.2f}"
    return formatted.replace(',', 'X').replace('.', ',').replace('X', '.')

def safe_pdf_text(value):
    return str(value or '').replace('\n', ' ').strip()

def sale_pdf_filename(sale_id):
    return f"ticket_T-{int(sale_id):06d}.pdf"

def fetch_sale_for_ticket(sale_id):
    db = get_db()
    sale = db.execute('''
        SELECT s.*, COALESCE(c.name, '') AS client_name
        FROM sales s
        LEFT JOIN clients c ON c.id = s.client_id
        WHERE s.id=?
    ''', (sale_id,)).fetchone()
    if not sale:
        return None, []
    items = db.execute('''
        SELECT product_id, product_name, unit_price, quantity, line_total
        FROM sale_items
        WHERE sale_id=?
        ORDER BY id ASC
    ''', (sale_id,)).fetchall()
    return sale, items

def ticket_flag(settings, key, default='1'):
    return str(settings.get(key, default)).lower() in ('1', 'true', 'on', 'yes', 'si', 'sí')

def ticket_number_value(settings, key, default, min_value, max_value):
    try:
        value = float(str(settings.get(key, default)).replace(',', '.'))
    except (TypeError, ValueError):
        value = float(default)
    return max(min_value, min(max_value, value))

def ticket_page_size(settings):
    from reportlab.lib.pagesizes import A5
    from reportlab.lib.units import mm

    size = (settings.get('ticket_pdf_size') or 'A5').strip()
    if size == '80mm':
        return 80 * mm, 210 * mm, '80mm'
    if size == '58mm':
        return 58 * mm, 210 * mm, '58mm'
    return A5[0], A5[1], 'A5'

def ticket_font_multiplier(settings):
    scale = (settings.get('ticket_font_scale') or 'normal').lower()
    if scale == 'chico':
        return 0.88
    if scale == 'grande':
        return 1.14
    return 1.0

def ticket_accent(settings):
    from reportlab.lib import colors

    raw = (settings.get('ticket_accent_color') or '#0F172A').strip()
    try:
        return colors.HexColor(raw)
    except Exception:
        return colors.HexColor('#0F172A')

def draw_qr_on_pdf(canvas_obj, value, x, y, size):
    from reportlab.graphics.barcode import qr
    from reportlab.graphics.shapes import Drawing
    from reportlab.graphics import renderPDF

    if not value:
        return False
    try:
        qr_widget = qr.QrCodeWidget(value)
        bounds = qr_widget.getBounds()
        qr_width = bounds[2] - bounds[0]
        qr_height = bounds[3] - bounds[1]
        drawing = Drawing(size, size, transform=[size / qr_width, 0, 0, size / qr_height, 0, 0])
        drawing.add(qr_widget)
        renderPDF.draw(drawing, canvas_obj, x, y)
        return True
    except Exception:
        return False

def ticket_qr_value(settings):
    value = (settings.get('ticket_qr_value') or '').strip()
    if value:
        return value
    phone = ''.join(ch for ch in (settings.get('business_phone') or '') if ch.isdigit())
    if phone:
        # Si el comercio cargó teléfono, el QR abre WhatsApp o queda como número simple si no corresponde.
        return f'https://wa.me/{phone}'
    return ''

def build_a5_ticket_pdf(sale_id):
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas
    from reportlab.lib.utils import ImageReader

    """Genera el PDF del ticket según la configuración elegida en el módulo Configuración > Diseño ticket."""
    sale, items = fetch_sale_for_ticket(sale_id)
    if not sale:
        raise ValueError('Venta no encontrada')

    settings = public_settings(get_settings())
    ticket_dir = current_app.config['TICKET_DIR']
    ticket_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = ticket_dir / sale_pdf_filename(sale_id)

    width, height, page_mode = ticket_page_size(settings)
    design = (settings.get('ticket_design') or 'moderno').lower()
    font_mul = ticket_font_multiplier(settings)
    margin_mm = ticket_number_value(settings, 'ticket_margin_mm', 12 if page_mode == 'A5' else 5, 3, 18)
    if page_mode in ('80mm', '58mm'):
        margin_mm = min(margin_mm, 6)
    margin = margin_mm * mm
    accent = ticket_accent(settings)

    c = canvas.Canvas(str(pdf_path), pagesize=(width, height))
    y = height - margin
    page_bottom = margin
    line_h = (5.2 if design != 'compacto' else 4.4) * mm * font_mul

    def fs(size):
        return max(5, round(size * font_mul, 1))

    def draw_center(text_value, y_pos, font='Helvetica', size=10, bold=False):
        c.setFont('Helvetica-Bold' if bold else font, fs(size))
        c.drawCentredString(width / 2, y_pos, safe_pdf_text(text_value))

    def draw_left(text_value, y_pos, x=None, font='Helvetica', size=8, bold=False):
        c.setFont('Helvetica-Bold' if bold else font, fs(size))
        c.drawString(x if x is not None else margin, y_pos, safe_pdf_text(text_value))

    def draw_right(text_value, y_pos, x=None, font='Helvetica', size=8, bold=False):
        c.setFont('Helvetica-Bold' if bold else font, fs(size))
        c.drawRightString(x or (width - margin), y_pos, safe_pdf_text(text_value))

    def new_page_if_needed(required=22*mm):
        nonlocal y
        if y - required < page_bottom:
            c.showPage()
            y = height - margin
            draw_center(f"Ticket T-{sale_id:06d} - continuación", y, size=8, bold=True)
            y -= 8 * mm

    def draw_separator(offset=0):
        c.setStrokeColor(colors.HexColor('#D1D5DB'))
        c.line(margin, y + offset, width - margin, y + offset)
        c.setStrokeColor(colors.black)

    narrow = page_mode in ('80mm', '58mm')
    logo_path = settings.get('logo_path') or ''
    if ticket_flag(settings, 'ticket_show_logo') and logo_path:
        candidate = current_app.root_path + '/static/' + logo_path.replace('\\', '/')
        if os.path.exists(candidate):
            try:
                logo_limit = ticket_number_value(settings, 'ticket_logo_size_mm', 22, 8, 45) * mm
                if narrow:
                    logo_limit = min(logo_limit, 22 * mm)

                img_reader = ImageReader(candidate)
                img_w_px, img_h_px = img_reader.getSize()
                if img_w_px > 0 and img_h_px > 0:
                    aspect = img_w_px / img_h_px
                    max_h = logo_limit
                    max_w = min(width - (2 * margin), logo_limit * (2.85 if not narrow else 2.15))
                    draw_w = max_w
                    draw_h = draw_w / aspect
                    if draw_h > max_h:
                        draw_h = max_h
                        draw_w = draw_h * aspect

                    x_logo = (width - draw_w) / 2
                    c.drawImage(img_reader, x_logo, y - draw_h, width=draw_w, height=draw_h, mask='auto')
                    y -= draw_h + (2 if narrow else 3) * mm
            except Exception:
                pass

    if ticket_flag(settings, 'ticket_show_business_name'):
        draw_center(settings.get('business_name') or 'POS Local', y, size=14 if narrow else 16, bold=True)
        y -= (5 if narrow else 6) * mm
    if ticket_flag(settings, 'ticket_show_cuit') and settings.get('business_cuit'):
        draw_center(f"CUIT: {settings.get('business_cuit')}", y, size=7 if narrow else 8)
        y -= (3.5 if narrow else 4) * mm
    if ticket_flag(settings, 'ticket_show_address') and settings.get('business_address'):
        draw_center(settings.get('business_address'), y, size=7 if narrow else 8)
        y -= (3.5 if narrow else 4) * mm
    if ticket_flag(settings, 'ticket_show_phone') and settings.get('business_phone'):
        draw_center(f"Tel: {settings.get('business_phone')}", y, size=7 if narrow else 8)
        y -= (3.5 if narrow else 4) * mm
    if ticket_flag(settings, 'ticket_show_email') and settings.get('business_email'):
        draw_center(settings.get('business_email'), y, size=7 if narrow else 8)
        y -= (3.5 if narrow else 4) * mm

    y -= (2 if narrow else 3) * mm
    draw_separator()
    y -= (5 if narrow else 7) * mm

    ticket_title = settings.get('ticket_title') or 'TICKET DE COMPRA'
    draw_center(ticket_title, y, size=10 if narrow else 13, bold=True)
    y -= (5 if narrow else 6) * mm
    draw_left('N°:', y, size=7 if narrow else 8, bold=True)
    draw_left(f"T-{sale_id:06d}", y, x=margin+(8 if narrow else 12)*mm, size=7 if narrow else 8)
    draw_right(format_datetime_ar(sale['created_at']), y, size=7 if narrow else 8)
    y -= (4 if narrow else 5) * mm
    if ticket_flag(settings, 'ticket_show_cashier'):
        draw_left('Cajero:', y, size=7 if narrow else 8, bold=True)
        draw_left(sale['cashier_name'] if 'cashier_name' in sale.keys() and sale['cashier_name'] else session.get('username', 'admin'), y, x=margin+(13 if narrow else 17)*mm, size=7 if narrow else 8)
        y -= (4 if narrow else 5) * mm
    if ticket_flag(settings, 'ticket_show_payment'):
        draw_left('Pago:', y, size=7 if narrow else 8, bold=True)
        draw_left(sale['payment_method'], y, x=margin+(10 if narrow else 16)*mm, size=7 if narrow else 8)
        y -= (4 if narrow else 5) * mm

    client_name = sale['client_name'] if 'client_name' in sale.keys() and sale['client_name'] else 'Consumidor final'
    draw_left('Cliente:', y, size=7 if narrow else 8, bold=True)
    draw_left(client_name, y, x=margin+(14 if narrow else 18)*mm, size=7 if narrow else 8)
    y -= (5 if narrow else 7) * mm

    header_h = (6 if narrow else 7) * mm
    if design == 'moderno':
        c.setFillColor(colors.HexColor('#F3F4F6'))
        c.roundRect(margin, y-header_h+1*mm, width-2*margin, header_h, 1.5*mm, fill=1, stroke=0)
        c.setFillColor(colors.black)
    else:
        draw_separator(offset=-1*mm)

    if narrow:
        qty_x = width - margin - 24*mm
        unit_x = width - margin - 12*mm
        total_x = width - margin
        draw_left('Producto', y-3*mm, size=7, bold=True)
        draw_right('Cant', y-3*mm, x=qty_x, size=7, bold=True)
        draw_right('Total', y-3*mm, x=total_x, size=7, bold=True)
    else:
        qty_x = width - 57*mm
        unit_x = width - 31*mm
        total_x = width - margin
        draw_left('Producto', y-2.8*mm, size=8, bold=True)
        draw_right('Cant.', y-2.8*mm, x=qty_x, size=8, bold=True)
        draw_right('Unit.', y-2.8*mm, x=unit_x, size=8, bold=True)
        draw_right('Total', y-2.8*mm, x=total_x, size=8, bold=True)
    y -= (8 if narrow else 10) * mm

    def wrap_pdf_text(text_value, max_width, font_name='Helvetica', font_size=8):
        """Divide el texto en todas las líneas necesarias sin cortar el nombre del producto."""
        text_value = safe_pdf_text(text_value)
        if not text_value:
            return ['']

        lines = []
        current_line = ''

        for word in text_value.split():
            candidate = word if not current_line else f"{current_line} {word}"
            if c.stringWidth(candidate, font_name, font_size) <= max_width:
                current_line = candidate
                continue

            if current_line:
                lines.append(current_line)
                current_line = ''

            # Si una palabra sola es demasiado larga, se parte por caracteres
            # para que tampoco se pierda información del producto.
            if c.stringWidth(word, font_name, font_size) <= max_width:
                current_line = word
            else:
                chunk = ''
                for char in word:
                    test_chunk = f"{chunk}{char}"
                    if not chunk or c.stringWidth(test_chunk, font_name, font_size) <= max_width:
                        chunk = test_chunk
                    else:
                        lines.append(chunk)
                        chunk = char
                current_line = chunk

        if current_line:
            lines.append(current_line)

        return lines or ['']

    for item in items:
        product_font_size = fs(7 if narrow else 8)
        product_col_width = max(18*mm, qty_x - margin - (3*mm if narrow else 4*mm))
        name_lines = wrap_pdf_text(item['product_name'], product_col_width, 'Helvetica', product_font_size)
        required_height = max(line_h, len(name_lines) * line_h) + 2*mm
        new_page_if_needed(required_height + (2*mm if len(name_lines) > 1 else 0))

        qty = float(item['quantity'] or 0)
        qty_txt = str(int(qty)) if qty.is_integer() else f"{qty:.2f}".replace('.', ',')

        # Primera línea: nombre + cantidades/importes.
        draw_left(name_lines[0], y, size=7 if narrow else 8)
        draw_right(qty_txt, y, x=qty_x, size=7 if narrow else 8)
        if not narrow:
            draw_right(ar_currency(item['unit_price']), y, x=unit_x, size=8)
        draw_right(ar_currency(item['line_total']), y, x=total_x, size=7 if narrow else 8, bold=True)
        y -= line_h

        # Líneas siguientes: continúan el nombre completo del producto.
        for extra_line in name_lines[1:]:
            new_page_if_needed(line_h + 2*mm)
            draw_left(extra_line, y, size=7 if narrow else 8)
            y -= line_h

        if len(name_lines) > 1:
            y -= 1*mm

    y -= 2 * mm
    new_page_if_needed(38*mm if not narrow else 32*mm)
    draw_separator()
    y -= (6 if narrow else 7) * mm

    if ticket_flag(settings, 'ticket_show_received_change'):
        draw_left('Recibido', y, size=8 if narrow else 9)
        draw_right(ar_currency(sale['amount_received']), y, size=8 if narrow else 9)
        y -= (4.5 if narrow else 5) * mm
        draw_left('Vuelto', y, size=8 if narrow else 9)
        draw_right(ar_currency(sale['change_amount']), y, size=8 if narrow else 9)
        y -= (6 if narrow else 8) * mm

    total_box_h = (12 if narrow else 14) * mm
    if design == 'clasico':
        c.setFillColor(colors.black)
        draw_left('TOTAL', y-7*mm, x=margin, size=10 if narrow else 11, bold=True)
        draw_right(ar_currency(sale['total']), y-7.5*mm, x=width-margin, size=14 if narrow else 16, bold=True)
        y -= total_box_h + 4 * mm
    else:
        c.setFillColor(accent)
        c.roundRect(margin, y-total_box_h+2*mm, width-2*margin, total_box_h, 2*mm, fill=1, stroke=0)
        c.setFillColor(colors.white)
        draw_left('TOTAL', y-7.5*mm, x=margin+3*mm, size=9 if narrow else 11, bold=True)
        draw_right(ar_currency(sale['total']), y-8*mm, x=width-margin-3*mm, size=14 if narrow else 16, bold=True)
        y -= total_box_h + 5 * mm

    c.setFillColor(colors.black)

    qr_value = ticket_qr_value(settings)
    if ticket_flag(settings, 'ticket_show_qr', '0') and qr_value:
        qr_size = (20 if narrow else 24) * mm
        new_page_if_needed(qr_size + (13 if narrow else 15) * mm)
        x_qr = (width - qr_size) / 2
        if draw_qr_on_pdf(c, qr_value, x_qr, y - qr_size, qr_size):
            y -= qr_size + (3 if narrow else 4) * mm
            label = settings.get('ticket_qr_label') or 'Escaneá para contactarnos'
            draw_center(label, y, size=6.5 if narrow else 7.5)
            y -= (5 if narrow else 6) * mm

    if ticket_flag(settings, 'ticket_show_footer'):
        footer = settings.get('ticket_footer') or 'Gracias por su compra'
        draw_center(footer, max(y, page_bottom + 5*mm), size=7 if narrow else 8)
    c.save()
    return pdf_path

def print_pdf_file(pdf_path):
    path = str(pdf_path)
    if os.name == 'nt':
        try:
            os.startfile(path, 'print')  # type: ignore[attr-defined]
            return True, 'Enviado a la impresora predeterminada de Windows.'
        except Exception as exc:
            current_app.logger.exception('No se pudo imprimir el PDF en Windows')
            return False, 'El PDF se guardó, pero no se pudo enviar a la impresora. Revisá la impresora predeterminada.'
    try:
        subprocess.Popen(['lp', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True, 'Enviado a impresión con lp.'
    except Exception as exc:
        current_app.logger.exception('No se pudo enviar el PDF al servicio de impresión')
        return False, 'El PDF se guardó, pero no se pudo enviar a la impresora. Revisá el servicio de impresión.'

def clamp_int(value, default, min_value, max_value):
    try:
        value = int(float(str(value).replace(',', '.')))
    except (TypeError, ValueError):
        value = default
    return max(min_value, min(max_value, value))

def clamp_float(value, default, min_value, max_value):
    try:
        value = float(str(value).replace(',', '.'))
    except (TypeError, ValueError):
        value = default
    return max(min_value, min(max_value, value))

LABEL_FONT_MAP = {
    'helvetica': ('Helvetica', 'Helvetica-Bold', 'Helvetica / Arial'),
    'arial': ('Helvetica', 'Helvetica-Bold', 'Helvetica / Arial'),
    'times': ('Times-Roman', 'Times-Bold', 'Times / Serif'),
    'times-roman': ('Times-Roman', 'Times-Bold', 'Times / Serif'),
    'courier': ('Courier', 'Courier-Bold', 'Courier / Monoespaciada'),
}

def label_font_pair(font_family):
    key = str(font_family or 'Helvetica').strip().lower()
    return LABEL_FONT_MAP.get(key, LABEL_FONT_MAP['helvetica'])

def best_label_grid(labels_per_sheet):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm

    """Devuelve columnas y filas para repartir etiquetas en una hoja A4 vertical.
    Prioriza que la cantidad de celdas sea exactamente la pedida; si no existe una
    distribución cómoda, usa la capacidad inmediata superior y deja celdas vacías.
    """
    labels_per_sheet = clamp_int(labels_per_sheet, 24, 1, 80)
    # En A4 vertical las etiquetas de precio suelen funcionar mejor anchas que altas.
    target_ratio = 1.65
    candidates = []
    for rows in range(1, labels_per_sheet + 1):
        cols = math.ceil(labels_per_sheet / rows)
        capacity = rows * cols
        if capacity < labels_per_sheet or capacity > labels_per_sheet + max(4, labels_per_sheet // 5):
            continue
        page_w, page_h = A4
        usable_w = page_w - 16 * mm
        usable_h = page_h - 16 * mm
        label_w = usable_w / cols
        label_h = usable_h / rows
        ratio = label_w / label_h if label_h else 1
        exact_penalty = 0 if capacity == labels_per_sheet else 2 + (capacity - labels_per_sheet) * 0.2
        skinny_penalty = 0 if 0.72 <= ratio <= 3.2 else 1.5
        score = abs(ratio - target_ratio) + exact_penalty + skinny_penalty
        candidates.append((score, cols, rows, capacity))
    if not candidates:
        return 3, 8, 24
    candidates.sort(key=lambda x: (x[0], x[3], x[2]))
    _, cols, rows, capacity = candidates[0]
    return cols, rows, capacity

def wrap_pdf_text(text, max_width, font_name='Helvetica', font_size=10):
    from reportlab.pdfbase import pdfmetrics

    text = safe_pdf_text(text)
    if not text:
        return ['']
    words = text.split()
    lines = []
    current = ''
    # pdfmetrics evita crear un Canvas temporal en cada llamada.
    for word in words:
        candidate = word if not current else f'{current} {word}'
        if pdfmetrics.stringWidth(candidate, font_name, font_size) <= max_width:
            current = candidate
        else:
            if current:
                lines.append(current)
            # Si la palabra sola no entra, la partimos sin cortar el flujo.
            if pdfmetrics.stringWidth(word, font_name, font_size) > max_width:
                chunk = ''
                for char in word:
                    candidate_chunk = f'{chunk}{char}'
                    if not chunk or pdfmetrics.stringWidth(candidate_chunk, font_name, font_size) <= max_width:
                        chunk = candidate_chunk
                    else:
                        lines.append(chunk)
                        chunk = char
                current = chunk
            else:
                current = word
    if current:
        lines.append(current)
    return lines or ['']

def build_product_labels_pdf(items, labels_per_sheet=24, show_guides=True, font_family='Helvetica', name_font_size=10, price_font_size=18):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas

    if not items:
        raise ValueError('Agregá al menos un producto para imprimir etiquetas.')

    db = get_db()

    def valid_label_groups():
        # Consultar y expandir de manera perezosa: no se crea una lista con una
        # referencia por etiqueta, incluso cuando se solicitan muchas copias.
        for item in items:
            if not isinstance(item, dict):
                continue
            try:
                product_id = int(item.get('product_id') or 0)
            except (TypeError, ValueError):
                continue
            quantity = clamp_int(item.get('quantity'), 1, 1, 999)
            product = db.execute(
                'SELECT id, barcode, name, sale_price FROM products WHERE id=?',
                (product_id,)
            ).fetchone()
            if product:
                yield product, quantity

    label_iterator = iter(iter_repeated_items(valid_label_groups()))
    sentinel = object()
    pending_product = next(label_iterator, sentinel)
    if pending_product is sentinel:
        raise ValueError('No se encontraron productos válidos para imprimir.')

    labels_per_sheet = clamp_int(labels_per_sheet, 24, 1, 80)
    body_font, bold_font, _font_label = label_font_pair(font_family)
    configured_name_font = clamp_float(name_font_size, 10, 6, 28)
    configured_price_font = clamp_float(price_font_size, 18, 8, 42)
    cols, rows, capacity = best_label_grid(labels_per_sheet)
    page_w, page_h = A4
    margin = 8 * mm
    gap = 2 * mm
    usable_w = page_w - (2 * margin) - (gap * (cols - 1))
    usable_h = page_h - (2 * margin) - (gap * (rows - 1))
    label_w = usable_w / cols
    label_h = usable_h / rows

    output = BytesIO()
    c = canvas.Canvas(output, pagesize=A4)
    c.setTitle('Etiquetas de productos')

    def draw_label(product, x, y, w, h):
        inner = 3 * mm
        if show_guides:
            c.setStrokeColor(colors.HexColor('#CBD5E1'))
            c.setLineWidth(0.35)
            c.roundRect(x, y, w, h, 2 * mm, stroke=1, fill=0)

        name = safe_pdf_text(product['name']).upper()
        price = ar_currency(product['sale_price'])
        code = safe_pdf_text(product['barcode'])
        center_x = x + (w / 2)

        max_name_font = max(6.5, min(28, h / mm * 0.28))
        max_price_font = max(8, min(42, h / mm * 0.48))
        name_font = min(configured_name_font, max_name_font)
        price_font = min(configured_price_font, max_price_font)
        code_font = max(5.2, min(7.4, h / mm * 0.11))

        name_lines = wrap_pdf_text(name, w - 2 * inner, bold_font, name_font)[:3]
        total_name_height = len(name_lines) * (name_font + 1.8)
        price_height = price_font + 4
        code_height = code_font + 2 if code else 0
        block_height = total_name_height + price_height + code_height + 4
        start_y = y + (h + block_height) / 2 - name_font

        c.setFillColor(colors.black)
        c.setFont(bold_font, name_font)
        yy = start_y
        for line in name_lines:
            c.drawCentredString(center_x, yy, line)
            yy -= name_font + 1.8

        yy -= 1.5
        c.setFont(bold_font, price_font)
        c.drawCentredString(center_x, yy - price_font * 0.25, price)
        yy -= price_font + 2

        if code:
            c.setFillColor(colors.HexColor('#475569'))
            c.setFont(body_font, code_font)
            c.drawCentredString(center_x, max(y + inner, yy), code)
            c.setFillColor(colors.black)

    # Aunque la grilla pueda tener alguna celda extra para mantener buenas proporciones,
    # se imprimen como máximo las etiquetas configuradas por hoja. Así la vista previa
    # y el PDF respetan exactamente la cantidad que eligió el usuario.
    while pending_product is not sentinel:
        printed_on_page = 0
        for row in range(rows):
            for col in range(cols):
                cell_number = (row * cols) + col
                if cell_number >= labels_per_sheet:
                    continue
                if pending_product is sentinel:
                    break
                x = margin + col * (label_w + gap)
                y = page_h - margin - (row + 1) * label_h - row * gap
                draw_label(pending_product, x, y, label_w, label_h)
                printed_on_page += 1
                pending_product = next(label_iterator, sentinel)
            if pending_product is sentinel:
                break
        if printed_on_page == 0:
            break
        if pending_product is not sentinel:
            c.showPage()

    c.save()
    output.seek(0)
    return output
