"""Iteradores pequeños para evitar listas intermedias de gran tamaño."""


def iter_repeated_items(groups):
    """Produce cada elemento la cantidad indicada sin materializar copias.

    ``groups`` es un iterable de pares (elemento, cantidad). La función es
    perezosa: solicita el siguiente grupo solamente cuando el consumidor lo
    necesita y conserva una única referencia por grupo activo.
    """
    for item, quantity in groups:
        for _ in range(max(0, int(quantity))):
            yield item
