"""Lecturas de varias consultas que deben representar el mismo instante."""
from functools import wraps
from ..db import get_db

def consistent_read(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        db = get_db()
        owned = not db.in_transaction
        if owned:
            db.execute('BEGIN')
        try:
            return view(*args, **kwargs)
        finally:
            if owned:
                db.rollback()
    return wrapped
