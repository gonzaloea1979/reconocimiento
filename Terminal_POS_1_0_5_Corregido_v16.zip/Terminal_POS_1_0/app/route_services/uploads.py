"""Limpieza conservadora de archivos creados por una petición fallida."""
from contextlib import closing
from pathlib import Path
import sqlite3
from flask import current_app, g

def track_upload(path):
    pending = g.setdefault('_pos_new_uploads', [])
    pending.append(Path(path))

def cleanup_uncommitted_uploads():
    pending = g.pop('_pos_new_uploads', [])
    if not pending:
        return
    from ..db import connect_database
    root = Path(current_app.config['UPLOAD_DIR']).resolve()
    try:
        with closing(connect_database(current_app.config['DATABASE'], read_only=True)) as db:
            for path in pending:
                if path.parent.resolve() != root or path.is_symlink():
                    continue
                relative = 'uploads/' + path.name
                referenced = db.execute('SELECT 1 FROM products WHERE photo_path=? LIMIT 1', (relative,)).fetchone()
                referenced = referenced or db.execute("SELECT 1 FROM app_settings WHERE key='logo_path' AND value=?", (relative,)).fetchone()
                if not referenced:
                    try:
                        path.unlink(missing_ok=True)
                    except OSError:
                        current_app.logger.warning('No se pudo retirar una carga sin confirmar: %s', path.name)
    except (sqlite3.Error, OSError):
        # Si no se puede verificar la referencia, conservar el archivo.
        current_app.logger.exception('No se pudo verificar la limpieza de archivos recién cargados')
