"""Servicios compartidos independientes de las rutas HTTP."""
