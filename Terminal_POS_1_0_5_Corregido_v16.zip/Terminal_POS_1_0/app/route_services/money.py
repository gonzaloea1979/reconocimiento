from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_UP
from ..db import get_settings

def money(value):
    """Normaliza importes a dos decimales con redondeo comercial HALF_UP.

    Decimal(str(...)) evita errores binarios como round(2.675, 2) == 2.67.
    Los valores no numéricos o no finitos se convierten en cero para conservar
    el comportamiento tolerante de esta función auxiliar; los endpoints usan
    strict_number para rechazar entradas inválidas.
    """
    try:
        number = Decimal(str(value or 0).strip())
        if not number.is_finite():
            return 0.0
        return float(number.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))
    except (InvalidOperation, TypeError, ValueError, OverflowError):
        return 0.0

def money_product(left, right):
    """Multiplica importes/cantidades con Decimal y redondea una sola vez a centavos."""
    try:
        a = Decimal(str(left if left is not None else 0).strip())
        b = Decimal(str(right if right is not None else 0).strip())
        if not a.is_finite() or not b.is_finite():
            raise ValueError('Los valores deben ser números finitos')
        if a.copy_abs() > Decimal('999999999999.99') or b.copy_abs() > Decimal('999999999999.99'):
            raise ValueError('Los valores exceden el rango seguro')
        result = (a * b).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        if result.copy_abs() > Decimal('999999999999.99'):
            raise ValueError('El importe excede el rango que conserva centavos')
        return float(result)
    except (InvalidOperation, TypeError, ValueError, OverflowError):
        raise ValueError('No se pudo calcular el importe de la línea')

def money_sum(values):
    """Suma importes con Decimal y redondea el total una sola vez."""
    try:
        total = Decimal('0')
        for value in values:
            number = Decimal(str(value if value is not None else 0).strip())
            if not number.is_finite():
                raise ValueError('Los importes deben ser números finitos')
            if number.copy_abs() > Decimal('999999999999.99'):
                raise ValueError('El importe excede el rango seguro')
            total += number
        result = total.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        if result.copy_abs() > Decimal('999999999999.99'):
            raise ValueError('El total excede el rango que conserva centavos')
        return float(result)
    except (InvalidOperation, TypeError, ValueError, OverflowError):
        raise ValueError('No se pudo calcular el total')

def strict_number(value, label, default=None):
    """Valida importes/cantidades sin convertir entradas inválidas en cero."""
    if value is None or value == '':
        if default is not None:
            return default
        raise ValueError(f'{label}: ingresá un número válido')
    try:
        number = Decimal(str(value).strip())
    except (InvalidOperation, TypeError, ValueError, OverflowError):
        raise ValueError(f'{label}: ingresá un número válido')
    if not number.is_finite():
        raise ValueError(f'{label}: ingresá un número finito')
    try:
        # SQLite REAL y JavaScript usan doubles: reservar margen para centavos.
        if number.copy_abs() > Decimal('999999999999.99'):
            raise ValueError(f'{label}: el máximo admitido es 999999999999.99')
        return float(number.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))
    except InvalidOperation:
        raise ValueError(f'{label}: ingresá un número válido')

def normalize_rounding_mode(value):
    # Un valor no textual (número/lista) no es un modo válido: se cae al
    # predeterminado en lugar de romper con AttributeError en .strip().
    mode = value.strip().lower() if isinstance(value, str) else ''
    return mode if mode in ('none', 'nearest', 'up', 'down') else 'none'

def apply_price_rounding(value, rounding_mode='none', rounding_multiple=1):
    """Aplica el redondeo configurado usando aritmética decimal exacta."""
    mode = normalize_rounding_mode(rounding_mode)
    try:
        price = Decimal(str(value or 0))
        multiple = Decimal(str(money(rounding_multiple) or 1))
        if not price.is_finite() or not multiple.is_finite():
            return 0.0
    except (InvalidOperation, TypeError, ValueError, OverflowError):
        return 0.0
    if mode == 'none' or multiple <= 0:
        return float(price)
    quotient = price / multiple
    if mode == 'up':
        steps = quotient.to_integral_value(rounding=ROUND_CEILING)
    elif mode == 'down':
        steps = quotient.to_integral_value(rounding=ROUND_FLOOR)
    else:
        # ROUND_HALF_UP evita los errores binarios y el redondeo bancario.
        steps = quotient.to_integral_value(rounding=ROUND_HALF_UP)
    return float(steps * multiple)

def calculate_prices(cost_without_tax, iva_percent, gross_income_percent, margin_percent, rounding_mode='none', rounding_multiple=1):
    """Calcula costo y precio sin operaciones intermedias en punto flotante."""
    try:
        cost = Decimal(str(money(cost_without_tax)))
        iva = Decimal(str(money(iva_percent)))
        gross = Decimal(str(money(gross_income_percent)))
        margin = Decimal(str(money(margin_percent)))
        if not all(number.is_finite() for number in (cost, iva, gross, margin)):
            raise ValueError('Los valores del precio deben ser finitos')
    except (InvalidOperation, TypeError, ValueError, OverflowError):
        raise ValueError('Los valores del precio deben ser números válidos')
    hundred = Decimal('100')
    total_cost_raw = cost + (cost * iva / hundred) + (cost * gross / hundred)
    sale_price_raw = total_cost_raw + (total_cost_raw * margin / hundred)
    sale_price = apply_price_rounding(sale_price_raw, rounding_mode, rounding_multiple)
    # No usar money() tolerante aquí: un desborde nunca debe crear precio cero.
    results = []
    for value in (total_cost_raw, sale_price):
        number = Decimal(str(value)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        if not number.is_finite() or number.copy_abs() > Decimal('999999999999.99'):
            raise ValueError('El costo o precio calculado supera el máximo de 999999999999.99')
        results.append(float(number))
    return tuple(results)

def get_global_product_rounding():
    settings = get_settings()
    return (
        normalize_rounding_mode(settings.get('product_rounding_mode')),
        money(settings.get('product_rounding_multiple')) or 1,
    )
