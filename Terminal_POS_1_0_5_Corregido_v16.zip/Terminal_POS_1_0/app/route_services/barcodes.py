"""Lectura local de códigos; OpenCV y NumPy se importan al decodificar."""
import logging
import re

def clean_detected_barcode(value):
    raw = str(value or '').strip()
    if not raw:
        return ''
    # Quita caracteres de control que pueden aparecer en algunas lecturas.
    raw = re.sub(r'[\x00-\x1f\x7f]+', '', raw).strip()
    return raw[:128]

def _decode_1d_candidates(result):
    """Extrae los textos que devuelve ``detectAndDecode``.

    El resultado varía entre versiones de OpenCV: puede ser un string, una tupla
    o una tupla con listas internas. Normalizarlo en un solo lugar evita repetir
    el mismo bucle en cada intento de decodificación.
    """
    if isinstance(result, str):
        return [result]
    if not isinstance(result, tuple):
        return []
    candidates = []
    for part in result:
        if isinstance(part, str):
            candidates.append(part)
        elif isinstance(part, (list, tuple)):
            candidates.extend(x for x in part if isinstance(x, str))
    return candidates

def _decode_barcode_frame(cv2, frame):
    """Intenta decodificar un frame (1D, QR y reintento en gris). Devuelve el código o ''."""
    try:
        detector = cv2.barcode_BarcodeDetector()
        result = detector.detectAndDecode(frame)
        for candidate in _decode_1d_candidates(result):
            code = clean_detected_barcode(candidate)
            if code:
                return code
    except Exception:
        pass

    # QR como apoyo adicional.
    try:
        qr_detector = cv2.QRCodeDetector()
        qr_code, _points, _straight = qr_detector.detectAndDecode(frame)
        qr_code = clean_detected_barcode(qr_code)
        if qr_code:
            return qr_code
    except Exception:
        pass

    # Segundo intento con escala de grises y contraste suave.
    try:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)
        detector = cv2.barcode_BarcodeDetector()
        result = detector.detectAndDecode(cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR))
        for candidate in _decode_1d_candidates(result):
            code = clean_detected_barcode(candidate)
            if code:
                return code
    except Exception:
        pass

    return ''

def decode_barcode_image_bytes(raw_bytes):
    """Decodifica un frame enviado desde el navegador.

    Usa OpenCV si está instalado. Se mantiene dentro de la app local para que el
    lector funcione aun cuando el navegador no soporte BarcodeDetector.
    """
    if not raw_bytes:
        return '', 'No llegó imagen para decodificar.'
    try:
        import numpy as np
        import cv2
    except Exception:
        return '', 'Instalá opencv-python para activar el respaldo local por servidor.'

    try:
        data = np.frombuffer(raw_bytes, dtype=np.uint8)
        frame = cv2.imdecode(data, cv2.IMREAD_COLOR)
        if frame is None:
            return '', 'No se pudo leer la imagen enviada por la cámara.'
        return _decode_barcode_frame(cv2, frame), ''
    except Exception as exc:
        logging.getLogger(__name__).exception('No se pudo decodificar la imagen de la cámara')
        return '', 'No se pudo procesar la imagen. Volvé a capturar el código con buena iluminación.'
