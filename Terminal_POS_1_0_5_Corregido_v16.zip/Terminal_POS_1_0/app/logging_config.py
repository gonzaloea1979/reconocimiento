"""Diagnósticos sin cuerpos HTTP, consultas, mensajes de excepción ni variables."""
import logging
import re
import sqlite3
from pathlib import Path
from traceback import walk_tb


def exception_diagnostic(info):
    """Conservar tipo, función y línea; omitir valores, código fuente y rutas completas."""
    _kind, error, tb = info
    lines = ['Detalle técnico sin datos de la solicitud:']
    visited = set()
    for _ in range(8):
        if error is None or id(error) in visited:
            break
        visited.add(id(error))
        codes = []
        if isinstance(error, OSError):
            for key in ('errno', 'winerror'):
                value = getattr(error, key, None)
                if isinstance(value, int) and 0 <= value <= 65535:
                    codes.append(f'{key}={value}')
        if isinstance(error, sqlite3.Error):
            name = getattr(error, 'sqlite_errorname', '')
            if isinstance(name, str) and re.fullmatch(r'SQLITE_[A-Z0-9_]{1,64}', name):
                codes.append(name)
        lines.append(type(error).__name__ + (' (' + ', '.join(codes) + ')' if codes else ''))
        if tb is not None:
            for index, (frame, number) in enumerate(walk_tb(tb)):
                if index >= 32:
                    lines.append('  ...')
                    break
                lines.append(f'  {Path(frame.f_code.co_filename).name}:{number} en {frame.f_code.co_name}')
        error = error.__cause__ or (None if error.__suppress_context__ else error.__context__)
        tb = error.__traceback__ if error is not None else None
    return '\n'.join(lines)


class DiagnosticFilter(logging.Filter):
    def filter(self, record):
        # Un registro puede pasar por el logger de Flask y luego por el handler raíz.
        if getattr(record, '_pos_safe_diagnostic', False):
            return True
        record._pos_safe_diagnostic = True
        if record.exc_info:
            record.exc_text = exception_diagnostic(record.exc_info)
            record.exc_info = None
        elif record.exc_text:
            # Un handler anterior pudo haber cacheado un traceback sin filtrar.
            record.exc_text = 'Detalle de excepción previo omitido.'
        if record.stack_info:
            record.stack_info = None
        if isinstance(record.msg, str) and record.msg.startswith('Exception on '):
            record.msg = 'Error inesperado durante la solicitud HTTP'
            record.args = ()
        if record.name == 'werkzeug':
            # Incluye accesos normales y solicitudes HTTP malformadas. Nunca
            # persistir URL/query, cabeceras o fragmentos enviados por un cliente.
            args = record.args if isinstance(record.args, tuple) else ()
            line = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', str(args[0])) if args else ''
            method = re.match(r'(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\s', line)
            status = str(args[1]) if len(args) > 1 else ''
            if method and re.fullmatch(r'[1-5][0-9]{2}', status):
                record.msg = 'Solicitud HTTP: %s; estado %s'
                record.args = (method.group(1), status)
            else:
                record.msg = 'Diagnóstico del servidor HTTP'
                record.args = ()
        else:
            # Evitar que %r/%s vuelvan a imprimir un objeto de excepción.
            if isinstance(record.msg, BaseException):
                record.msg = type(record.msg).__name__
            if isinstance(record.args, tuple):
                record.args = tuple(type(v).__name__ if isinstance(v, BaseException) else v for v in record.args)
            elif isinstance(record.args, dict):
                record.args = {k: type(v).__name__ if isinstance(v, BaseException) else v for k,v in record.args.items()}
        return True


_SAFE_FILTER = DiagnosticFilter()


def configure_diagnostic_logging(app=None):
    """Cubrir handlers de escritorio, Flask y servidor sin crear archivos nuevos."""
    loggers = [logging.getLogger(), logging.getLogger('werkzeug')]
    if app is not None:
        loggers.append(app.logger)
    for logger in loggers:
        if _SAFE_FILTER not in logger.filters:
            logger.addFilter(_SAFE_FILTER)
        for handler in logger.handlers:
            if _SAFE_FILTER not in handler.filters:
                handler.addFilter(_SAFE_FILTER)
