"""Rutas de reports."""
from ..route_core import (
    BytesIO,
    ar_currency,
    bp,
    consistent_read,
    date,
    format_date_ar,
    format_datetime_ar,
    get_db,
    jsonify,
    login_required,
    money,
    normalize_date,
    request,
    safe_pdf_text,
    send_file,
    stock_control_enabled,
)

def report_date_range():
    """Lee y valida 'from'/'to'. Devuelve (fechas, error).

    Sin validar, un valor como 'xx' se propagaba a la consulta y el reporte
    mostraba 0 ventas como si el rango fuera válido, y el export generaba un
    archivo con el nombre basura. Devuelve un error 400 en ese caso.
    """
    raw_from = (request.args.get('from') or '').strip()
    raw_to = (request.args.get('to') or '').strip()
    default_from = date.today().replace(day=1).isoformat()
    default_to = date.today().isoformat()
    try:
        date_from = normalize_date(raw_from) if raw_from else default_from
        date_to = normalize_date(raw_to) if raw_to else default_to
    except ValueError:
        return None, (jsonify({'error': 'Rango de fechas inválido. Usá el formato AAAA-MM-DD.'}), 400)
    if date_from > date_to:
        return None, (jsonify({'error': 'La fecha "desde" no puede ser posterior a "hasta".'}), 400)
    return (date_from, date_to), None

@bp.get('/api/reports')
@login_required
@consistent_read
def api_reports():
    dates, error = report_date_range()
    if error:
        return error
    date_from, date_to = dates
    db = get_db()
    params = (date_from, date_to)
    # Una sola lectura indexada obtiene el resumen general y el desglose por
    # medio de pago. Las ventanas suman los grupos y reproducen exactamente
    # COUNT/SUM globales sin ejecutar una segunda consulta sobre sales.
    payment_metrics = db.execute('''
        SELECT payment_method,
               COUNT(*) AS count,
               COALESCE(SUM(total),0) AS total,
               SUM(COUNT(*)) OVER () AS sales_count,
               COALESCE(SUM(SUM(total)) OVER (),0) AS total_sales,
               COALESCE(SUM(SUM(change_amount)) OVER (),0) AS total_change
        FROM sales
        WHERE created_at >= date(?) AND created_at < date(?, '+1 day')
        GROUP BY payment_method
        ORDER BY total DESC
    ''', params).fetchall()
    if payment_metrics:
        totals = payment_metrics[0]
        summary = {
            'sales_count': totals['sales_count'],
            'total_sales': totals['total_sales'],
            'total_change': totals['total_change'],
        }
        by_payment = [{
            'payment_method': row['payment_method'],
            'count': row['count'],
            'total': row['total'],
        } for row in payment_metrics]
    else:
        summary = {'sales_count': 0, 'total_sales': 0, 'total_change': 0}
        by_payment = []
    # V106: no forzamos materialización del conjunto de ventas ni de la agrupación
    # intermedia; verificado contra la misma consulta V105 en bases sintéticas.
    # Los tres cálculos recorrían por separado los artículos del período
    # (más vendidos, menos vendidos y ganancia estimada). El CTE materializa
    # una sola agregación y la reutiliza para los dos rankings y la ganancia.
    # MATERIALIZED está soportado desde SQLite 3.35; la versión distribuida
    # y verificada para este POS es SQLite 3.49.1.
    report_rollups = db.execute('''
        WITH period_sales AS NOT MATERIALIZED (
            SELECT id FROM sales
            WHERE created_at >= date(?) AND created_at < date(?, '+1 day')
        ), item_agg AS NOT MATERIALIZED (
            -- Agrupar primero las líneas. Así evitamos consultar products
            -- una vez por cada artículo vendido cuando se necesita el costo
            -- actual como fallback histórico.
            SELECT si.product_id, si.product_name,
                   SUM(si.quantity) AS qty,
                   SUM(si.line_total) AS total,
                   SUM(CASE WHEN si.unit_cost_at_sale IS NOT NULL
                            THEN si.line_total - (si.unit_cost_at_sale * si.quantity)
                            ELSE si.line_total END) AS profit_before_fallback,
                   SUM(CASE WHEN si.unit_cost_at_sale IS NULL
                            THEN si.quantity ELSE 0 END) AS fallback_quantity
            FROM period_sales ps
            JOIN sale_items si ON si.sale_id = ps.id
            GROUP BY si.product_id, si.product_name
        ), item_rollup AS MATERIALIZED (
            SELECT a.product_id, a.product_name, a.qty, a.total,
                   a.profit_before_fallback - (COALESCE(p.total_cost, 0) * a.fallback_quantity) AS profit
            FROM item_agg a
            LEFT JOIN products p ON p.id = a.product_id
        ), product_rollup AS MATERIALIZED (
            SELECT product_id, SUM(qty) AS qty, SUM(total) AS total
            FROM item_rollup
            GROUP BY product_id
        )
        SELECT kind, product_id, name, qty, total, estimated_profit
        FROM (
            SELECT 'top' AS kind, product_id, product_name AS name, qty, total,
                   NULL AS estimated_profit, 1 AS section
            FROM (
                SELECT product_id, product_name, qty, total
                FROM item_rollup ORDER BY qty DESC LIMIT 15
            )
            UNION ALL
            SELECT 'least' AS kind, id AS product_id, name, qty, total,
                   NULL AS estimated_profit, 2 AS section
            FROM (
                SELECT p.id, p.name, COALESCE(r.qty, 0) AS qty, COALESCE(r.total, 0) AS total
                FROM products p
                LEFT JOIN product_rollup r ON r.product_id = p.id
                ORDER BY qty ASC, p.name ASC LIMIT 15
            )
            UNION ALL
            SELECT 'profit' AS kind, NULL AS product_id, NULL AS name,
                   NULL AS qty, NULL AS total, COALESCE(SUM(profit), 0) AS estimated_profit,
                   3 AS section
            FROM item_rollup
        )
        ORDER BY section,
                 CASE WHEN section=1 THEN qty END DESC,
                 CASE WHEN section=2 THEN qty END ASC,
                 CASE WHEN section=2 THEN name END ASC
    ''', params).fetchall()
    # Mantener exactamente el contrato JSON anterior: solo name, qty y total.
    top = [{'name': row['name'], 'qty': row['qty'], 'total': row['total']}
           for row in report_rollups if row['kind'] == 'top']
    least = [{'name': row['name'], 'qty': row['qty'], 'total': row['total']}
             for row in report_rollups if row['kind'] == 'least']
    profit_row = next(row for row in report_rollups if row['kind'] == 'profit')
    profit = profit_row['estimated_profit']
    daily = db.execute('''
        SELECT date(created_at) AS day, COALESCE(SUM(total),0) AS total, COUNT(*) AS count
        FROM sales WHERE created_at >= date(?) AND created_at < date(?, '+1 day')
        GROUP BY date(created_at) ORDER BY day ASC
    ''', params).fetchall()
    stock_low = db.execute('SELECT COUNT(*) AS c FROM products WHERE min_stock > 0 AND stock <= min_stock').fetchone()['c']
    clients_debt = db.execute('SELECT COALESCE(SUM(balance),0) AS total FROM clients WHERE balance > 0').fetchone()['total']
    avg_ticket = money((summary['total_sales'] or 0) / summary['sales_count']) if summary['sales_count'] else 0
    stock_value = db.execute('SELECT COALESCE(SUM(stock * total_cost),0) AS cost_value, COALESCE(SUM(stock * sale_price),0) AS sale_value FROM products').fetchone()
    low_products = db.execute('''
        SELECT name, barcode, stock, min_stock, sale_price
        FROM products WHERE min_stock > 0 AND stock <= min_stock
        ORDER BY (stock - min_stock) ASC, name ASC LIMIT 30
    ''').fetchall()
    debtors = db.execute('SELECT id, name, document, phone, balance FROM clients WHERE balance > 0 ORDER BY balance DESC LIMIT 20').fetchall()
    recent_sales = db.execute('''
        SELECT s.id, s.created_at, s.total, s.payment_method, s.sale_type, COALESCE(c.name, '') AS client_name
        FROM sales s LEFT JOIN clients c ON c.id=s.client_id
        WHERE s.created_at >= date(?) AND s.created_at < date(?, '+1 day')
        ORDER BY s.id DESC LIMIT 20
    ''', params).fetchall()
    return jsonify({
        'date_from': date_from, 'date_to': date_to,
        # Booleano real para que la pantalla distinga "stock bajo" de
        # "control de stock desactivado". El frontend ya consume este campo.
        'stock_control_enabled': stock_control_enabled(),
        'summary': {
            'sales_count': summary['sales_count'],
            'total_sales': money(summary['total_sales']),
            'estimated_profit': money(profit),
            'stock_low_count': stock_low,
            'clients_debt': money(clients_debt),
            'avg_ticket': avg_ticket,
            'stock_cost_value': money(stock_value['cost_value']),
            'stock_sale_value': money(stock_value['sale_value']),
        },
        'by_payment': [dict(r) for r in by_payment],
        'top_products': [dict(r) for r in top],
        'least_products': [dict(r) for r in least],
        'daily': [{**dict(r), 'day_formatted': format_date_ar(r['day'])} for r in daily],
        'low_products': [dict(r) for r in low_products],
        'debtors': [dict(r) for r in debtors],
        'recent_sales': [{**dict(r), 'ticket_number': f"T-{r['id']:06d}", 'created_at_formatted': format_datetime_ar(r['created_at'])} for r in recent_sales],
    })

@bp.get('/api/reports/export')
@login_required
def api_reports_export():
    import xlwt

    dates, error = report_date_range()
    if error:
        return error
    date_from, date_to = dates
    data = reports_result().get_json()
    book = xlwt.Workbook()
    sheet = book.add_sheet('Reporte')
    rows = [
        ['Desde', format_date_ar(date_from)], ['Hasta', format_date_ar(date_to)], [],
        ['Ventas', data['summary']['sales_count']], ['Total ventas', data['summary']['total_sales']],
        ['Ganancia estimada', data['summary']['estimated_profit']], ['Deuda clientes', data['summary']['clients_debt']], [],
        ['Forma de pago', 'Cantidad', 'Total']
    ]
    for p in data['by_payment']:
        rows.append([p['payment_method'], p['count'], p['total']])
    rows.append([]); rows.append(['Productos más vendidos', 'Cantidad', 'Total'])
    for p in data['top_products']:
        rows.append([p['name'], p['qty'], p['total']])
    for r, row in enumerate(rows):
        for c, value in enumerate(row):
            sheet.write(r, c, value)
    output = BytesIO(); book.save(output); output.seek(0)
    return send_file(output, as_attachment=True, download_name=f'reporte_{format_date_ar(date_from).replace("/", "-")}_a_{format_date_ar(date_to).replace("/", "-")}.xls', mimetype='application/vnd.ms-excel')

@bp.get('/api/reports/export-pdf')
@login_required
def api_reports_export_pdf():
    from reportlab.lib.pagesizes import A5
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas

    dates, error = report_date_range()
    if error:
        return error
    date_from, date_to = dates
    data = reports_result().get_json()
    output = BytesIO()
    c = canvas.Canvas(output, pagesize=A5)
    width, height = A5
    y = height - 18 * mm
    margin = 15 * mm

    def line(text, size=9, bold=False, gap=6):
        nonlocal y
        if y < 20 * mm:
            c.showPage(); y = height - 18 * mm
        c.setFont('Helvetica-Bold' if bold else 'Helvetica', size)
        c.drawString(margin, y, safe_pdf_text(text))
        y -= gap * mm

    line('REPORTE DE VENTAS', 15, True, 8)
    line(f'Desde {format_date_ar(date_from)} hasta {format_date_ar(date_to)}', 9, False, 8)
    line(f"Ventas: {data['summary']['sales_count']}  |  Total: {ar_currency(data['summary']['total_sales'])}", 10, True)
    line(f"Ganancia estimada: {ar_currency(data['summary']['estimated_profit'])}", 10, False)
    line(f"Ticket promedio: {ar_currency(data['summary'].get('avg_ticket', 0))}", 10, False)
    line(f"Deuda clientes: {ar_currency(data['summary']['clients_debt'])}", 10, False)
    line(f"Stock valorizado a venta: {ar_currency(data['summary'].get('stock_sale_value', 0))}", 10, False, 8)

    line('Por forma de pago', 11, True)
    for pmt in data.get('by_payment', []):
        line(f"- {pmt['payment_method']}: {pmt['count']} ventas · {ar_currency(pmt['total'])}", 8, False, 4)
    y -= 2 * mm
    line('Productos más vendidos', 11, True)
    for item in data.get('top_products', [])[:12]:
        line(f"- {item['name']}: {item['qty']} u. · {ar_currency(item['total'])}", 8, False, 4)
    y -= 2 * mm
    line('Clientes con deuda', 11, True)
    for item in data.get('debtors', [])[:12]:
        line(f"- {item['name']}: {ar_currency(item['balance'])}", 8, False, 4)

    c.save(); output.seek(0)
    filename = f'reporte_{format_date_ar(date_from).replace("/", "-")}_a_{format_date_ar(date_to).replace("/", "-")}.pdf'
    return send_file(output, as_attachment=True, download_name=filename, mimetype='application/pdf')


def reports_result():
    return api_reports()
