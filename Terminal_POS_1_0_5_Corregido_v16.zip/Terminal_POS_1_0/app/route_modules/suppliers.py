"""Rutas de suppliers."""
from ..route_core import (
    bp,
    get_db,
    jsonify,
    like_contains,
    log_audit,
    login_required,
    now_iso,
    request,
    require_json_object,
    require_security_password_from_payload,
    rollback_on_db_error,
    sqlite3,
    supplier_to_dict,
    text_field,
)

@bp.get('/api/suppliers')
@login_required
def api_suppliers():
    q = (request.args.get('q') or '').strip()
    if q:
        like = like_contains(q)
        db = get_db()
        has_trigram = len(q) >= 3 and db.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='suppliers_search'"
        ).fetchone()
        if has_trigram:
            try:
                rows = db.execute('''
                    SELECT s.* FROM suppliers s
                    JOIN (
                        SELECT rowid FROM suppliers_search WHERE name LIKE ? ESCAPE '\\'
                        UNION
                        SELECT rowid FROM suppliers_search WHERE cuit LIKE ? ESCAPE '\\'
                        UNION
                        SELECT rowid FROM suppliers_search WHERE phone LIKE ? ESCAPE '\\'
                        UNION
                        SELECT rowid FROM suppliers_search WHERE category LIKE ? ESCAPE '\\'
                    ) matches ON matches.rowid=s.id
                    ORDER BY s.name ASC LIMIT 200
                ''', (like, like, like, like)).fetchall()
            except sqlite3.OperationalError:
                rows = db.execute('''
                    SELECT * FROM suppliers
                    WHERE name LIKE ? ESCAPE '\\' OR cuit LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\' OR category LIKE ? ESCAPE '\\'
                    ORDER BY name ASC LIMIT 200
                ''', (like, like, like, like)).fetchall()
        else:
            rows = db.execute('''
                SELECT * FROM suppliers
                WHERE name LIKE ? ESCAPE '\\' OR cuit LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\' OR category LIKE ? ESCAPE '\\'
                ORDER BY name ASC LIMIT 200
            ''', (like, like, like, like)).fetchall()
    else:
        rows = get_db().execute('SELECT * FROM suppliers ORDER BY name ASC LIMIT 300').fetchall()
    return jsonify([supplier_to_dict(r) for r in rows])

@bp.post('/api/suppliers')
@login_required
@require_json_object
def api_create_supplier():
    data = request.get_json(force=True)
    try:
        name = text_field(data.get('name'))
        cuit = text_field(data.get('cuit'))
        phone = text_field(data.get('phone'))
        address = text_field(data.get('address'))
        category = text_field(data.get('category'))
        notes = text_field(data.get('notes'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    if not name:
        return jsonify({'error': 'Ingresá el nombre del proveedor'}), 400
    stamp = now_iso()
    cur = get_db().execute('''
        INSERT INTO suppliers (name, cuit, phone, address, category, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (name, cuit, phone, address, category, notes, stamp, stamp))
    log_audit('Crear proveedor', 'Proveedores', name)
    get_db().commit()
    return jsonify(supplier_to_dict(get_db().execute('SELECT * FROM suppliers WHERE id=?', (cur.lastrowid,)).fetchone())), 201

@bp.put('/api/suppliers/<int:supplier_id>')
@login_required
@require_json_object
def api_update_supplier(supplier_id):
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403
    try:
        name = text_field(data.get('name'))
        cuit = text_field(data.get('cuit'))
        phone = text_field(data.get('phone'))
        address = text_field(data.get('address'))
        category = text_field(data.get('category'))
        notes = text_field(data.get('notes'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    if not name:
        return jsonify({'error': 'Ingresá el nombre del proveedor'}), 400
    get_db().execute('''
        UPDATE suppliers SET name=?, cuit=?, phone=?, address=?, category=?, notes=?, updated_at=? WHERE id=?
    ''', (name, cuit, phone, address, category, notes, now_iso(), supplier_id))
    log_audit('Editar proveedor', 'Proveedores', name)
    get_db().commit()
    row = get_db().execute('SELECT * FROM suppliers WHERE id=?', (supplier_id,)).fetchone()
    return jsonify(supplier_to_dict(row))

@bp.delete('/api/suppliers/<int:supplier_id>')
@login_required
@rollback_on_db_error
@require_json_object
def api_delete_supplier(supplier_id):
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403
    db = get_db()
    db.execute('BEGIN IMMEDIATE')
    row = db.execute('SELECT * FROM suppliers WHERE id=?', (supplier_id,)).fetchone()
    if db.execute('SELECT 1 FROM products WHERE supplier_id=? LIMIT 1', (supplier_id,)).fetchone():
        db.rollback()
        return jsonify({'error': 'No se puede eliminar este proveedor porque tiene productos asociados.'}), 409
    try:
        get_db().execute('DELETE FROM suppliers WHERE id=?', (supplier_id,))
        log_audit('Eliminar proveedor', 'Proveedores', row['name'] if row else str(supplier_id))
        get_db().commit()
    except sqlite3.IntegrityError:
        get_db().rollback()
        return jsonify({'error': 'No se puede eliminar este proveedor porque tiene compras históricas asociadas.'}), 409
    return jsonify({'ok': True})

