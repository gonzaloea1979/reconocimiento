"""Rutas de users."""
from ..route_core import (
    bp,
    commit_operation,
    current_app,
    current_user_is_admin,
    g,
    generate_password_hash,
    get_db,
    get_settings,
    idempotent_operation,
    jsonify,
    login_required,
    now_iso,
    request,
    require_json_object,
    require_security_password_from_payload,
    rollback_on_db_error,
    sqlite3,
    text_field,
    user_to_dict,
)

@bp.get('/api/users')
@login_required
def api_list_users():
    rows = get_db().execute('''
        SELECT id, username, full_name, role, is_active, created_at, updated_at
        FROM users
        ORDER BY is_active DESC, role ASC, username ASC
    ''').fetchall()
    return jsonify([user_to_dict(r) for r in rows])

@bp.post('/api/users')
@login_required
@rollback_on_db_error
@require_json_object
@idempotent_operation
def api_create_user():
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403

    try:
        username = text_field(data.get('username'))
        full_name = text_field(data.get('full_name'))
        role = text_field(data.get('role')) or 'Cajero'
        password = text_field(data.get('user_password'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    if not username:
        return jsonify({'error': 'El usuario es obligatorio'}), 400
    if len(username) < 3:
        return jsonify({'error': 'El usuario debe tener al menos 3 caracteres'}), 400
    if role not in ('Administrador', 'Cajero', 'Supervisor'):
        role = 'Cajero'
    if len(password) < 4:
        return jsonify({'error': 'La clave del usuario debe tener al menos 4 caracteres'}), 400

    stamp = now_iso()
    db = get_db()
    if not db.in_transaction:
        db.execute('BEGIN IMMEDIATE')
    if db.execute('SELECT 1 FROM users WHERE LOWER(username)=LOWER(?)', (username,)).fetchone():
        db.rollback()
        return jsonify({'error': 'El nombre de usuario ya existe'}), 400
    try:
        cur = get_db().execute('''
            INSERT INTO users (username, full_name, role, password_hash, is_active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (username, full_name, role, generate_password_hash(password), 1 if data.get('is_active', True) else 0, stamp, stamp))
        commit_operation(get_db())
    except sqlite3.IntegrityError:
        db.rollback()
        current_app.logger.exception('No se pudo crear el usuario')
        return jsonify({'error': 'No se pudo crear el usuario. Revisá si el nombre de usuario ya existe.'}), 400

    row = get_db().execute('SELECT * FROM users WHERE id=?', (cur.lastrowid,)).fetchone()
    return jsonify(user_to_dict(row)), 201

@bp.put('/api/users/<int:user_id>')
@login_required
@rollback_on_db_error
@require_json_object
@idempotent_operation
def api_update_user(user_id):
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403

    try:
        username = text_field(data.get('username'))
        full_name = text_field(data.get('full_name'))
        role = text_field(data.get('role')) or 'Cajero'
        password = text_field(data.get('user_password'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    is_active = 1 if data.get('is_active', True) else 0
    if not username:
        return jsonify({'error': 'El usuario es obligatorio'}), 400
    if len(username) < 3:
        return jsonify({'error': 'El usuario debe tener al menos 3 caracteres'}), 400
    if role not in ('Administrador', 'Cajero', 'Supervisor'):
        role = 'Cajero'

    db = get_db()
    if not db.in_transaction:
        db.execute('BEGIN IMMEDIATE')
    current = db.execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
    if not current:
        db.rollback()
        return jsonify({'error': 'Usuario no encontrado'}), 404
    if db.execute('SELECT 1 FROM users WHERE LOWER(username)=LOWER(?) AND id<>?', (username, user_id)).fetchone():
        db.rollback()
        return jsonify({'error': 'El nombre de usuario ya existe'}), 400
    version_change = int(bool(password) or bool(current['is_active']) != bool(is_active))

    if current['role'] == 'Administrador' and (role != 'Administrador' or not is_active):
        active_admins = get_db().execute(
            "SELECT COUNT(*) AS c FROM users WHERE role='Administrador' AND is_active=1 AND id<>?",
            (user_id,)
        ).fetchone()['c']
        if active_admins == 0:
            db.rollback()
            return jsonify({'error': 'Debe quedar al menos un administrador activo'}), 400

    try:
        if password:
            if len(password) < 4:
                db.rollback()
                return jsonify({'error': 'La nueva clave del usuario debe tener al menos 4 caracteres'}), 400
            get_db().execute('''
                UPDATE users
                SET username=?, full_name=?, role=?, is_active=?, password_hash=?, updated_at=?, session_version=session_version+?
                WHERE id=?
            ''', (username, full_name, role, is_active, generate_password_hash(password), now_iso(), version_change, user_id))
        else:
            get_db().execute('''
                UPDATE users
                SET username=?, full_name=?, role=?, is_active=?, updated_at=?, session_version=session_version+?
                WHERE id=?
            ''', (username, full_name, role, is_active, now_iso(), version_change, user_id))
        if current['username'].lower() == (get_settings().get('login_username') or '').lower():
            if password or not is_active:
                db.execute("UPDATE app_settings SET value='' WHERE key='login_password_hash'")
            if username != current['username']:
                db.execute("UPDATE app_settings SET value=? WHERE key='login_username'", (username,))
            g.pop('_pos_settings_cache', None)
        commit_operation(get_db())
    except sqlite3.IntegrityError:
        db.rollback()
        current_app.logger.exception('No se pudo actualizar el usuario %s', user_id)
        return jsonify({'error': 'No se pudo actualizar el usuario. Revisá los datos e intentá nuevamente.'}), 400

    row = get_db().execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
    return jsonify(user_to_dict(row))

@bp.delete('/api/users/<int:user_id>')
@login_required
@rollback_on_db_error
@require_json_object
def api_delete_user(user_id):
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403

    db = get_db()
    db.execute('BEGIN IMMEDIATE')
    current = db.execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
    if not current:
        db.rollback()
        return jsonify({'error': 'Usuario no encontrado'}), 404
    if current['role'] == 'Administrador':
        active_admins = get_db().execute(
            "SELECT COUNT(*) AS c FROM users WHERE role='Administrador' AND is_active=1 AND id<>?",
            (user_id,)
        ).fetchone()['c']
        if active_admins == 0:
            db.rollback()
            return jsonify({'error': 'No se puede eliminar el único administrador activo'}), 400

    get_db().execute('DELETE FROM users WHERE id=?', (user_id,))
    if current['username'].lower() == (get_settings().get('login_username') or '').lower():
        # La clave global asociada a una cuenta eliminada no debe revivirla como alias.
        db.execute("UPDATE app_settings SET value='' WHERE key='login_password_hash'")
        g.pop('_pos_settings_cache', None)
    get_db().commit()
    return jsonify({'ok': True})

@bp.post('/api/admin-check')
@login_required
@require_json_object
def api_admin_check():
    if current_user_is_admin():
        return jsonify({'ok': True, 'admin_bypass': True})
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña incorrecta'}), 403
    return jsonify({'ok': True})

