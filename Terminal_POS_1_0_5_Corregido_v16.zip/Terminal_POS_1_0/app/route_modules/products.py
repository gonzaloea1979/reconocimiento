"""Rutas de products."""
from ..route_core import (
    MAX_BARCODE_IMAGE_BYTES,
    base64,
    bp,
    build_product_labels_pdf,
    calculate_prices,
    commit_operation,
    current_app,
    date,
    datetime,
    decode_barcode_image_bytes,
    get_db,
    get_global_product_rounding,
    idempotent_operation,
    jsonify,
    like_contains,
    like_prefix,
    login_required,
    money,
    non_negative_amount,
    normalize_date,
    now_iso,
    percent_amount,
    print_pdf_file,
    product_payload,
    product_to_dict,
    request,
    require_json_object,
    require_security_password_from_payload,
    rollback_on_db_error,
    save_product_photo,
    send_file,
    sqlite3,
    stock_control_enabled,
    stock_movement,
    strict_number,
    record_id,
    text_field,
)

@bp.get('/api/products')
@login_required
def api_products():
    q = (request.args.get('q') or '').strip()
    compact = request.args.get('compact') == '1'
    db = get_db()
    if q:
        like = like_contains(q)
        has_trigram = len(q) >= 3 and db.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='products_search'"
        ).fetchone()
        projection = 'p.id, p.name, p.stock' if compact else 'p.*'
        if has_trigram:
            try:
                rows = db.execute(f'''
                    SELECT {projection} FROM products p
                    JOIN (
                        SELECT rowid FROM products_search WHERE barcode LIKE ? ESCAPE '\\'
                        UNION
                        SELECT rowid FROM products_search WHERE name LIKE ? ESCAPE '\\'
                        UNION
                        SELECT rowid FROM products_search WHERE detail LIKE ? ESCAPE '\\'
                    ) matches ON matches.rowid=p.id
                    ORDER BY p.name ASC
                    LIMIT 100
                ''', (like, like, like)).fetchall()
            except sqlite3.OperationalError:
                fallback_projection = 'id, name, stock' if compact else '*'
                rows = db.execute(f'''
                    SELECT {fallback_projection} FROM products
                    WHERE barcode LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\' OR detail LIKE ? ESCAPE '\\'
                    ORDER BY name ASC
                    LIMIT 100
                ''', (like, like, like)).fetchall()
        else:
            fallback_projection = 'id, name, stock' if compact else '*'
            rows = db.execute(f'''
                SELECT {fallback_projection} FROM products
                WHERE barcode LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\' OR detail LIKE ? ESCAPE '\\'
                ORDER BY name ASC
                LIMIT 100
            ''', (like, like, like)).fetchall()
    else:
        projection = 'id, name, stock' if compact else '*'
        rows = db.execute(f'SELECT {projection} FROM products ORDER BY name ASC LIMIT 200').fetchall()

    if compact:
        # Proyección exclusiva del selector de stock: evita serializar campos
        # comerciales que esa pantalla no utiliza. La API completa no cambia.
        return jsonify([{'id': r['id'], 'name': r['name'], 'stock': money(r['stock'])} for r in rows])
    return jsonify([product_to_dict(r) for r in rows])

@bp.get('/api/products/<int:product_id>')
@login_required
def api_get_product(product_id):
    row = get_db().execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    if not row:
        return jsonify({'error': 'Producto no encontrado'}), 404
    return jsonify(product_to_dict(row))

@bp.post('/api/products')
@login_required
@rollback_on_db_error
@require_json_object
@idempotent_operation
def api_create_product():
    data = product_payload()
    try:
        name = text_field(data.get('name'))
        barcode = text_field(data.get('barcode')) or None
        detail = text_field(data.get('detail'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    if not name:
        return jsonify({'error': 'El nombre del producto es obligatorio'}), 400

    try:
        cost = non_negative_amount(data.get('cost_without_tax'), 'Costo sin impuestos')
        iva = percent_amount(data.get('iva_percent'), 'IVA')
        gross = percent_amount(data.get('gross_income_percent'), 'Ingresos brutos')
        margin = non_negative_amount(data.get('margin_percent'), 'Margen')
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    rounding_mode, rounding_multiple = get_global_product_rounding()
    try:
        total_cost, sale_price = calculate_prices(cost, iva, gross, margin, rounding_mode, rounding_multiple)
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    try:
        stock = non_negative_amount(data.get('stock'), 'Stock') if stock_control_enabled() else 0.0
        min_stock = non_negative_amount(data.get('min_stock'), 'Stock mínimo') if stock_control_enabled() else 0.0
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    try:
        supplier_id = record_id(data.get('supplier_id') or 0) or None
    except (ValueError, TypeError):
        return jsonify({'error': 'Proveedor inválido'}), 400
    # Serializar la validación del proveedor y la escritura con su eliminación.
    if not get_db().in_transaction:
        get_db().execute('BEGIN IMMEDIATE')
    if supplier_id is not None and not get_db().execute(
        'SELECT 1 FROM suppliers WHERE id=?', (supplier_id,)
    ).fetchone():
        return jsonify({'error': 'El proveedor seleccionado no existe'}), 400
    try:
        expiry_date = normalize_date(data.get('expiry_date'))
        photo_path = save_product_photo(request.files.get('photo')) if request.files else ''
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    stamp = now_iso()

    try:
        cur = get_db().execute("""
            INSERT INTO products (
                barcode, name, detail, cost_without_tax, iva_percent, gross_income_percent,
                total_cost, margin_percent, rounding_mode, rounding_multiple, sale_price, stock, min_stock, supplier_id, expiry_date, photo_path, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            barcode, name, detail, cost, iva, gross,
            total_cost, margin, rounding_mode, rounding_multiple, sale_price, stock, min_stock, supplier_id, expiry_date, photo_path, stamp, stamp
        ))
        commit_operation(get_db())
    except sqlite3.IntegrityError:
        get_db().rollback()
        current_app.logger.exception('No se pudo guardar un producto')
        return jsonify({'error': 'No se pudo guardar el producto. Revisá si el código de barras ya existe.'}), 400

    row = get_db().execute('SELECT * FROM products WHERE id=?', (cur.lastrowid,)).fetchone()
    return jsonify(product_to_dict(row)), 201

@bp.put('/api/products/<int:product_id>')
@login_required
@rollback_on_db_error
@require_json_object
@idempotent_operation
def api_update_product(product_id):
    data = product_payload()
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña incorrecta'}), 403

    try:
        name = text_field(data.get('name'))
        barcode = text_field(data.get('barcode')) or None
        detail = text_field(data.get('detail'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    if not name:
        return jsonify({'error': 'El nombre del producto es obligatorio'}), 400

    try:
        cost = non_negative_amount(data.get('cost_without_tax'), 'Costo sin impuestos')
        iva = percent_amount(data.get('iva_percent'), 'IVA')
        gross = percent_amount(data.get('gross_income_percent'), 'Ingresos brutos')
        margin = non_negative_amount(data.get('margin_percent'), 'Margen')
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    rounding_mode, rounding_multiple = get_global_product_rounding()
    try:
        total_cost, sale_price = calculate_prices(cost, iva, gross, margin, rounding_mode, rounding_multiple)
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    try:
        stock = non_negative_amount(data.get('stock'), 'Stock') if 'stock' in data else None
        min_stock = non_negative_amount(data.get('min_stock'), 'Stock mínimo') if 'min_stock' in data else None
        original_stock = strict_number(data.get('original_stock'), 'Stock original') if 'original_stock' in data else None
        if original_stock is not None and original_stock < 0:
            raise ValueError('El stock original no puede ser negativo')
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    try:
        supplier_id = record_id(data.get('supplier_id') or 0) or None
    except (ValueError, TypeError):
        return jsonify({'error': 'Proveedor inválido'}), 400
    db = get_db()
    if not db.in_transaction:
        db.execute('BEGIN IMMEDIATE')
    current_row = db.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    if not current_row:
        db.rollback()
        return jsonify({'error': 'Producto no encontrado'}), 404
    previous_stock = money(current_row['stock'])
    stock_enabled = stock_control_enabled()
    if not stock_enabled:
        stock = previous_stock
        min_stock = money(current_row['min_stock'])
    else:
        # No tocar existencias si la ficha solo cambia datos comerciales.
        if stock is None or (original_stock is not None and stock == original_stock):
            stock = previous_stock
        elif stock != previous_stock and (original_stock is None or original_stock != previous_stock):
            db.rollback()
            return jsonify({'error': 'El stock cambió o falta su valor original. Volvé a abrir el producto antes de ajustar existencias.'}), 409
        if min_stock is None:
            min_stock = money(current_row['min_stock'])
    if supplier_id is not None and not db.execute(
        'SELECT 1 FROM suppliers WHERE id=?', (supplier_id,)
    ).fetchone():
        db.rollback()
        return jsonify({'error': 'El proveedor seleccionado no existe'}), 400
    try:
        expiry_date = normalize_date(data.get('expiry_date'))
        photo_path = current_row['photo_path'] or ''
        if request.files and request.files.get('photo') and request.files.get('photo').filename:
            photo_path = save_product_photo(request.files.get('photo'))
    except ValueError as exc:
        db.rollback()
        return jsonify({'error': str(exc)}), 400

    try:
        db.execute("""
            UPDATE products
            SET barcode=?, name=?, detail=?, cost_without_tax=?, iva_percent=?, gross_income_percent=?,
                total_cost=?, margin_percent=?, rounding_mode=?, rounding_multiple=?, sale_price=?, stock=?, min_stock=?, supplier_id=?, expiry_date=?, photo_path=?, updated_at=?
            WHERE id=?
        """, (
            barcode, name, detail, cost, iva, gross,
            total_cost, margin, rounding_mode, rounding_multiple, sale_price, stock, min_stock, supplier_id, expiry_date, photo_path, now_iso(), product_id
        ))
        if stock_enabled and stock != previous_stock:
            stock_movement(current_row, 'Ajuste manual', money(stock - previous_stock),
                           previous_stock, stock, 'Edición de producto')
        commit_operation(db)
    except sqlite3.IntegrityError:
        db.rollback()
        current_app.logger.exception('No se pudo editar el producto %s', product_id)
        return jsonify({'error': 'No se pudo editar el producto. Revisá los datos e intentá nuevamente.'}), 400

    row = get_db().execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    if not row:
        return jsonify({'error': 'Producto no encontrado'}), 404
    return jsonify(product_to_dict(row))

@bp.delete('/api/products/<int:product_id>')
@login_required
@require_json_object
def api_delete_product(product_id):
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña incorrecta'}), 403
    try:
        get_db().execute('DELETE FROM products WHERE id=?', (product_id,))
        get_db().commit()
    except sqlite3.IntegrityError:
        get_db().rollback()
        return jsonify({'error': 'No se puede eliminar este producto porque tiene ventas, compras o movimientos históricos asociados.'}), 409
    return jsonify({'ok': True})

@bp.post('/api/barcode/decode')
@login_required
def api_barcode_decode():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({'code': '', 'error': 'El contenido enviado no es válido.'}), 400
    image_data = data.get('image') or ''
    if not isinstance(image_data, str):
        return jsonify({'code': '', 'error': 'El formato de imagen enviado no es válido.'}), 400
    image_data = image_data.strip()
    if not image_data:
        return jsonify({'code': '', 'error': 'No llegó imagen para decodificar.'}), 400
    try:
        if ',' in image_data:
            image_data = image_data.split(',', 1)[1]
        # Límite previo a base64.b64decode: una trama de cámara no necesita
        # decenas de MB y no debe consumir CPU/RAM sin control.
        max_encoded_length = ((MAX_BARCODE_IMAGE_BYTES + 2) // 3) * 4
        if len(image_data) > max_encoded_length:
            return jsonify({'code': '', 'error': 'La imagen supera el límite de 4 MB.'}), 413
        raw_bytes = base64.b64decode(image_data, validate=True)
        if len(raw_bytes) > MAX_BARCODE_IMAGE_BYTES:
            return jsonify({'code': '', 'error': 'La imagen supera el límite de 4 MB.'}), 413
    except Exception:
        return jsonify({'code': '', 'error': 'La imagen enviada no es válida.'}), 400

    code, error = decode_barcode_image_bytes(raw_bytes)
    if error and 'opencv-python' in error:
        return jsonify({'code': '', 'available': False, 'error': error})
    if error:
        return jsonify({'code': '', 'error': error}), 422
    return jsonify({'code': code, 'available': True})

@bp.get('/api/product-lookup')
@login_required
def api_product_lookup():
    q = (request.args.get('q') or '').strip()
    if not q:
        return jsonify([])
    db = get_db()
    exact = db.execute('SELECT * FROM products WHERE barcode=? LIMIT 1', (q,)).fetchone()
    if exact:
        return jsonify([product_to_dict(exact)])
    like = like_contains(q)
    has_trigram = len(q) >= 3 and db.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name='products_search'"
    ).fetchone()
    if has_trigram:
        try:
            rows = db.execute('''
                SELECT p.* FROM products p
                JOIN (
                    SELECT rowid FROM products_search WHERE barcode LIKE ? ESCAPE '\\'
                    UNION
                    SELECT rowid FROM products_search WHERE name LIKE ? ESCAPE '\\'
                    UNION
                    SELECT rowid FROM products_search WHERE detail LIKE ? ESCAPE '\\'
                ) matches ON matches.rowid=p.id
                ORDER BY CASE WHEN p.name LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END, p.name ASC
                LIMIT 20
            ''', (like, like, like, like_prefix(q))).fetchall()
        except sqlite3.OperationalError:
            rows = db.execute('''
                SELECT * FROM products
                WHERE barcode LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\' OR detail LIKE ? ESCAPE '\\'
                ORDER BY CASE WHEN name LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END, name ASC
                LIMIT 20
            ''', (like, like, like, like_prefix(q))).fetchall()
    else:
        rows = db.execute('''
            SELECT * FROM products
            WHERE barcode LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\' OR detail LIKE ? ESCAPE '\\'
            ORDER BY CASE WHEN name LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END, name ASC
            LIMIT 20
        ''', (like, like, like, like_prefix(q))).fetchall()
    return jsonify([product_to_dict(r) for r in rows])

@bp.post('/api/product-labels/pdf')
@login_required
@require_json_object
def api_product_labels_pdf():
    data = request.get_json(force=True)
    items = data.get('items') or []
    labels_per_sheet = data.get('labels_per_sheet') or 24
    show_guides = str(data.get('show_guides', '1')).lower() in ('1', 'true', 'on', 'yes', 'si', 'sí')
    font_family = data.get('font_family') or 'Helvetica'
    name_font_size = data.get('name_font_size') or 10
    price_font_size = data.get('price_font_size') or 18
    try:
        output = build_product_labels_pdf(
            items,
            labels_per_sheet=labels_per_sheet,
            show_guides=show_guides,
            font_family=font_family,
            name_font_size=name_font_size,
            price_font_size=price_font_size,
        )
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception:
        current_app.logger.exception('No se pudo generar el PDF de etiquetas')
        return jsonify({'error': 'No se pudo generar el PDF de etiquetas. Intentá nuevamente.'}), 500
    filename = f'etiquetas_productos_{date.today().strftime("%d-%m-%Y")}.pdf'
    return send_file(output, as_attachment=True, download_name=filename, mimetype='application/pdf')

@bp.post('/api/product-labels/pdf-file')
@login_required
@require_json_object
def api_product_labels_pdf_file():
    """Genera etiquetas en archivo local y opcionalmente las envía a impresión.

    Esta variante se usa en la edición de escritorio para no depender de
    window.open(blob), que no es fiable dentro de WebView2/pywebview.
    """
    data = request.get_json(force=True)
    items = data.get('items') or []
    labels_per_sheet = data.get('labels_per_sheet') or 24
    show_guides = str(data.get('show_guides', '1')).lower() in ('1', 'true', 'on', 'yes', 'si', 'sí')
    font_family = data.get('font_family') or 'Helvetica'
    name_font_size = data.get('name_font_size') or 10
    price_font_size = data.get('price_font_size') or 18
    should_print = bool(data.get('print'))
    try:
        output = build_product_labels_pdf(
            items,
            labels_per_sheet=labels_per_sheet,
            show_guides=show_guides,
            font_family=font_family,
            name_font_size=name_font_size,
            price_font_size=price_font_size,
        )
        folder = current_app.config['TICKET_DIR']
        folder.mkdir(parents=True, exist_ok=True)
        filename = f'etiquetas_productos_{date.today().strftime("%d-%m-%Y")}_{datetime.now().strftime("%H%M%S")}.pdf'
        pdf_path = folder / filename
        pdf_path.write_bytes(output.getvalue())
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception:
        current_app.logger.exception('No se pudo generar el PDF de etiquetas')
        return jsonify({'error': 'No se pudo generar el PDF de etiquetas. Intentá nuevamente.'}), 500

    printed = False
    print_message = ''
    if should_print:
        printed, print_message = print_pdf_file(pdf_path)

    return jsonify({
        'ok': True,
        'filename': filename,
        'folder': str(pdf_path.parent),
        'path': str(pdf_path),
        'printed': printed,
        'print_message': print_message,
    })

