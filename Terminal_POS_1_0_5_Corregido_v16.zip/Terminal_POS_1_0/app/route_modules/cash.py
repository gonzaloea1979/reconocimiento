"""Rutas de cash."""
from ..route_core import (
    active_cash_session,
    add_cash_movement,
    bp,
    commit_operation,
    consistent_read,
    current_cashier_display_name,
    format_datetime_ar,
    get_db,
    idempotent_operation,
    jsonify,
    log_audit,
    login_required,
    money,
    now_iso,
    request,
    require_security_password_from_payload,
    rollback_on_db_error,
    strict_number,
    non_negative_amount,
    text_field,
)

@bp.get('/api/cash/status')
@login_required
@consistent_read
def api_cash_status():
    session_row = active_cash_session()
    db = get_db()
    if not session_row:
        last = db.execute('SELECT * FROM cash_sessions ORDER BY id DESC LIMIT 1').fetchone()
        return jsonify({'open': False, 'last': dict(last) if last else None})
    movements = db.execute('SELECT * FROM cash_movements WHERE cash_session_id=? ORDER BY id DESC LIMIT 200', (session_row['id'],)).fetchall()
    totals = db.execute('''
        SELECT payment_method, movement_type, COALESCE(SUM(amount),0) AS amount
        FROM cash_movements WHERE cash_session_id=? GROUP BY payment_method, movement_type
    ''', (session_row['id'],)).fetchall()
    # La tabla mostrada conserva el límite de 200 filas, pero el saldo de caja
    # debe sumar TODO el efectivo de la sesión, no solamente las filas visibles.
    # Tarjetas y transferencias se conservan en totals.
    summary = db.execute('''
        SELECT COALESCE(SUM(CASE
            WHEN movement_type IN ('Ingreso', 'Venta') THEN amount
            WHEN movement_type = 'Retiro' THEN -amount
            ELSE 0 END), 0) AS delta
        FROM cash_movements WHERE cash_session_id=? AND LOWER(TRIM(payment_method))='efectivo'
    ''', (session_row['id'],)).fetchone()
    expected = money(money(session_row['initial_amount']) + money(summary['delta']))
    return jsonify({
        'open': True,
        'session': {**dict(session_row), 'opened_at_formatted': format_datetime_ar(session_row['opened_at']), 'expected_amount': money(expected)},
        'movements': [{**dict(m), 'created_at_formatted': format_datetime_ar(m['created_at'])} for m in movements],
        'totals': [dict(t) for t in totals],
    })

@bp.post('/api/cash/open')
@login_required
@rollback_on_db_error
def api_cash_open():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({'error': 'Los datos de apertura deben ser un objeto válido'}), 400
    if data.get('notes') is not None and not isinstance(data.get('notes'), str):
        return jsonify({'error': 'Las notas de caja deben ser texto'}), 400
    try:
        initial = non_negative_amount(data.get('initial_amount'), 'Importe inicial')
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    if initial < 0:
        return jsonify({'error': 'El importe inicial no puede ser negativo'}), 400
    # El bloqueo de escritura se obtiene ANTES de leer si hay caja abierta.
    # Sin esta transacción dos peticiones pueden ver 'sin caja' y abrir dos cajas.
    db = get_db()
    db.execute('BEGIN IMMEDIATE')
    if active_cash_session():
        db.rollback()
        return jsonify({'error': 'Ya hay una caja abierta'}), 409
    cur = db.execute('INSERT INTO cash_sessions (opened_at, initial_amount, cashier_name, notes) VALUES (?, ?, ?, ?)',
                           (now_iso(), initial, current_cashier_display_name(), (data.get('notes') or '').strip()))
    log_audit('Abrir caja', 'Caja', f'Inicial {initial}')
    db.commit()
    return jsonify({'ok': True, 'cash_session_id': cur.lastrowid})

@bp.post('/api/cash/movement')
@login_required
@rollback_on_db_error
@idempotent_operation
def api_cash_movement():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({'error': 'Los datos del movimiento deben ser un objeto válido'}), 400
    if data.get('description') is not None and not isinstance(data.get('description'), str):
        return jsonify({'error': 'La descripción debe ser texto'}), 400
    try:
        movement_type = text_field(data.get('movement_type'))
        description = text_field(data.get('description'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    if movement_type not in ('Ingreso', 'Retiro'):
        return jsonify({'error': 'Movimiento inválido'}), 400
    try:
        amount = strict_number(data.get('amount'), 'Importe de caja')
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    if amount <= 0:
        return jsonify({'error': 'El importe debe ser mayor a cero'}), 400
    add_cash_movement(movement_type, amount, description, 'Efectivo')
    log_audit(f'{movement_type} de caja', 'Caja', f'{amount}')
    commit_operation(get_db())
    return jsonify({'ok': True})

@bp.post('/api/cash/close')
@login_required
@rollback_on_db_error
def api_cash_close():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({'error': 'Los datos del cierre deben ser un objeto válido'}), 400
    if data.get('notes') is not None and not isinstance(data.get('notes'), str):
        return jsonify({'error': 'Las notas de cierre deben ser texto'}), 400
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403
    try:
        closing = strict_number(data.get('closing_amount'), 'Importe de cierre')
        non_negative_amount(data.get('closing_amount'), 'Importe de cierre')
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    if closing < 0:
        return jsonify({'error': 'El importe de cierre no puede ser negativo'}), 400
    # Bloquear antes de consultar: los escritores eligen caja bajo este bloqueo.
    db = get_db()
    db.execute('BEGIN IMMEDIATE')
    session_row = active_cash_session()
    if not session_row:
        db.rollback()
        return jsonify({'error': 'No hay caja abierta'}), 400
    status = cash_status_result().get_json()
    expected = money(status.get('session', {}).get('expected_amount'))
    diff = money(closing - expected)
    get_db().execute('''
        UPDATE cash_sessions SET closed_at=?, closing_amount=?, expected_amount=?, difference=?, status='cerrada', notes=? WHERE id=?
    ''', (now_iso(), closing, expected, diff, (data.get('notes') or '').strip(), session_row['id']))
    log_audit('Cerrar caja', 'Caja', f'Esperado {expected} / Real {closing} / Diferencia {diff}')
    get_db().commit()
    return jsonify({'ok': True, 'expected_amount': expected, 'difference': diff})


def cash_status_result():
    return api_cash_status()
