"""Módulos HTTP de Terminal POS. El Blueprint se comparte desde route_core."""
