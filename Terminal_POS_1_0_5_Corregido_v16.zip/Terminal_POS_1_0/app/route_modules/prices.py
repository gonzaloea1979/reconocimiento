from ..route_services.price_import import prepare_price_rows, load_import_products
"""Rutas de prices."""
from ..route_core import (
    Decimal,
    EXCEL_HEADERS,
    InvalidOperation,
    bp,
    calculate_prices,
    current_app,
    date,
    excel_number,
    excel_text,
    get_db,
    get_global_product_rounding,
    jsonify,
    login_required,
    money,
    non_negative_amount,
    now_iso,
    percent_amount,
    read_xls_date,
    request,
    require_security_password_from_payload,
    rollback_on_db_error,
    send_file,
    sqlite3,
    stock_control_enabled,
    stock_movement,
    strict_number,
    write_xls_products,
)

@bp.get('/api/prices/export')
@login_required
def api_export_prices():
    rows = get_db().execute('SELECT * FROM products ORDER BY name ASC')
    output = write_xls_products(rows)
    filename = f'lista_precios_{date.today().strftime("%d-%m-%Y")}.xls'
    return send_file(
        output,
        as_attachment=True,
        download_name=filename,
        mimetype='application/vnd.ms-excel'
    )

@bp.get('/api/prices/template')
@login_required
def api_prices_template():
    output = write_xls_products([])
    return send_file(
        output,
        as_attachment=True,
        download_name='plantilla_lista_precios.xls',
        mimetype='application/vnd.ms-excel'
    )

@bp.post('/api/prices/import')
@login_required
@rollback_on_db_error
def api_import_prices():
    import xlrd

    if not require_security_password_from_payload(request.form):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403

    file = request.files.get('file')
    if not file or not file.filename:
        return jsonify({'error': 'Tenés que seleccionar un archivo .xls'}), 400
    if not file.filename.lower().endswith('.xls'):
        return jsonify({'error': 'El archivo debe tener formato .xls'}), 400

    try:
        content = file.read()
        book = xlrd.open_workbook(file_contents=content)
        sheet = book.sheet_by_index(0)
    except Exception:
        current_app.logger.exception('No se pudo abrir la lista de precios Excel')
        return jsonify({'error': 'No se pudo abrir el archivo Excel. Verificá que sea un .xls válido.'}), 400

    header_row = None
    header_map = {}
    normalized_expected = {h.lower().strip(): h for h in EXCEL_HEADERS}
    for r in range(min(sheet.nrows, 10)):
        possible = [excel_text(sheet.cell_value(r, c)).lower().strip() for c in range(sheet.ncols)]
        if 'nombre' in possible and ('precio venta' in possible or 'código de barra' in possible):
            header_row = r
            for c, name in enumerate(possible):
                if name in normalized_expected:
                    header_map[normalized_expected[name]] = c
            break

    if header_row is None:
        return jsonify({'error': 'No se encontró la fila de encabezados. Usá el archivo exportado o la plantilla del sistema.'}), 400
    if 'Nombre' not in header_map:
        return jsonify({'error': 'La columna Nombre es obligatoria'}), 400

    # La exportación guarda una referencia oculta para distinguir un recuento
    # explícito de una cantidad antigua que no se editó al cambiar precios.
    stock_snapshot = {}
    try:
        if '_POS_stock' in book.sheet_names():
            snapshot = book.sheet_by_name('_POS_stock')
            if snapshot.ncols < 2 or snapshot.nrows < 1 or snapshot.cell_value(0, 0) != 'ID' or snapshot.cell_value(0, 1) != 'Stock original':
                raise ValueError('La referencia de stock del archivo no es válida. Exportá nuevamente la lista.')
            for r in range(1, snapshot.nrows):
                raw_id = Decimal(str(snapshot.cell_value(r, 0)))
                if not raw_id.is_finite() or raw_id <= 0 or raw_id != raw_id.to_integral_value():
                    raise ValueError('La referencia de stock contiene un ID inválido.')
                product_id = int(raw_id)
                if product_id in stock_snapshot:
                    raise ValueError('La referencia de stock contiene productos duplicados.')
                original_stock = strict_number(snapshot.cell_value(r, 1), 'Stock original')
                if original_stock < 0:
                    raise ValueError('El stock original no puede ser negativo')
                stock_snapshot[product_id] = original_stock
    except (ValueError, TypeError, InvalidOperation) as exc:
        return jsonify({'error': str(exc)}), 400

    prepared, preparation_errors = prepare_price_rows(
        book, sheet, dict(header_map, __row__=header_row), excel_text, excel_number,
        non_negative_amount, percent_amount, read_xls_date)
    if preparation_errors:
        return jsonify({'error': 'No se importó nada porque hay errores en el archivo.', 'details': preparation_errors}), 400
    db = get_db()
    db.execute('BEGIN IMMEDIATE')
    products_by_id, products_by_code = load_import_products(db, prepared, excel_text)
    created = 0
    updated = 0
    skipped = 0
    errors = []
    stock_conflict = False
    stock_preserved = 0
    stamp = now_iso()
    rounding_mode, rounding_multiple = get_global_product_rounding()
    stock_enabled = stock_control_enabled()

    def col_value(row_index, header, default=None):
        return prepared.get(row_index, {}).get(header, default)

    for r in range(header_row + 1, sheet.nrows):
        try:
            raw_name = excel_text(col_value(r, 'Nombre'))
            if not raw_name:
                skipped += 1
                continue

            product_id = col_value(r, 'ID') or None
            lookup_barcode = excel_text(col_value(r, 'Código de barra')) or None
            existing = products_by_id.get(product_id) if product_id else None
            if not existing and lookup_barcode:
                existing = products_by_code.get(lookup_barcode)
            previous = dict(existing) if existing else {}
            barcode = lookup_barcode if 'Código de barra' in header_map else previous.get('barcode')
            detail = excel_text(col_value(r, 'Detalle')) if 'Detalle' in header_map else previous.get('detail', '')
            numeric_values = {}
            for field, header, validator in (
                ('cost_without_tax', 'Precio sin impuestos', non_negative_amount),
                ('iva_percent', 'IVA %', percent_amount),
                ('gross_income_percent', 'Ingresos brutos %', percent_amount),
                ('margin_percent', 'Margen ganancia %', non_negative_amount),
            ):
                cell = col_value(r, header)
                value = cell if cell not in ('', None) else previous.get(field, 0)
                numeric_values[field] = validator(value, header)
            cost, iva, gross, margin = (numeric_values[field] for field in
                                      ('cost_without_tax', 'iva_percent', 'gross_income_percent', 'margin_percent'))
            pricing_changed = not existing or any(value != money(previous[field]) for field, value in numeric_values.items())
            total_cost_cell = col_value(r, 'Costo total')
            sale_price_cell = col_value(r, 'Precio venta')
            calc_total_cost, calc_sale_price = calculate_prices(cost, iva, gross, margin, rounding_mode, rounding_multiple)
            default_cost = calc_total_cost if pricing_changed else previous['total_cost']
            default_price = calc_sale_price if pricing_changed else previous['sale_price']
            total_cost = non_negative_amount(total_cost_cell if total_cost_cell not in ('', None) else default_cost, 'Costo total')
            sale_price = non_negative_amount(sale_price_cell if sale_price_cell not in ('', None) else default_price, 'Precio venta')
            if margin == 0 and total_cost > 0 and sale_price > 0 and (not existing or col_value(r, 'Margen ganancia %') not in ('', None)):
                derived_margin = money(((sale_price / total_cost) - 1) * 100)
                # No guardar un margen negativo: dejaría el producto inconsistente
                # y luego la pantalla de edición no lo podría volver a guardar.
                if derived_margin >= 0:
                    margin = derived_margin
            if total_cost == 0:
                total_cost = calc_total_cost
            stock_cell = col_value(r, 'Stock')
            requested_stock = non_negative_amount(stock_cell, 'Stock') if stock_cell not in ('', None) else None
            old_stock = money(previous.get('stock', 0))
            stock = old_stock
            if not existing:
                stock = (requested_stock or 0) if stock_enabled else 0
            if existing and stock_enabled and requested_stock is not None:
                original_stock = stock_snapshot.get(existing['id'])
                if original_stock is not None and requested_stock != original_stock:
                    if old_stock != original_stock and requested_stock != old_stock:
                        stock_conflict = True
                        raise ValueError(f'El stock de {raw_name} cambió desde la exportación. Exportá nuevamente la lista antes de ajustar existencias.')
                    stock = requested_stock
                if stock == old_stock and requested_stock != old_stock:
                    stock_preserved += 1
            try:
                expiry_date = (col_value(r, 'Fecha vencimiento')
                               if 'Fecha vencimiento' in header_map else previous.get('expiry_date'))
            except ValueError as exc:
                raise ValueError(f'Fecha vencimiento inválida: {exc}')

            if existing:
                db.execute("""
                    UPDATE products
                    SET barcode=?, name=?, detail=?, cost_without_tax=?, iva_percent=?, gross_income_percent=?,
                        total_cost=?, margin_percent=?, rounding_mode=?, rounding_multiple=?, sale_price=?, stock=?, expiry_date=?, updated_at=?
                    WHERE id=?
                """, (barcode, raw_name, detail, cost, iva, gross, total_cost, margin, rounding_mode, rounding_multiple, sale_price, stock, expiry_date, stamp, existing['id']))
                if stock_enabled and stock != old_stock:
                    stock_movement(existing, 'Ajuste manual', money(stock - old_stock), old_stock, stock, 'Importación Excel')
                updated += 1
            else:
                inserted = db.execute("""
                    INSERT INTO products (
                        barcode, name, detail, cost_without_tax, iva_percent, gross_income_percent,
                        total_cost, margin_percent, rounding_mode, rounding_multiple, sale_price, stock, expiry_date, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (barcode, raw_name, detail, cost, iva, gross, total_cost, margin, rounding_mode, rounding_multiple, sale_price, stock, expiry_date, stamp, stamp))
                created += 1
            cached = dict(previous, id=existing['id'] if existing else inserted.lastrowid,
                          barcode=barcode, name=raw_name, detail=detail, cost_without_tax=cost,
                          iva_percent=iva, gross_income_percent=gross, total_cost=total_cost,
                          margin_percent=margin, sale_price=sale_price, stock=stock, expiry_date=expiry_date)
            products_by_id[cached['id']] = cached
            if previous.get('barcode') and products_by_code.get(previous['barcode'], {}).get('id') == cached['id']:
                products_by_code.pop(previous['barcode'], None)
            if barcode:
                products_by_code[barcode] = cached
        except sqlite3.OperationalError:
            raise
        except Exception as exc:
            errors.append(f'Fila {r + 1}: {exc}')
            if len(errors) >= 10:
                break

    if errors:
        db.rollback()
        return jsonify({'error': 'No se importó nada porque hay errores en el archivo.', 'details': errors}), 409 if stock_conflict else 400

    db.commit()
    return jsonify({'ok': True, 'created': created, 'updated': updated, 'skipped': skipped, 'stock_preserved': stock_preserved})

