from .route_services.documents import (
    LABEL_FONT_MAP,
    ar_currency,
    best_label_grid,
    build_a5_ticket_pdf,
    build_product_labels_pdf,
    clamp_float,
    clamp_int,
    draw_qr_on_pdf,
    fetch_sale_for_ticket,
    label_font_pair,
    print_pdf_file,
    safe_pdf_text,
    sale_pdf_filename,
    ticket_accent,
    ticket_flag,
    ticket_font_multiplier,
    ticket_number_value,
    ticket_page_size,
    ticket_qr_value,
    wrap_pdf_text,
)
from .route_services.barcodes import (
    _decode_1d_candidates,
    _decode_barcode_frame,
    clean_detected_barcode,
    decode_barcode_image_bytes,
)
from .route_services.uploads import track_upload
from .route_services.transactions import consistent_read
from .route_services.money import money, money_product, money_sum, strict_number, normalize_rounding_mode, apply_price_rounding, calculate_prices, get_global_product_rounding
from .route_services.dates import now_iso, format_date_ar, format_datetime_ar, normalize_date
from .route_services.iterators import iter_repeated_items
from datetime import datetime, date, timedelta

import base64
import hashlib
import json

import re

import os

import math

import warnings

from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_UP

import subprocess

import sqlite3

import sys

import threading

import time

from functools import wraps

from io import BytesIO

from uuid import uuid4

from flask import Blueprint, make_response, current_app, g, jsonify, redirect, render_template, request, send_file, session, url_for

from werkzeug.exceptions import RequestEntityTooLarge

from werkzeug.security import check_password_hash, generate_password_hash

from werkzeug.utils import secure_filename

from .db import get_db, get_settings, update_settings, public_settings, backup_database

bp = Blueprint('main', __name__)

ALLOWED_LOGO_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}

ALLOWED_PRODUCT_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}
MAX_IMAGE_UPLOAD_BYTES = 30 * 1024 * 1024
MAX_IMAGE_PIXELS = 40_000_000
MAX_BARCODE_IMAGE_BYTES = 4 * 1024 * 1024

EXCEL_HEADERS = [
    'ID', 'Código de barra', 'Nombre', 'Detalle', 'Precio sin impuestos',
    'IVA %', 'Ingresos brutos %', 'Costo total', 'Margen ganancia %',
    'Precio venta', 'Stock', 'Fecha vencimiento'
]

def stock_control_enabled():
    """Indica si las operaciones deben controlar y actualizar existencias."""
    cache_key = '_pos_stock_control_enabled'
    if not hasattr(g, cache_key):
        raw = str(get_settings().get('stock_control_enabled', '1')).strip().lower()
        setattr(g, cache_key, raw in ('1', 'true', 'on', 'yes', 'si', 'sí'))
    return bool(getattr(g, cache_key))

def rollback_on_db_error(view):
    """Revierte la operación si falla una escritura SQL antes del commit."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        try:
            return view(*args, **kwargs)
        except sqlite3.Error:
            try:
                get_db().rollback()
            except Exception:
                pass
            current_app.logger.exception('Error de base de datos en %s; operación revertida', view.__name__)
            return jsonify({'error': 'No se pudo completar la operación por un error de base de datos. No se guardaron los cambios; intentá nuevamente.'}), 500
        except Exception:
            # También revertir excepciones de lógica inesperadas antes de que
            # Flask genere el 500. Así no queda una transacción abierta en g.
            try:
                get_db().rollback()
            except Exception:
                pass
            raise
    return wrapped

def require_json_object(view):
    """Rechaza con 400 un cuerpo JSON que sea válido pero no un objeto.

    Sin esta comprobación, un cuerpo como [] o "texto" llega a ``data.get(...)``
    y termina en un 500 con traza. Los endpoints que aceptan formulario
    (multipart) no se ven afectados porque se omite la validación.
    """
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not (request.files or request.form):
            data = request.get_json(silent=True)
            if not isinstance(data, dict):
                return jsonify({'error': 'El cuerpo de la solicitud debe ser un objeto JSON válido.'}), 400
        return view(*args, **kwargs)
    return wrapped

def commit_operation(db):
    # Cuando existe clave de reintento, la respuesta y los cambios de negocio
    # se confirman juntos en idempotent_operation.
    if not getattr(g, '_pos_idempotent_operation', False):
        db.commit()

def idempotent_operation(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        key = request.headers.get('Idempotency-Key')
        if key is None:
            return view(*args, **kwargs)  # Compatibilidad con clientes anteriores.
        if not re.fullmatch(r'[A-Za-z0-9_-]{16,128}', key):
            return jsonify({'error': 'Identificador de operación inválido'}), 400
        if request.mimetype == 'multipart/form-data':
            payload = {'form': request.form.to_dict(flat=False), 'files': []}
            for field, uploaded in request.files.items(multi=True):
                digest = hashlib.sha256()
                position = uploaded.stream.tell()
                for chunk in iter(lambda: uploaded.stream.read(65536), b''):
                    digest.update(chunk)
                uploaded.stream.seek(position)
                payload['files'].append([field, uploaded.filename, digest.hexdigest()])
        else:
            payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({'error': 'Los datos de la operación deben ser un objeto válido'}), 400
        payload_hash = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':'),
                                                  ensure_ascii=True).encode('utf-8')).hexdigest()
        scope = request.method + ':' + request.path + ':' + current_user_name()
        db = get_db()
        db.execute('BEGIN IMMEDIATE')
        try:
            receipt = db.execute('''SELECT payload_hash, response_json, status_code
                                   FROM operation_receipts WHERE scope=? AND request_key=?''',
                                 (scope, key)).fetchone()
            if receipt:
                db.rollback()
                if receipt['payload_hash'] != payload_hash:
                    return jsonify({'error': 'La operación ya fue confirmada con otros datos. Revisá el registro antes de reintentar.'}), 409
                response = current_app.response_class(receipt['response_json'], status=receipt['status_code'],
                                                      mimetype='application/json')
                response.headers['Idempotency-Replayed'] = 'true'
                return response
            g._pos_idempotent_operation = True
            response = make_response(view(*args, **kwargs))
            if 200 <= response.status_code < 300:
                if not db.in_transaction:
                    raise RuntimeError('La operación se confirmó fuera de su transacción')
                db.execute('''INSERT INTO operation_receipts
                    (scope, request_key, payload_hash, response_json, status_code, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)''',
                    (scope, key, payload_hash, response.get_data(as_text=True), response.status_code, now_iso()))
                db.commit()
            else:
                db.rollback()
            return response
        except Exception:
            db.rollback()
            raise
        finally:
            g._pos_idempotent_operation = False
    return wrapped

def password_matches(raw_password, stored_value):
    raw_password = raw_password or ''
    stored_value = stored_value or ''
    if not stored_value:
        return False
    if stored_value.startswith(('scrypt:', 'pbkdf2:', 'argon2:')):
        try:
            return check_password_hash(stored_value, raw_password)
        except ValueError:
            return False
    # Compatibilidad por si alguna base antigua tenía la clave en texto.
    return raw_password == stored_value

def active_admin_exists():
    try:
        row = get_db().execute(
            "SELECT COUNT(*) AS c FROM users WHERE role='Administrador' AND is_active=1"
        ).fetchone()
        return bool(row and row['c'] > 0)
    except Exception:
        return False

def create_first_admin(username, password):
    stamp = now_iso()
    db = get_db()
    cur = db.execute('''
        INSERT INTO users (username, full_name, role, password_hash, is_active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        username, 'Administrador', 'Administrador', generate_password_hash(password), 1, stamp, stamp
    ))
    update_settings({
        'login_username': username,
        'default_cashier_name': username,
        'login_password_hash': generate_password_hash(password),
        'admin_password_hash': generate_password_hash(password),
    })
    db.commit()
    return cur.lastrowid

def start_default_admin_session():
    """Inicia la sesión local como el administrador predeterminado, sin contraseña."""
    row = get_db().execute(
        """
        SELECT id, username, session_version FROM users
        WHERE role='Administrador' AND is_active=1
        ORDER BY CASE WHEN LOWER(username)='admin' THEN 0 ELSE 1 END, id
        LIMIT 1
        """
    ).fetchone()
    if not row:
        return False
    session.clear()
    session['logged_in'] = True
    session['authenticated_login'] = False
    session['local_auto_login'] = False
    session['passwordless_admin_login'] = True
    session['username'] = row['username']
    session['user_id'] = row['id']
    session['session_version'] = row['session_version']
    session['user_role'] = 'Administrador'
    return True

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if session.get('access_revoked'):
            if request.path.startswith('/api/'):
                return jsonify({'error': 'La sesión ya no es válida. Iniciá sesión nuevamente.', 'login_required': True}), 401
            return redirect(url_for('main.login_page'))
        # La configuración inicial crea un administrador local predeterminado.
        if not active_admin_exists():
            if request.path.startswith('/api/'):
                return jsonify({'error': 'No se encontró un administrador activo.', 'setup_required': True}), 428
            return redirect(url_for('main.first_setup_page'))

        # Inicio local automático como administrador, sin pedir contraseña.
        # También migra cookies de versiones anteriores que eran sesiones de cajero.
        needs_default_admin = (
            not session.get('logged_in')
            or (
                not session.get('authenticated_login')
                and (session.get('local_auto_login') or not session.get('passwordless_admin_login'))
            )
        )
        if needs_default_admin:
            if not start_default_admin_session():
                if request.path.startswith('/api/'):
                    return jsonify({'error': 'No se encontró un administrador activo.'}), 428
                return redirect(url_for('main.first_setup_page'))

        # El ID impide que una cuenta nueva con el mismo nombre herede la sesión.
        # La versión invalida sesiones incluso tras desactivar y reactivar al usuario.
        try:
            global_valid = True
            if session.get('legacy_global_login') or session.get('global_password_login'):
                settings = get_settings()
                fingerprint = hashlib.sha256(((settings.get('login_username') or 'admin').lower()
                                              + ':' + (settings.get('login_password_hash') or '')).encode()).hexdigest()
                global_valid = session.get('global_credential_fingerprint') == fingerprint
            if session.get('legacy_global_login'):
                valid = global_valid
                session['user_role'] = 'Cajero'
            else:
                if session.get('user_id') is not None:
                    row = get_db().execute(
                        'SELECT id, username, role, is_active, session_version FROM users WHERE id=?',
                        (session['user_id'],)
                    ).fetchone()
                else:
                    # Solo el inicio local puede migrar cookies antiguas sin ID.
                    row = get_db().execute(
                        'SELECT id, username, role, is_active, session_version FROM users WHERE LOWER(username)=LOWER(?) LIMIT 1',
                        (session.get('username'),)
                    ).fetchone()
                valid = bool(global_valid and row and row['is_active']
                             and session.get('session_version', row['session_version']) == row['session_version'])
                if session.get('authenticated_login') and ('user_id' not in session or 'session_version' not in session):
                    valid = False
                if session.get('passwordless_admin_login') and row and row['role'] != 'Administrador':
                    valid = False
                if valid:
                    session['user_id'] = row['id']
                    session['username'] = row['username']
                    session['user_role'] = row['role']
                    session['session_version'] = row['session_version']
        except sqlite3.Error:
            current_app.logger.exception('No se pudo verificar la sesión')
            return jsonify({'error': 'No se pudo verificar la sesión. Intentá nuevamente.'}), 503
        if not valid:
            session.clear()
            session['access_revoked'] = True
            if request.path.startswith('/api/'):
                return jsonify({'error': 'La sesión ya no es válida. Iniciá sesión nuevamente.', 'login_required': True}), 401
            return redirect(url_for('main.login_page'))
        return fn(*args, **kwargs)
    return wrapper

def admin_password_ok(password):
    settings = get_settings()
    return password_matches(password, settings.get('admin_password_hash'))

def current_user_name():
    return session.get('username') or get_settings().get('default_cashier_name') or 'admin'

def current_cashier_display_name():
    """Respeta el nombre de cajero configurado en tickets durante el autoingreso admin."""
    if session.get('passwordless_admin_login'):
        return get_settings().get('default_cashier_name') or current_user_name()
    return current_user_name()

def current_user_row():
    # La sesión passwordless predeterminada se asocia al administrador activo
    # almacenado en la base; las sesiones locales antiguas se migran en login_required.
    if session.get('access_revoked') or session.get('legacy_global_login') or (session.get('local_auto_login') and not session.get('authenticated_login')):
        return None
    name = current_user_name()
    try:
        if session.get('user_id') is not None:
            return get_db().execute('SELECT * FROM users WHERE is_active=1 AND id=?', (session['user_id'],)).fetchone()
        return get_db().execute(
            """
            SELECT * FROM users
            WHERE is_active=1 AND LOWER(username)=LOWER(?)
            LIMIT 1
            """,
            (name,)
        ).fetchone()
    except Exception:
        return None

def current_user_role():
    if session.get('local_auto_login') and not session.get('authenticated_login'):
        return 'Cajero'
    row = current_user_row()
    if row:
        return row['role'] or 'Cajero'
    return 'Cajero'

def current_user_is_admin():
    return current_user_role() == 'Administrador'

def product_to_dict(row):
    """Serializa un producto evitando conversiones y lecturas repetidas por fila."""
    row_keys = row.keys() if hasattr(row, 'keys') else ()
    has_rounding_mode = 'rounding_mode' in row_keys
    has_rounding_multiple = 'rounding_multiple' in row_keys
    has_min_stock = 'min_stock' in row_keys
    has_supplier_id = 'supplier_id' in row_keys

    try:
        photo_path = row['photo_path'] or ''
    except Exception:
        photo_path = ''

    # Reutilizar valores ya normalizados evita repetir Decimal/quantize
    # en el cálculo de low_stock para cada uno de los 200-300 productos.
    stock = money(row['stock'])
    min_stock = money(row['min_stock']) if has_min_stock else 0
    expiry_date = row['expiry_date'] or ''
    low_stock = stock_control_enabled() and stock <= min_stock and min_stock > 0

    return {
        'id': row['id'],
        'barcode': row['barcode'] or '',
        'name': row['name'],
        'detail': row['detail'] or '',
        'cost_without_tax': money(row['cost_without_tax']),
        'iva_percent': money(row['iva_percent']),
        'gross_income_percent': money(row['gross_income_percent']),
        'total_cost': money(row['total_cost']),
        'margin_percent': money(row['margin_percent']),
        'rounding_mode': row['rounding_mode'] if has_rounding_mode else 'none',
        'rounding_multiple': money(row['rounding_multiple']) if has_rounding_multiple else 1,
        'sale_price': money(row['sale_price']),
        'stock': stock,
        'min_stock': min_stock,
        'supplier_id': row['supplier_id'] if has_supplier_id else None,
        'low_stock': low_stock,
        'expiry_date': expiry_date,
        'expiry_date_formatted': format_date_ar(expiry_date),
        'photo_path': photo_path,
        'photo_url': url_for('static', filename=photo_path) if photo_path else '',
    }

def settings_response():
    settings = public_settings(get_settings())
    logo_path = settings.get('logo_path') or ''
    settings['logo_url'] = url_for('static', filename=logo_path) if logo_path else ''
    return settings

def _close_dedicated_browser_window(base_dir=None):
    """Intenta cerrar solo la ventana dedicada del POS abierta por run.py."""
    try:
        if base_dir is None:
            base_dir = current_app.config.get('BASE_DIR') or os.path.abspath(os.path.join(current_app.root_path, os.pardir))
        pid_file = os.path.join(str(base_dir), 'logs', 'browser_pid.txt')
        if not os.path.exists(pid_file):
            return
        raw_pid = open(pid_file, 'r', encoding='utf-8').read().strip()
        if not raw_pid.isdigit():
            return
        pid = int(raw_pid)
        if os.name == 'nt':
            subprocess.run(['taskkill', '/PID', str(pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            try:
                os.kill(pid, 15)
            except Exception:
                pass
    except Exception:
        pass

def _shutdown_pc():
    """Apaga la computadora cuando el usuario lo solicita con F12."""
    try:
        if os.name == 'nt':
            subprocess.Popen(['shutdown', '/s', '/f', '/t', '0'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif sys.platform == 'darwin':
            subprocess.Popen(['osascript', '-e', 'tell app "System Events" to shut down'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            # En Linux puede requerir permisos de administrador según la distribución.
            subprocess.Popen(['shutdown', '-h', 'now'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

def logo_extension(filename):
    if not filename or '.' not in filename:
        return ''
    ext = filename.rsplit('.', 1)[1].lower()
    return ext if ext in ALLOWED_LOGO_EXTENSIONS else ''

def product_image_extension(filename):
    if not filename or '.' not in filename:
        return ''
    ext = filename.rsplit('.', 1)[1].lower()
    return ext if ext in ALLOWED_PRODUCT_IMAGE_EXTENSIONS else ''

def _validate_uploaded_file_size(file_storage, max_bytes=MAX_IMAGE_UPLOAD_BYTES):
    """Mide el archivo sin cargarlo completo en RAM y rechaza cargas excesivas."""
    stream = getattr(file_storage, 'stream', None)
    size = None
    if stream is not None:
        try:
            position = stream.tell()
            stream.seek(0, os.SEEK_END)
            size = stream.tell()
            stream.seek(position, os.SEEK_SET)
        except (AttributeError, OSError, ValueError):
            size = None
    if size is None:
        size = getattr(file_storage, 'content_length', None)
    if size is None or int(size) <= 0:
        raise ValueError('El archivo está vacío o no se pudo verificar su tamaño.')
    if int(size) > int(max_bytes):
        raise ValueError('La imagen supera el límite permitido de 30 MB.')
    return int(size)

def save_uploaded_image(file_storage, prefix, allowed_ext_func, error_message, max_pixels=1200):
    """Guarda una imagen local y la optimiza para evitar archivos enormes.

    Acepta fotos grandes tomadas desde celular. Para PNG/JPG/JPEG/WEBP intenta
    redimensionar y comprimir; para GIF conserva el archivo original.
    """
    if not file_storage or not file_storage.filename:
        return ''
    ext = allowed_ext_func(file_storage.filename)
    if not ext:
        raise ValueError(error_message)
    _validate_uploaded_file_size(file_storage)

    upload_dir = current_app.config['UPLOAD_DIR']
    upload_dir.mkdir(parents=True, exist_ok=True)

    try:
        from PIL import Image
    except ImportError:
        Image = None

    # GIF animado de productos: se guarda sin procesar para no romper la animación.
    # En logos conviene convertir incluso GIF/WEBP/JPG a PNG para que el ticket
    # PDF los inserte con mejor calidad y con transparencia cuando exista.
    if Image is None:
        # Pillow es dependencia del paquete, pero se conserva el fallback de
        # instalaciones mínimas; el límite de bytes sigue siendo obligatorio.
        filename = secure_filename(f'{prefix}_{uuid4().hex}.{ext}')
        track_upload(upload_dir / filename)
        file_storage.save(upload_dir / filename)
        return f'uploads/{filename}'

    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(file_storage.stream) as source_image:
                expected_formats = {
                    'jpg': {'JPEG'}, 'jpeg': {'JPEG'}, 'png': {'PNG'},
                    'webp': {'WEBP'}, 'gif': {'GIF'},
                }
                if source_image.format not in expected_formats.get(ext, set()):
                    raise ValueError('El contenido real de la imagen no coincide con su extensión.')
                width, height = source_image.size
                if width <= 0 or height <= 0 or width * height > MAX_IMAGE_PIXELS:
                    raise ValueError('La imagen tiene dimensiones superiores al límite permitido.')
                # GIF animado de productos: verificar y conservar el original
                # antes de decodificar el primer frame para no perder animación.
                if ext == 'gif' and prefix != 'logo':
                    source_image.verify()
                    file_storage.stream.seek(0)
                    filename = secure_filename(f'{prefix}_{uuid4().hex}.{ext}')
                    track_upload(upload_dir / filename)
                    file_storage.save(upload_dir / filename)
                    return f'uploads/{filename}'

                # Fuerza la decodificación para detectar archivos truncados o corruptos.
                source_image.load()
                source_image.thumbnail((max_pixels, max_pixels), Image.LANCZOS)

                # Los logos se guardan en PNG para conservar transparencia.
                if prefix == 'logo':
                    filename = secure_filename(f'{prefix}_{uuid4().hex}.png')
                    output_path = upload_dir / filename
                    track_upload(output_path)
                    output_image = source_image if source_image.mode in ('RGBA', 'LA') else source_image.convert('RGBA')
                    try:
                        output_image.save(output_path, format='PNG', optimize=True)
                    finally:
                        if output_image is not source_image:
                            output_image.close()
                    return f'uploads/{filename}'

                filename = secure_filename(f'{prefix}_{uuid4().hex}.jpg')
                output_path = upload_dir / filename
                track_upload(output_path)
                output_image = source_image if source_image.mode in ('RGB', 'L') else source_image.convert('RGB')
                try:
                    output_image.save(output_path, format='JPEG', quality=86, optimize=True)
                finally:
                    if output_image is not source_image:
                        output_image.close()
                return f'uploads/{filename}'
    except ValueError:
        raise
    except (OSError, SyntaxError, Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
        raise ValueError('La imagen está dañada o supera los límites de procesamiento.') from exc

def save_logo_image(file_storage):
    return save_uploaded_image(
        file_storage,
        'logo',
        logo_extension,
        'El logo debe ser PNG, JPG, JPEG, WEBP o GIF',
        max_pixels=1400,
    )

def save_product_photo(file_storage):
    return save_uploaded_image(
        file_storage,
        'producto',
        product_image_extension,
        'La foto del producto debe ser PNG, JPG, JPEG, WEBP o GIF',
        max_pixels=1200,
    )

def product_payload():
    if request.files or request.form:
        return request.form
    return request.get_json(force=True)

def text_field(value, default=''):
    """Normaliza un campo de texto y rechaza tipos que no sean texto.

    Antes, un número o una lista llegaban a ``.strip()`` y provocaban un 500 con
    traza. Ahora un valor no textual se traduce en ValueError, que el endpoint
    convierte en 400 con un mensaje claro.
    """
    if value is None:
        return default
    if isinstance(value, str):
        return value.strip()
    raise ValueError('El valor de texto no es válido')

def non_negative_amount(value, label):
    """Convierte un importe y rechaza valores negativos.

    Las compras ya validaban sus importes; los productos no, y permitían guardar
    un costo negativo que producía un precio de venta negativo imposible de vender.
    """
    number = strict_number(value, label, default=0)
    if Decimal(str(value or 0)) < 0:
        raise ValueError(f'{label}: no puede ser negativo')
    return number

def percent_amount(value, label):
    """Convierte un porcentaje y lo limita al rango 0-100."""
    number = strict_number(value, label, default=0)
    if Decimal(str(value or 0)) < 0:
        raise ValueError(f'{label}: no puede ser negativo')
    if Decimal(str(value or 0)) > 100:
        raise ValueError(f'{label}: no puede superar 100')
    return number

LIKE_ESCAPE = '\\'

def like_contains(value):
    """Patrón LIKE 'contiene' con comodines escapados.

    Sin escapar, un término como '50%' o 'a_b' se interpreta como comodín y
    devuelve resultados que no coinciden con el texto buscado. El patrón debe
    usarse junto a ``ESCAPE '\\'`` en la consulta.
    """
    return '%' + escape_like_value(value) + '%'

def like_prefix(value):
    """Patrón LIKE 'empieza con' con comodines escapados."""
    return escape_like_value(value) + '%'

def escape_like_value(value):
    text = str(value)
    for char in (LIKE_ESCAPE, '%', '_'):
        text = text.replace(char, LIKE_ESCAPE + char)
    return text

def user_to_dict(row):
    return {
        'id': row['id'],
        'username': row['username'],
        'full_name': row['full_name'] or '',
        'role': row['role'] or 'Cajero',
        'is_active': bool(row['is_active']),
        'created_at': row['created_at'] or '',
        'updated_at': row['updated_at'] or '',
    }

def require_security_password_from_payload(data):
    # Administrador activo: no se solicita contraseña para modificaciones.
    # Otros usuarios deben ingresar la clave de seguridad.
    if current_user_is_admin():
        return True
    # Un valor no textual (número/lista) no es una contraseña válida: se rechaza
    # sin romper con 500 al llamar a .strip().
    raw_password = data.get('security_password')
    if raw_password is None:
        raw_password = data.get('password')
    password = raw_password.strip() if isinstance(raw_password, str) else ''
    if not admin_password_ok(password):
        return False
    return True

def log_audit(action, module='', detail=''):
    try:
        get_db().execute(
            'INSERT INTO audit_logs (user_name, action, module, detail, created_at) VALUES (?, ?, ?, ?, ?)',
            (current_user_name(), str(action)[:120], str(module)[:80], str(detail)[:500], now_iso())
        )
    except Exception:
        pass

def active_cash_session():
    return get_db().execute(
        "SELECT * FROM cash_sessions WHERE status='abierta' ORDER BY id DESC LIMIT 1"
    ).fetchone()

def add_cash_movement(movement_type, amount, description='', payment_method='Efectivo', sale_id=None, cash_session_id=None):
    db = get_db()
    # Compartir el bloqueo con el cierre hasta el commit del llamador.
    if not db.in_transaction:
        db.execute('BEGIN IMMEDIATE')
    if cash_session_id:
        session_row = db.execute("SELECT * FROM cash_sessions WHERE id=? AND status='abierta'", (cash_session_id,)).fetchone()
        if not session_row:
            raise ValueError('La caja indicada ya no está abierta')
    else:
        session_row = active_cash_session()
    session_id = session_row['id'] if session_row else None
    db.execute('''
        INSERT INTO cash_movements (cash_session_id, movement_type, amount, description, payment_method, sale_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (session_id, movement_type, money(amount), description, payment_method, sale_id, now_iso()))
    return session_id

def stock_movement(product, movement_type, qty, previous_stock, new_stock, reference='', notes=''):
    # No ocultar fallas: el llamador revierte la transacción para que el stock
    # y su historial nunca queden desincronizados.
    get_db().execute('''
        INSERT INTO product_movements (product_id, product_name, movement_type, quantity, previous_stock, new_stock, reference, notes, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (product['id'], product['name'], movement_type, money(qty), money(previous_stock), money(new_stock), reference, notes, now_iso()))

def excel_text(value):
    if value is None:
        return ''
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()

def excel_number(value):
    if value is None or value == '':
        return 0.0
    if isinstance(value, (int, float)):
        return strict_number(value, 'Valor numérico de Excel')
    raw = str(value).strip().replace('$', '').replace(' ', '')
    # Permite formato argentino 1.234,56 y formato simple 1234.56.
    if ',' in raw and '.' in raw:
        raw = raw.replace('.', '').replace(',', '.')
    elif ',' in raw:
        raw = raw.replace(',', '.')
    elif '.' in raw:
        parts = raw.split('.')
        if len(parts) > 1 and all(len(part) == 3 for part in parts[1:]):
            raw = ''.join(parts)
    return strict_number(raw, 'Valor numérico de Excel')

def read_xls_date(book, sheet, row_index, col_index):
    import xlrd

    if col_index is None or col_index >= sheet.ncols:
        return None
    cell = sheet.cell(row_index, col_index)
    value = cell.value
    if value in ('', None):
        return None
    if cell.ctype == xlrd.XL_CELL_DATE:
        try:
            return xlrd.xldate_as_datetime(value, book.datemode).date().isoformat()
        except Exception:
            pass
    if isinstance(value, float) and value.is_integer() and value > 20000:
        try:
            return xlrd.xldate_as_datetime(value, book.datemode).date().isoformat()
        except Exception:
            pass
    return normalize_date(str(value).strip())

def write_xls_products(rows):
    import xlwt

    workbook = xlwt.Workbook(encoding='utf-8')
    sheet = workbook.add_sheet('Lista de precios')
    snapshot = workbook.add_sheet('_POS_stock')
    snapshot.visibility = 1
    snapshot.write(0, 0, 'ID')
    snapshot.write(0, 1, 'Stock original')

    title_style = xlwt.easyxf(
        'font: bold on, colour white, height 320;'
        'pattern: pattern solid, fore_colour ocean_blue;'
        'alignment: horiz center, vert center;'
    )
    header_style = xlwt.easyxf(
        'font: bold on, colour white;'
        'pattern: pattern solid, fore_colour dark_blue;'
        'alignment: horiz center, vert center;'
        'borders: left thin, right thin, top thin, bottom thin;'
    )
    text_style = xlwt.easyxf('borders: left thin, right thin, top thin, bottom thin; alignment: vert center;')
    money_style = xlwt.easyxf('borders: left thin, right thin, top thin, bottom thin; alignment: vert center;', num_format_str='$ #,##0.00')
    percent_style = xlwt.easyxf('borders: left thin, right thin, top thin, bottom thin; alignment: vert center;', num_format_str='0.00')
    number_style = xlwt.easyxf('borders: left thin, right thin, top thin, bottom thin; alignment: vert center;', num_format_str='0.00')
    date_style = xlwt.easyxf('borders: left thin, right thin, top thin, bottom thin; alignment: vert center;', num_format_str='DD/MM/YYYY')

    sheet.write_merge(0, 0, 0, len(EXCEL_HEADERS)-1, 'LISTA DE PRECIOS - POS LOCAL', title_style)
    sheet.write_merge(1, 1, 0, len(EXCEL_HEADERS)-1, 'No cambies el nombre de las columnas. Para actualizar, editá precios y volvé a importar este archivo.', text_style)

    widths = [10, 22, 34, 40, 18, 12, 18, 18, 18, 18, 12, 18]
    for idx, width in enumerate(widths):
        sheet.col(idx).width = int(width * 256)

    header_row = 3
    for col, header in enumerate(EXCEL_HEADERS):
        sheet.write(header_row, col, header, header_style)

    for r_idx, row in enumerate(rows, start=header_row + 1):
        product = product_to_dict(row)
        snapshot.write(r_idx - header_row, 0, product['id'])
        snapshot.write(r_idx - header_row, 1, product['stock'])
        values = [
            product['id'], product['barcode'], product['name'], product['detail'],
            product['cost_without_tax'], product['iva_percent'], product['gross_income_percent'],
            product['total_cost'], product['margin_percent'], product['sale_price'], product['stock'],
            product['expiry_date']
        ]
        for c_idx, value in enumerate(values):
            if c_idx in (4, 7, 9):
                sheet.write(r_idx, c_idx, value, money_style)
            elif c_idx in (5, 6, 8):
                sheet.write(r_idx, c_idx, value, percent_style)
            elif c_idx == 10:
                sheet.write(r_idx, c_idx, value, number_style)
            elif c_idx == 11:
                if value:
                    try:
                        sheet.write(r_idx, c_idx, datetime.strptime(value, '%Y-%m-%d'), date_style)
                    except Exception:
                        sheet.write(r_idx, c_idx, format_date_ar(value), text_style)
                else:
                    sheet.write(r_idx, c_idx, '', text_style)
            else:
                sheet.write(r_idx, c_idx, value, text_style)

    out = BytesIO()
    workbook.save(out)
    out.seek(0)
    return out

def supplier_to_dict(row):
    return {
        'id': row['id'], 'name': row['name'], 'cuit': row['cuit'] or '',
        'phone': row['phone'] or '', 'address': row['address'] or '',
        'category': row['category'] or '', 'notes': row['notes'] or '',
        'created_at': row['created_at'], 'updated_at': row['updated_at'],
    }

def client_to_dict(row):
    return {
        'id': row['id'], 'name': row['name'], 'document': row['document'] or '',
        'phone': row['phone'] or '', 'address': row['address'] or '',
        'notes': row['notes'] or '', 'balance': money(row['balance']),
        'created_at': row['created_at'], 'updated_at': row['updated_at'],
    }

__all__ = [name for name in globals() if not name.startswith("__")]

def record_id(value):
    """Valida identificadores antes de pasarlos a SQLite (entero de 64 bits)."""
    try:
        if isinstance(value, bool):
            raise ValueError
        number = Decimal(str(value))
        if not number.is_finite() or number < 0 or number > 9223372036854775807 or number != number.to_integral_value():
            raise ValueError
        return int(number)
    except (InvalidOperation, TypeError, ValueError, OverflowError):
        raise ValueError('El identificador debe ser un entero entre 0 y 9223372036854775807')
