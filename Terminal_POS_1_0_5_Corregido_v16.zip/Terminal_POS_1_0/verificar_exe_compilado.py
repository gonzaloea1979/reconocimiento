"""Verificación estructural, de solo lectura; no prueba ejecución de Windows."""
from pathlib import Path
import sys


def verify_distribution(root):
    root = Path(root)
    exe = root / 'TerminalPOS.exe'
    if not exe.is_file() or exe.stat().st_size <= 100_000:
        raise ValueError('No existe un EXE compilado de tamano valido.')
    with exe.open('rb') as stream:
        if stream.read(2) != b'MZ':
            raise ValueError('El archivo no tiene cabecera PE/DOS (MZ).')
    for relative in ('app/templates', 'app/static'):
        folder = root / relative
        if not folder.is_dir() or not any(p.is_file() for p in folder.rglob('*')):
            raise ValueError('Faltan recursos externos: ' + relative)
    if not (root / 'INICIAR_POS.bat').is_file():
        raise ValueError('Falta lanzador.')
    protected = {'instance', 'backups', 'ticket', 'uploads', 'browser_profile', 'logs'}
    for path in root.rglob('*'):
        if path.is_symlink():
            raise ValueError('Enlace simbolico en distribucion: ' + str(path))
        if not path.is_file():
            continue
        name = path.name.lower()
        parts = {part.lower() for part in path.relative_to(root).parts[:-1]}
        if name == '.session_key' or path.suffix.lower() in {'.db', '.sqlite', '.sqlite3'} or name.endswith(('-wal', '-shm')) or parts & protected:
            raise ValueError('Datos de uso en distribucion: ' + str(path))
    return root


if __name__ == '__main__':
    try:
        verify_distribution(sys.argv[1] if len(sys.argv) > 1 else 'dist/TerminalPOS')
    except ValueError as exc:
        print('ERROR:', exc)
        raise SystemExit(1)
    print('OK: estructura EXE, recursos presentes, sin datos de uso.')
    print('AVISO: requiere ejecutar y probar el EXE en Windows.')
