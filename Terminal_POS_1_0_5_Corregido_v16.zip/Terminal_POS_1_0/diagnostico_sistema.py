from __future__ import annotations

import compileall
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import traceback
from pathlib import Path

BASE = Path(__file__).resolve().parent
LOG_DIR = BASE / 'logs'
LOG_DIR.mkdir(exist_ok=True)
REPORT = LOG_DIR / 'diagnostico.txt'

lines: list[str] = []

def log(msg=''):
    print(msg)
    lines.append(str(msg))


def section(title):
    log('\n' + '=' * 70)
    log(title)
    log('=' * 70)


def ok(name, detail=''):
    log(f'[OK] {name}' + (f' — {detail}' if detail else ''))


def fail(name, detail=''):
    log(f'[ERROR] {name}' + (f' — {detail}' if detail else ''))


def warn(name, detail=''):
    log(f'[AVISO] {name}' + (f' — {detail}' if detail else ''))


section('1. ARCHIVOS PRINCIPALES')
required = [
    'run.py', 'requirements.txt', 'app/__init__.py', 'app/routes.py', 'app/db.py',
    'app/templates/base.html', 'app/static/css/styles.css', 'app/static/js/common.js',
    'instance/pos.db'
]
for rel in required:
    p = BASE / rel
    (ok if p.exists() else fail)(rel)

section('2. SINTAXIS PYTHON')
try:
    result = compileall.compile_dir(str(BASE / 'app'), quiet=1, force=True)
    result = compileall.compile_file(str(BASE / 'run.py'), quiet=1, force=True) and result
    (ok if result else fail)('Compilación sintáctica Python')
except Exception as exc:
    fail('Compilación sintáctica Python', repr(exc))

section('3. BASE DE DATOS SQLITE')
db_path = BASE / 'instance' / 'pos.db'
try:
    con = sqlite3.connect(db_path)
    integrity = con.execute('PRAGMA integrity_check').fetchone()[0]
    if integrity == 'ok':
        ok('Integridad SQLite')
    else:
        fail('Integridad SQLite', integrity)
    fk = con.execute('PRAGMA foreign_key_check').fetchall()
    if not fk:
        ok('Foreign key check')
    else:
        warn('Foreign key check', f'{len(fk)} observaciones')
    tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    expected = {
        'products', 'sales', 'sale_items', 'suppliers', 'purchases', 'purchase_items',
        'product_movements', 'cash_sessions', 'cash_movements', 'clients',
        'client_movements', 'users', 'app_settings', 'audit_logs'
    }
    missing = sorted(expected - tables)
    if missing:
        fail('Tablas requeridas', ', '.join(missing))
    else:
        ok('Tablas requeridas', f'{len(expected)} presentes')
    for table in ['users','products','sales','suppliers','purchases','cash_sessions','clients']:
        if table in tables:
            count = con.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]
            log(f'  {table}: {count} registros')
    con.close()
except Exception as exc:
    fail('Base de datos', repr(exc))

section('4. JAVASCRIPT')
node = shutil.which('node')
js_files = sorted((BASE / 'app' / 'static' / 'js').glob('*.js'))
if node:
    errors = 0
    for js in js_files:
        proc = subprocess.run([node, '--check', str(js)], capture_output=True, text=True)
        if proc.returncode:
            errors += 1
            fail(js.name, (proc.stderr or proc.stdout).strip())
    if not errors:
        ok('Sintaxis JavaScript', f'{len(js_files)} archivos')
else:
    warn('Node.js no disponible', 'Se omite node --check; esto no impide usar el POS.')

section('5. REFERENCIAS DE RUTAS')
try:
    routes_text = (BASE / 'app' / 'routes.py').read_text(encoding='utf-8')
    defined = re.findall(r"@bp\.(?:route|get|post|put|delete|patch)\(['\"]([^'\"]+)", routes_text)
    literals = []
    for js in js_files:
        text = js.read_text(encoding='utf-8')
        literals.extend((js.name, m.group(1)) for m in re.finditer(r"['\"](/api/[^'\"`?$]*)", text))
    normalized_routes = [re.sub(r'<[^>]+>', '', r) for r in defined]
    suspicious = []
    for filename, literal in literals:
        base = literal.rstrip('/')
        if not any(r.startswith(base) or base.startswith(r.rstrip('/')) for r in normalized_routes):
            suspicious.append((filename, literal))
    if suspicious:
        warn('Referencias API a revisar', json.dumps(suspicious, ensure_ascii=False))
    else:
        ok('Referencias API JavaScript ↔ Flask', f'{len(literals)} referencias revisadas')
except Exception as exc:
    fail('Auditoría de rutas', repr(exc))


section('6. MOTOR DE ESCRITORIO / WEBVIEW2')
if os.name == 'nt':
    try:
        import winreg
        guid = '{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}'
        locations = [
            (winreg.HKEY_CURRENT_USER, rf"Software\Microsoft\EdgeUpdate\Clients\{guid}"),
            (winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{guid}"),
            (winreg.HKEY_LOCAL_MACHINE, rf"SOFTWARE\Microsoft\EdgeUpdate\Clients\{guid}"),
        ]
        version = None
        for hive, key_path in locations:
            try:
                with winreg.OpenKey(hive, key_path) as key:
                    value, _ = winreg.QueryValueEx(key, 'pv')
                    value = str(value or '').strip()
                    if value and value != '0.0.0.0':
                        version = value
                        break
            except OSError:
                pass
        if version:
            ok('WebView2 Runtime (no requerido en V17)', version)
        else:
            warn('WebView2 Runtime', 'No detectado. V17 no lo requiere porque usa Edge/Chrome modo app.')
    except Exception as exc:
        warn('Detección WebView2 Runtime', repr(exc))
else:
    warn('WebView2 Runtime', 'Chequeo específico de Windows omitido.')

section('7. PRUEBA FLASK SI LAS DEPENDENCIAS ESTÁN INSTALADAS')
try:
    from app import create_app
    app = create_app()
    app.testing = True
    client = app.test_client()
    pages = [
        '/', '/productos', '/consulta-precio', '/ventas', '/configuracion', '/ticket',
        '/usuarios', '/lista-precios', '/stock', '/proveedores', '/compras', '/caja',
        '/reportes', '/clientes', '/historial'
    ]
    page_errors = []
    for path in pages:
        resp = client.get(path, follow_redirects=False)
        if resp.status_code >= 500:
            page_errors.append((path, resp.status_code))
    if page_errors:
        fail('Pantallas Flask', str(page_errors))
    else:
        ok('Pantallas Flask', f'{len(pages)} pantallas sin error 500')

    apis = [
        '/api/settings', '/api/ticket-settings', '/api/users', '/api/system-keys',
        '/api/dashboard', '/api/products', '/api/suppliers', '/api/stock/alerts',
        '/api/stock/movements', '/api/purchases', '/api/cash/status', '/api/clients',
        '/api/reports', '/api/backup/list', '/api/audit', '/api/sales/last'
    ]
    api_errors = []
    for path in apis:
        resp = client.get(path, follow_redirects=False)
        # 404 es válido para /api/sales/last si todavía no hubo ventas; 428 es válido
        # antes de crear el administrador en un sistema nuevo.
        if resp.status_code >= 500:
            api_errors.append((path, resp.status_code))
    if api_errors:
        fail('APIs Flask', str(api_errors))
    else:
        ok('APIs Flask', f'{len(apis)} endpoints sin error 500')
except ModuleNotFoundError as exc:
    warn('Prueba Flask omitida', f'Falta dependencia: {exc}. Ejecutá este diagnóstico desde .venv.')
except Exception as exc:
    fail('Prueba Flask', repr(exc))
    log(traceback.format_exc())

section('8. RESULTADO')
error_count = sum(1 for line in lines if line.startswith('[ERROR]'))
warning_count = sum(1 for line in lines if line.startswith('[AVISO]'))
if error_count == 0:
    log(f'DIAGNÓSTICO COMPLETADO: sin errores críticos. Avisos: {warning_count}.')
else:
    log(f'DIAGNÓSTICO COMPLETADO: {error_count} errores y {warning_count} avisos.')

REPORT.write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(f'\nInforme guardado en: {REPORT}')
raise SystemExit(1 if error_count else 0)
