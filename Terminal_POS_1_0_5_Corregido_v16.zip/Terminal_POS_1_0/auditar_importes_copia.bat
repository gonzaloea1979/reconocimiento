@echo off
setlocal
cd /d "%~dp0"
echo AUDITORIA DE IMPORTES - SOLO LECTURA
 echo.
echo Antes de continuar, COPIE su base pos.db a otra carpeta,
echo renombre la COPIA a COPIA_POS.db, y use esa ruta.
echo NO utilice el archivo original del sistema.
echo.
set /p "POS_DB_COPIA=Ruta completa de COPIA_POS.db: "
if not defined POS_DB_COPIA (echo Sin ruta. Cancelado.& pause & exit /b 1)
if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" "tests\auditar_importes_existentes.py" "%POS_DB_COPIA%"
) else (
  py -3 "tests\auditar_importes_existentes.py" "%POS_DB_COPIA%"
)
set "RESULT=%errorlevel%"
echo.
pause
exit /b %RESULT%
