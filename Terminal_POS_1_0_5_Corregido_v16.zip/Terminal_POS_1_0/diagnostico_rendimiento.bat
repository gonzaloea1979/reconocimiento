@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
title Terminal POS - Diagnostico de Rendimiento

echo ================================================
echo      TERMINAL POS - DIAGNOSTICO DE RENDIMIENTO
echo ================================================
echo.
echo IMPORTANTE:
echo - Deja el POS abierto para medir las respuestas reales.
echo - El diagnostico lee la base de datos en modo SOLO LECTURA.
echo - No crea ventas, compras ni modifica informacion.
echo.
pause

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" diagnostico_rendimiento.py
) else (
    py -3 diagnostico_rendimiento.py 2>nul
    if errorlevel 1 python diagnostico_rendimiento.py
)

set "RC=%ERRORLEVEL%"
echo.
echo Informe: logs\diagnostico_rendimiento.txt
echo.
pause
exit /b %RC%
