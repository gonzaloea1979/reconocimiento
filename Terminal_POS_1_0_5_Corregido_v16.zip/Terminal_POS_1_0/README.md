## Entrega 1.0.5 — instalación y actualización

Versiones de dependencias fijas, preparación local compartida y sin descargas
cuando el entorno ya es correcto. Leé `MEJORAS_1_0_5.txt` y las guías de actualización.
Se conservan todas las funciones y correcciones previas, incluida la validación
de referencias de 1.0.4 que puede impedir iniciar con una base inconsistente.

## Entrega 1.0.4 — seguridad de respaldos

Mismas funciones comerciales. Se protegen nombres, retención, origen de solo lectura
y errores de los respaldos. Leé `MEJORAS_1_0_4.txt` antes de actualizar.
Se conservan todas las mejoras de las entregas anteriores.

## Entrega 1.0.3 — importes y rendimiento

Mismas funciones comerciales. Se corrigen las diferencias de redondeo entre
pantalla y servidor con cantidades fraccionadas, y se agiliza el formato de fechas.
Leé `MEJORAS_1_0_3.txt`. Se conservan las correcciones de 1.0.1 y 1.0.2.

## Entrega 1.0.2 — mejoras de estabilidad

Mismas funciones comerciales. Se protegen las confirmaciones contra doble envío y
reintentos con respuesta perdida, y se refuerza la compilación sin borrar datos de uso.
Leé `MEJORAS_1_0_2.txt`. El ZIP incluye código y kit Windows, no un EXE precompilado.

## Entrega corregida 1.0.1

Correcciones de saldos concurrentes, efectivo esperado y cierre de caja.
Leé `CORRECCIONES_1_0_1.txt` para los cambios, validación e instalación.
Este paquete contiene el código completo y el kit de compilación; no incluye un EXE precompilado.

# Terminal POS Python Local

Sistema web local de punto de venta desarrollado en Python + Flask + SQLite.

## Ejecutar en Windows

1. Descomprimir el ZIP.
2. Entrar a la carpeta.
3. Hacer doble clic en `ejecutar.bat`.

El archivo `ejecutar.bat` prepara el entorno, instala dependencias si faltan, crea carpetas necesarias e inicia el sistema.

## Actualización: ejecutar.bat revisado

- Se revisó y reemplazó `ejecutar.bat` por una versión más robusta.
- Ahora valida que existan `run.py`, `app/` y `requirements.txt` antes de iniciar.
- Detecta Python 3.12, 3.11, 3.10 o superior.
- Repara un entorno virtual incompleto.
- Instala dependencias con `--prefer-binary` para evitar errores con paquetes como Pillow/ReportLab.
- Muestra los errores en pantalla y deja la ventana abierta.
- El sistema escribe el puerto usado en `logs/pos_url.txt`.
- El registro de inicio queda en `logs/inicio.log`.

## Última actualización

- En el módulo Venta, cuando se ingresa o escanea un código de producto no registrado, aparece una ventana emergente pequeña dentro del mismo módulo con la leyenda **Producto no encontrado**.
- La ventana muestra una cuenta regresiva de 3 segundos y se limpia sola.
- Si se presiona Enter o se ingresa otro código, el aviso se cancela para permitir la nueva consulta.

## Datos importantes

- La base SQLite se crea localmente en `instance/pos.db`.
- Los backups se guardan en `backups/`.
- Los tickets PDF se guardan en `TICKET/`.
- Las imágenes se guardan en `app/static/uploads/`.

## Actualización: proporciones unificadas

- Se unificaron las proporciones de todos los módulos.
- Todos usan el mismo ancho de barra lateral, mismo alto útil, mismos márgenes y tarjetas con tamaño proporcional.
- Los módulos principales quedan contenidos en una sola pantalla cuando el monitor lo permite.
- Si un módulo tiene mucha información, el desplazamiento queda dentro de la tabla/lista/formulario correspondiente, no desordena toda la pantalla.


## Compilar a EXE

Para generar una versión ejecutable de Windows, abrí:

```text
compilar_exe.bat
```

El resultado queda en:

```text
dist\TerminalPOS\TerminalPOS.exe
```

Para moverlo a otra PC, copiá toda la carpeta `dist\TerminalPOS`, no solo el `.exe`. La base de datos, los tickets, los backups y las fotos se crean durante el uso y no se incluyen automáticamente en el paquete compilado. Para trasladar datos existentes, seguí `MIGRAR_DATOS_EXE.txt` y conservá una copia de seguridad antes de hacerlo.

Si la compilación falla, revisá:

```text
logs\compilar_exe.log
```


## Cierre del sistema

- **F10** o botón **Salir**: cierra el sistema POS y el servidor local.
- **F12** o botón **Apagar PC**: cierra el sistema POS y luego intenta apagar la computadora.

En ambos casos aparece una ventana emergente con cuenta regresiva de 5 segundos antes de ejecutar la acción.

## Versión gestión completa

Esta versión suma módulos de gestión comercial:

- Stock con mínimo y ajustes protegidos por contraseña.
- Proveedores.
- Compras/reposición con actualización automática de stock y costos.
- Caja diaria con apertura, movimientos y cierre.
- Reportes por período, forma de pago, productos y ganancia estimada.
- Clientes y cuenta corriente.
- Historial de acciones del sistema.
- Reimpresión del último ticket desde Ventas.
- Navegador en ventana dedicada maximizada.

Los módulos se acceden desde la barra lateral. Las acciones sensibles siguen solicitando la clave de seguridad configurada.


## Actualización: redondeo de precio final

En el módulo Productos, al agregar o editar un artículo, ahora se puede configurar el redondeo del precio de venta final.

Opciones disponibles:

- Sin redondeo.
- Al múltiplo más cercano.
- Siempre hacia arriba.
- Siempre hacia abajo.

Múltiplos disponibles: $1, $5, $10, $50, $100, $500 y $1000.

El formulario muestra el precio antes de redondear y el precio final redondeado.


## Organización de Configuración

- Diseño ticket y Usuarios / Contraseñas ahora están dentro de Configuración.
- F6 abre Configuración y desde ahí se administran negocio, ticket y usuarios/claves.
- Las rutas antiguas `/ticket` y `/usuarios` redirigen automáticamente a Configuración.

## Actualización: redondeo general desde Configuración

- El redondeo del precio final ahora se configura desde **Configuración > Negocio > Redondeo general de productos**.
- La opción elegida queda guardada como configuración general del sistema.
- Al cargar o editar productos, el cálculo del precio final usa automáticamente ese redondeo.
- El módulo Productos muestra el redondeo activo como referencia, pero ya no hace falta elegirlo producto por producto.

## Mejora Compras

- El módulo Compras ahora permite buscar productos por código o nombre.
- Si el producto comprado no está registrado, se puede crear desde la misma compra.
- Al registrar la compra, el sistema guarda el detalle de productos comprados y actualiza stock automáticamente.
- El historial de compras muestra el resumen de artículos cargados.

## Actualización - Módulo Compras optimizado
- El módulo Compras fue reorganizado para entrar mejor en una sola pantalla.
- El detalle de productos comprados y el historial usan desplazamiento interno.
- El alta rápida de productos se abre como panel superpuesto para no agrandar la pantalla.


## Atajos de módulos actualizados

- **F1**: Panel principal.
- **F2**: Ventas.
- **F3**: Precios.
- **F4**: Productos.
- **F5**: Compras.
- **F6**: Reportes.
- **F10**: Salir del sistema.
- **F12**: Apagar la PC.

F7 y F8 quedan sin asignar a módulos.


## Actualización - Compras con cálculo completo

- En Compras, tanto para productos existentes como para productos nuevos, se puede cargar:
  - Cantidad comprada.
  - Costo sin impuestos.
  - IVA %.
  - Ingresos brutos %.
  - Margen de ganancia %.
- El sistema muestra automáticamente:
  - Costo real calculado.
  - Precio de venta calculado con el redondeo general configurado.
- Al registrar la compra, actualiza stock, costo, impuestos, margen y precio de venta del producto.


## Actualización de atajos

- F1: Panel principal
- F2: Ventas
- F3: Precios
- F4: Productos
- F5: Compras
- F10: Salir del sistema
- F12: Apagar PC

F7 y F8 no quedan asignadas a módulos del menú lateral.


## Actualización F9 en Venta

- En el módulo Venta, **F9** abre un selector de clientes registrados.
- Se puede buscar por nombre, documento o teléfono.
- La lista se navega con flechas y se selecciona con Enter.
- Si no se selecciona cliente, la venta continúa como **Consumidor final**.
- El cliente seleccionado queda asociado a la venta y aparece en el ticket.

## Navegación por teclado

Además del mouse, el sistema se puede recorrer con teclado:

- Flechas de dirección: moverse entre botones, campos, listas y tablas.
- Enter: aceptar, abrir o seleccionar el elemento enfocado.
- Escape: cancelar o cerrar ventanas emergentes.
- Los selectores de productos/clientes mantienen navegación con flechas y Enter.


## Actualización: barra lateral y permisos de administrador

- La barra lateral fue compactada para que entren todos los módulos del sistema dentro de la pantalla.
- Se agruparon mejor los módulos y se redujeron espacios internos.
- Si el usuario/cajero activo tiene rol **Administrador**, el sistema ya no solicita contraseña para editar, eliminar, importar o realizar acciones protegidas.
- Para usuarios **Cajero** o **Supervisor**, las acciones protegidas siguen solicitando la clave de seguridad.

## Cambio agregado
- Barra lateral optimizada: los nombres y botones de los módulos ahora se muestran lo más grandes posible según el alto de pantalla, manteniendo visibles los 12 módulos sin cortarse.

## Actualización - Ventana de carga de productos optimizada

- La ventana emergente de **Agregar/Editar producto** ahora usa casi todo el espacio disponible de la pantalla sin salirse del módulo.
- Se agrandaron título, campos, selectores, área de foto, detalle y botones.
- Los datos principales y los costos/impuestos quedan mejor distribuidos en dos paneles internos.
- Cada panel tiene desplazamiento interno si la pantalla es baja, evitando que la ventana se corte.
- En pantallas chicas el formulario se adapta automáticamente a una sola columna para seguir siendo usable.

## Actualización - Ventana de producto nuevo en Compras optimizada

- La ventana emergente para cargar un producto nuevo desde el módulo **Compras** ahora ocupa el ancho útil completo del módulo.
- Se reorganizó en dos paneles grandes: **Datos principales** y **Costos, impuestos y venta**.
- Se agrandaron campos, selectores, área de foto, títulos y botones.
- La ventana queda contenida dentro del módulo y usa desplazamiento interno cuando la pantalla es baja.
- En pantallas angostas se adapta automáticamente a una sola columna para que no se corte.

## Actualización - Venta en ventana emergente grande

- El módulo Venta ahora se presenta como una ventana emergente grande dentro del área principal del sistema.
- La ventana se adapta al tamaño de pantalla para aprovechar el máximo espacio disponible sin salirse del módulo.
- Se reforzó la vista lateral como "Vista previa del ticket", manteniendo la actualización en vivo del ticket mientras se cargan productos.
- Se optimizaron tamaños de buscador, tabla, campos de pago, botones y panel lateral de ticket para trabajar cómodo en pantalla completa.

## Actualización Compras grande
- Se optimizó el módulo Compras para aprovechar mejor la pantalla completa.
- Se agrandaron títulos, campos, selectores, botones, tabla de productos y total.
- El panel de carga de compra queda más ancho y el historial queda compacto a la derecha.
- Se agregó desplazamiento interno en el panel principal y listas para que nada se salga de la pantalla.
- La ventana de producto nuevo desde Compras mantiene tamaño grande y queda contenida dentro del módulo.

## Actualización: módulos en pantalla completa

- Todos los módulos, excepto el Panel principal, se abren ocupando toda la pantalla del POS.
- El menú lateral se oculta dentro de cada módulo para aprovechar el espacio completo.
- En cualquier módulo, la tecla Escape vuelve al Panel principal.
- En los módulos que no son Venta se agregó un botón flotante “Esc Panel principal” como acceso visual de salida.

## Actualización agregada

Esta versión suma las mejoras pedidas:

- Escaneo de códigos de barra con cámara web desde Ventas y Productos, usando el navegador cuando soporta `BarcodeDetector`.
- Venta en cuenta corriente vinculada a clientes, registro de pagos y exportación de cuentas corrientes.
- Backup automático al iniciar y al cerrar el sistema con F10/F12, más backup manual desde Configuración.
- Búsqueda rápida en Venta con sugerencias mientras se escribe y carga automática por código exacto.
- Reportes ampliados: ticket promedio, stock valorizado, productos más/menos vendidos, stock bajo, deudores y últimas ventas.
- Ticket PDF configurable con opción de QR para WhatsApp, link de pago, Instagram o texto libre.
- Exportaciones a Excel y PDF: reportes, lista de precios y cuentas de clientes.

Nota sobre la cámara: la lectura por webcam depende del navegador. Si el navegador no soporta `BarcodeDetector`, el sistema sigue funcionando con lector USB o carga manual del código.

## Actualización agregada - Etiquetas de productos

- En **Reportes** se agregó la pestaña **Etiquetas**.
- Permite buscar productos por nombre o código de barra y agregarlos a una lista de impresión.
- Cada producto puede tener una cantidad distinta de etiquetas.
- Se puede configurar cuántas etiquetas entran por hoja **A4**.
- Incluye **vista previa visual de la hoja A4** para ver cómo queda la distribución antes de imprimir.
- Permite elegir **tipo de letra** entre Helvetica/Arial, Times/Serif y Courier/Monoespaciada.
- Permite configurar el **tamaño del nombre** y el **tamaño del precio** de la etiqueta.
- El PDF generado muestra **nombre del producto y precio grande**, listo para descargar o abrir e imprimir.
- Incluye opción para mostrar u ocultar guías de corte/bordes.

## Actualización agregada - Atajo Insert y vista previa de etiquetas

- En **Venta** y **Productos**, la tecla **Insert** abre el escáner por cámara y activa la webcam directamente.
- En Productos, si el formulario de alta/edición está abierto, **Insert** carga el código detectado en el campo de código de barra; si no, usa el código para buscar productos.
- Se mejoró la vista previa de **Reportes > Etiquetas** para que respete proporciones reales de impresión en A4: hoja 210 x 297 mm, margen de 8 mm, separación de 2 mm, distribución por columnas/filas y tamaño de fuente proporcional al PDF.
- El PDF de etiquetas ahora respeta exactamente la cantidad configurada por hoja, aun cuando la grilla tenga celdas extra para mantener una buena distribución visual.

## Actualización agregada - Navegación de productos en etiquetas

- En **Reportes > Etiquetas**, al escribir en el buscador y presionar **Enter**, se despliega la lista de productos encontrados.
- La lista se puede recorrer con las teclas **Flecha arriba** y **Flecha abajo**.
- El producto seleccionado se agrega con **Enter** o con clic.
- La tecla **Escape** cierra la lista de resultados.

## Actualización agregada - Compatibilidad ampliada del lector por cámara

- El lector por cámara ahora usa `getUserMedia()` con configuración flexible para mejorar compatibilidad entre Chrome, Edge, Firefox, Safari y navegadores móviles.
- Se agregó selector de cámara para elegir cámara automática, integrada, USB o externa. El sistema recuerda la última cámara usada.
- Si el navegador soporta `BarcodeDetector`, lo usa como lector principal por ser más rápido.
- Si el navegador no soporta `BarcodeDetector`, el sistema usa respaldo local enviando fotogramas al servidor del POS para intentar decodificar con OpenCV.
- Se agregaron mensajes claros para permisos denegados, cámara inexistente, cámara ocupada o bloqueo por no usar localhost/HTTPS.
- En **Reportes > Etiquetas** también se agregó botón **Insert 📷 Escanear** para agregar productos a la lista de etiquetas mediante cámara.
- La tecla **Insert** abre el escáner directamente en Ventas, Productos y Etiquetas.
- Se agregaron las dependencias `numpy` y `opencv-python` para el respaldo local por servidor.

## Versión escritorio
Esta entrega usa `pywebview` para mostrar la misma interfaz HTML/CSS/JavaScript dentro de una ventana propia de Windows. No abre Edge/Chrome como aplicación externa. Para compilar, ejecutar `compilar_exe.bat`.


## V15 — estabilización de escritorio
- Se fuerza WebView2/Edge Chromium en Windows para evitar incompatibilidades con motores web antiguos.
- F10/F12 cierran mediante puente nativo de escritorio y crean backup antes de salir.
- Se corrigió la prioridad de F1-F6 y de las teclas internas de Venta.
- Escape ahora respeta primero modales y controles internos.
- La impresión de etiquetas ya no depende de abrir un `blob:` en otra ventana.
- Se agregó `diagnostico.bat` para comprobar base de datos, JavaScript, Python, pantallas y APIs.


## V16 - corrección de motor de escritorio
V16 corrige el fallback a MSHTML detectado en los logs reales, exige WebView2/Edge Chromium y elimina la recursión causada por exponer el objeto Window completo mediante js_api.

## V17 - host de escritorio Chromium estable
V17 deja de usar pywebview como host. El backend sigue siendo Flask local y la interfaz HTML/CSS/JS se abre en Microsoft Edge o Google Chrome con `--app`, sin pestañas ni barra de direcciones. Este enfoque conserva el renderizado Chromium original y evita el fallback a MSHTML observado en los logs de Windows.

> IMPORTANTE V17: cualquier instrucción anterior que mencione pywebview/WebView2 corresponde a V12-V16. Para V17, el host vigente es Edge/Chrome en modo aplicación.

## Auditoría V31-V36

Las pruebas ejecutables están en `tests/`. Trabajan sobre copias temporales; antes de usar el sistema en el negocio, conservá una copia de seguridad de la base de datos real.

## Instalación y actualización segura (V37 en adelante)

- El ZIP de distribución no incluye `instance/pos.db` ni respaldos de desarrollo.
- Al primer inicio, el programa crea una base vacía y solicita configurar el administrador.
- Los productos de demostración no se cargan por defecto. Para un entorno de demostración únicamente, definir `POS_SEED_DEMO_PRODUCTS=1` antes de iniciar.
- Para actualizar una instalación existente, cerrar Terminal POS, hacer una copia externa de `instance/pos.db`, `backups/`, `app/static/uploads/` y `TICKET/`, y extraer el código nuevo sin reemplazar esas carpetas de datos.
- No eliminar los archivos de datos al actualizar. Si se usa un ZIP, comprobar su contenido antes de copiarlo sobre una instalación existente.
- El ZIP de desarrollo puede incluir datos ficticios en versiones antiguas; no usar sus bases de datos para reemplazar una base de negocio.



## V43-V48 - Auditoría de integración, permisos, migraciones y rendimiento

- El ejecutor de pruebas corre cada caso en espacios de nombres separados y muestra los casos omitidos por dependencias faltantes.
- Se agregó una prueba de integración Flask que ejercita la configuración inicial, ventas, compras, caja, rechazo por stock y acceso a la ruta de apagado, usando una base temporal.
- La ruta de apagado físico de la computadora ahora exige rol administrador; el cierre normal del POS sigue disponible con una sesión válida.
- Se agregó una prueba real de migración idempotente sobre un esquema legado temporal y verifica que ventas/productos existentes se conserven.
- Se mantienen las pruebas de respaldo/restauración, adaptación responsive y plan de consulta con 10.000 ventas y 10.000 detalles.
- La validación visual completa y la integración Flask deben ejecutarse en Windows; este entorno no dispone de Flask ni de un escritorio Windows.


## V58 — Auditoría de siete áreas

La batería de pruebas se ejecuta con `probar_pruebas.bat`; la integración HTTP requiere que las dependencias de `requirements.txt` estén instaladas.


## V59 — distribución y pruebas

La compilación del EXE excluye por defecto la base de datos y los archivos de usuario del directorio uploads. Si necesitás migrar una instalación existente, seguí `MIGRAR_DATOS_EXE.txt` y hacé una copia externa antes de copiar los datos. La prueba de integración Flask incluye validaciones de venta con producto repetido y de payload inválido.


## V60 — precisión monetaria y stock concurrente

- `money()` y `strict_number()` usan `Decimal` con redondeo comercial `ROUND_HALF_UP` a dos decimales.
- Se agregaron pruebas para empates monetarios, valores no finitos y descuentos concurrentes de stock.
- Ejecutar `probar_pruebas.bat` para la batería completa. La integración HTTP requiere instalar `requirements.txt`; las pruebas visuales y del EXE deben completarse en Windows.

## Organización del código (V81)

Las rutas HTTP se agrupan por dominio en `app/route_modules/` (ventas,
compras, caja, productos, clientes, usuarios, configuración, reportes, etc.).
`app/routes.py` conserva el punto de entrada y registra los módulos en el mismo
Blueprint para preservar las URLs y las integraciones existentes.
Las utilidades de negocio y compatibilidad se encuentran en `app/route_core.py`.
Antes de modificar un módulo, ejecutar `probar_pruebas.bat` en Windows; las
pruebas que necesitan Flask requieren que esté instalado. Para validar también
el comportamiento de caja y ventas, usar una base temporal o copia de prueba.


### Optimizaciones V80 y V81
- Dependencias pesadas de imágenes, Excel y PDF cargadas bajo demanda.
- Medición de texto PDF con `pdfmetrics.stringWidth`, sin crear un canvas temporal por llamada.
- El cierre no se inicia si falla el respaldo previo; el usuario recibe un error y la aplicación permanece abierta.


### Optimizaciones V81 — índices SQLite
- Se agregaron índices para las consultas frecuentes de nombres, vencimientos, saldos de clientes, sesión abierta, búsqueda del administrador e historiales ordenados.
- Se sustituyeron tres índices simples por índices compuestos equivalentes que cubren también el orden por identificador.
- La prueba `tests/test_db_performance_indexes.py` verifica diez planes de consulta con `EXPLAIN QUERY PLAN` y datos temporales.
- No se alteraron las consultas ni la interfaz. Los índices aumentan ligeramente el espacio y el trabajo de escritura a cambio de acelerar las lecturas cubiertas.


### Optimizaciones V82 — índices SQLite adicionales

- Índice parcial de prioridad para alertas de stock bajo, alineado con el filtro y ordenamiento usado por las pantallas existentes.
- Índice compuesto de movimientos de producto por producto e ID descendente para acelerar historiales.
- Se retiró el índice simple anterior de movimientos de producto para evitar duplicación.
- El paquete no distribuye bytecode ni cachés Python.
- No se modificaron rutas, resultados comerciales, datos históricos ni interfaz.


## V85 — optimización de consultas en Ventas

- La validación de una venta ahora reutiliza la lectura inicial de un producto cuando aparece en varias líneas.
- Se evita ejecutar consultas `SELECT` duplicadas para el mismo producto dentro de una venta.
- Se mantienen las líneas individuales del ticket, el cálculo monetario, la validación y el descuento atómico de stock, y los movimientos de inventario.
- La prueba de integración Flask verifica el número de consultas SQL cuando un producto aparece repetido.
- No se modifica la base de datos ni se requiere migración.


## V86 — optimización de consultas en Compras

- La validación de una compra ahora reutiliza la lectura inicial de un producto cuando aparece en varias líneas.
- Se evitan consultas `SELECT` duplicadas para el mismo producto dentro de una compra.
- Se mantienen los renglones individuales, los cálculos de costo y precio, las actualizaciones de stock y los movimientos de inventario.
- La prueba de integración Flask verifica el número de consultas SQL en ventas y compras.
- No se modifica la base de datos ni se requiere migración.


## V87 — optimización general de desempeño, estabilidad y seguridad

### Seguridad de interfaz
- Se centralizó `escapeHTML()` y se aplicó a los datos persistidos que se muestran en HTML: clientes, proveedores, usuarios, productos, movimientos, caja, auditoría, reportes, resultados de importación y consulta de precios.
- Se evita que nombres, descripciones o notas ingresadas en el POS puedan convertirse en etiquetas o atributos HTML ejecutables.
- Las respuestas de API envían `Cache-Control: no-store, max-age=0`, `Pragma: no-cache`, `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY` y `Referrer-Policy: no-referrer`.
- La identidad y el rol de una sesión se resuelven por `username`, no por coincidencias con el nombre visible.
- La clave de sesión persistente se repara si el archivo quedó vacío o truncado; en sistemas Unix se limitan sus permisos a lectura/escritura del propietario.

### Rendimiento y estabilidad
- `get_settings()` mantiene una caché de configuración por petición, devuelve copias defensivas y la invalida cuando se guarda un cambio.
- `init_db()` cierra siempre la conexión, incluso si una migración falla.
- Las búsquedas en Clientes y Proveedores esperan 180 ms desde la última tecla antes de consultar el servidor.
- Los pitidos del lector liberan el `AudioContext` al terminar.
- Si la cámara falla durante la activación, el lector libera las pistas de video y no deja la cámara encendida.

### Validación
- Se agregaron pruebas para XSS almacenado, caché de configuración, cierre de conexión, cabeceras HTTP y liberación de recursos del navegador.
- La batería portátil y las comprobaciones sintácticas se ejecutan antes de distribuir el paquete.
- La prueba de integración Flask requiere instalar las dependencias de `requirements.txt` y validarse en Windows antes de usar esta versión en el negocio.
- No se altera el esquema SQLite ni se requiere migración de datos.


## V88 — diagnóstico de rendimiento real

Se incorpora `diagnostico_rendimiento.bat` y `diagnostico_rendimiento.py` para medir el comportamiento del POS en la computadora donde funciona.

### Qué mide
- Sistema operativo, versión de Python, procesadores lógicos, RAM total/disponible, muestra breve de CPU global y espacio libre.
- Tamaño de la base SQLite, archivos WAL/SHM, páginas, quick_check y cantidades por tabla.
- Consultas representativas de productos, ventas, stock, clientes, proveedores, movimientos, auditoría y compras, con mediana de tres lecturas y su plan `EXPLAIN QUERY PLAN`.
- Latencia de endpoints principales del POS en ejecución, usando una petición de calentamiento y dos mediciones por endpoint.

### Seguridad
- La base se abre mediante URI `mode=ro` y `PRAGMA query_only=ON`.
- No ejecuta migraciones, escrituras, reparaciones, ventas ni compras.
- El sondeo HTTP se limita a `127.0.0.1`, `localhost` o `::1`, y solo utiliza GET.
- No guarda cuerpos de respuesta ni datos personales; el informe incluye métricas, cantidades y planes SQL.
- El uso de CPU informado es global del equipo, no exclusivo del proceso POS.

### Cómo ejecutarlo
1. Iniciá Terminal POS y dejalo abierto.
2. Ejecutá `diagnostico_rendimiento.bat` desde la carpeta del sistema.
3. Compartí `logs/diagnostico_rendimiento.txt` para analizar los cuellos de botella.
4. Si querés medir solo SQLite sin HTTP, ejecutá `python diagnostico_rendimiento.py --no-http`.

El informe permite elegir la siguiente optimización con evidencia del equipo y de la base reales. No modifica ni migra datos.


## V89-V95 — optimización integral en siete etapas

### V89 — Dashboard
- Se combina la suma de ventas diarias y el conteo de tickets en una consulta.
- El contador de stock usa el predicado exacto del índice parcial existente.
- Se valida equivalencia de resultados y plan de consulta con datos de prueba.

### V90 — Búsquedas
- Se incorpora FTS5 con tokenizer trigram opcional para búsquedas por subcadena en productos, clientes y proveedores.
- Triggers transaccionales sincronizan altas, ediciones y bajas.
- Para consultas de menos de tres caracteres o instalaciones sin FTS5/trigram se mantiene el `LIKE` anterior.
- Se verifica que los resultados coincidan con el método previo.

### V91 — SQLite y concurrencia
- `init_db()` intenta activar `journal_mode=WAL`.
- Si el sistema de archivos o la versión no lo permiten, se conserva el modo actual y el arranque continúa.
- Se mantiene la durabilidad predeterminada `synchronous=FULL`; no se cambia a NORMAL.
- Se limita el crecimiento posterior a checkpoints con `journal_size_limit` y se mantiene `wal_autocheckpoint`.
- Se prueba lectura concurrente, escritura y backup con WAL.

### V92 — Consultas de stock
- Se verifican los planes de Dashboard, reportes y alertas para aprovechar `idx_products_low_stock_priority`.
- Se comprueba equivalencia de resultados con 20.000 productos de prueba.

### V93 — Memoria y archivos de ejecución
- `desktop.log` rota al alcanzar 5 MB y conserva hasta cuatro archivos anteriores.
- Al iniciar, se eliminan perfiles Chromium `session_<pid>` de más de siete días únicamente cuando el proceso propietario no está activo.
- Ante errores al comprobar el PID, el perfil se conserva.

### V94 — Frontend
- La función `api()` envía `Content-Type: application/json` solo cuando hay body y conserva headers, señales y opciones del llamador.
- Búsquedas de productos, clientes, proveedores, ventas y etiquetas cancelan solicitudes anteriores y descartan respuestas obsoletas.
- Se agrega debounce donde corresponde.
- Las vistas previas de imágenes liberan Blob URLs anteriores para evitar acumulación de memoria.
- Las búsquedas locales de Compras siguen usando su caché en memoria.

### V95 — Seguridad
- Los archivos de imagen tienen un máximo de 30 MB y 40 megapíxeles.
- Se comprueba que el contenido real coincida con la extensión declarada y se detectan archivos dañados.
- El lector de códigos limita las imágenes a 4 MB antes de decodificar Base64 y exige Base64 válido.
- El payload del lector debe ser un objeto JSON con imagen de tipo texto.
- Las respuestas de error no exponen detalles SQL, rutas ni excepciones internas; los detalles quedan en el log del servidor.

### Validación de V95
- Batería portátil: 49 aprobadas y 1 omitida por falta de Flask en el entorno de auditoría.
- Compilación sintáctica Python y JavaScript: correcta.
- Las pruebas utilizan bases temporales y archivos de prueba; no alteran la base comercial real.
- La integración Flask debe ejecutarse en Windows con las dependencias de `requirements.txt` antes de actualizar el equipo del negocio.


## V96 — pruebas de carga y optimización del Dashboard

### Optimizaciones aplicadas
- Se reemplaza `idx_sale_items_product_id` por el índice de cobertura `idx_sale_items_product_rollup(product_id, product_name, quantity, line_total)`. El prefijo `product_id` mantiene el soporte de búsquedas por producto y las columnas restantes cubren las agregaciones de los rankings del Dashboard.
- En productos, selector de ventas, clientes y proveedores, las búsquedas FTS5 trigram se dividen por columna mediante subconsultas `UNION`. Así SQLite puede usar el índice trigram para cada `LIKE`, en lugar de evaluar un `OR` que provocaba un recorrido completo del índice virtual. Los resultados se deduplican y se conserva el orden y el límite de cada pantalla.
- Cuando FTS5/trigram no está disponible, se mantiene el `LIKE` tradicional.

### Prueba de carga aislada
Ejecutar `prueba_carga_v96.bat` en Windows, con las dependencias de `requirements.txt` instaladas. El POS normal puede permanecer cerrado: el script levanta una instancia temporal en `127.0.0.1`, con su propia base.

La prueba genera datos ficticios: 10.000 productos, 20.000 ventas, 60.000 artículos de venta, 10.000 movimientos de stock, 2.000 clientes, 300 proveedores, 5.000 compras, 15.000 artículos de compra, 250 sesiones de caja, 10.000 movimientos de caja, 5.000 movimientos de clientes y 20.000 registros de auditoría.

Mide consultas SQL, planes de ejecución, endpoints HTTP, búsquedas, concurrencia con 1/2/4/8 usuarios virtuales, P50/P95/P99, CPU de proceso, memoria RSS y tamaño de la base temporal. Solo realiza solicitudes GET durante la medición HTTP.

El informe se guarda en `logs\prueba_carga_v96.txt`. La base temporal y los archivos de la aplicación de prueba se eliminan automáticamente al finalizar. El script nunca apunta a `instance\pos.db`.

### Validación V96
- Se comprueba que los rankings del Dashboard devuelvan exactamente los mismos resultados con el índice nuevo.
- Se verifica que el plan use el índice de cobertura y que el agrupamiento superior no necesite una tabla temporal de `GROUP BY`.
- Se comprueba que FTS5 mantenga los mismos resultados que el `OR` anterior y que cada columna use su índice trigram.
- La prueba HTTP/concurrencia requiere Flask y Werkzeug instalados; si no están disponibles, el script solo puede ejecutarse en modo SQL con `--allow-sql-only`.
- Las pruebas se realizan en bases temporales; no incluyen ni modifican datos comerciales.


## V97 — optimización de reportes basada en la prueba de carga V96

### Hallazgos de V96
- Con 10.000 productos, 20.000 ventas y 60.000 artículos, la integridad SQLite fue correcta y no hubo errores HTTP.
- El endpoint `/api/reports` fue el más lento: P50 313,96 ms y P95 340,69 ms.
- El análisis de sus consultas mostró tres agregaciones separadas sobre los artículos vendidos para calcular más vendidos, menos vendidos y ganancia estimada.
- Las búsquedas sintéticas de clientes y proveedores de V96 devolvían `[]` porque sus términos no coincidían con los nombres de cinco dígitos generados. V97 corrige esos términos para medir resultados reales.

### Optimizaciones V97
- Se sustituye `idx_sale_items_sale_id(sale_id)` por `idx_sale_items_sale_report(sale_id, product_id, product_name, quantity, line_total, unit_cost_at_sale)`. El nuevo índice conserva el prefijo `sale_id` y cubre las columnas utilizadas por los reportes; se evita mantener dos índices redundantes con el mismo prefijo.
- `/api/reports` calcula más vendidos, menos vendidos y ganancia estimada mediante un único rollup materializado de artículos del período. Se preservan los nombres históricos de los artículos para el ranking de más vendidos, la agregación por producto para menos vendidos y el fallback de costo histórico a `products.total_cost` cuando `unit_cost_at_sale` es NULL.
- La prueba de regresión compara los resultados nuevos con las tres consultas anteriores, incluyendo productos renombrados, costos históricos nulos y períodos sin ventas.
- El banco `prueba_carga_v97.py` fija el rango del reporte en los últimos 30 días para que el resultado no dependa de si la prueba se ejecuta al principio o al final del mes.
- Las consultas de búsqueda de clientes y proveedores ahora usan términos que coinciden con los nombres sintéticos; en V96 esas dos mediciones devolvían `[]` por un desajuste en el texto consultado.
- Se corrigen las consultas sintéticas de clientes y proveedores para que encuentren registros reales del generador y no midan respuestas vacías.

### Prueba V97
Ejecutar `prueba_carga_v97.bat` en Windows con las dependencias de `requirements.txt`. El POS habitual puede permanecer cerrado. La prueba crea una base temporal independiente, usa exclusivamente GET durante la fase HTTP y elimina el entorno temporal al terminar.

El informe se guarda en `logs\prueba_carga_v97.txt`. Se deben comparar P50/P95/P99 de `/api/reports`, la concurrencia y los resultados de búsqueda con el informe V96. La carga sintética no garantiza que todos los equipos obtengan los mismos tiempos.

### Validación V97
- Prueba de equivalencia de los rankings y ganancia estimada con casos de nombres históricos y costos NULL.
- Verificación de uso de `idx_sales_created_at` y del índice de cobertura `idx_sale_items_sale_report`.
- Pruebas de rango vacío: top vacío, 15 productos menos vendidos y ganancia cero.
- En el benchmark local de desarrollo con 10.000 productos, 20.000 ventas y 60.000 artículos, la suma de las medianas de las tres consultas anteriores fue 48,82 ms y el rollup compartido 42,91 ms (aprox. 12% menos tiempo SQL). Es una medición del entorno de desarrollo, no una promesa de tiempo HTTP en Windows.
- El índice de reporte agregó aproximadamente 1,68 MB a la base sintética de 20,59 MB; la carga sintética pasó de 2,36 s con el índice simple a 2,44 s con el índice de cobertura. El costo de escritura medido fue pequeño en este ensayo y debe contrastarse en el equipo real.
- La validación HTTP completa de Flask debe repetirse en Windows con el banco V97.


## V98 — eliminación de cálculo duplicado en Reportes

- `/api/reports` ya obtiene los productos menos vendidos en `report_rollups` mediante el CTE compartido.
- Se eliminó una segunda consulta que volvía a recorrer ventas y artículos del mismo período y sobrescribía el ranking ya calculado.
- Se conserva el mismo ranking, orden, límite de 15 elementos y contrato JSON.
- Se agrega una prueba de equivalencia y un benchmark sintético con 10.000 productos, 20.000 ventas y 60.000 artículos vendidos.
- La prueba de carga usa una base temporal independiente y no modifica `instance/pos.db`.

- Para medir V98 con datos sintéticos, ejecutar `prueba_carga_v98.bat`. El informe se guarda en `logs/prueba_carga_v98.txt`; usa una base temporal independiente y no toca `instance/pos.db`.


## V99 — agregación previa en Reportes

- El reporte agrupa primero los artículos vendidos por producto y nombre histórico.
- El costo actual del producto se consulta después de la agregación y solo para completar líneas cuyo `unit_cost_at_sale` es NULL.
- Se conserva la fórmula de ganancia estimada, los rankings, el rango de fechas y el contrato JSON.
- Se incorpora una prueba comparativa con datos sintéticos y casos de costo histórico nulo.
- La prueba de carga `prueba_carga_v99.bat` usa una base temporal aislada; no abre ni modifica `instance/pos.db`.


## V100 — perfilado de rendimiento y concurrencia

Esta versión no cambia las operaciones comerciales ni las consultas del POS. Amplía el banco de diagnóstico para medir mejor dónde se consume el tiempo de cada endpoint:

- 50 mediciones por endpoint (antes 12), para percentiles más estables.
- Tiempo total de cada solicitud.
- Tiempo acumulado dentro de `execute`/`fetch` de SQLite.
- Tiempo restante aproximado de Python, autenticación, serialización JSON y servidor WSGI.
- Cantidad media de consultas SQL por solicitud.
- Tiempo y cantidad de llamadas a conversores de filas (`product_to_dict`, `client_to_dict`, `supplier_to_dict`, entre otros), para separar parte del costo de transformación de respuestas.
- Desglose por endpoint en ejecución secuencial y bajo 1, 2, 4 y 8 usuarios.
- No registra sentencias SQL, parámetros, nombres, teléfonos ni datos comerciales.

El tiempo NO-SQL es una diferencia orientativa, no una medición aislada de serialización: incluye autenticación, código Python, JSON/WSGI y sobrecarga de instrumentación.

Ejecutar `prueba_carga_v100.bat`. El informe se guarda en `logs/prueba_carga_v100.txt`. La base es sintética y temporal; no se abre ni modifica `instance/pos.db`.


## Perfilado V100 ajustado al uso real (máximo 2 usuarios)

- La prueba HTTP mide exclusivamente 1 y 2 usuarios simultáneos.
- No ejecuta escenarios de 4 u 8 usuarios.
- Mantiene 50 rondas por endpoint y el perfilado interno de SQL, NO-SQL y conversores.
- La base de datos de prueba es temporal y sintética; nunca abre ni modifica `instance/pos.db`.
- El objetivo es priorizar velocidad, estabilidad, seguridad e integridad para uno o dos usuarios.


## V101 — optimización enfocada en un máximo de dos usuarios

- Se configura la caché SQLite en 8 MiB por conexión (`PRAGMA cache_size=-8192`; los valores negativos se expresan en KiB). El cambio es local a cada conexión, no reduce `synchronous=FULL`, no cambia WAL ni modifica el esquema.
- Se optimiza `product_to_dict`: se normalizan stock y stock mínimo una sola vez, se reutilizan valores y se evita consultar repetidamente las claves opcionales de cada fila. El contrato JSON se conserva.
- La prueba de equivalencia compara los 20 campos serializados, con control de stock activado y desactivado, en 300 productos sintéticos.
- Se incorpora `prueba_carga_v101.py` y `prueba_carga_v101.bat`; el perfilado mantiene exclusivamente escenarios de uno y dos usuarios.
- No se modifica la lógica de ventas, caja, compras, ganancias, movimientos ni migraciones comerciales.
- Microbenchmark de desarrollo (300 filas): la serialización pasó de 6,46 a 5,01 ms P50 en una ejecución y de 9,68 a 7,75 ms en otra; ambas conservaron exactamente el JSON. El resultado local sugiere una mejora de aproximadamente 20–22%, pendiente de confirmación HTTP en Windows.
- Prueba exploratoria de caché en SQLite 3.46: con dos lectores, la consulta de reporte pasó de 71,16 a 67,04 ms P50 y de 93,74 a 72,07 ms P95. Es una medición de desarrollo, no una garantía para el equipo Windows.
- En este entorno no está instalado Flask: la suite ejecutó 60 pruebas y omitió una integración Flask. La prueba HTTP completa debe ejecutarse en Windows con las dependencias del proyecto.
- Los cambios se someten a prueba en Windows antes de considerar V101 para la instalación del negocio.


## V102 — rankings del Dashboard y diagnóstico SQLite

- `/api/dashboard` comparte una única agregación materializada de `sale_items` para los rankings de productos más y menos vendidos; evita recorrer la tabla dos veces.
- Se conservan los nombres históricos de las líneas para el ranking superior y los nombres actuales del catálogo para el inferior.
- La prueba V102 compara ambos rankings contra las consultas anteriores, incluye productos sin ventas y comprueba el índice de cobertura.
- Se corrige el informe de `PRAGMA cache_size`: SQLite expresa los valores negativos en KiB y los positivos en páginas. `-8192` equivale a 8 MiB, no a 32 MiB. La configuración de la aplicación no cambia.
- Se incorpora `prueba_carga_v102.py` y `prueba_carga_v102.bat`; el banco mide exclusivamente 1 y 2 usuarios, con base temporal sintética, loopback y solicitudes GET.
- Se conserva WAL, `synchronous=FULL`, claves foráneas, contratos JSON, operaciones comerciales y base de datos del usuario.
- Benchmark sintético de desarrollo (10.000 productos, 60.000 artículos): los dos rankings separados dieron 29,65 ms P50 / 35,16 ms P95; el rollup compartido dio 27,57 ms P50 / 32,54 ms P95. Mejora observada aproximada del 7%; debe confirmarse en Windows con el hardware real.


## V103 — optimización de pantallas de stock y reportes (máximo 2 usuarios)

- Se agregan modos `?compact=1` para `/api/products` y `/api/stock/alerts`. Solo los solicita el módulo interno de stock; las respuestas completas por defecto se mantienen sin cambios.
- El selector de stock recibe únicamente `id`, `name` y `stock`.
- Las alertas reciben únicamente `id`, `name`, `stock` y `min_stock`.
- `/api/reports` combina resumen general y medios de pago en una consulta SQL con funciones de ventana. Se conserva el resultado del resumen, el desglose por medio de pago y el comportamiento cuando el período no tiene ventas.
- El banco V103 mide tanto los endpoints completos como los compactos, con 1 y 2 usuarios simultáneos.
- Ejecutar `prueba_carga_v103.bat`; el informe se guarda en `logs/prueba_carga_v103.txt`.
- Las pruebas utilizan una base temporal sintética y no abren ni modifican `instance/pos.db`.


## V104 — ajuste controlado del Dashboard y diagnóstico A/B (máximo 2 usuarios)

- No se fuerza un cambio en el SQL del Dashboard: las pruebas A/B locales mostraron que quitar `MATERIALIZED` no cambió el plan de SQLite ni produjo una mejora estable. Se conserva la consulta V103 para no introducir una optimización aparente.
- El banco V104 mide la consulta compartida actual y, por separado, los SQL de top productos y menos vendidos. Permite comparar en el Windows real si dividir los rankings reduciría el tiempo total.
- El banco extrae desde el código real de `reports.py` y mide por separado el resumen/formas de pago y el rollup de rankings/ganancia. No se fuerzan más cambios en reportes: las variantes probadas no demostraron una mejora estable; el endpoint ya había mejorado en V103.
- Se conservan las respuestas compactas de stock/productos, WAL, `synchronous=FULL`, la caché actual y todas las operaciones comerciales.
- Ejecutar `prueba_carga_v104.bat`; el informe se guarda en `logs/prueba_carga_v104.txt`.
- La prueba utiliza una base temporal sintética, mide solo 1 y 2 usuarios y nunca abre ni modifica `instance/pos.db`.


## V105 — Comparación A/B del cálculo de reportes

V105 conserva la lógica comercial de V104; añade al banco de pruebas una comparación reproducible de variantes de la consulta de rankings y ganancia estimada. Cada variante se verifica contra la consulta original antes de medir. Se prueban períodos de 30 días y vacíos, además de costos históricos NULL sobre la **base temporal sintética**. Las pruebas A/B alternan el orden de las variantes para mitigar los efectos de la caché. No se ajustan políticas SQLite, ni se cambia una consulta de producción sin una mejora confiable medida en Windows.

Ejecutá `prueba_carga_v105.bat` y compartí `logs/prueba_carga_v105.txt`; se limita la concurrencia a uno o dos usuarios.


## V106 — selección del A/B de V105 (máximo dos usuarios)

- La consulta `/api/reports` conserva los mismos resultados y usa `AS NOT MATERIALIZED` para `period_sales` e `item_agg`, variante ganadora de la comparación A/B V105.
- Se distribuye `reportes_sql_v105_referencia.sql` como referencia de regresión (no se ejecuta en producción).
- El diagnóstico compara las alternativas contra la consulta V105 y verifica equivalencia con base ficticia y costos históricos NULL.
- `prueba_carga_v106.bat` genera la base temporal y prueba solo 1–2 usuarios; informe `logs/prueba_carga_v106.txt`.
- La prueba de carga HTTP no incluye escrituras comerciales: validar operaciones de ventas/caja en un ambiente de pruebas antes de actualizar un comercio.
- La mejora local es una hipótesis de rendimiento: confirmar con Windows antes de sustituir la instalación habitual.


## V107 — Validación de concurrencia comercial (máximo 2 usuarios)

- V106 se mantiene sin cambios funcionales: la consulta SQL optimizada de reportes permanece intacta.
- `probar_dos_usuarios_v107.bat` verifica mediante peticiones HTTP reales dos sesiones independientes realizando ventas simultáneas.
- Caso A: dos ventas de dos unidades sobre stock inicial cinco; ambas se registran y stock final uno.
- Caso B: dos ventas de cuatro unidades sobre stock inicial cinco; solo una puede registrarse.
- Comprueba integridad SQLite y claves foráneas después de las operaciones.
- Todas las pruebas usan una base temporal; NO abren ni escriben `instance/pos.db`.
- `prueba_carga_v107.bat` conserva los parámetros de V106 para comparar rendimiento en Windows.
- Ejecutar `probar_pruebas.bat`, `probar_dos_usuarios_v107.bat` y `prueba_carga_v107.bat`.

## V108.1 - corrección de apertura concurrente
- Falla reproducida en Windows V108: dos POST `/api/cash/open` simultáneos respondían 200 y creaban dos sesiones abiertas.
- Solución: `BEGIN IMMEDIATE` antes de consultar `active_cash_session()`, comprobación bajo bloqueo de escritura, rollback y HTTP 409 si ya hay caja abierta. La inserción y la auditoría se confirman juntas.
- Sin migraciones de esquema; no altera bases comerciales durante las pruebas.
- Ejecutar `probar_caja_dos_usuarios_v108.bat` en Windows con base temporal.
- Si una base comercial ya tuviera dos cajas abiertas de pruebas anteriores, esta corrección no las cierra automáticamente; revisar manualmente esos registros antes de operación real.

## V109 - Validación aislada de respaldos y recuperación
Ejecutar `probar_recuperacion_v109.bat` y enviar el resultado. Esta versión conserva el código funcional de V108.1 y añade una prueba de recuperación del respaldo real del programa con datos sintéticos en una carpeta temporal. Valida restauración de ventas, existencias y caja, integridad SQLite y fallo simulado de creación de respaldo sin falsa confirmación. No abre ni modifica `instance/pos.db`. La prueba no sustituye una recuperación real verificada antes de instalar en producción.

## V109.1 — Corrección de limpieza de pruebas en Windows
Cierre explícito de conexiones sqlite3 en tres pruebas aisladas para evitar WinError 32 en eliminación de bases temporales; preferencia por Python 3.12 en probar_pruebas.bat. No se modifica la lógica comercial ni la base del negocio.


## V110-RC1 — Candidata final (NO certificada para producción)
- Continúa V109.1; congelada la lógica comercial.
- Incorpora validación de estructura y ausencia de datos comerciales.
- Incluye `MANUAL_VALIDACION_FINAL_V110.txt` con las etapas de validación operativa, copia/recuperación e instalación.
- Ejecutar `probar_pruebas.bat`, luego `validar_distribucion_v110.bat`.
- Este archivo ZIP contiene el código fuente; **no incluye ejecutable EXE**.
- Antes de adoptar comercialmente, verificar compilación e instalación real en Windows y realizar pruebas manuales.
