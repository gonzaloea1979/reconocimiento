@echo off
chcp 65001 >nul
setlocal EnableExtensions
set "PYTHONUTF8=1"
cd /d "%~dp0"
title Terminal POS Local - Inicio

if not exist "logs" mkdir "logs"
set "LOG_FILE=logs\inicio.log"

REM Comprobar escritura antes de detectar Python o redirigir diagnosticos.
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $s = [System.IO.File]::Open($env:LOG_FILE, [System.IO.FileMode]::Append, [System.IO.FileAccess]::Write, [System.IO.FileShare]::ReadWrite); $s.Dispose(); exit 0 } catch { exit 1 }" >nul 2>nul
if errorlevel 1 (
    echo ERROR: no se pudo escribir el registro del POS.
    echo Verifica espacio y permisos de escritura. Usa una carpeta de tu usuario.
    echo Conservar la instalacion anterior y sus datos.
    pause
    exit /b 1
)

>>"%LOG_FILE%" echo.
>>"%LOG_FILE%" echo ==========================================
>>"%LOG_FILE%" echo [%DATE% %TIME%] INICIO TERMINAL POS LOCAL
>>"%LOG_FILE%" echo Carpeta: %CD%
>>"%LOG_FILE%" echo ==========================================

cls
echo ==========================================
echo        TERMINAL POS LOCAL - INICIO
echo ==========================================
echo.
echo Preparando el sistema. No cierres esta ventana.
echo Si aparece un error, esta ventana quedara abierta.
echo.

REM Validar que el BAT se este ejecutando desde la carpeta principal del POS.
if not exist "run.py" (
    echo ERROR: No se encontro run.py en esta carpeta.
    echo.
    echo Descomprimi el ZIP completo y ejecuta ejecutar.bat desde la carpeta principal.
    echo No lo ejecutes directamente dentro del ZIP comprimido.
    >>"%LOG_FILE%" echo ERROR: run.py no encontrado.
    pause
    exit /b 1
)

if not exist "app\__init__.py" (
    echo ERROR: No se encontro la carpeta app completa.
    echo Descomprimi nuevamente el ZIP completo.
    >>"%LOG_FILE%" echo ERROR: app\__init__.py no encontrado.
    pause
    exit /b 1
)

if not exist "requirements.txt" (
    echo ERROR: No se encontro requirements.txt.
    echo Descomprimi nuevamente el ZIP completo.
    >>"%LOG_FILE%" echo ERROR: requirements.txt no encontrado.
    pause
    exit /b 1
)

REM Buscar Python 3.11 o superior. Se prueban varias opciones comunes en Windows.
set "PY_CMD="
call :check_python py -3.12
if defined PY_CMD goto :python_ok
call :check_python py -3.11
if defined PY_CMD goto :python_ok
call :check_python py -3
if defined PY_CMD goto :python_ok
call :check_python python
if defined PY_CMD goto :python_ok
call :check_python python3
if defined PY_CMD goto :python_ok

echo ERROR: No se encontro Python 3.11 o superior funcionando.
echo.
echo Solucion recomendada:
echo 1^) Instala Python desde python.org
echo 2^) En la instalacion marca: Add Python to PATH
echo 3^) Cierra esta ventana y vuelve a ejecutar ejecutar.bat
echo.
echo Tambien podes probar en CMD:
echo   py -3 --version
echo   python --version
echo.
>>"%LOG_FILE%" echo ERROR: Python 3.11+ no encontrado.
pause
exit /b 1

:python_ok
echo Python detectado: %PY_CMD%
>>"%LOG_FILE%" echo Python detectado: %PY_CMD%

REM La misma preparacion local que instalar_dependencias.bat.
%PY_CMD% "preparar_entorno.py" >>"%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo ERROR: no se pudo preparar o verificar el entorno.
    echo Se recomienda Python 3.12 de 64 bits. No se iniciara el POS.
    call :show_log_tail
    pause
    exit /b 1
)
set "VENV_PY=.venv\Scripts\python.exe"

REM Iniciar aplicacion de escritorio en ventana propia.
echo.
echo ==========================================
echo Sistema listo. Iniciando POS...
echo ==========================================
echo.
echo Si la ventana no se abre, revisa el registro en:
echo logs\inicio.log
echo.
echo Para cerrar el sistema, usa Salir F10. Para apagar la PC, usa F12.
echo.
>>"%LOG_FILE%" echo Iniciando run.py

"%VENV_PY%" run.py
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if not "%EXIT_CODE%"=="0" (
    echo El sistema se detuvo con un error.
    echo.
    echo Ultimas lineas del registro:
    echo ------------------------------------------
    call :show_log_tail
    echo ------------------------------------------
    echo.
    echo.
    if exist "logs\inicio_error.log" (
        echo Detalle del arranque de escritorio:
        echo ------------------------------------------
        type "logs\inicio_error.log"
        echo ------------------------------------------
    )
    echo.
    echo Archivos utiles para revisar el error:
    echo   logs\inicio.log
    echo   logs\inicio_error.log
    echo   logs\desktop.log
    echo.
    echo Tambien podes ejecutar diagnostico.bat.
    pause
    exit /b %EXIT_CODE%
) else (
    echo El sistema se cerro correctamente.
    timeout /t 2 >nul
    exit /b 0
)

:check_python
%* -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >>"%LOG_FILE%" 2>&1
if errorlevel 1 exit /b 0
set "PY_CMD=%*"
exit /b 0

:show_log_tail
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path -LiteralPath $env:LOG_FILE) { Get-Content -LiteralPath $env:LOG_FILE -Tail 80 } else { Write-Host 'No se encontro logs\inicio.log' }"
exit /b 0
