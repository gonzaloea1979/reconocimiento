@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
title Terminal POS - Prueba de Carga V104

echo =====================================================
echo       TERMINAL POS - PRUEBA DE CARGA V104
echo =====================================================
echo.
echo IMPORTANTE:
echo - Se genera una base de datos TEMPORAL con datos ficticios.
echo - NO se abre ni modifica instance\pos.db.
echo - NO se crean ventas ni compras en la base del negocio.
echo - El servidor de prueba escucha solo en 127.0.0.1 y se cierra al terminar.
echo - La prueba mide exclusivamente 1 y 2 usuarios simultaneos.
echo - No se prueban escenarios de 4 u 8 usuarios.
echo - La prueba incluye un rango de ventas de los ultimos 30 dias.
echo.
echo Deja cerrada cualquier otra instancia de prueba del mismo proyecto.
echo.
pause

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" prueba_carga_v104.py
) else (
    py -3.12 prueba_carga_v104.py 2>nul
    if errorlevel 1 python prueba_carga_v104.py
)
set "RC=%ERRORLEVEL%"
echo.
echo Informe: logs\prueba_carga_v104.txt
echo.
if not "%RC%"=="0" echo La prueba termino con errores. Compartime el mensaje para revisarlo.
pause
exit /b %RC%
