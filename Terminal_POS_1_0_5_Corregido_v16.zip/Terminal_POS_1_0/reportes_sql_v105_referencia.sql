
        WITH period_sales AS MATERIALIZED (
            SELECT id FROM sales
            WHERE created_at >= date(?) AND created_at < date(?, '+1 day')
        ), item_agg AS MATERIALIZED (
            -- Agrupar primero las líneas. Así evitamos consultar products
            -- una vez por cada artículo vendido cuando se necesita el costo
            -- actual como fallback histórico.
            SELECT si.product_id, si.product_name,
                   SUM(si.quantity) AS qty,
                   SUM(si.line_total) AS total,
                   SUM(CASE WHEN si.unit_cost_at_sale IS NOT NULL
                            THEN si.line_total - (si.unit_cost_at_sale * si.quantity)
                            ELSE si.line_total END) AS profit_before_fallback,
                   SUM(CASE WHEN si.unit_cost_at_sale IS NULL
                            THEN si.quantity ELSE 0 END) AS fallback_quantity
            FROM period_sales ps
            JOIN sale_items si ON si.sale_id = ps.id
            GROUP BY si.product_id, si.product_name
        ), item_rollup AS MATERIALIZED (
            SELECT a.product_id, a.product_name, a.qty, a.total,
                   a.profit_before_fallback - (COALESCE(p.total_cost, 0) * a.fallback_quantity) AS profit
            FROM item_agg a
            LEFT JOIN products p ON p.id = a.product_id
        ), product_rollup AS MATERIALIZED (
            SELECT product_id, SUM(qty) AS qty, SUM(total) AS total
            FROM item_rollup
            GROUP BY product_id
        )
        SELECT kind, product_id, name, qty, total, estimated_profit
        FROM (
            SELECT 'top' AS kind, product_id, product_name AS name, qty, total,
                   NULL AS estimated_profit, 1 AS section
            FROM (
                SELECT product_id, product_name, qty, total
                FROM item_rollup ORDER BY qty DESC LIMIT 15
            )
            UNION ALL
            SELECT 'least' AS kind, id AS product_id, name, qty, total,
                   NULL AS estimated_profit, 2 AS section
            FROM (
                SELECT p.id, p.name, COALESCE(r.qty, 0) AS qty, COALESCE(r.total, 0) AS total
                FROM products p
                LEFT JOIN product_rollup r ON r.product_id = p.id
                ORDER BY qty ASC, p.name ASC LIMIT 15
            )
            UNION ALL
            SELECT 'profit' AS kind, NULL AS product_id, NULL AS name,
                   NULL AS qty, NULL AS total, COALESCE(SUM(profit), 0) AS estimated_profit,
                   3 AS section
            FROM item_rollup
        )
        ORDER BY section,
                 CASE WHEN section=1 THEN qty END DESC,
                 CASE WHEN section=2 THEN qty END ASC,
                 CASE WHEN section=2 THEN name END ASC
    