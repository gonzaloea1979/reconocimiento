@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
title Terminal POS - Diagnostico V15

echo ==========================================
echo       TERMINAL POS - DIAGNOSTICO
 echo ==========================================
echo.

if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" diagnostico_sistema.py
) else (
  py -3 diagnostico_sistema.py 2>nul || python diagnostico_sistema.py
)

set "RC=%ERRORLEVEL%"
echo.
echo Informe: logs\diagnostico.txt
echo.
pause
exit /b %RC%
