"""Comprobación local de versiones e imports, sin acceder a red ni abrir el POS."""
from importlib import metadata
from pathlib import Path
import argparse
import importlib
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def read_requirements(path, environment=None, seen=None):
    from packaging.requirements import Requirement
    path = Path(path).resolve()
    seen = set() if seen is None else seen
    if path in seen:
        return []
    seen.add(path)
    requirements = []
    for raw in path.read_text(encoding='utf-8').splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        if line.startswith('-r '):
            requirements.extend(read_requirements(path.parent / line[3:].strip(), environment, seen))
            continue
        requirement = Requirement(line)
        if requirement.url or len(list(requirement.specifier)) != 1 or next(iter(requirement.specifier)).operator != '==' or '*' in next(iter(requirement.specifier)).version:
            raise ValueError('La entrega requiere una version exacta por dependencia: ' + requirement.name)
        if requirement.marker is None or requirement.marker.evaluate(environment):
            requirements.append(requirement)
    return requirements


def check_dependencies(build=False):
    if sys.version_info < (3, 11):
        print('ERROR: se requiere Python 3.11 o superior; se recomienda 3.12 de 64 bits.')
        return 1
    try:
        requirements = read_requirements(ROOT / ('requirements-build.txt' if build else 'requirements.txt'))
    except ImportError:
        print('Falta packaging para verificar el entorno de esta entrega.')
        return 1
    problems = []
    for requirement in requirements:
        try:
            version = metadata.version(requirement.name)
        except metadata.PackageNotFoundError:
            problems.append(requirement.name + ': no instalado')
            continue
        if not requirement.specifier.contains(version, prereleases=True):
            problems.append(f'{requirement.name}: instalado {version}, requerido {requirement.specifier}')
    if problems:
        print('Dependencias que requieren preparacion:\n' + '\n'.join(problems))
        return 1
    modules = ['flask', 'werkzeug', 'xlrd', 'xlwt', 'reportlab', 'PIL.Image']
    if build:
        modules.extend(['numpy', 'cv2', 'PyInstaller'])
    try:
        for name in modules:
            importlib.import_module(name)
    except (ImportError, OSError) as exc:
        print('ERROR: no se pudo cargar una dependencia instalada:', exc)
        return 1
    result = subprocess.run([sys.executable, '-m', 'pip', '--disable-pip-version-check', 'check'], check=False)
    if result.returncode:
        return result.returncode
    print(f'OK: {len(requirements)} versiones e imports verificados localmente.')
    return 0


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    raise SystemExit(check_dependencies(parser.parse_args().build))
