@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
title Terminal POS V108 - Caja con dos usuarios
echo Prueba HTTP de caja con base temporal. NO modifica instance\pos.db.
echo.
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" tests\test_v108_two_user_cash_http.py
) else (
    py -3.12 tests\test_v108_two_user_cash_http.py
    if errorlevel 1 python tests\test_v108_two_user_cash_http.py
)
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo ATENCION: la validacion de caja no fue aprobada; copia todo el error.
pause
exit /b %RC%
