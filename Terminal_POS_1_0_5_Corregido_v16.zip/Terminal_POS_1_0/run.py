from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

from app import create_app
from app.db import backup_database
from app.logging_config import configure_diagnostic_logging

HOST = "127.0.0.1"
DEFAULT_PORT = int(os.environ.get("POS_PORT", "5000"))


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


BASE_DIR = _base_dir()
LOG_DIR = BASE_DIR / "logs"
URL_FILE = LOG_DIR / "pos_url.txt"
BROWSER_PID_FILE = LOG_DIR / "browser_pid.txt"
DESKTOP_LOG = LOG_DIR / "desktop.log"
PROFILE_ROOT = BASE_DIR / "browser_profile"


def _configure_logging() -> None:
    configure_diagnostic_logging()
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(threadName)s | %(message)s",
        handlers=[
            RotatingFileHandler(
                DESKTOP_LOG,
                maxBytes=5 * 1024 * 1024,
                backupCount=4,
                encoding="utf-8",
            )
        ],
        force=True,
    )
    configure_diagnostic_logging()


def _process_is_running(pid: int) -> bool:
    """Comprueba si un PID existe; ante dudas conserva el perfil por seguridad."""
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        # En Windows algunos errores de permisos/consulta no permiten asegurar
        # que el proceso haya terminado. Es preferible conservar el perfil.
        return True


def _cleanup_stale_browser_profiles(max_age_days: int = 7) -> int:
    """Elimina perfiles Chromium antiguos solo si su proceso propietario no vive."""
    if not PROFILE_ROOT.exists():
        return 0
    cutoff = time.time() - max(1, int(max_age_days)) * 24 * 60 * 60
    removed = 0
    for profile in PROFILE_ROOT.glob("session_*"):
        try:
            if not profile.is_dir():
                continue
            pid_text = profile.name.removeprefix("session_")
            if not pid_text.isdigit():
                continue
            pid = int(pid_text)
            if pid <= 0 or pid == os.getpid() or _process_is_running(pid):
                continue
            if profile.stat().st_mtime >= cutoff:
                continue
            shutil.rmtree(profile)
            removed += 1
        except OSError:
            logging.warning("No se pudo limpiar el perfil Chromium antiguo: %s", profile, exc_info=True)
    return removed


def _message_box(title: str, message: str) -> None:
    if os.name != "nt":
        return
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, message, title, 0x10)
    except Exception:
        logging.exception("No se pudo mostrar el mensaje nativo")


def _port_is_free(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.4)
        return sock.connect_ex((host, port)) != 0


def _choose_port() -> int:
    ports = [DEFAULT_PORT] + [p for p in range(5001, 5021) if p != DEFAULT_PORT]
    for port in ports:
        if _port_is_free(HOST, port):
            return port
    raise RuntimeError("No se encontró un puerto libre entre 5000 y 5020.")


def _browser_candidates() -> list[Path]:
    candidates: list[Path] = []

    if os.name == "nt":
        for exe in ("msedge.exe", "chrome.exe"):
            found = shutil.which(exe)
            if found:
                candidates.append(Path(found))

        program_files = [
            os.environ.get("PROGRAMFILES", ""),
            os.environ.get("PROGRAMFILES(X86)", ""),
            os.environ.get("LOCALAPPDATA", ""),
        ]
        rel_paths = [
            Path("Microsoft") / "Edge" / "Application" / "msedge.exe",
            Path("Google") / "Chrome" / "Application" / "chrome.exe",
        ]
        for base in program_files:
            if not base:
                continue
            for rel in rel_paths:
                candidates.append(Path(base) / rel)
    else:
        for exe in (
            "microsoft-edge",
            "microsoft-edge-stable",
            "google-chrome",
            "google-chrome-stable",
            "chromium",
            "chromium-browser",
        ):
            found = shutil.which(exe)
            if found:
                candidates.append(Path(found))

    seen: set[str] = set()
    result: list[Path] = []
    for path in candidates:
        try:
            resolved = str(path.resolve())
        except Exception:
            resolved = str(path)
        key = resolved.lower() if os.name == "nt" else resolved
        if key in seen or not path.exists():
            continue
        seen.add(key)
        result.append(path)
    return result


def _launch_app_window(url: str) -> subprocess.Popen | None:
    """Abre el POS en Chromium/Edge modo app: sin pestañas ni barra del navegador."""
    candidates = _browser_candidates()
    if not candidates:
        logging.error("No se encontró Microsoft Edge ni Google Chrome.")
        return None

    # Perfil aislado por ejecución. Evita bloqueos de perfil y garantiza un proceso
    # independiente cuyo PID podamos cerrar con F10.
    profile_dir = PROFILE_ROOT / f"session_{os.getpid()}"
    profile_dir.mkdir(parents=True, exist_ok=True)

    last_error: Exception | None = None
    for browser in candidates:
        try:
            args = [
                str(browser),
                f"--app={url}",
                "--new-window",
                f"--user-data-dir={profile_dir}",
                "--start-maximized",
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-extensions",
                "--disable-session-crashed-bubble",
                "--disable-features=msEdgeSidebarV2",
            ]
            creationflags = 0
            if os.name == "nt" and hasattr(subprocess, "CREATE_NO_WINDOW"):
                creationflags = subprocess.CREATE_NO_WINDOW
            proc = subprocess.Popen(
                args,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=creationflags,
            )
            BROWSER_PID_FILE.write_text(str(proc.pid), encoding="utf-8")
            logging.info("Ventana POS iniciada con %s PID=%s", browser, proc.pid)
            return proc
        except Exception as exc:
            last_error = exc
            logging.exception("No se pudo iniciar navegador modo app: %s", browser)

    if last_error:
        logging.error("Fallaron todos los navegadores candidatos: %r", last_error)
    return None


def _open_window_after_server(url: str) -> None:
    # Flask ya está levantando en el hilo principal. Una espera corta evita la pantalla
    # de conexión rechazada en equipos más lentos.
    time.sleep(1.2)
    proc = _launch_app_window(url)
    if proc is None:
        # Último recurso: abre el navegador predeterminado para que el sistema siga siendo utilizable.
        try:
            webbrowser.open(url, new=2)
            logging.warning("Se abrió el navegador predeterminado como respaldo.")
        except Exception:
            logging.exception("No se pudo abrir ninguna interfaz para el POS")
            _message_box(
                "Terminal POS - Error",
                "No se encontró Microsoft Edge ni Google Chrome para abrir Terminal POS.",
            )
        return

    def _watch_browser() -> None:
        try:
            proc.wait()
            logging.info("La ventana Chromium del POS se cerró. Finalizando servidor local.")
            try:
                app = APP_HOLDER.get("app")
                if app is not None:
                    with app.app_context():
                        backup_database()
            except Exception:
                logging.exception("No se pudo realizar backup al cerrar la ventana")
            # Si F10 ya inició /api/shutdown, ese flujo cerrará el proceso antes.
            time.sleep(0.4)
            os._exit(0)
        except Exception:
            logging.exception("Error monitoreando la ventana Chromium")

    threading.Thread(target=_watch_browser, name="TerminalPOS-BrowserWatch", daemon=True).start()


APP_HOLDER: dict[str, object] = {}


def main() -> None:
    _configure_logging()
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    PROFILE_ROOT.mkdir(parents=True, exist_ok=True)
    removed_profiles = _cleanup_stale_browser_profiles()
    if removed_profiles:
        logging.info("Perfiles Chromium antiguos eliminados: %s", removed_profiles)

    port = _choose_port()
    url = f"http://{HOST}:{port}"
    try:
        URL_FILE.write_text(url, encoding="utf-8")
    except Exception:
        logging.exception("No se pudo guardar pos_url.txt")

    os.environ["POS_DESKTOP"] = "1"
    app = create_app()
    app.config["POS_DESKTOP"] = True
    APP_HOLDER["app"] = app

    logging.info("Terminal POS V102 (host de escritorio V17) iniciando en %s", url)
    logging.info("Motor de escritorio: Chromium modo app (Edge/Chrome), sin pywebview/MSHTML")

    threading.Thread(
        target=_open_window_after_server,
        args=(url,),
        name="TerminalPOS-Launcher",
        daemon=True,
    ).start()

    # Mantener Flask en el hilo principal. /api/shutdown cierra navegador y proceso con F10/F12.
    app.run(host=HOST, port=port, debug=False, use_reloader=False, threaded=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        try:
            _configure_logging()
            logging.exception("No se pudo iniciar Terminal POS")
        except Exception:
            pass
        message = f"No se pudo iniciar Terminal POS.\n\n{type(exc).__name__}\n\nRevisá logs\\desktop.log."
        try:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            (LOG_DIR / "inicio_error.log").write_text(message + "\n", encoding="utf-8")
        except Exception:
            message = f"No se pudo iniciar Terminal POS.\n\n{type(exc).__name__}\n\nNo se pudo guardar el registro. Revisá la carpeta logs, el espacio disponible y los permisos de escritura."
        _message_box("Terminal POS - Error de inicio", message)
        raise SystemExit(1) from None
