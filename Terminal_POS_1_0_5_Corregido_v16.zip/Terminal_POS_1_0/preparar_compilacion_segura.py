"""Impide borrar una salida de compilación que ya contenga datos de uso."""
from pathlib import Path
import sys
from preparar_entorno import linked_directory


def check_output(root):
    root = Path(root)
    if linked_directory(root):
        raise ValueError('La salida de compilacion no debe ser un enlace simbolico.')
    if not root.exists():
        return
    protected = {'instance', 'backups', 'ticket', 'uploads', 'browser_profile', 'logs'}
    for path in root.rglob('*'):
        if linked_directory(path):
            raise ValueError('La salida contiene enlaces: no se borrara automaticamente.')
        parts = {part.lower() for part in path.relative_to(root).parts[:-1]}
        if path.is_file() and (path.name.lower() == '.session_key' or parts & protected or path.suffix.lower() in {'.db', '.sqlite', '.sqlite3'} or path.name.lower().endswith(('-wal', '-shm'))):
            raise ValueError('La salida contiene datos de una instalacion usada. No se eliminara. '
                             'Cierre el POS, conserve una copia externa y compile en una carpeta nueva.')


if __name__ == '__main__':
    try:
        check_output(sys.argv[1] if len(sys.argv) > 1 else 'dist/TerminalPOS')
    except ValueError as exc:
        print('ERROR:', exc)
        raise SystemExit(1)
    print('OK: salida sin datos de uso; limpieza de compilacion permitida.')
