"""V103: la pantalla de stock usa proyecciones compactas sin romper APIs completas."""
from pathlib import Path
import sqlite3
import tempfile

ROOT = Path(__file__).resolve().parents[1]
PRODUCTS = (ROOT / "app" / "route_modules" / "products.py").read_text(encoding="utf-8")
STOCK = (ROOT / "app" / "route_modules" / "stock.py").read_text(encoding="utf-8")
JS = (ROOT / "app" / "static" / "js" / "stock.js").read_text(encoding="utf-8")

assert "compact = request.args.get('compact') == '1'" in PRODUCTS
assert "projection = 'id, name, stock' if compact else '*'" in PRODUCTS
assert "SELECT {projection} FROM products ORDER BY name ASC LIMIT 200" in PRODUCTS
assert "return jsonify([product_to_dict(r) for r in rows])" in PRODUCTS
assert "compact = request.args.get('compact') == '1'" in STOCK
assert "SELECT id, name, stock, min_stock FROM products" in STOCK
assert "return jsonify([product_to_dict(r) for r in rows])" in STOCK
assert "/api/stock/alerts?compact=1" in JS
assert "/api/products?compact=1" in JS

with tempfile.TemporaryDirectory(prefix="pos_v103_compact_") as tmp:
    db = sqlite3.connect(Path(tmp) / "products.db")
    db.row_factory = sqlite3.Row
    db.executescript("""
        CREATE TABLE products(
            id INTEGER PRIMARY KEY, name TEXT NOT NULL, stock REAL NOT NULL,
            min_stock REAL NOT NULL, detail TEXT, cost_without_tax REAL,
            total_cost REAL, sale_price REAL, expiry_date TEXT
        );
        CREATE INDEX idx_products_name ON products(name);
    """)
    db.executemany("INSERT INTO products(id,name,stock,min_stock,detail,cost_without_tax,total_cost,sale_price,expiry_date) VALUES(?,?,?,?,?,?,?,?,?)", [
        (1, "A", 0, 5, "detalle", 10, 12.4, 20, "2026-11-05"),
        (2, "B", 4, 5, "detalle", 10, 12.4, 20, None),
        (3, "C", 8, 5, "detalle", 10, 12.4, 20, None),
        (4, "D", 2, 0, "detalle", 10, 12.4, 20, None),
    ])
    full_products = db.execute("SELECT * FROM products ORDER BY name ASC LIMIT 200").fetchall()
    compact_products = db.execute("SELECT id,name,stock FROM products ORDER BY name ASC LIMIT 200").fetchall()
    assert [(r["id"],r["name"],r["stock"]) for r in full_products] == [
        (r["id"],r["name"],r["stock"]) for r in compact_products
    ]
    full_alerts = db.execute("""
        SELECT * FROM products WHERE min_stock>0 AND stock<=min_stock
        ORDER BY (stock-min_stock) ASC,name ASC LIMIT 300
    """).fetchall()
    compact_alerts = db.execute("""
        SELECT id,name,stock,min_stock FROM products WHERE min_stock>0 AND stock<=min_stock
        ORDER BY (stock-min_stock) ASC,name ASC LIMIT 300
    """).fetchall()
    assert [(r["id"],r["name"],r["stock"],r["min_stock"]) for r in full_alerts] == [
        (r["id"],r["name"],r["stock"],r["min_stock"]) for r in compact_alerts
    ]
    assert [r["id"] for r in compact_alerts] == [1,2]
    db.close()

print("OK: proyecciones compactas conservan selección/orden; APIs completas siguen disponibles.")
