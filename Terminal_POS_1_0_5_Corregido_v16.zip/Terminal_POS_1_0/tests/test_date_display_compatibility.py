"""Fechas ISO rápidas conservan formato y compatibilidad histórica."""
import importlib.util
from pathlib import Path
from datetime import datetime, timedelta
import random

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('_pos_date_display_test',ROOT/'app/route_services/dates.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)

# Contrato histórico, sin depender de Flask ni de otra instalación.
def reference_date(value):
    if not value: return ''
    raw=str(value).strip()
    for fmt in ('%Y-%m-%d','%Y-%m-%dT%H:%M:%S','%d/%m/%Y'):
        try: return datetime.strptime(raw[:19] if 'T' in fmt else raw[:10],fmt).strftime('%d/%m/%Y')
        except ValueError: pass
    return raw

def reference_datetime(value):
    if not value: return ''
    raw=str(value).strip()
    for fmt in ('%Y-%m-%dT%H:%M:%S','%Y-%m-%d %H:%M:%S','%Y-%m-%d'):
        try:
            parsed=datetime.strptime(raw[:19],fmt)
            return parsed.strftime('%d/%m/%Y' if fmt=='%Y-%m-%d' else '%d/%m/%Y %H:%M')
        except ValueError: pass
    return raw

cases=[None,'','   ','2026-11-04','04/11/2026','2026-11-04T12:34:56','2026-11-04 12:34:56',
       '2026-11-04T12:34:56.987654-03:00','2026-11-04 texto','2026-02-30','2024-02-29',
       '2026-1-2','2026-01-02T1:2:3','2026-W01-1','no es fecha',12345]
rng=random.Random(103)
for _ in range(400):
    dt=datetime(2020,1,1)+timedelta(seconds=rng.randrange(10*365*24*3600))
    cases.extend([dt.isoformat(),dt.isoformat(sep=' '),dt.date().isoformat(),dt.strftime('%d/%m/%Y'),dt.isoformat()+'Z'])
for value in cases:
    assert module.format_date_ar(value)==reference_date(value),(value,module.format_date_ar(value),reference_date(value))
    assert module.format_datetime_ar(value)==reference_datetime(value),(value,module.format_datetime_ar(value),reference_datetime(value))
print(f'OK: {len(cases)} fechas ISO, históricas e inválidas conservan exactamente su presentación')
