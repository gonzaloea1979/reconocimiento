"""Prueba las funciones reales de redondeo extrayéndolas del AST de routes.py.
No importa Flask ni modifica la base de datos.
"""
from tests.route_source import read_all_routes
import ast
import math
from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = read_all_routes(ROOT)
tree = ast.parse(source)
wanted = {'money', 'normalize_rounding_mode', 'apply_price_rounding', 'calculate_prices'}
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in wanted]
if {n.name for n in nodes} != wanted:
    raise SystemExit('ERROR: no se encontraron todas las funciones de cálculo')
module = ast.Module(body=nodes, type_ignores=[])
namespace = {'math': math, 'Decimal': Decimal, 'InvalidOperation': InvalidOperation, 'ROUND_CEILING': ROUND_CEILING, 'ROUND_FLOOR': ROUND_FLOOR, 'ROUND_HALF_UP': ROUND_HALF_UP}
exec(compile(module, str(ROOT / 'app' / 'routes.py'), 'exec'), namespace)
round_price = namespace['apply_price_rounding']

cases = [
    (12.5, 'nearest', 5, 15),
    (17.5, 'nearest', 5, 20),
    (12.4, 'nearest', 5, 10),
    (12.1, 'up', 5, 15),
    (14.9, 'down', 5, 10),
    (-12.5, 'nearest', 5, -15),
]
for value, mode, multiple, expected in cases:
    actual = round_price(value, mode, multiple)
    if actual != expected:
        raise SystemExit(f'ERROR: {value=} {mode=} {multiple=}: esperado {expected}, obtenido {actual}')
print(f'OK: {len(cases)} casos de redondeo')

# Cálculo de costo y precio sin aritmética intermedia en float.
calculate = namespace['calculate_prices']
calc_cases = [
    ((0.10, 5, 0, 0, 'none', 1), (0.11, 0.11)),
    ((19.99, 21, 3, 35, 'none', 1), (24.79, 33.46)),
    ((10, 0, 0, 25, 'nearest', 5), (10.0, 15.0)),
]
for args, expected in calc_cases:
    actual = calculate(*args)
    if actual != expected:
        raise SystemExit(f'ERROR: calculate_prices{args!r}: esperado {expected}, obtenido {actual}')
print(f'OK: {len(cases)} casos de redondeo y {len(calc_cases)} cálculos de precios decimales')
