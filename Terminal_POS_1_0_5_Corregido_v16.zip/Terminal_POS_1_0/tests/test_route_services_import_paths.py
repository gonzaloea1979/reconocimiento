"""Regression check: route services must import shared app modules correctly."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'app' / 'route_services' / 'money.py').read_text(encoding='utf-8')
tree = ast.parse(source)
imports = [node for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)]
assert any(node.level == 2 and node.module == 'db' for node in imports), (
    'money.py debe importar get_settings desde app.db mediante from ..db'
)
assert not any(node.level == 1 and node.module == 'db' for node in imports), (
    'No debe buscarse app.route_services.db: ese módulo no existe'
)
print('OK: importación de base de datos desde route_services resuelta correctamente')
