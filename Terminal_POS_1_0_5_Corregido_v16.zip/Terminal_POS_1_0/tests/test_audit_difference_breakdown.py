"""Comprueba clasificación de diferencias sin tocar el origen de prueba."""
import hashlib
import sqlite3
from contextlib import closing
import subprocess
import sys
import tempfile
from pathlib import Path

script = Path(__file__).with_name('auditar_importes_existentes.py')
with tempfile.TemporaryDirectory(prefix='pos_audit_breakdown_') as tmp:
    db = Path(tmp) / 'COPIA_POS.db'
    with closing(sqlite3.connect(db)) as conn:
        conn.executescript('''
            CREATE TABLE sales(id INTEGER PRIMARY KEY,total REAL);
            CREATE TABLE sale_items(id INTEGER PRIMARY KEY,sale_id INTEGER,line_total REAL);
            INSERT INTO sales VALUES(1,5.35),(2,10),(3,2);
            INSERT INTO sale_items VALUES(1,1,2.675),(2,1,2.675),
                (3,2,9.97),(4,3,2.00);
        ''')
    before = hashlib.sha256(db.read_bytes()).hexdigest()
    proc = subprocess.run([sys.executable, str(script), str(db)], text=True, capture_output=True)
    assert proc.returncode == 0, proc.stdout + proc.stderr
    for expected in ('Diferencias de 1 centavo: 1', 'Diferencias de más de 1 centavo: 1',
                     'Diferencia neta (centavos): -2', 'Mayor diferencia por operación (centavos): 3'):
        assert expected in proc.stdout, (expected,proc.stdout)
    assert hashlib.sha256(db.read_bytes()).hexdigest() == before
print('OK: clasificación y suma neta de diferencias sin modificar origen')
