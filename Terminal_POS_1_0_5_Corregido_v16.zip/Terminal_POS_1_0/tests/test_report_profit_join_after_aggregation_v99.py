"""V99 agrega líneas antes del fallback de costo y conserva la ganancia monetaria."""
import ast
import sqlite3
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "app" / "route_modules" / "reports.py").read_text(encoding="utf-8")
tree = ast.parse(SOURCE)
route = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "api_reports")
assignment = next(
    n for n in ast.walk(route)
    if isinstance(n, ast.Assign)
    and any(isinstance(t, ast.Name) and t.id == "report_rollups" for t in n.targets)
)
call = assignment.value
if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "fetchall":
    call = call.func.value
NEW_SQL = call.args[0].value
assert "item_agg AS NOT MATERIALIZED" in NEW_SQL
assert "profit_before_fallback" in NEW_SQL
assert "fallback_quantity" in NEW_SQL
assert "LEFT JOIN products p ON p.id = a.product_id" in NEW_SQL

OLD_SQL = """WITH period_sales AS MATERIALIZED (
    SELECT id FROM sales WHERE created_at >= date(?) AND created_at < date(?, '+1 day')
), item_rollup AS MATERIALIZED (
    SELECT si.product_id, si.product_name,
           SUM(si.quantity) AS qty, SUM(si.line_total) AS total,
           SUM(si.line_total - (COALESCE(si.unit_cost_at_sale, p.total_cost, 0) * si.quantity)) AS profit
    FROM period_sales ps JOIN sale_items si ON si.sale_id = ps.id
    LEFT JOIN products p ON p.id = si.product_id
    GROUP BY si.product_id, si.product_name
), product_rollup AS MATERIALIZED (
    SELECT product_id, SUM(qty) AS qty, SUM(total) AS total
    FROM item_rollup GROUP BY product_id
)
SELECT kind, product_id, name, qty, total, estimated_profit FROM (
    SELECT 'top' AS kind, product_id, product_name AS name, qty, total,
           NULL AS estimated_profit, 1 AS section
    FROM (SELECT product_id, product_name, qty, total FROM item_rollup ORDER BY qty DESC LIMIT 15)
    UNION ALL
    SELECT 'least' AS kind, id AS product_id, name, qty, total,
           NULL AS estimated_profit, 2 AS section
    FROM (
        SELECT p.id, p.name, COALESCE(r.qty,0) AS qty, COALESCE(r.total,0) AS total
        FROM products p LEFT JOIN product_rollup r ON r.product_id=p.id
        ORDER BY qty ASC, p.name ASC LIMIT 15
    )
    UNION ALL
    SELECT 'profit' AS kind, NULL AS product_id, NULL AS name, NULL AS qty, NULL AS total,
           COALESCE(SUM(profit),0) AS estimated_profit, 3 AS section FROM item_rollup
)
ORDER BY section, CASE WHEN section=1 THEN qty END DESC,
         CASE WHEN section=2 THEN qty END ASC,
         CASE WHEN section=2 THEN name END ASC"""

with tempfile.TemporaryDirectory(prefix="pos_report_profit_v99_") as tmp:
    db = sqlite3.connect(Path(tmp) / "reports.db")
    db.row_factory = sqlite3.Row
    db.executescript("""
        PRAGMA foreign_keys=ON;
        CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT NOT NULL, total_cost REAL NOT NULL);
        CREATE TABLE sales(id INTEGER PRIMARY KEY, created_at TEXT NOT NULL, total REAL NOT NULL);
        CREATE TABLE sale_items(
            id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL REFERENCES sales(id),
            product_id INTEGER NOT NULL REFERENCES products(id), product_name TEXT NOT NULL,
            quantity REAL NOT NULL, line_total REAL NOT NULL, unit_cost_at_sale REAL
        );
        CREATE INDEX idx_sales_created_at ON sales(created_at);
        CREATE INDEX idx_sale_items_sale_report
            ON sale_items(sale_id,product_id,product_name,quantity,line_total,unit_cost_at_sale);
    """)
    products = [(i, f"Producto {i:04d}", 12.345 + i * 0.0137) for i in range(1, 81)]
    db.executemany("INSERT INTO products VALUES(?,?,?)", products)
    sales = []
    items = []
    item_id = 1
    for sale_id in range(1, 1201):
        day = sale_id % 28 + 1
        sales.append((sale_id, f"2026-10-{day:02d}T12:00:00", 1000.25 + sale_id))
        for line in range(3):
            product_id = (sale_id * 7 + line * 11) % 80 + 1
            quantity = (sale_id % 7 + line + 1) / 3.0
            line_total = round(quantity * (40.125 + product_id * 0.31), 2)
            # Mezcla de costos históricos presentes y NULL que requieren fallback.
            historical_cost = None if (sale_id + line) % 4 == 0 else 9.876 + product_id * 0.071
            product_name = f"Producto {product_id:04d}" if sale_id % 2 else f"Nombre anterior {product_id:04d}"
            items.append((item_id, sale_id, product_id, product_name, quantity, line_total, historical_cost))
            item_id += 1
    db.executemany("INSERT INTO sales VALUES(?,?,?)", sales)
    db.executemany("INSERT INTO sale_items VALUES(?,?,?,?,?,?,?)", items)
    params = ("2026-10-01", "2026-10-31")

    old_rows = db.execute(OLD_SQL, params).fetchall()
    new_rows = db.execute(NEW_SQL, params).fetchall()
    old_top = [(r["name"], r["qty"], r["total"]) for r in old_rows if r["kind"] == "top"]
    new_top = [(r["name"], r["qty"], r["total"]) for r in new_rows if r["kind"] == "top"]
    old_least = [(r["name"], r["qty"], r["total"]) for r in old_rows if r["kind"] == "least"]
    new_least = [(r["name"], r["qty"], r["total"]) for r in new_rows if r["kind"] == "least"]
    old_profit = next(r["estimated_profit"] for r in old_rows if r["kind"] == "profit")
    new_profit = next(r["estimated_profit"] for r in new_rows if r["kind"] == "profit")

    assert old_top == new_top, "Cambió el ranking de más vendidos o sus snapshots históricos."
    assert old_least == new_least, "Cambió el ranking de menos vendidos."
    assert abs(old_profit - new_profit) < 0.005, (
        f"La diferencia de ganancia supera medio centavo: old={old_profit}, new={new_profit}"
    )
    assert round(old_profit + 1e-9, 2) == round(new_profit + 1e-9, 2), (
        "La ganancia visible en centavos cambió."
    )

    # Sin ventas: 15 menos vendidos, cero más vendidos y ganancia cero.
    empty = db.execute(NEW_SQL, ("2020-01-01", "2020-01-31")).fetchall()
    assert len([r for r in empty if r["kind"] == "top"]) == 0
    assert len([r for r in empty if r["kind"] == "least"]) == 15
    assert next(r["estimated_profit"] for r in empty if r["kind"] == "profit") == 0
    assert db.execute("PRAGMA quick_check").fetchone()[0] == "ok"
    db.close()

print("OK: V99 conserva rankings, snapshots y ganancia al centavo con costos históricos NULL.")
