"""Regresiones 1.0.5.3: tope de porcentajes en compras y refactor del lector.

Cubre:
  1. La compra escribe iva_percent/gross_income_percent directamente en el
     producto. Antes solo rechazaba negativos, así que una
     compra con IVA 500% dejaba el producto con un precio imposible.
  2. El decodificador de códigos de barras se refactorizó en helpers
     (_decode_1d_candidates / _decode_barcode_frame); se comprueba que sigue
     aceptando los distintos formatos de OpenCV y el fallback QR.

Usa una base temporal; nunca toca datos comerciales.
"""
from pathlib import Path
from types import SimpleNamespace
import os
import sys
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import app.config as config
from app import create_app
from app.route_core import _decode_1d_candidates, _decode_barcode_frame, decode_barcode_image_bytes

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {k: getattr(config, k) for k in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_v1053_regressions_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base / 'instance',
                               BACKUP_DIR=base / 'backups', DATABASE=base / 'instance' / 'pos.db',
                               UPLOAD_DIR=base / 'uploads', TICKET_DIR=base / 'TICKET').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = True
        client = app.test_client()
        assert client.get('/api/products').status_code == 200

        product = client.post('/api/products', json={
            'name': 'CompraPct', 'cost_without_tax': 100, 'iva_percent': 21, 'margin_percent': 30, 'stock': 10,
        }).get_json()

        def buy(item):
            return client.post('/api/purchases', json={'items': [item], 'supplier_name': 'Prov'})

        # --- 1. Compras con porcentajes fuera de rango -----------------------
        assert buy({'product_id': product['id'], 'quantity': 1, 'cost_without_tax': 100, 'iva_percent': 500}).status_code == 400
        assert buy({'product_id': product['id'], 'quantity': 1, 'cost_without_tax': 100, 'gross_income_percent': 200}).status_code == 400
        # El margen es un recargo: puede superar 100, pero no ser negativo.
        assert buy({'product_id': product['id'], 'quantity': 1, 'cost_without_tax': 100, 'margin_percent': -1}).status_code == 400
        assert buy({'product_id': product['id'], 'quantity': 1, 'cost_without_tax': 100, 'iva_percent': -1}).status_code == 400
        assert buy({'product_id': product['id'], 'quantity': 1, 'cost_without_tax': -5}).status_code == 400

        # Tras los intentos inválidos el producto no cambió.
        unchanged = client.get(f"/api/products/{product['id']}").get_json()
        assert unchanged['iva_percent'] == 21, unchanged['iva_percent']
        assert unchanged['margin_percent'] == 30, unchanged['margin_percent']

        # Una compra válida con el límite exacto se acepta y actualiza el producto.
        ok = buy({'product_id': product['id'], 'quantity': 1, 'cost_without_tax': 100,
                  'iva_percent': 100, 'gross_income_percent': 3, 'margin_percent': 30})
        assert ok.status_code == 200, ok.get_json()
        after = client.get(f"/api/products/{product['id']}").get_json()
        assert after['iva_percent'] == 100
        assert after['sale_price'] > 0

        # --- 2. Refactor del lector de códigos de barras ---------------------
        assert _decode_1d_candidates('ABC') == ['ABC']
        assert _decode_1d_candidates(('ABC', None)) == ['ABC']
        assert _decode_1d_candidates((['A', 'B'], None)) == ['A', 'B']
        assert _decode_1d_candidates(None) == []
        assert _decode_1d_candidates(42) == []

        class OneDDetector:
            def detectAndDecode(self, frame):
                return ('1234567890', None)

        class EmptyQR:
            def detectAndDecode(self, frame):
                return ('', None, None)

        fake_cv2 = SimpleNamespace(
            barcode_BarcodeDetector=lambda: OneDDetector(),
            QRCodeDetector=lambda: EmptyQR(),
            COLOR_BGR2GRAY=6, COLOR_GRAY2BGR=8,
            cvtColor=lambda frame, mode: frame, equalizeHist=lambda frame: frame,
        )
        assert _decode_barcode_frame(fake_cv2, object()) == '1234567890'

        class NoDetector:
            def detectAndDecode(self, frame):
                return ('', None)

        class QRDetector:
            def detectAndDecode(self, frame):
                return ('QR-CODE-1', None, None)

        fake_cv2.barcode_BarcodeDetector = lambda: NoDetector()
        fake_cv2.QRCodeDetector = lambda: QRDetector()
        assert _decode_barcode_frame(fake_cv2, object()) == 'QR-CODE-1'

        fake_cv2.QRCodeDetector = lambda: NoDetector()
        assert _decode_barcode_frame(fake_cv2, object()) == ''

        assert decode_barcode_image_bytes(b'') == ('', 'No llegó imagen para decodificar.')

        print('OK: tope de porcentajes en compras y refactor del lector de códigos')
finally:
    for key, value in saved.items():
        setattr(config, key, value)
