"""Verifica que el banco V98 mida el reporte optimizado en aislamiento."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "prueba_carga_v98.py").read_text(encoding="utf-8")
route = (ROOT / "app" / "route_modules" / "reports.py").read_text(encoding="utf-8")
assert 'TemporaryDirectory(prefix="terminal_pos_v98_")' in source
assert "No se abre ni modifica instance/pos.db" in source
assert "127.0.0.1" in source
assert "ThreadPoolExecutor" in source
assert "foreign_key_check" in source and "quick_check" in source
assert 'idx_sale_items_sale_report' in source
assert 'Cliente%2000050' in source
assert 'Proveedor%2000050' in source
assert 'date.today() - timedelta(days=30)' in source
assert 'V98' in source
assert "sales_by_product" not in route
assert "least = [{'name': row['name'], 'qty': row['qty'], 'total': row['total']}" in route
print("OK: banco V98 aislado y endpoint de reportes sin ranking duplicado.")
