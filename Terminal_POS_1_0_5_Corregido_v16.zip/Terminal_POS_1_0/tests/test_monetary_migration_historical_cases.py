"""Prueba de escenarios historicos para una eventual migracion monetaria.

No modifica produccion: construye dos SQLite temporales, convierte solo la copia
con transaccion explicita y comprueba rollback de casos invalidos.
"""
from contextlib import closing
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import sqlite3
import tempfile

MONEY_COLUMNS = {
    'products': ('cost_without_tax', 'total_cost', 'sale_price'),
    'sales': ('total', 'amount_received', 'change_amount'),
    'sale_items': ('unit_price', 'line_total', 'unit_cost_at_sale'),
    'purchases': ('total',),
    'purchase_items': ('unit_cost', 'cost_without_tax', 'total_cost', 'sale_price', 'line_total'),
    'cash_sessions': ('initial_amount', 'closing_amount', 'expected_amount', 'difference'),
    'cash_movements': ('amount',),
    'clients': ('balance',),
    'client_movements': ('amount',),
}

# SQLite REAL does not retain exact textual subcent values. Converting it to cents
# is a rounding policy, not an exact reconstruction of an original decimal entry.
def to_cents(value):
    if value is None:
        return None
    x = Decimal(str(value))
    if not x.is_finite():
        raise ValueError('non-finite monetary value')
    n = int((x * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    if not -(2**63) <= n <= 2**63 - 1:
        raise OverflowError('outside SQLite integer range')
    return n

samples = [None, 0, 0.01, 0.105, -0.105, 2.675, -2.675, 999999.999,
           125.50, -300.25, 1.005, 0.000001, 100000000.99]

with tempfile.TemporaryDirectory(prefix='pos_historical_money_') as temp:
    original = Path(temp) / 'historical.db'
    copy = Path(temp) / 'candidate.db'
    with closing(sqlite3.connect(original)) as src:
        for table, cols in MONEY_COLUMNS.items():
            src.execute(f'CREATE TABLE "{table}" (id INTEGER PRIMARY KEY, {", ".join(f"{c} REAL" for c in cols)})')
            placeholders = ','.join('?' for _ in cols)
            for row in range(len(samples)):
                values = [samples[(row + i) % len(samples)] for i in range(len(cols))]
                src.execute(f'INSERT INTO "{table}" ({", ".join(cols)}) VALUES ({placeholders})', values)
        src.commit()
        with closing(sqlite3.connect(copy)) as dest:
            src.backup(dest)
    with closing(sqlite3.connect(copy)) as db:
        db.execute('BEGIN')
        try:
            for table, cols in MONEY_COLUMNS.items():
                for col in cols:
                    db.execute(f'ALTER TABLE "{table}" ADD COLUMN "{col}_cents_candidate" INTEGER')
                    for pk, value in db.execute(f'SELECT id, "{col}" FROM "{table}"').fetchall():
                        db.execute(f'UPDATE "{table}" SET "{col}_cents_candidate"=? WHERE id=?',
                                   (to_cents(value), pk))
            db.commit()
        except Exception:
            db.rollback()
            raise
        for table, cols in MONEY_COLUMNS.items():
            assert db.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0] == len(samples)
            for col in cols:
                for raw, stored in db.execute(f'SELECT "{col}", "{col}_cents_candidate" FROM "{table}"'):
                    assert stored == to_cents(raw), (table, col, raw, stored)
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        # Force failure halfway through a transaction: no schema/data leftovers.
        db.execute('BEGIN')
        db.execute('ALTER TABLE "sales" ADD COLUMN abort_test INTEGER')
        try:
            to_cents(float('inf'))
            raise AssertionError('invalid value did not fail')
        except ValueError:
            db.rollback()
        assert 'abort_test' not in {r[1] for r in db.execute('PRAGMA table_info(sales)')}
    with closing(sqlite3.connect(original)) as src:
        assert src.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        for table, cols in MONEY_COLUMNS.items():
            assert [r[1] for r in src.execute(f'PRAGMA table_info("{table}")')] == ['id', *cols]
            assert src.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0] == len(samples)
    assert to_cents('-0.105') == -11
    assert to_cents('2.675') == 268
    for invalid in ('NaN', 'Infinity', '-Infinity'):
        try:
            to_cents(invalid)
            raise AssertionError(f'{invalid} accepted')
        except ValueError:
            pass
    try:
        to_cents('1000000000000000000000')
        raise AssertionError('out-of-range value accepted')
    except OverflowError:
        pass

print(f'OK: simulacion historica de {len(MONEY_COLUMNS)} tablas, {sum(map(len, MONEY_COLUMNS.values()))} columnas y {len(samples)} registros por tabla; rollback, limites y origen intacto')
