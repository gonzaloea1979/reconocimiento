"""Regresión 1.0.5.4: la importación de Excel valida los datos del producto.

Antes, /api/prices/import escribía costos, IVA, ingresos brutos, precios y stock
directamente en products sin validar nada: un archivo .xls con IVA 500% y costo
-100 dejaba el producto con precio -80792. Ahora cada fila pasa por los mismos
validadores que la creación/edición de productos y, ante un error, no se importa
ninguna fila.

Usa una base temporal; nunca toca datos comerciales.
"""
from pathlib import Path
import io
import os
import sys
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import app.config as config
from app import create_app

HEADERS = ['ID', 'Código de barra', 'Nombre', 'Detalle', 'Precio sin impuestos',
           'IVA %', 'Ingresos brutos %', 'Costo total', 'Margen ganancia %',
           'Precio venta', 'Stock', 'Fecha vencimiento']

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {k: getattr(config, k) for k in keys}
try:
    import xlwt

    with tempfile.TemporaryDirectory(prefix='pos_v1054_regressions_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base / 'instance',
                               BACKUP_DIR=base / 'backups', DATABASE=base / 'instance' / 'pos.db',
                               UPLOAD_DIR=base / 'uploads', TICKET_DIR=base / 'TICKET').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = True
        client = app.test_client()
        assert client.get('/api/products').status_code == 200

        def build_book(rows):
            book = xlwt.Workbook()
            sheet = book.add_sheet('Lista')
            for col, header in enumerate(HEADERS):
                sheet.write(0, col, header)
            for row_index, row in enumerate(rows, start=1):
                for col, value in enumerate(row):
                    sheet.write(row_index, col, value)
            buffer = io.BytesIO()
            book.save(buffer)
            buffer.seek(0)
            return buffer

        def import_rows(rows):
            return client.post('/api/prices/import',
                               data={'file': (build_book(rows), 'lista.xls')},
                               content_type='multipart/form-data')

        # Cada fila inválida se rechaza y no importa nada.
        bad_cases = [
            (['', '111', 'MalIva', '', 100, 500, 0, '', 30, '', 5, ''], 'IVA'),
            (['', '222', 'MalCosto', '', -100, 21, 0, '', 30, '', 5, ''], 'Precio sin impuestos'),
            (['', '333', 'MalStock', '', 100, 21, 0, '', 30, '', -50, ''], 'Stock'),
            (['', '444', 'MalGross', '', 100, 21, 200, '', 30, '', 5, ''], 'Ingresos brutos'),
        ]
        for row, expected_label in bad_cases:
            response = import_rows([row])
            assert response.status_code == 400, response.get_json()
            body = response.get_json()
            assert expected_label in body['details'][0], body
        # Ninguna de las filas inválidas creó productos.
        assert client.get('/api/products').get_json() == []

        # Una fila válida sí se importa.
        ok = import_rows([['', '555', 'Bien', '', 100, 21, 3, None, 30, None, 5, '']])
        assert ok.status_code == 200, ok.get_json()
        products = client.get('/api/products').get_json()
        assert len(products) == 1
        product = products[0]
        assert product['name'] == 'Bien'
        assert product['iva_percent'] == 21
        assert product['cost_without_tax'] == 100
        assert product['stock'] == 5
        assert product['sale_price'] > 0

        # Un margen derivado negativo (precio de venta menor al costo) no se guarda.
        low = import_rows([['', '666', 'PrecioBajo', '', 100, 0, 0, None, None, 50, 5, '']])
        assert low.status_code == 200, low.get_json()
        low_product = [p for p in client.get('/api/products').get_json() if p['name'] == 'PrecioBajo'][0]
        assert low_product['margin_percent'] == 0
        assert low_product['sale_price'] == 50

        print('OK: la importación de Excel valida los datos del producto')
finally:
    for key, value in saved.items():
        setattr(config, key, value)
