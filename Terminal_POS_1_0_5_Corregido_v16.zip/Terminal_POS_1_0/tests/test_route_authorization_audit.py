"""Auditoría estática: todas las rutas de operación deben requerir sesión, salvo excepciones explícitas."""
from tests.route_source import read_all_routes
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = read_all_routes(ROOT)
tree = ast.parse(source)
public_exceptions = {"api_first_setup", "api_login", "api_shutdown", "first_setup_page", "login_page"}
unprotected = []
for node in tree.body:
    if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
        continue
    decorators = [ast.unparse(d) for d in node.decorator_list]
    route_decorators = [d for d in decorators if d.startswith("bp.") and ".app_errorhandler(" not in d]
    if not route_decorators:
        continue
    if node.name in public_exceptions:
        continue
    if "login_required" not in decorators:
        unprotected.append((node.name, node.lineno, route_decorators))
if unprotected:
    raise SystemExit(f"ERROR: rutas sin login_required ni excepción explícita: {unprotected}")

shutdown = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "api_shutdown")
shutdown_src = ast.get_source_segment(source, shutdown) or ""
if "if shutdown_pc and not current_user_is_admin()" not in shutdown_src:
    raise SystemExit("ERROR: apagar la PC debe requerir rol administrador")
print("OK: rutas protegidas o excepciones explícitas; apagado físico restringido al administrador")
