"""El POS no debe cerrarse si el respaldo previo no pudo completarse."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / 'app' / 'route_modules' / 'auth.py'
tree = ast.parse(path.read_text(encoding='utf-8'))
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'api_shutdown')
source = ast.get_source_segment(path.read_text(encoding='utf-8'), node) or ''
required = [
    'backup_path = backup_database()',
    'if backup_path is None:',
    'current_app.logger.exception',
    "}), 503",
    'def delayed_shutdown():',
]
for item in required:
    if item not in source:
        raise SystemExit(f'ERROR: api_shutdown no garantiza respaldo antes del cierre: falta {item!r}')
if source.index('}), 503') > source.index('def delayed_shutdown():'):
    raise SystemExit('ERROR: el flujo de apagado se define antes de resolver el fallo del respaldo')
if 'except Exception:\n        pass' in source:
    raise SystemExit('ERROR: el fallo de respaldo no puede silenciarse')
print('OK: si falla el respaldo, el cierre se cancela, se registra el error y se devuelve HTTP 503')
