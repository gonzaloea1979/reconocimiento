"""Respaldo real: reloj repetido, retención, fallos y bloqueos en BD temporal."""
import errno
import hashlib
import importlib.util
import os
from pathlib import Path
import sqlite3
import sys
import tempfile
import time
import types
from contextlib import closing
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
fake=types.ModuleType('flask'); fake.current_app=types.SimpleNamespace(config={}); fake.g=types.SimpleNamespace()
previous=sys.modules.get('flask'); sys.modules['flask']=fake
try:
    spec=importlib.util.spec_from_file_location('_pos_backup_failure_test',ROOT/'app/db.py')
    module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
finally:
    if previous is None: sys.modules.pop('flask',None)
    else: sys.modules['flask']=previous

with tempfile.TemporaryDirectory(prefix='pos_backup_failures_') as tmp:
    b=Path(tmp); src=b/'datos #1 %.db'; backups=b/'backups'; backups.mkdir()
    with closing(sqlite3.connect(src)) as db:
        db.executescript('''PRAGMA foreign_keys=ON;
        CREATE TABLE products(id INTEGER PRIMARY KEY,stock REAL);
        CREATE TABLE sales(id INTEGER PRIMARY KEY,total REAL);
        CREATE TABLE items(id INTEGER PRIMARY KEY,sale_id INTEGER REFERENCES sales(id),product_id INTEGER REFERENCES products(id));
        INSERT INTO products VALUES(1,7); INSERT INTO sales VALUES(1,42.50); INSERT INTO items VALUES(1,1,1);
        '''); db.commit()
    fake.current_app.config={'DATABASE':src,'BACKUP_DIR':backups}
    def fingerprint():
        return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in backups.glob('pos_backup_*.db')}
    # URI mode=ro con espacios/#/%; no permite ni escritura ni crear archivos.
    with closing(module.connect_database(src,read_only=True)) as db:
        assert db.execute('SELECT stock FROM products').fetchone()[0]==7
        try: db.execute('UPDATE products SET stock=0')
        except sqlite3.OperationalError: pass
        else: raise AssertionError('El origen de respaldo admite escrituras')
    missing=b/'no existe.db'
    try: module.connect_database(missing,read_only=True)
    except sqlite3.OperationalError: pass
    else: raise AssertionError('Se abrio un origen inexistente')
    assert not missing.exists()
    frozen=types.SimpleNamespace(now=lambda:datetime(2026,11,4,12))
    with patch.object(module,'datetime',frozen):
        first=module.backup_database()
        with closing(sqlite3.connect(src)) as db:
            db.execute('INSERT INTO sales VALUES(2,99)'); db.commit()
        first_hash=hashlib.sha256(first.read_bytes()).hexdigest()
        second=module.backup_database()
    assert first!=second and first.is_file() and second.is_file()
    assert hashlib.sha256(first.read_bytes()).hexdigest()==first_hash
    with closing(sqlite3.connect(first)) as db: assert db.execute('SELECT COUNT(*) FROM sales').fetchone()[0]==1
    with closing(sqlite3.connect(second)) as db: assert db.execute('SELECT COUNT(*) FROM sales').fetchone()[0]==2
    print('OK: reloj repetido no sobrescribe copias; origen solo lectura con rutas especiales')

    # Seis copias del mismo proceso pueden coexistir sin nombres repetidos.
    with ThreadPoolExecutor(6) as pool:
        with patch.object(module,'datetime',frozen): paths=list(pool.map(lambda _:module.backup_database(),range(6)))
    assert len(set(paths))==6 and all(p.is_file() for p in paths)
    for p in paths:
        with closing(sqlite3.connect(p)) as db:
            assert db.execute('PRAGMA quick_check').fetchone()[0]=='ok'
            assert not db.execute('PRAGMA foreign_key_check').fetchall()
    print('OK: seis respaldos simultáneos válidos y distintos')

    # Las fechas futuras de copias anteriores no pueden eliminar la recién creada.
    for p in backups.glob('pos_backup_*.db'): os.utime(p,(2_000_000_000,2_000_000_000))
    newest=module.backup_database(max_backups=1)
    assert newest.is_file() and list(backups.glob('pos_backup_*.db'))==[newest]
    before=fingerprint()
    for failure in (OSError(errno.ENOSPC,'disco lleno simulado'), PermissionError('archivo bloqueado simulado')):
        with patch.object(module.os,'replace',side_effect=failure):
            try: module.backup_database(max_backups=1)
            except OSError as exc: assert type(exc) is type(failure)
            else: raise AssertionError('Falso éxito de respaldo fallido')
        assert fingerprint()==before
        assert not list(backups.glob('.pos_backup_*.tmp'))
    print('OK: retención conserva respaldo actual; disco lleno/bloqueo no publica ni borra copias anteriores')

    # quick_check no detecta referencias huérfanas: no declarar verificada esa copia.
    with closing(sqlite3.connect(src)) as db:
        db.execute('PRAGMA foreign_keys=OFF'); db.execute('INSERT INTO items VALUES(2,999,1)'); db.commit()
    try: module.backup_database()
    except sqlite3.IntegrityError: pass
    else: raise AssertionError('Se publico una copia con referencias invalidas')
    assert fingerprint()==before and not list(backups.glob('.pos_backup_*.tmp'))
    with closing(sqlite3.connect(src)) as db:
        db.execute('DELETE FROM items WHERE id=2'); db.commit()
    print('OK: referencias inválidas impiden informar respaldo verificado y preservan copias previas')

    # Bloqueo SQLite REAL, sin esperar indefinidamente en Connection.backup.
    with closing(sqlite3.connect(src)) as writer:
        writer.execute('BEGIN EXCLUSIVE'); writer.execute('UPDATE products SET stock=6')
        start=time.monotonic()
        with patch.object(module,'BACKUP_TIMEOUT_SECONDS',0.15):
            try: module.backup_database()
            except (TimeoutError,sqlite3.OperationalError): pass
            else: raise AssertionError('La copia de origen bloqueado debió fallar')
        assert time.monotonic()-start < 3, 'La copia bloqueada no tuvo límite'
        writer.rollback()
    assert fingerprint()==before and not list(backups.glob('.pos_backup_*.tmp'))
    recovered=module.backup_database()
    assert recovered.is_file()
    print('OK: bloqueo real termina con error acotado; al liberar el bloqueo se crea una copia válida')

    # Si el archivo desaparece después de exists(), no recrearlo ni copiar vacío.
    original=module.connect_database
    before=fingerprint()
    def disappear(path,*args,**kwargs):
        if Path(path)==src and src.exists(): src.unlink()
        return original(path,*args,**kwargs)
    with patch.object(module,'connect_database',side_effect=disappear):
        try: module.backup_database()
        except sqlite3.OperationalError: pass
        else: raise AssertionError('No se detecto origen desaparecido')
    assert not src.exists() and fingerprint()==before and not list(backups.glob('.pos_backup_*.tmp'))
    print('OK: origen desaparecido no se recrea vacío ni genera una falsa copia de seguridad')
    # Una base corrupta no deja conexiones abiertas ni reemplaza copias validas.
    damaged=b/'corrupta.db'; damaged.write_bytes(b'no es una base SQLite' * 100)
    fake.current_app.config['DATABASE']=damaged
    try: module.backup_database()
    except sqlite3.DatabaseError: pass
    else: raise AssertionError('No se detecto origen corrupto')
    assert fingerprint()==before and not list(backups.glob('.pos_backup_*.tmp'))
    damaged.unlink()
    print('OK: origen corrupto falla sin publicar copia ni dejar handles abiertos')


    empty=b/'vacia.db'; empty.touch()
    fake.current_app.config['DATABASE']=empty
    try: module.backup_database()
    except sqlite3.DatabaseError: pass
    else: raise AssertionError('Se publico una base vacia sin tablas')
    assert fingerprint()==before and not list(backups.glob('.pos_backup_*.tmp'))
    print('OK: archivo de origen vacío no se declara respaldo válido ni retira copias previas')
