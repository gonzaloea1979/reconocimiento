"""Prueba de respaldo/restauración SQLite sobre una base temporal o existente en solo lectura.

No modifica instance/pos.db. Si el paquete está limpio, crea datos ficticios temporales.
"""
from __future__ import annotations
import sqlite3
import tempfile
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "instance" / "pos.db"
CRITICAL_TABLES = ("products", "sales", "sale_items", "purchases", "purchase_items", "cash_sessions", "cash_movements")


def integrity(conn: sqlite3.Connection) -> str:
    return str(conn.execute("PRAGMA integrity_check").fetchone()[0])


def counts(conn: sqlite3.Connection) -> dict[str, int]:
    names = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    return {table: int(conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0])
            for table in CRITICAL_TABLES if table in names}


def table_schema(conn: sqlite3.Connection) -> dict[str, str]:
    return {row[0]: row[1] for row in conn.execute(
        "SELECT name, sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")}


def create_sample_database(path: Path) -> None:
    with closing(sqlite3.connect(path)) as conn:
        conn.execute('PRAGMA journal_mode=WAL')
        conn.executescript('''
          PRAGMA foreign_keys=ON;
          CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
          CREATE TABLE sales(id INTEGER PRIMARY KEY, total REAL NOT NULL);
          CREATE TABLE sale_items(id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL REFERENCES sales(id), product_id INTEGER NOT NULL REFERENCES products(id), quantity REAL NOT NULL);
          CREATE TABLE purchases(id INTEGER PRIMARY KEY, total REAL NOT NULL);
          CREATE TABLE purchase_items(id INTEGER PRIMARY KEY, purchase_id INTEGER NOT NULL REFERENCES purchases(id), product_id INTEGER NOT NULL REFERENCES products(id), quantity REAL NOT NULL);
          CREATE TABLE cash_sessions(id INTEGER PRIMARY KEY, opening_amount REAL NOT NULL);
          CREATE TABLE cash_movements(id INTEGER PRIMARY KEY, cash_session_id INTEGER NOT NULL REFERENCES cash_sessions(id), amount REAL NOT NULL);
          INSERT INTO products VALUES (1, 'producto-prueba');
          INSERT INTO sales VALUES (1, 120.50);
          INSERT INTO sale_items VALUES (1, 1, 1, 2);
          INSERT INTO purchases VALUES (1, 80.00);
          INSERT INTO purchase_items VALUES (1, 1, 1, 4);
          INSERT INTO cash_sessions VALUES (1, 1000.00);
          INSERT INTO cash_movements VALUES (1, 1, 120.50);
        ''')
        conn.commit()


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="pos_backup_test_") as temp:
        temp_dir = Path(temp)
        source_path = SOURCE if SOURCE.exists() else temp_dir / "source_sample.db"
        if not SOURCE.exists():
            create_sample_database(source_path)
        backup_path = temp_dir / "backup.db"
        restored_path = temp_dir / "restored.db"
        with closing(sqlite3.connect(source_path, timeout=10)) as source, closing(sqlite3.connect(backup_path, timeout=10)) as target:
            source.execute('PRAGMA foreign_keys=ON')
            source_counts = counts(source)
            source_schema = table_schema(source)
            source.backup(target)
            if integrity(target) != "ok":
                print("ERROR: el respaldo no supera integrity_check")
                return 1
            if source_counts != counts(target) or source_schema != table_schema(target):
                print("ERROR: esquema o conteos no coinciden entre origen y respaldo")
                return 1
            if target.execute('PRAGMA foreign_key_check').fetchall():
                print("ERROR: el respaldo contiene referencias foráneas inválidas")
                return 1
        with closing(sqlite3.connect(backup_path)) as backup, closing(sqlite3.connect(restored_path)) as restored:
            backup.backup(restored)
            if integrity(restored) != "ok" or source_counts != counts(restored) or source_schema != table_schema(restored):
                print("ERROR: la restauración no coincide con el respaldo")
                return 1
            if restored.execute('PRAGMA foreign_key_check').fetchall():
                print("ERROR: la restauración contiene referencias foráneas inválidas")
                return 1
        # Comprobar por inspección que el mecanismo de producción conserva copia atómica y handles cerrados.
        source_code = (ROOT / 'app' / 'db.py').read_text(encoding='utf-8')
        for required in ('source.backup(target, pages=256, progress=check_progress', 'PRAGMA quick_check', 'os.replace(temporary, dst)', 'tempfile.mkstemp', 'closing(connect_database'):
            if required not in source_code:
                print(f'ERROR: falta protección en backup_database: {required}')
                return 1
        print("OK: esquema, conteos, integridad, referencias y restauración verificados en base temporal")
        print(f"Tablas comprobadas: {source_counts}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
