"""V103: resumen de ventas y desglose de pagos en una sola consulta."""
import sqlite3
import tempfile
import time
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "app" / "route_modules" / "reports.py").read_text(encoding="utf-8")
assert "payment_metrics = db.execute(" in SOURCE
assert "SUM(COUNT(*)) OVER () AS sales_count" in SOURCE
assert "SUM(SUM(total)) OVER (),0) AS total_sales" in SOURCE
assert "SUM(SUM(change_amount)) OVER (),0) AS total_change" in SOURCE

COMBINED = """
SELECT payment_method,
       COUNT(*) AS count,
       COALESCE(SUM(total),0) AS total,
       SUM(COUNT(*)) OVER () AS sales_count,
       COALESCE(SUM(SUM(total)) OVER (),0) AS total_sales,
       COALESCE(SUM(SUM(change_amount)) OVER (),0) AS total_change
FROM sales
WHERE created_at >= date(?) AND created_at < date(?, '+1 day')
GROUP BY payment_method
ORDER BY total DESC
"""
OLD_SUMMARY = """
SELECT COUNT(*) AS sales_count, COALESCE(SUM(total),0) AS total_sales,
       COALESCE(SUM(change_amount),0) AS total_change
FROM sales WHERE created_at >= date(?) AND created_at < date(?, '+1 day')
"""
OLD_PAYMENT = """
SELECT payment_method, COUNT(*) AS count, COALESCE(SUM(total),0) AS total
FROM sales WHERE created_at >= date(?) AND created_at < date(?, '+1 day')
GROUP BY payment_method ORDER BY total DESC
"""

with tempfile.TemporaryDirectory(prefix="pos_v103_report_metrics_") as tmp:
    db = sqlite3.connect(Path(tmp) / "report.db")
    db.row_factory = sqlite3.Row
    db.executescript("""
        CREATE TABLE sales(
            id INTEGER PRIMARY KEY,
            created_at TEXT NOT NULL,
            payment_method TEXT NOT NULL,
            total REAL NOT NULL,
            change_amount REAL NOT NULL
        );
        CREATE INDEX idx_sales_created_at ON sales(created_at);
    """)
    methods = ("Efectivo", "Transferencia", "Débito", "Crédito")
    rows = []
    for i in range(1, 12001):
        day = (i % 45) + 1
        month = "10" if day <= 31 else "11"
        day_num = day if day <= 31 else day - 31
        stamp = f"2026-{month}-{day_num:02d}T12:00:00"
        rows.append((i, stamp, methods[i % len(methods)], float((i * 137) % 50000),
                     float((i * 29) % 3000)))
    db.executemany("INSERT INTO sales VALUES(?,?,?,?,?)", rows)
    db.execute("ANALYZE")
    for params in (("2026-10-01", "2026-10-31"), ("2026-11-01", "2026-11-14"),
                   ("2030-01-01", "2030-01-31")):
        old_summary = dict(db.execute(OLD_SUMMARY, params).fetchone())
        old_payments = [dict(r) for r in db.execute(OLD_PAYMENT, params).fetchall()]
        combined_rows = [dict(r) for r in db.execute(COMBINED, params).fetchall()]
        if combined_rows:
            first = combined_rows[0]
            new_summary = {
                "sales_count": first["sales_count"],
                "total_sales": first["total_sales"],
                "total_change": first["total_change"],
            }
            new_payments = [
                {"payment_method": r["payment_method"], "count": r["count"], "total": r["total"]}
                for r in combined_rows
            ]
        else:
            new_summary = {"sales_count": 0, "total_sales": 0, "total_change": 0}
            new_payments = []
        assert new_summary == old_summary, (params, new_summary, old_summary)
        assert new_payments == old_payments, (params, new_payments, old_payments)

    # Informational benchmark only; no hardware-dependent threshold.
    params = ("2026-10-01", "2026-10-31")
    def measure(fn, n=50):
        for _ in range(5): fn()
        samples = []
        for _ in range(n):
            start = time.perf_counter_ns()
            fn()
            samples.append((time.perf_counter_ns() - start) / 1_000_000)
        return statistics.median(samples)
    old_ms = measure(lambda: (db.execute(OLD_SUMMARY, params).fetchone(),
                              db.execute(OLD_PAYMENT, params).fetchall()))
    new_ms = measure(lambda: db.execute(COMBINED, params).fetchall())
    print(f"Resumen + pagos anterior: {old_ms:.3f} ms; consulta combinada: {new_ms:.3f} ms")
    assert db.execute("PRAGMA quick_check").fetchone()[0] == "ok"
    db.close()

print("OK: resumen, total de cambio y medios de pago equivalentes; incluye período vacío.")
