"""El reporte mensual comparte una sola agregación sin cambiar sus resultados."""
import ast
import sqlite3
import tempfile
import time
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS_SOURCE = (ROOT / "app" / "route_modules" / "reports.py").read_text(encoding="utf-8")
DB_SOURCE = (ROOT / "app" / "db.py").read_text(encoding="utf-8")

# Extraer el SQL real asignado a report_rollups para probar la consulta que usa la ruta.
tree = ast.parse(REPORTS_SOURCE)
route = next(
    node for node in tree.body
    if isinstance(node, ast.FunctionDef) and node.name == "api_reports"
)
rollup_assignment = next(
    node for node in ast.walk(route)
    if isinstance(node, ast.Assign)
    and any(isinstance(target, ast.Name) and target.id == "report_rollups" for target in node.targets)
)
call = rollup_assignment.value
if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "fetchall":
    call = call.func.value
assert isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "execute"
OPTIMIZED_SQL = call.args[0].value
assert "WITH period_sales AS NOT MATERIALIZED" in OPTIMIZED_SQL
assert "item_rollup AS MATERIALIZED" in OPTIMIZED_SQL
assert "product_rollup AS MATERIALIZED" in OPTIMIZED_SQL
assert "ORDER BY section," in OPTIMIZED_SQL
assert "ROW_NUMBER()" not in OPTIMIZED_SQL
assert "top = [{'name': row['name'], 'qty': row['qty'], 'total': row['total']}" in REPORTS_SOURCE
assert "least = [{'name': row['name'], 'qty': row['qty'], 'total': row['total']}" in REPORTS_SOURCE
assert "idx_sale_items_sale_report" in DB_SOURCE
assert "DROP INDEX IF EXISTS idx_sale_items_sale_id" in DB_SOURCE

OLD_TOP = """SELECT si.product_name AS name, SUM(si.quantity) AS qty, SUM(si.line_total) AS total
FROM sale_items si JOIN sales s ON s.id=si.sale_id
WHERE s.created_at >= date(?) AND s.created_at < date(?, '+1 day')
GROUP BY si.product_id, si.product_name ORDER BY qty DESC LIMIT 15"""
OLD_PROFIT = """SELECT COALESCE(SUM(si.line_total - (COALESCE(si.unit_cost_at_sale, p.total_cost, 0) * si.quantity)),0) AS estimated_profit
FROM sale_items si JOIN sales s ON s.id=si.sale_id LEFT JOIN products p ON p.id=si.product_id
WHERE s.created_at >= date(?) AND s.created_at < date(?, '+1 day')"""
OLD_LEAST = """SELECT p.name AS name, COALESCE(sales_by_product.qty, 0) AS qty, COALESCE(sales_by_product.total, 0) AS total
FROM products p LEFT JOIN (
    SELECT si.product_id, SUM(si.quantity) AS qty, SUM(si.line_total) AS total
    FROM sales s JOIN sale_items si ON si.sale_id = s.id
    WHERE s.created_at >= date(?) AND s.created_at < date(?, '+1 day')
    GROUP BY si.product_id
) AS sales_by_product ON sales_by_product.product_id = p.id
ORDER BY qty ASC, p.name ASC LIMIT 15"""

with tempfile.TemporaryDirectory(prefix="pos_report_rollup_v97_") as tmp:
    db = sqlite3.connect(Path(tmp) / "reports.db")
    db.row_factory = sqlite3.Row
    db.executescript("""
        PRAGMA foreign_keys=ON;
        CREATE TABLE products(
            id INTEGER PRIMARY KEY, name TEXT NOT NULL,
            total_cost REAL NOT NULL DEFAULT 0
        );
        CREATE TABLE sales(
            id INTEGER PRIMARY KEY, created_at TEXT NOT NULL,
            total REAL NOT NULL DEFAULT 0
        );
        CREATE TABLE sale_items(
            id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL REFERENCES sales(id),
            product_id INTEGER NOT NULL REFERENCES products(id),
            product_name TEXT NOT NULL, quantity REAL NOT NULL,
            line_total REAL NOT NULL, unit_cost_at_sale REAL
        );
        CREATE INDEX idx_sales_created_at ON sales(created_at);
        CREATE INDEX idx_sale_items_sale_report
            ON sale_items(sale_id, product_id, product_name, quantity, line_total, unit_cost_at_sale);
    """)
    products = [(i, f"Producto {i:05d}", float(50 + i)) for i in range(1, 501)]
    db.executemany("INSERT INTO products(id,name,total_cost) VALUES(?,?,?)", products)
    sales = []
    items = []
    item_id = 1
    for sale_id in range(1, 3001):
        day = (sale_id % 31) + 1
        created = f"2026-10-{day:02d}T12:00:00"
        sales.append((sale_id, created, float(1000 + sale_id)))
        for line in range(3):
            product_id = ((sale_id * 7 + line * 31) % 450) + 1
            # Cambios históricos de nombre: top conserva el agrupamiento por snapshot,
            # mientras que menos vendidos suma por product_id como la ruta anterior.
            product_name = f"Producto {product_id:05d}" if sale_id % 2 else f"Nombre anterior {product_id:05d}"
            quantity = float(((sale_id + line) % 5) + 1)
            line_total = quantity * float(100 + product_id)
            unit_cost = None if sale_id % 7 == 0 else float(30 + product_id)
            items.append((item_id, sale_id, product_id, product_name, quantity, line_total, unit_cost))
            item_id += 1
    db.executemany("INSERT INTO sales(id,created_at,total) VALUES(?,?,?)", sales)
    db.executemany(
        "INSERT INTO sale_items(id,sale_id,product_id,product_name,quantity,line_total,unit_cost_at_sale) VALUES(?,?,?,?,?,?,?)",
        items,
    )
    db.execute("ANALYZE")
    params = ("2026-10-01", "2026-10-31")

    old_top = [tuple(row) for row in db.execute(OLD_TOP, params).fetchall()]
    old_profit = db.execute(OLD_PROFIT, params).fetchone()["estimated_profit"]
    old_least = [tuple(row) for row in db.execute(OLD_LEAST, params).fetchall()]

    optimized_rows = db.execute(OPTIMIZED_SQL, params).fetchall()
    new_top = [(r["name"], r["qty"], r["total"]) for r in optimized_rows if r["kind"] == "top"]
    new_least = [(r["name"], r["qty"], r["total"]) for r in optimized_rows if r["kind"] == "least"]
    new_profit = next(r["estimated_profit"] for r in optimized_rows if r["kind"] == "profit")
    assert new_top == old_top, "Cambió el ranking de productos más vendidos."
    assert new_least == old_least, "Cambió el ranking de productos menos vendidos."
    assert abs(new_profit - old_profit) < 1e-7, "Cambió la ganancia estimada."
    assert len([r for r in optimized_rows if r["kind"] == "top"]) == 15
    assert len([r for r in optimized_rows if r["kind"] == "least"]) == 15
    assert len([r for r in optimized_rows if r["kind"] == "profit"]) == 1

    plan = " | ".join(r[3] for r in db.execute("EXPLAIN QUERY PLAN " + OPTIMIZED_SQL, params))
    assert "idx_sales_created_at" in plan, plan
    assert "COVERING INDEX idx_sale_items_sale_report" in plan, plan

    # La agregación nueva debe seguir devolviendo 15 productos menos vendidos
    # y ganancia cero cuando no hay ventas dentro del rango consultado.
    empty_rows = db.execute(OPTIMIZED_SQL, ("2020-01-01", "2020-01-31")).fetchall()
    assert len([r for r in empty_rows if r["kind"] == "top"]) == 0
    assert len([r for r in empty_rows if r["kind"] == "least"]) == 15
    assert next(r["estimated_profit"] for r in empty_rows if r["kind"] == "profit") == 0

    # Benchmark informativo A/B; no impone umbrales dependientes del hardware.
    def median_ms(sql, count=20):
        for _ in range(3):
            db.execute(sql, params).fetchall()
        samples = []
        for _ in range(count):
            start = time.perf_counter_ns()
            db.execute(sql, params).fetchall()
            samples.append((time.perf_counter_ns() - start) / 1_000_000)
        return statistics.median(samples)

    old_combined_ms = sum(median_ms(sql) for sql in (OLD_TOP, OLD_PROFIT, OLD_LEAST))
    new_combined_ms = median_ms(OPTIMIZED_SQL)
    print(f"Benchmark sintético A/B: 3 consultas anteriores {old_combined_ms:.2f} ms; rollup compartido {new_combined_ms:.2f} ms")
    print("OK: rankings, ganancia histórica, nombres anteriores, rango vacío e índices conservan semántica.")
    db.close()
