"""Regresión 1.0.5.7: cuerpo JSON que no es objeto devuelve 400, no 500.

``/api/login``, ``/api/first-setup`` y ``/api/sales/<id>/ticket-pdf`` leían el
cuerpo sin comprobar que fuera un objeto. Un cuerpo ``[]``, ``"texto"`` o ``5``
llegaba a ``data.get(...)`` y terminaba en 500 con traza. Ahora usan el
decorador ``@require_json_object`` como el resto de los endpoints.

Usa una base temporal; nunca toca datos comerciales.
"""
from pathlib import Path
import os
import sys
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import app.config as config
from app import create_app

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {k: getattr(config, k) for k in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_v1057_regressions_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base / 'instance',
                               BACKUP_DIR=base / 'backups', DATABASE=base / 'instance' / 'pos.db',
                               UPLOAD_DIR=base / 'uploads', TICKET_DIR=base / 'TICKET').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = False
        app.logger.disabled = True
        client = app.test_client()
        assert client.get('/api/products').status_code == 200

        product = client.post('/api/products', json={
            'name': 'P', 'cost_without_tax': 100, 'iva_percent': 21,
            'margin_percent': 30, 'stock': 10,
        }).get_json()
        product_id = product['id']

        endpoints = ['/api/login', '/api/first-setup',
                     f'/api/sales/{product_id}/ticket-pdf']
        for path in endpoints:
            for body in ([], 'texto', 5):
                response = client.post(path, json=body)
                assert response.status_code == 400, (path, body, response.status_code)

        # Un objeto válido sigue funcionando: el login incorrecto da 403, no 400.
        wrong = client.post('/api/login', json={'username': 'admin', 'password': 'mal'})
        assert wrong.status_code == 403, wrong.status_code

        print('OK: cuerpo no-objeto responde 400 en login/first-setup/ticket-pdf')
finally:
    for key, value in saved.items():
        setattr(config, key, value)
