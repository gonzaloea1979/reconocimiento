"""Las bibliotecas de exportación/imagen no deben cargarse durante el arranque."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HEAVY = {'PIL', 'xlrd', 'xlwt', 'reportlab'}
FILES = [ROOT / 'app' / 'route_core.py'] + list((ROOT / 'app' / 'route_modules').glob('*.py')) + list((ROOT / 'app' / 'route_services').glob('*.py'))
violations = []
for path in FILES:
    tree = ast.parse(path.read_text(encoding='utf-8'))
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.split('.')[0] in HEAVY:
                    violations.append((path.name, node.lineno, alias.name))
        elif isinstance(node, ast.ImportFrom):
            if (node.module or '').split('.')[0] in HEAVY:
                violations.append((path.name, node.lineno, node.module))
if violations:
    raise SystemExit(f'ERROR: dependencias pesadas importadas al iniciar: {violations}')

core = (ROOT / 'app' / 'route_services' / 'documents.py').read_text(encoding='utf-8')
assert 'pdfmetrics.stringWidth' in core, 'Las etiquetas deben medir texto sin crear un Canvas temporal'
assert 'tmp = canvas.Canvas(BytesIO())' not in core, 'No crear Canvas temporal por cada etiqueta'
print('OK: PIL, xlrd, xlwt y ReportLab se cargan de forma diferida; medición PDF optimizada')
