"""Pruebas de integración reales con Flask y una base SQLite temporal.

Se ejecuta en el entorno del usuario, donde requirements.txt instala Flask.
No usa ni altera instance/pos.db del negocio.
"""
from __future__ import annotations
import importlib.util
import os
import tempfile
from pathlib import Path
import sys

# Allow direct execution from the tests directory on Windows as well as through the runner.
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

if importlib.util.find_spec("flask") is None:
    print("SKIP: Flask no está instalado en este entorno; ejecutar después de instalar requirements.txt")
    raise SystemExit(77)

from unittest.mock import patch
import app.config as config_module
import app.db as db_module
from app import create_app
from app.db import get_db

with tempfile.TemporaryDirectory(prefix="pos_flask_integration_") as temp:
    base = Path(temp)
    instance = base / "instance"
    backups = base / "backups"
    uploads = base / "uploads"
    tickets = base / "TICKET"
    for directory in (instance, backups, uploads, tickets):
        directory.mkdir(parents=True, exist_ok=True)

    # Redirigir toda persistencia a una carpeta temporal.
    config_module.BASE_DIR = base
    config_module.INSTANCE_DIR = instance
    config_module.BACKUP_DIR = backups
    config_module.DATABASE = instance / "pos.db"
    config_module.UPLOAD_DIR = uploads
    config_module.TICKET_DIR = tickets

    with patch.dict(os.environ, {"POS_SEED_DEMO_PRODUCTS": "0"}):
        app = create_app()
    app.config.update(TESTING=True)
    client = app.test_client()

    # Host no local y mutaciones cross-origin deben rechazarse antes de llegar a la ruta.
    hostile_host = client.get('/api/products', headers={'Host': 'evil.example'})
    assert hostile_host.status_code == 403, f'host externo no rechazado: {hostile_host.status_code}'
    hostile_origin = client.post('/api/cash/open', json={'initial_amount': 100},
                                 headers={'Origin': 'http://evil.example'})
    assert hostile_origin.status_code == 403, f'origen externo no rechazado: {hostile_origin.status_code}'

    # La instalación crea/reutiliza el administrador predeterminado y entra sin contraseña.
    response = client.get("/api/products")
    assert response.status_code == 200, f"el inicio local passwordless debe crear sesión admin, recibido {response.status_code}: {response.get_data(as_text=True)}"
    with client.session_transaction() as sess:
        assert sess.get('logged_in') is True
        assert sess.get('passwordless_admin_login') is True
        assert sess.get('user_role') == 'Administrador'

    # Crear un artículo de prueba directamente en la BD temporal para aislar la prueba.
    with app.app_context():
        db = get_db()
        stamp = "2026-10-28T12:00:00"
        cur = db.execute("""
            INSERT INTO products
              (barcode, name, detail, cost_without_tax, iva_percent, gross_income_percent,
               total_cost, margin_percent, rounding_mode, rounding_multiple, sale_price,
               stock, expiry_date, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, ("TEST-INTEGRATION-001", "Producto Integración", "", 5, 0, 0, 5, 0,
              "none", 1, 10, 5, None, stamp, stamp))
        product_id = cur.lastrowid
        db.commit()

    # Venta real por endpoint: 2 unidades, stock 5 -> 3.
    response = client.post("/api/sales", json={
        "items": [{"product_id": product_id, "quantity": 2}],
        "payment_method": "Efectivo",
        "amount_received": 20,
    })
    assert response.status_code == 200, response.get_data(as_text=True)
    assert response.json.get("ok")
    with app.app_context():
        db = get_db()
        stock = db.execute("SELECT stock FROM products WHERE id=?", (product_id,)).fetchone()[0]
        sale_count = db.execute("SELECT COUNT(*) FROM sales").fetchone()[0]
        assert stock == 3 and sale_count == 1, (stock, sale_count)

    # Venta superior al stock: debe rechazarse sin registrar una segunda venta.
    response = client.post("/api/sales", json={
        "items": [{"product_id": product_id, "quantity": 4}],
        "payment_method": "Efectivo",
        "amount_received": 40,
    })
    assert response.status_code in (400, 409), response.get_data(as_text=True)
    with app.app_context():
        db = get_db()
        assert db.execute("SELECT COUNT(*) FROM sales").fetchone()[0] == 1
        assert db.execute("SELECT stock FROM products WHERE id=?", (product_id,)).fetchone()[0] == 3

    # Venta con el mismo producto en dos líneas: debe descontar ambas cantidades
    # y consultar el producto una sola vez durante la validación inicial.
    original_connect = db_module.connect_database

    def traced_connect_for(collector):
        def traced_connect(*args, **kwargs):
            connection = original_connect(*args, **kwargs)
            connection.set_trace_callback(collector.append)
            return connection
        return traced_connect

    traced_sql = []
    with patch("app.db.connect_database", side_effect=traced_connect_for(traced_sql)):
        response = client.post("/api/sales", json={
            "items": [
                {"product_id": product_id, "quantity": 1},
                {"product_id": product_id, "quantity": 1},
            ],
            "payment_method": "Efectivo",
            "amount_received": 20,
        })
    assert response.status_code == 200, response.get_data(as_text=True)
    product_reads = [
        sql for sql in traced_sql
        if sql.strip().upper().startswith("SELECT * FROM PRODUCTS WHERE ID=")
    ]
    assert len(product_reads) == 1, (
        f"el producto repetido debe consultarse una sola vez; consultas: {product_reads}"
    )
    with app.app_context():
        db = get_db()
        stock = db.execute("SELECT stock FROM products WHERE id=?", (product_id,)).fetchone()[0]
        sale_count = db.execute("SELECT COUNT(*) FROM sales").fetchone()[0]
        assert stock == 1 and sale_count == 2, (stock, sale_count)

    # Payload mal formado debe rechazarse sin crear ventas.
    response = client.post("/api/sales", json=[{"product_id": product_id}])
    assert response.status_code == 400, response.get_data(as_text=True)
    with app.app_context():
        db = get_db()
        assert db.execute("SELECT COUNT(*) FROM sales").fetchone()[0] == 2
        assert db.execute("SELECT stock FROM products WHERE id=?", (product_id,)).fetchone()[0] == 1

    # Compra real por endpoint: stock 1 -> 4. El producto repetido se consulta una vez.
    traced_purchase_sql = []
    with patch("app.db.connect_database", side_effect=traced_connect_for(traced_purchase_sql)):
        response = client.post("/api/purchases", json={
            "supplier_name": "Proveedor de prueba",
            "notes": "Prueba temporal",
            "items": [
                {
                    "product_id": product_id, "quantity": 1, "unit_cost": 5,
                    "cost_without_tax": 5, "iva_percent": 0,
                    "gross_income_percent": 0, "margin_percent": 0,
                    "total_cost": 5, "sale_price": 10,
                },
                {
                    "product_id": product_id, "quantity": 2, "unit_cost": 5,
                    "cost_without_tax": 5, "iva_percent": 0,
                    "gross_income_percent": 0, "margin_percent": 0,
                    "total_cost": 5, "sale_price": 10,
                },
            ],
        })
    assert response.status_code == 200, response.get_data(as_text=True)
    purchase_product_reads = [
        sql for sql in traced_purchase_sql
        if sql.strip().upper().startswith("SELECT * FROM PRODUCTS WHERE ID=")
    ]
    assert len(purchase_product_reads) == 1, (
        f"el producto repetido en compra debe consultarse una sola vez; consultas: {purchase_product_reads}"
    )
    with app.app_context():
        db = get_db()
        stock = db.execute("SELECT stock FROM products WHERE id=?", (product_id,)).fetchone()[0]
        assert stock == 4, stock
        assert db.execute("SELECT COUNT(*) FROM purchases").fetchone()[0] == 1

    # Caja real: apertura + ingreso + cierre con sesión administrativa autenticada.
    response = client.post("/api/cash/open", json={"initial_amount": 100, "notes": "Prueba"})
    assert response.status_code == 200, response.get_data(as_text=True)
    response = client.post("/api/cash/movement", json={
        "movement_type": "Ingreso", "amount": 50, "description": "Prueba de integración"
    })
    assert response.status_code == 200, response.get_data(as_text=True)
    response = client.get("/api/cash/status")
    assert response.status_code == 200, response.get_data(as_text=True)
    expected = response.json.get("session", {}).get("expected_amount")
    assert expected == 150, f"saldo esperado incorrecto: {expected}"
    response = client.post("/api/cash/close", json={"closing_amount": 150, "notes": "Prueba"})
    assert response.status_code == 200, response.get_data(as_text=True)
    assert response.json.get("difference") == 0

    # Una sesión no autenticada no puede solicitar apagar la computadora.
    with client.session_transaction() as sess:
        sess.clear()
    response = client.post("/api/shutdown", json={"shutdown_pc": True})
    assert response.status_code == 401, response.get_data(as_text=True)

print("OK: integración Flask real — inicio passwordless como administrador, venta, rechazo por stock, compra, caja y acceso a apagado")
