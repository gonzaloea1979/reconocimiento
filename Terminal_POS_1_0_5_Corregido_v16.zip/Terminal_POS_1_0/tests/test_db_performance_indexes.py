"""Comprueba que los índices nuevos cubran las consultas frecuentes del POS."""
import sqlite3
import tempfile
from pathlib import Path

INDEXES = [
    'CREATE INDEX idx_products_name ON products(name)',
    'CREATE INDEX idx_products_expiry_date ON products(date(expiry_date))',
    'CREATE INDEX idx_clients_name ON clients(name)',
    'CREATE INDEX idx_clients_balance_desc ON clients(balance DESC)',
    'CREATE INDEX idx_suppliers_name ON suppliers(name)',
    'CREATE INDEX idx_cash_sessions_status_id ON cash_sessions(status, id DESC)',
    'CREATE INDEX idx_users_active_role_lower_username ON users(is_active, role, LOWER(username))',
    'CREATE INDEX idx_cash_movements_session_id_id ON cash_movements(cash_session_id, id DESC)',
    'CREATE INDEX idx_purchase_items_purchase_id_id ON purchase_items(purchase_id, id ASC)',
    'CREATE INDEX idx_client_movements_client_id_id ON client_movements(client_id, id DESC)',
    'CREATE INDEX idx_product_movements_product_id_id ON product_movements(product_id, id DESC)',
    'CREATE INDEX idx_products_low_stock_priority ON products((stock-min_stock), name) WHERE min_stock > 0 AND stock <= min_stock',
]

with tempfile.TemporaryDirectory(prefix='pos_perf_indexes_') as tmp:
    db = sqlite3.connect(Path(tmp) / 'indexes.db')
    db.executescript('''
        CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT, expiry_date TEXT, barcode TEXT, stock REAL NOT NULL DEFAULT 0, min_stock REAL NOT NULL DEFAULT 0);
        CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT, balance REAL);
        CREATE TABLE suppliers(id INTEGER PRIMARY KEY, name TEXT);
        CREATE TABLE cash_sessions(id INTEGER PRIMARY KEY, status TEXT);
        CREATE TABLE users(id INTEGER PRIMARY KEY, is_active INTEGER, role TEXT, username TEXT);
        CREATE TABLE cash_movements(id INTEGER PRIMARY KEY, cash_session_id INTEGER);
        CREATE TABLE purchase_items(id INTEGER PRIMARY KEY, purchase_id INTEGER);
        CREATE TABLE client_movements(id INTEGER PRIMARY KEY, client_id INTEGER);
        CREATE TABLE product_movements(id INTEGER PRIMARY KEY, product_id INTEGER);
    ''')
    for statement in INDEXES:
        db.execute(statement)

    db.executemany('INSERT INTO products VALUES (?,?,?,?,?,?)', [
        (i, f'Producto {i:05d}', f'2026-{(i % 12) + 1:02d}-15', str(i),
         float(i % 20), 10.0 if i % 3 == 0 else 0.0) for i in range(1, 5001)
    ])
    db.executemany('INSERT INTO clients VALUES (?,?,?)', [
        (i, f'Cliente {i:05d}', float(i)) for i in range(1, 3001)
    ])
    db.executemany('INSERT INTO suppliers VALUES (?,?)', [(i, f'Proveedor {i:05d}') for i in range(1, 1001)])
    db.executemany('INSERT INTO cash_sessions VALUES (?,?)', [(i, 'abierta' if i == 500 else 'cerrada') for i in range(1, 501)])
    db.executemany('INSERT INTO users VALUES (?,?,?,?)', [(i, 1, 'Administrador', f'user{i}') for i in range(1, 101)])
    db.executemany('INSERT INTO cash_movements VALUES (?,?)', [(i, (i % 10) + 1) for i in range(1, 5001)])
    db.executemany('INSERT INTO purchase_items VALUES (?,?)', [(i, (i % 100) + 1) for i in range(1, 5001)])
    db.executemany('INSERT INTO client_movements VALUES (?,?)', [(i, (i % 100) + 1) for i in range(1, 5001)])
    db.executemany('INSERT INTO product_movements VALUES (?,?)', [(i, (i % 5000) + 1) for i in range(1, 5001)])
    db.execute('ANALYZE')

    checks = {
        'productos por nombre': ("SELECT * FROM products ORDER BY name ASC LIMIT 200", (), 'idx_products_name'),
        'productos por vencimiento': ("SELECT id FROM products WHERE date(expiry_date)>=date(?) AND date(expiry_date)<=date(?) ORDER BY date(expiry_date) LIMIT 50", ('2026-01-01', '2026-12-31'), 'idx_products_expiry_date'),
        'clientes por nombre': ("SELECT * FROM clients ORDER BY name ASC LIMIT 300", (), 'idx_clients_name'),
        'deudores por saldo': ("SELECT * FROM clients WHERE balance>0 ORDER BY balance DESC LIMIT 20", (), 'idx_clients_balance_desc'),
        'proveedores por nombre': ("SELECT * FROM suppliers ORDER BY name ASC LIMIT 300", (), 'idx_suppliers_name'),
        'caja abierta': ("SELECT * FROM cash_sessions WHERE status='abierta' ORDER BY id DESC LIMIT 1", (), 'idx_cash_sessions_status_id'),
        'usuario administrador': ("SELECT role FROM users WHERE is_active=1 AND role='Administrador' AND LOWER(username)=LOWER(?) LIMIT 1", ('user1',), 'idx_users_active_role_lower_username'),
        'movimientos de caja': ("SELECT * FROM cash_movements WHERE cash_session_id=? ORDER BY id DESC LIMIT 200", (1,), 'idx_cash_movements_session_id_id'),
        'detalles de compra': ("SELECT * FROM purchase_items WHERE purchase_id=? ORDER BY id ASC", (1,), 'idx_purchase_items_purchase_id_id'),
        'movimientos de cliente': ("SELECT * FROM client_movements WHERE client_id=? ORDER BY id DESC LIMIT 200", (1,), 'idx_client_movements_client_id_id'),
        'movimientos de producto': ("SELECT * FROM product_movements WHERE product_id=? ORDER BY id DESC LIMIT 300", (1,), 'idx_product_movements_product_id_id'),
        'alertas de stock': ("SELECT * FROM products WHERE min_stock > 0 AND stock <= min_stock ORDER BY (stock-min_stock) ASC, name ASC LIMIT 300", (), 'idx_products_low_stock_priority'),
    }
    for label, (sql, params, expected_index) in checks.items():
        plan = ' '.join(str(row) for row in db.execute('EXPLAIN QUERY PLAN ' + sql, params).fetchall())
        if expected_index not in plan:
            raise SystemExit(f'ERROR: {label} no usa {expected_index}: {plan}')
    print(f'OK: {len(checks)} consultas frecuentes aprovechan sus índices específicos con datos de prueba')
    db.close()
