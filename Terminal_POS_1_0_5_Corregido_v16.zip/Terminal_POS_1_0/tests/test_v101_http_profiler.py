"""V101 perfila HTTP y valida las optimizaciones acotadas a 1-2 usuarios."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "prueba_carga_v101.py").read_text(encoding="utf-8")
tree = ast.parse(source)

assert 'prueba_carga_v101.txt' in source
assert 'TemporaryDirectory(prefix="terminal_pos_v101_")' in source
assert 'No se abre ni modifica instance/pos.db' in source
assert 'def install_http_profiler(app)' in source
assert 'class TimedConnection' in source
assert 'class TimedCursor' in source
assert 'route_core.get_db = timed_get_db' in source
assert 'module.get_db = timed_get_db' in source
assert 'g._v101_sql_count' in source
assert 'g._v101_sql_ns' in source
assert 'non_sql_ms' in source
assert 'sql_count_avg' in source
assert 'converter_ms' in source and 'converter_counts' in source
assert 'product_to_dict' in source and 'client_to_dict' in source
assert 'default=50' in source
assert 'for workers in (1, 2):' in source
assert 'for workers in (1, 2, 4, 8):' not in source
assert 'máximo 2 usuarios' in source
assert '"--rounds debe estar entre 10 y 200"' in source

# The report may contain metrics and SQL time, but never statement text or bind values.
assert 'lines.append("SQL:' not in source

assert 'cache_size' in (ROOT / "app" / "db.py").read_text(encoding="utf-8")
assert 'PRAGMA cache_size' in source and 'PRAGMA synchronous' in source
assert 'def product_to_dict(row):' in (ROOT / "app" / "route_core.py").read_text(encoding="utf-8")

print("OK: perfilado HTTP/SQL V101, 50 rondas, concurrencia 1-2 y optimizaciones acotadas.")
