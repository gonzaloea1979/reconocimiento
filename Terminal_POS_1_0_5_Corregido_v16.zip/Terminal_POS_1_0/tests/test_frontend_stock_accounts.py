"""Ejecuta el JavaScript real de stock y saldos con DOM controlado."""
from pathlib import Path
import shutil
import subprocess

node = shutil.which('node')
if not node:
    print('SKIP: Node.js requerido para comprobar formularios de stock y saldos')
    raise SystemExit(77)
root = Path(__file__).resolve().parents[1]
result = subprocess.run([node, str(root / 'tests/stock_account_frontend_checks.js'), str(root)],
                        capture_output=True, text=True, timeout=15)
assert result.returncode == 0, result.stdout + result.stderr
print(result.stdout.strip())
