"""Regresiones 1.0.5.2: validación de productos, comodines LIKE y fechas de reportes.

Cubre tres defectos confirmados:
  1. Crear/editar productos aceptaba costos, stock, margen y porcentajes
     inválidos (un costo negativo generaba un precio de venta negativo).
  2. La búsqueda usaba LIKE sin escapar, así que '%' y '_' del término buscado
     actuaban como comodines ('%rroz' encontraba "Arroz").
  3. /api/reports y sus exportaciones aceptaban fechas malformadas y mostraban
     un rango válido con 0 ventas.

Usa una base temporal; nunca toca datos comerciales.
"""
from pathlib import Path
import os
import sys
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import app.config as config
from app import create_app
from app.route_core import like_contains, like_prefix, escape_like_value

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {k: getattr(config, k) for k in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_v1052_regressions_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base / 'instance',
                               BACKUP_DIR=base / 'backups', DATABASE=base / 'instance' / 'pos.db',
                               UPLOAD_DIR=base / 'uploads', TICKET_DIR=base / 'TICKET').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = True
        client = app.test_client()
        assert client.get('/api/products').status_code == 200

        # --- 1. Validación de productos ---------------------------------------
        invalid_products = [
            ({'name': 'CostoNeg', 'cost_without_tax': -100, 'margin_percent': 50, 'stock': 5}, 'costo negativo'),
            ({'name': 'StockNeg', 'cost_without_tax': 10, 'stock': -5}, 'stock negativo'),
            ({'name': 'MinNeg', 'cost_without_tax': 10, 'min_stock': -5, 'stock': 5}, 'stock mínimo negativo'),
            ({'name': 'MargenNeg', 'cost_without_tax': 10, 'margin_percent': -50, 'stock': 5}, 'margen negativo'),
            ({'name': 'IvaAlto', 'cost_without_tax': 10, 'iva_percent': 500, 'stock': 5}, 'IVA mayor a 100'),
            ({'name': 'IvaNeg', 'cost_without_tax': 10, 'iva_percent': -5, 'stock': 5}, 'IVA negativo'),
            ({'name': 'GrossAlto', 'cost_without_tax': 10, 'gross_income_percent': 150, 'stock': 5}, 'ingresos brutos mayor a 100'),
        ]
        for payload, label in invalid_products:
            response = client.post('/api/products', json=payload)
            assert response.status_code == 400, f'{label} debe rechazarse: {response.status_code}'

        # Los límites válidos y los valores normales se siguen aceptando.
        for payload in (
            {'name': 'Iva100', 'cost_without_tax': 10, 'iva_percent': 100, 'stock': 5},
            {'name': 'Normal', 'cost_without_tax': 10, 'iva_percent': 21, 'gross_income_percent': 3, 'margin_percent': 30, 'stock': 5},
            {'name': 'StockCero', 'cost_without_tax': 10, 'stock': 0},
        ):
            assert client.post('/api/products', json=payload).status_code == 201, payload['name']

        # Un costo negativo ya no produce un precio de venta negativo.
        ok = client.post('/api/products', json={'name': 'PrecioOk', 'cost_without_tax': 100, 'margin_percent': 50, 'stock': 5})
        assert ok.status_code == 201
        assert ok.json['sale_price'] > 0

        # La edición también valida.
        pid = ok.json['id']
        assert client.put(f'/api/products/{pid}', json={'name': 'PrecioOk', 'cost_without_tax': -1}).status_code == 400

        # --- 2. Comodines LIKE escapados --------------------------------------
        assert escape_like_value('50%') == '50\\%'
        assert escape_like_value('a_b') == 'a\\_b'
        assert escape_like_value('c\\d') == 'c\\\\d'
        assert like_contains('x') == '%x%'
        assert like_prefix('x') == 'x%'

        client.post('/api/products', json={'name': 'Arroz', 'barcode': 'AAA1', 'cost_without_tax': 10, 'stock': 5})
        client.post('/api/products', json={'name': 'Descuento 50%', 'barcode': 'BBB2', 'cost_without_tax': 10, 'stock': 5})
        client.post('/api/clients', json={'name': 'Juan_Perez'})
        client.post('/api/clients', json={'name': 'Maria Lopez'})

        def names(url):
            return sorted(item.get('name') for item in client.get(url).json)

        # Los comodines ya no se interpretan: '%rroz' y '_' no coinciden con todo.
        assert names('/api/products?q=%25rroz') == [], 'El % del término no debe actuar como comodín'
        assert names('/api/products?q=_') == [], 'El _ no debe coincidir con cualquier carácter'
        assert names('/api/products?q=Arroz') == ['Arroz']
        # Un '%' literal sí encuentra el producto que lo contiene.
        assert names('/api/products?q=50%25') == ['Descuento 50%']
        assert names('/api/clients?q=J_n') == [], 'El _ en clientes tampoco debe ser comodín'
        assert names('/api/clients?q=Lopez') == ['Maria Lopez']
        # product-lookup también escapa.
        assert client.get('/api/product-lookup?q=%25rroz').json == []
        assert [p['name'] for p in client.get('/api/product-lookup?q=Arroz').json] == ['Arroz']

        # --- 3. Fechas de reportes --------------------------------------------
        for query in ('from=xx&to=yy', 'from=2026-13-45&to=abc', 'from=2026-01-01&to=zz'):
            response = client.get(f'/api/reports?{query}')
            assert response.status_code == 400, f'reports?{query} debe dar 400: {response.status_code}'

        # Rango invertido -> 400.
        assert client.get('/api/reports?from=2026-12-31&to=2026-01-01').status_code == 400
        # Rango válido y valores por defecto -> 200.
        assert client.get('/api/reports?from=2026-01-01&to=2026-12-31').status_code == 200
        assert client.get('/api/reports').status_code == 200
        assert client.get('/api/reports?from=2026-01-01').status_code == 200

        # Las exportaciones comparten la validación.
        assert client.get('/api/reports/export?from=xx&to=yy').status_code == 400
        assert client.get('/api/reports/export?from=2026-12-31&to=2026-01-01').status_code == 400
        assert client.get('/api/reports/export?from=2026-01-01&to=2026-01-31').status_code == 200
        assert client.get('/api/reports/export-pdf?from=xx&to=yy').status_code == 400
        assert client.get('/api/reports/export-pdf?from=2026-01-01&to=2026-01-31').status_code == 200

        print('OK: validación de productos, comodines LIKE y fechas de reportes')
finally:
    for key, value in saved.items():
        setattr(config, key, value)
