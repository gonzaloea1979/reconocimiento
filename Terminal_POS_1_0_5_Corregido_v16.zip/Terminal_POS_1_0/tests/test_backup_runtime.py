"""Ejercita backup_database real de app/db.py usando una base temporal.

No importa Flask ni toca la base de datos del negocio. Solo se sustituye el
proxy current_app/g que db.py necesita para poder probar el mecanismo SQLite.
"""
from __future__ import annotations
import importlib.util
import sqlite3
import sys
import tempfile
import types
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB_SOURCE = ROOT / "app" / "db.py"

class FakeCurrentApp:
    config = {}

fake_flask = types.ModuleType("flask")
fake_flask.current_app = FakeCurrentApp()
fake_flask.g = types.SimpleNamespace()
old_flask = sys.modules.get("flask")
sys.modules["flask"] = fake_flask
try:
    spec = importlib.util.spec_from_file_location("_pos_db_backup_runtime_test", DB_SOURCE)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
finally:
    if old_flask is None:
        sys.modules.pop("flask", None)
    else:
        sys.modules["flask"] = old_flask

with tempfile.TemporaryDirectory(prefix="pos_backup_runtime_") as temp:
    base = Path(temp)
    source_path = base / "source.db"
    backup_dir = base / "backups"
    backup_dir.mkdir()
    with closing(sqlite3.connect(source_path)) as conn:
        conn.executescript("""
            PRAGMA foreign_keys=ON;
            CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
            CREATE TABLE sales(id INTEGER PRIMARY KEY, total REAL NOT NULL);
            INSERT INTO products VALUES (1, 'Temporal');
            INSERT INTO sales VALUES (1, 123.45);
        """)
        conn.commit()

    fake_flask.current_app.config = {"DATABASE": source_path, "BACKUP_DIR": backup_dir}
    first = module.backup_database()
    second = module.backup_database()
    assert first and first.exists(), "No se creó el primer respaldo"
    assert second and second.exists(), "No se creó el segundo respaldo"
    assert first != second, "Los respaldos consecutivos deben tener nombres distintos"
    assert not list(backup_dir.glob(".pos_backup_*.tmp")), "Quedaron temporales sin limpiar"
    for path in (first, second):
        with closing(sqlite3.connect(path)) as conn:
            assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            assert conn.execute("SELECT name FROM products WHERE id=1").fetchone()[0] == "Temporal"
            assert conn.execute("SELECT total FROM sales WHERE id=1").fetchone()[0] == 123.45
    with closing(sqlite3.connect(source_path)) as conn:
        assert conn.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 1
        assert conn.execute("SELECT COUNT(*) FROM sales").fetchone()[0] == 1

print("OK: backup_database real creó dos respaldos válidos, nombres únicos, sin temporales y sin alterar el origen")
