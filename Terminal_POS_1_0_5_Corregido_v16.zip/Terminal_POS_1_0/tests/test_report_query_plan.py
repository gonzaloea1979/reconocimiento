"""Comprueba el rango inclusivo y que SQLite use índices para el reporte."""
import sqlite3
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory(prefix='pos_query_plan_') as tmp:
    db = sqlite3.connect(Path(tmp) / 'test.db')
    db.executescript('''
        CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
        CREATE TABLE sales(id INTEGER PRIMARY KEY, created_at TEXT NOT NULL, total REAL NOT NULL);
        CREATE TABLE sale_items(id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL, product_id INTEGER NOT NULL, product_name TEXT NOT NULL DEFAULT '', quantity REAL NOT NULL, line_total REAL NOT NULL, unit_cost_at_sale REAL);
        CREATE INDEX idx_sales_created_at ON sales(created_at);
        CREATE INDEX idx_sale_items_sale_report ON sale_items(sale_id, product_id, product_name, quantity, line_total, unit_cost_at_sale);
        CREATE INDEX idx_sale_items_product_rollup ON sale_items(product_id, product_name, quantity, line_total);
    ''')
    db.executemany('INSERT INTO products(id,name) VALUES (?,?)', [(1,'A'),(2,'B')])
    db.executemany('INSERT INTO sales(id,created_at,total) VALUES (?,?,?)', [(d,f'2026-10-{((d - 1) % 28) + 1:02d}T{(d % 24):02d}:00:00',10) for d in range(1,10001)])
    db.executemany('INSERT INTO sale_items(sale_id,product_id,quantity,line_total) VALUES (?,?,?,?)', [(d,1,1,10) for d in range(1,10001)])
    plan_rows = db.execute("EXPLAIN QUERY PLAN SELECT SUM(total) FROM sales WHERE created_at >= date(?) AND created_at < date(?, '+1 day')", ('2026-10-01','2026-10-28')).fetchall()
    plan = ' '.join(str(row) for row in plan_rows)
    if 'idx_sales_created_at' not in plan:
        raise SystemExit(f'ERROR: el filtro de fechas no usa el índice: {plan}')
    total = db.execute("SELECT SUM(total) FROM sales WHERE created_at >= date(?) AND created_at < date(?, '+1 day')", ('2026-10-01','2026-10-28')).fetchone()[0]
    if total != 100000:
        raise SystemExit(f'ERROR: rango de fechas incorrecto, total={total}')
    agg_sql = '''SELECT p.name, COALESCE(a.qty,0), COALESCE(a.total,0)
        FROM products p LEFT JOIN (
          SELECT si.product_id, SUM(si.quantity) qty, SUM(si.line_total) total
          FROM sales s JOIN sale_items si ON si.sale_id=s.id
          WHERE s.created_at >= date(?) AND s.created_at < date(?, '+1 day')
          GROUP BY si.product_id
        ) a ON a.product_id=p.id ORDER BY COALESCE(a.qty,0), p.name LIMIT 15'''
    agg_plan = ' '.join(str(row) for row in db.execute('EXPLAIN QUERY PLAN '+agg_sql, ('2026-10-01','2026-10-28')).fetchall())
    if 'idx_sales_created_at' not in agg_plan or 'idx_sale_items_sale_report' not in agg_plan:
        raise SystemExit(f'ERROR: el reporte de productos no aprovecha los índices esperados: {agg_plan}')
    rows = db.execute(agg_sql, ('2026-10-01','2026-10-28')).fetchall()
    if rows[0][0] != 'B' or rows[0][1] != 0 or rows[1][0] != 'A' or rows[1][1] != 10000:
        raise SystemExit(f'ERROR: resultados del reporte inesperados: {rows}')
    print('OK: rango inclusivo e índices verificados con 10.000 ventas y 10.000 detalles')
    db.close()
