"""Verifica que el banco V103 mida las rutas compactas y solo 1-2 usuarios."""
from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "prueba_carga_v103.py"
spec = importlib.util.spec_from_file_location("pos_load_v103", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)
source = SCRIPT.read_text(encoding="utf-8")
assert "prueba_carga_v103.txt" in source
assert 'TemporaryDirectory(prefix="terminal_pos_v103_")' in source
assert 'for workers in (1, 2):' in source
assert 'for workers in (1, 2, 4, 8):' not in source
assert '"/api/stock/alerts?compact=1"' in source
assert '"/api/products?compact=1"' in source
assert module.format_cache_size(-8192, 4096) == "-8192 KiB (8.0 MiB)"
assert module.format_cache_size(8192, 4096) == "8192 páginas (32.0 MiB)"
print("OK: banco V103 aislado, compact endpoints medidos y concurrencia limitada a 1-2 usuarios.")
