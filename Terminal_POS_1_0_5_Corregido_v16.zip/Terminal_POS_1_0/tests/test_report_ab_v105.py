"""Las variantes de reportes se miden solo sobre la base temporal del banco."""
import sys
import tempfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from diagnostico_reportes_v105 import current_sql, variants, evaluate_variants
from prueba_carga_v105 import create_fallback_database, seed_database
sql=current_sql()
vs=variants(sql)
assert len(vs)==5
assert all('SELECT kind, product_id, name' in q for q in vs.values())
with tempfile.TemporaryDirectory(prefix='test_pos_v105_') as d:
    db=Path(d)/'solo_sintetica.db'
    create_fallback_database(db)
    seed_database(db)
    output=evaluate_variants(db,rounds=3)
    assert any('Equivalencia: OK' in line for line in output)
    assert any('original_V104' in line for line in output)
    assert any('V106 utiliza' in line for line in output)
print('OK: variantes SQL equivalentes, casos NULL, rangos y período vacío; datos temporales.')
