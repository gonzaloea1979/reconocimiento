"""Comprueba política/documentación de distribución sin interferir con datos del usuario."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
manifest_path = ROOT / 'DISTRIBUTION_MANIFEST.txt'
if not manifest_path.exists():
    raise SystemExit('ERROR: falta el manifiesto del paquete')
manifest = manifest_path.read_text(encoding='utf-8')
for phrase in ('instance/pos.db', 'backups/*.db', '.venv/', 'app/static/uploads/', 'POS_SEED_DEMO_PRODUCTS=1'):
    if phrase not in manifest:
        raise SystemExit(f'ERROR: el manifiesto no documenta {phrase}')

db_source = (ROOT / 'app' / 'db.py').read_text(encoding='utf-8')
assert "POS_SEED_DEMO_PRODUCTS" in db_source
assert "not in ('1', 'true', 'yes', 'si', 'sí')" in db_source

doc = (ROOT / 'INSTALAR_Y_ACTUALIZAR_SEGURO.txt').read_text(encoding='utf-8')
assert 'Nunca reemplaces tu pos.db real' in doc
assert 'copia externa' in doc.lower()

print('OK: manifiesto, demo opt-in y guía de actualización presentes; no inspecciona ni altera datos reales')

# La compilación no debe empaquetar automáticamente datos reales ni uploads.
build_script = (ROOT / 'compilar_exe.bat').read_text(encoding='utf-8')
assert 'if exist "instance\\pos.db" copy' not in build_script.lower()
assert '/XD "%CD%\\app\\static\\uploads"' in build_script
transfer_doc = ROOT / 'MIGRAR_DATOS_EXE.txt'
assert transfer_doc.exists(), 'falta guía para migrar datos intencionalmente al EXE'
print('OK: compilación EXE excluye base de datos y uploads automáticamente')

# La guía de migración debe viajar junto al EXE compilado.
assert 'MIGRAR_DATOS_EXE.txt' in build_script
integration = (ROOT / 'tests' / 'test_flask_integration.py').read_text(encoding='utf-8')
assert 'Venta con el mismo producto en dos líneas' in integration
assert 'Payload mal formado debe rechazarse' in integration
print('OK: integración cubre producto repetido y payload inválido; guía de migración se distribuye con EXE')
