"""Test no destructivo del auditor sobre datos simulados."""
import hashlib
from pathlib import Path
import sqlite3
from contextlib import closing
import subprocess
import sys
import tempfile
ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix='pos_copia_audit_') as folder:
    file = Path(folder) / 'COPIA_POS.db'
    with closing(sqlite3.connect(file)) as con:
        con.executescript('''CREATE TABLE sales (id INTEGER PRIMARY KEY,total REAL);
            CREATE TABLE sale_items(id INTEGER PRIMARY KEY,sale_id INTEGER,line_total REAL);
            CREATE TABLE purchases (id INTEGER PRIMARY KEY,total REAL);
            CREATE TABLE purchase_items(id INTEGER PRIMARY KEY,purchase_id INTEGER,line_total REAL);
            INSERT INTO sales VALUES(1,5.35);
            INSERT INTO sale_items VALUES(1,1,2.675);
            INSERT INTO sale_items VALUES(2,1,2.675);
            INSERT INTO purchases VALUES(1,10);
            INSERT INTO purchase_items VALUES(1,1,10);''')
    before = hashlib.sha256(file.read_bytes()).digest()
    result = subprocess.run([sys.executable, str(ROOT/'tests'/'auditar_importes_existentes.py'), str(file)], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    assert 'Diferencias: 1' in result.stdout and 'Diferencias: 0' in result.stdout, result.stdout
    assert hashlib.sha256(file.read_bytes()).digest() == before
print('OK: auditoría detecta diferencia de un centavo y no modifica la copia')

# NULL en una línea debe marcarse como importe inválido; no como operación sin detalles.
with tempfile.TemporaryDirectory(prefix='pos_audit_null_') as folder:
    file = Path(folder) / 'COPIA_POS.db'
    with closing(sqlite3.connect(file)) as con:
        con.executescript('''CREATE TABLE sales (id INTEGER PRIMARY KEY,total REAL);
            CREATE TABLE sale_items(id INTEGER PRIMARY KEY,sale_id INTEGER,line_total REAL);
            CREATE TABLE purchases (id INTEGER PRIMARY KEY,total REAL);
            CREATE TABLE purchase_items(id INTEGER PRIMARY KEY,purchase_id INTEGER,line_total REAL);
            INSERT INTO sales VALUES(1,10);
            INSERT INTO sale_items VALUES(1,1,NULL);''')
    before = hashlib.sha256(file.read_bytes()).digest()
    result = subprocess.run([sys.executable, str(ROOT/'tests'/'auditar_importes_existentes.py'), str(file)], capture_output=True, text=True)
    assert result.returncode == 0, result.stdout + result.stderr
    assert 'Importes inválidos: 1' in result.stdout, result.stdout
    assert hashlib.sha256(file.read_bytes()).digest() == before

# No informar éxito si se usa un archivo SQLite ajeno al esquema del POS.
with tempfile.TemporaryDirectory(prefix='pos_audit_schema_') as folder:
    file = Path(folder) / 'COPIA_POS.db'
    with closing(sqlite3.connect(file)) as con:
        con.execute('CREATE TABLE unrelated (id INTEGER)')
    result = subprocess.run([sys.executable, str(ROOT/'tests'/'auditar_importes_existentes.py'), str(file)], capture_output=True, text=True)
    assert result.returncode == 3, result.stdout + result.stderr
    assert 'no se pudo analizar ventas ni compras' in result.stdout, result.stdout
print('OK: NULL y esquema incompatible se detectan de forma controlada')
