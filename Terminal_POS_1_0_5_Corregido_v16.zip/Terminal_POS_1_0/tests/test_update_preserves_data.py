"""Ensayo de actualización sobre copia, sin alterar instalación ni datos originales."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
import app.config as config
from app import create_app
from app.db import get_db, get_settings, public_settings

# En la validación de entrega se proporciona el código REAL 1.0.4. Sin esa
# variable, la suite verifica el mismo contrato con una instalación de prueba.
old_source=Path(os.environ.get('POS_PREVIOUS_SOURCE',str(ROOT))).resolve()
seed=r'''
from pathlib import Path
import json,os,sys
root=Path(sys.argv[1]);base=Path(sys.argv[2]);sys.path.insert(0,str(root))
import app.config as config
from app import create_app
from app.db import get_db,update_settings,get_settings,public_settings
from PIL import Image
for k,v in dict(BASE_DIR=base,INSTANCE_DIR=base/'instance',BACKUP_DIR=base/'backups',DATABASE=base/'instance'/'pos.db',UPLOAD_DIR=base/'app'/'static'/'uploads',TICKET_DIR=base/'TICKET').items():setattr(config,k,v)
os.environ['POS_SEED_DEMO_PRODUCTS']='0'
app=create_app();app.config['TESTING']=True;client=app.test_client();assert client.get('/api/products').status_code==200
logo=base/'app/static/uploads/logo_prueba.png';Image.new('RGB',(4,4),'red').save(logo)
(base/'TICKET'/'conservar.pdf').write_bytes(b'%PDF-ficticio conservar sin cambiar')
with app.app_context():update_settings({'business_name':'Negocio ficticio de prueba','business_phone':'Telefono ficticio','logo_path':'uploads/logo_prueba.png','stock_control_enabled':'1'})
product=client.post('/api/products',json={'barcode':'UPGRADE-1','name':'Producto prueba','cost_without_tax':10,'stock':10});assert product.status_code==201
pid=product.json['id'];cid=client.post('/api/clients',json={'name':'Cliente prueba','balance':0}).json['id']
assert client.post('/api/cash/open',json={'initial_amount':100}).status_code==200
payload={'items':[{'product_id':pid,'quantity':2}],'client_id':cid,'payment_method':'Cuenta corriente'}
sale=client.post('/api/sales',json=payload,headers={'Idempotency-Key':'upgrade-sale-existing'});assert sale.status_code==200
assert client.post(f'/api/clients/{cid}/payment',json={'amount':5}).status_code==200
backup=client.post('/api/backup/create',json={});assert backup.status_code==200,backup.json
tables=('products','sales','sale_items','clients','client_movements','cash_sessions','cash_movements','operation_receipts')
with app.app_context():
 expected={t:[list(row) for row in get_db().execute(f'SELECT * FROM {t} ORDER BY id' if t!='operation_receipts' else 'SELECT * FROM operation_receipts ORDER BY scope,request_key')] for t in tables}
 settings=public_settings(get_settings())
print(json.dumps({'version':(root/'VERSION.txt').read_text().strip(),'backup':backup.json['path'],'expected':expected,'settings':settings,'sale':sale.json,'payload':payload,'pid':pid,'cid':cid}))
'''
keys=('BASE_DIR','INSTANCE_DIR','BACKUP_DIR','DATABASE','UPLOAD_DIR','TICKET_DIR')
saved={k:getattr(config,k) for k in keys}
try:
 with tempfile.TemporaryDirectory(prefix='pos_update_rehearsal_') as tmp:
    base=Path(tmp);old=base/"Instalacion anterior con espacios";old.mkdir()
    process=subprocess.run([sys.executable,'-c',seed,str(old_source),str(old)],capture_output=True,text=True,timeout=30)
    assert process.returncode==0,process.stdout+process.stderr
    record=json.loads(process.stdout)
    hashes={p.relative_to(old):hashlib.sha256(p.read_bytes()).hexdigest() for p in old.rglob('*') if p.is_file()}
    new=base/"Instalacion nueva con espacios";(new/'instance').mkdir(parents=True)
    shutil.copyfile(record['backup'],new/'instance'/'pos.db')
    shutil.copyfile(old/'instance'/'.session_key',new/'instance'/'.session_key')
    shutil.copytree(old/'app/static/uploads',new/'app/static/uploads')
    shutil.copytree(old/'TICKET',new/'TICKET')
    for k,v in dict(BASE_DIR=new,INSTANCE_DIR=new/'instance',BACKUP_DIR=new/'backups',DATABASE=new/'instance'/'pos.db',UPLOAD_DIR=new/'app/static/uploads',TICKET_DIR=new/'TICKET').items():setattr(config,k,v)
    with patch.dict(os.environ,{'POS_SEED_DEMO_PRODUCTS':'0'}):app=create_app()
    app.config['TESTING']=True;app.static_folder=str(new/'app/static')
    client=app.test_client();assert client.get('/api/products').status_code==200
    with app.app_context():
        for table,expected in record['expected'].items():
            sql=f'SELECT * FROM {table} ORDER BY id' if table!='operation_receipts' else 'SELECT * FROM operation_receipts ORDER BY scope,request_key'
            assert [list(row) for row in get_db().execute(sql)]==expected,table
        assert public_settings(get_settings())==record['settings']
        assert get_db().execute('PRAGMA integrity_check').fetchall()[0][0]=='ok'
        assert not get_db().execute('PRAGMA foreign_key_check').fetchall()
    image=client.get('/static/uploads/logo_prueba.png')
    assert image.status_code==200 and image.data==(old/'app/static/uploads/logo_prueba.png').read_bytes()
    image.close()
    assert (new/'TICKET/conservar.pdf').read_bytes()==(old/'TICKET/conservar.pdf').read_bytes()
    assert hashlib.sha256((new/'instance/.session_key').read_bytes()).hexdigest()==hashes[Path('instance/.session_key')]
    replay=client.post('/api/sales',json=record['payload'],headers={'Idempotency-Key':'upgrade-sale-existing'})
    assert replay.status_code==200 and replay.json==record['sale'] and replay.headers.get('Idempotency-Replayed')=='true'
    assert {p.relative_to(old):hashlib.sha256(p.read_bytes()).hexdigest() for p in old.rglob('*') if p.is_file()}==hashes
    print('OK: actualización desde '+record['version']+' conserva base, stock, deudas, caja, configuración, logo, tickets y clave')
    print('OK: instalación original intacta; reintentar venta anterior no la duplica en la copia actualizada')
finally:
 for k,v in saved.items():setattr(config,k,v)
