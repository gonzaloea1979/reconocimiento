"""Verifica la regla de autorización para sesiones locales automáticas sin Flask."""
from tests.route_source import read_all_routes
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source_path = ROOT / 'app' / 'routes.py'
tree = ast.parse(read_all_routes(ROOT))
needed = {'current_user_role', 'current_user_is_admin'}
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in needed]
if {n.name for n in nodes} != needed:
    raise SystemExit('ERROR: faltan funciones de autorización en routes.py')

class Session(dict):
    pass

namespace = {
    'session': Session(local_auto_login=True, authenticated_login=False, username='admin'),
    'current_user_row': lambda: {'role': 'Administrador'},
}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source_path), 'exec'), namespace)
if namespace['current_user_role']() != 'Cajero':
    raise SystemExit('ERROR: la sesión local heredó un rol elevado')
if namespace['current_user_is_admin']():
    raise SystemExit('ERROR: la sesión local quedó reconocida como administradora')
namespace['session'] = Session(local_auto_login=False, authenticated_login=False, passwordless_admin_login=True, username='admin')
if not namespace['current_user_is_admin']():
    raise SystemExit('ERROR: la sesión administrativa sin contraseña no reconoce al administrador')
namespace['session'] = Session(local_auto_login=False, authenticated_login=True, username='admin')
if not namespace['current_user_is_admin']():
    raise SystemExit('ERROR: la sesión autenticada no reconoce al administrador')
print('OK: sesión local antigua limitada; administrador predeterminado sin contraseña y sesión autenticada reconocidos')
