"""V108: caja con dos sesiones HTTP, exclusivamente sobre una base temporal.

Pruebas de apertura concurrente, movimientos simultáneos y consistencia de saldo.
No abre ni modifica la base comercial instance/pos.db.
"""
from __future__ import annotations
import importlib.util
import os
import sys
import tempfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if importlib.util.find_spec("flask") is None:
    print("SKIP: Flask no instalado; ejecutar probar_caja_dos_usuarios_v108.bat en Windows.")
    raise SystemExit(77)

import app.config as config
from app import create_app
from app.db import get_db

with tempfile.TemporaryDirectory(prefix="pos_v108_caja_dos_usuarios_") as tmp:
    base = Path(tmp)
    inst = base / "instance"
    for directory in (inst, base / "backups", base / "uploads", base / "TICKET"):
        directory.mkdir(parents=True, exist_ok=True)
    keys = ("BASE_DIR", "INSTANCE_DIR", "BACKUP_DIR", "DATABASE", "UPLOAD_DIR", "TICKET_DIR")
    old = {k: getattr(config, k) for k in keys}
    try:
        config.BASE_DIR = base
        config.INSTANCE_DIR = inst
        config.BACKUP_DIR = base / "backups"
        config.DATABASE = inst / "pos.db"
        config.UPLOAD_DIR = base / "uploads"
        config.TICKET_DIR = base / "TICKET"
        with patch.dict(os.environ, {"POS_SEED_DEMO_PRODUCTS": "0"}):
            app = create_app()
        app.config.update(TESTING=True)

        def parallel_requests(url, payload):
            gate = Barrier(2)
            def one(_i):
                with app.test_client() as client:
                    check = client.get("/api/cash/status")
                    assert check.status_code == 200, check.get_data(as_text=True)
                    gate.wait(timeout=20)
                    result = client.post(url, json=dict(payload))
                    return result.status_code, result.get_json(silent=True)
            with ThreadPoolExecutor(max_workers=2) as pool:
                return list(pool.map(one, range(2)))

        print("Prueba HTTP de caja V108: 2 clientes independientes y base temporal.")
        print("NO abre ni modifica instance\\pos.db.")
        results = parallel_requests("/api/cash/open", {"initial_amount": 100})
        codes = sorted(code for code, _ in results)
        with app.app_context():
            db = get_db()
            opened = db.execute("SELECT COUNT(*) FROM cash_sessions WHERE status='abierta'").fetchone()[0]
        assert opened == 1 and codes[0] == 200 and codes[1] in (400,409), (
            "APERTURA CONCURRENTE INSEGURA: deben quedar exactamente una caja y una respuesta de rechazo.",
            results, opened)
        print("OK: dos aperturas simultáneas -> solo una caja abierta")

        # Dos ingresos independientes deben quedar asociados a la misma caja.
        results = parallel_requests("/api/cash/movement", {
            "movement_type": "Ingreso", "amount": 25, "description": "Prueba V108",
        })
        assert [r[0] for r in results] == [200,200], results
        with app.app_context():
            db = get_db()
            cash = db.execute("SELECT id,initial_amount FROM cash_sessions WHERE status='abierta'").fetchone()
            rows = db.execute("""
                SELECT amount,cash_session_id FROM cash_movements
                WHERE movement_type='Ingreso' AND description='Prueba V108'
                ORDER BY id
            """).fetchall()
            assert len(rows)==2 and all(r["cash_session_id"]==cash["id"] for r in rows), rows
            assert sum(round(r["amount"]*100) for r in rows)==5000, rows
        print("OK: dos ingresos simultáneos, sin pérdida ni duplicación de importes")

        # Un ingreso y un retiro deben dar saldo esperado consistente.
        with app.test_client() as client:
            response = client.post("/api/cash/movement", json={
                "movement_type":"Retiro","amount":15,"description":"Prueba V108 retiro",
            })
            assert response.status_code==200, response.get_data(as_text=True)
            status = client.get("/api/cash/status")
            assert status.status_code==200, status.get_data(as_text=True)
            j = status.get_json()
            expected = 100 + 25 + 25 - 15
            assert round(j["session"]["expected_amount"]*100)==expected*100, j
        print("OK: saldo esperado = 135,00 tras 2 ingresos y 1 retiro")

        with app.app_context():
            db = get_db()
            assert db.execute("PRAGMA quick_check").fetchone()[0] == "ok"
            assert db.execute("PRAGMA foreign_key_check").fetchall()==[]
        print("OK: SQLite quick_check y foreign_key_check")
    finally:
        for k,v in old.items():
            setattr(config,k,v)
