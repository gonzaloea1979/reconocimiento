"""El bloque real de error de arranque no muestra ni guarda el mensaje privado."""
from pathlib import Path
import ast,os,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
secret='SYNTHETIC_STARTUP_PRIVATE_31cdd'
source=(ROOT/'run.py').read_text(encoding='utf-8');tree=ast.parse(source)
for node in tree.body:
    if isinstance(node,ast.FunctionDef) and node.name=='main':node.body=ast.parse('raise RuntimeError('+repr(secret)+')').body
    if isinstance(node,ast.FunctionDef) and node.name=='_message_box':node.body=ast.parse("(BASE_DIR/'startup-message.txt').write_text(message, encoding='utf-8')").body
ast.fix_missing_locations(tree)
with tempfile.TemporaryDirectory(prefix='pos_startup_private_') as tmp:
    for blocked in (False,True):
        base=Path(tmp)/('bloqueado' if blocked else 'normal');base.mkdir()
        script=base/'run.py';script.write_text(ast.unparse(tree),encoding='utf-8')
        if blocked:(base/'logs').write_text('archivo sintético que bloquea la carpeta')
        env=dict(os.environ,PYTHONPATH=str(ROOT),PYTHONUTF8='1')
        result=subprocess.run([sys.executable,str(script)],cwd=base,env=env,capture_output=True,text=True,timeout=15)
        assert result.returncode==1,(result.returncode,result.stdout,result.stderr)
        text=result.stdout+result.stderr+(base/'startup-message.txt').read_text(encoding='utf-8')
        if not blocked:
            text+='\n'.join(p.read_text(encoding='utf-8') for p in (base/'logs').glob('*.log'))
            assert 'RuntimeError' in text and 'run.py:' in text,text
            assert (base/'logs/inicio_error.log').is_file()
        else:
            assert (base/'logs').read_text()=='archivo sintético que bloquea la carpeta'
            assert 'No se pudo guardar el registro' in text and 'permisos de escritura' in text
        assert secret not in text,text
print('OK: arranque fallido sale con código 1 sin mostrar ni persistir el mensaje privado; tampoco lo filtra si la carpeta logs está bloqueada')
