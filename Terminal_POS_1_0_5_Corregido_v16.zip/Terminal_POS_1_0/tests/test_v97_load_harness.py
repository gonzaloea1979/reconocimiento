"""Verifica que el banco V97 mida reportes y búsquedas no vacías en aislamiento."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "prueba_carga_v97.py").read_text(encoding="utf-8")
assert 'TemporaryDirectory(prefix="terminal_pos_v97_")' in source
assert "No se abre ni modifica instance/pos.db" in source
assert "127.0.0.1" in source
assert "ThreadPoolExecutor" in source
assert "foreign_key_check" in source and "quick_check" in source
assert 'idx_sale_items_sale_report' in source
assert 'Cliente%2000050' in source
assert 'Proveedor%2000050' in source
assert 'date.today() - timedelta(days=30)' in source
assert 'V97' in source
print("OK: banco V97 aislado, reportes de 30 días y búsquedas sintéticas con coincidencias.")
