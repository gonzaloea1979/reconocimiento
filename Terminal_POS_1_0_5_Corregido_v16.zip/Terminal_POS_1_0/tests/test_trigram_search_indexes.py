"""Verifica FTS5 trigram, triggers y equivalencia con LIKE tradicional."""
import ast
import sqlite3
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
db_source = (ROOT / "app" / "db.py").read_text(encoding="utf-8")
tree = ast.parse(db_source)
helper_node = next(
    node for node in tree.body
    if isinstance(node, ast.FunctionDef) and node.name == "_ensure_optional_trigram_search"
)
namespace = {"sqlite3": sqlite3}
exec(compile(ast.Module(body=[helper_node], type_ignores=[]), "app/db.py", "exec"), namespace)
ensure_search = namespace["_ensure_optional_trigram_search"]

with tempfile.TemporaryDirectory(prefix="pos_trigram_search_") as tmp:
    db = sqlite3.connect(Path(tmp) / "search.db")
    db.executescript("""
        CREATE TABLE products(id INTEGER PRIMARY KEY, barcode TEXT, name TEXT NOT NULL, detail TEXT);
        CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT NOT NULL, document TEXT, phone TEXT);
        CREATE TABLE suppliers(id INTEGER PRIMARY KEY, name TEXT NOT NULL, cuit TEXT, phone TEXT, category TEXT);
        INSERT INTO products VALUES(1,'7791234567890','Camisa roja','Algodón premium');
        INSERT INTO products VALUES(2,'7790000000000','Pantalón azul','Jean elastizado');
        INSERT INTO clients VALUES(1,'María Gómez','30123456','3515551234');
        INSERT INTO clients VALUES(2,'Juan Pérez','30987654','3514442222');
        INSERT INTO suppliers VALUES(1,'Textil Centro','30700111223','3514000000','Indumentaria');
        INSERT INTO suppliers VALUES(2,'Mayorista Norte','30700999888','3514111111','Accesorios');
    """)
    assert ensure_search(db.cursor()) is True

    checks = [
        ("products_search", "products", ("barcode", "name", "detail"), "roja"),
        ("products_search", "products", ("barcode", "name", "detail"), "779"),
        ("clients_search", "clients", ("name", "document", "phone"), "Gómez"),
        ("clients_search", "clients", ("name", "document", "phone"), "555"),
        ("suppliers_search", "suppliers", ("name", "cuit", "phone", "category"), "Textil"),
        ("suppliers_search", "suppliers", ("name", "cuit", "phone", "category"), "Indum"),
    ]
    for fts, base, cols, query in checks:
        pattern = f"%{query}%"
        where = " OR ".join(f"{fts}.{col} LIKE ?" for col in cols)
        fts_ids = [r[0] for r in db.execute(
            f"SELECT {base}.id FROM {fts} JOIN {base} ON {base}.id={fts}.rowid WHERE {where} ORDER BY {base}.id",
            (pattern,) * len(cols)
        )]
        where_base = " OR ".join(f"{col} LIKE ?" for col in cols)
        base_ids = [r[0] for r in db.execute(
            f"SELECT id FROM {base} WHERE {where_base} ORDER BY id",
            (pattern,) * len(cols)
        )]
        assert fts_ids == base_ids, (fts, query, fts_ids, base_ids)

    plan = " ".join(str(r) for r in db.execute(
        "EXPLAIN QUERY PLAN SELECT p.id FROM products_search ps JOIN products p ON p.id=ps.rowid "
        "WHERE ps.name LIKE ?", ("%roja%",)
    ).fetchall())
    assert "VIRTUAL TABLE INDEX" in plan, plan

    # Triggers deben reflejar alta, edición y baja en la misma transacción.
    db.execute("INSERT INTO products VALUES(3,'123456','Remera verde','Algodón')")
    assert db.execute("SELECT rowid FROM products_search WHERE name LIKE '%verde%'").fetchone()
    db.execute("UPDATE products SET name='Remera negra' WHERE id=3")
    assert db.execute("SELECT rowid FROM products_search WHERE name LIKE '%negra%'").fetchone()
    assert not db.execute("SELECT rowid FROM products_search WHERE name LIKE '%verde%'").fetchone()
    db.execute("DELETE FROM products WHERE id=3")
    assert not db.execute("SELECT rowid FROM products_search WHERE name LIKE '%negra%'").fetchone()

    # La inicialización es idempotente: no duplica filas ni rompe triggers.
    assert ensure_search(db.cursor()) is True
    db.execute("INSERT INTO clients VALUES(3,'Cliente Nuevo','12345678','3511234567')")
    assert db.execute("SELECT rowid FROM clients_search WHERE name LIKE '%Nuevo%'").fetchone()
    db.close()

# Simular un SQLite sin módulo FTS5: la instalación opcional debe revertirse
# completa y permitir que el POS continúe con las consultas LIKE tradicionales.
with tempfile.TemporaryDirectory(prefix="pos_no_fts_") as tmp:
    fallback_db = sqlite3.connect(Path(tmp) / "fallback.db")
    fallback_db.executescript("""
        CREATE TABLE products(id INTEGER PRIMARY KEY, barcode TEXT, name TEXT NOT NULL, detail TEXT);
        CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT NOT NULL, document TEXT, phone TEXT);
        CREATE TABLE suppliers(id INTEGER PRIMARY KEY, name TEXT NOT NULL, cuit TEXT, phone TEXT, category TEXT);
    """)
    class NoFtsCursor:
        def __init__(self, connection):
            self.connection = connection
        def execute(self, sql, params=()):
            if "CREATE VIRTUAL TABLE" in sql:
                raise sqlite3.OperationalError("no such module: fts5")
            return self.connection.execute(sql, params)
    assert ensure_search(NoFtsCursor(fallback_db)) is False
    assert not fallback_db.execute(
        "SELECT 1 FROM sqlite_master WHERE name IN ('products_search','clients_search','suppliers_search')"
    ).fetchall()
    assert fallback_db.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 0
    fallback_db.close()

print("OK: FTS5 trigram conserva LIKE, sincroniza cambios y revierte completamente si no está disponible.")
