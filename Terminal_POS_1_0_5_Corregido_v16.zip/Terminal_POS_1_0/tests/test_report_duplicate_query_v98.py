"""V98 elimina el segundo recorrido de artículos del reporte sin cambiar rankings."""
import ast
import sqlite3
import tempfile
import time
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "app" / "route_modules" / "reports.py").read_text(encoding="utf-8")
tree = ast.parse(SOURCE)
route = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "api_reports")

rollup_assignment = next(
    n for n in ast.walk(route)
    if isinstance(n, ast.Assign)
    and any(isinstance(t, ast.Name) and t.id == "report_rollups" for t in n.targets)
)
call = rollup_assignment.value
if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "fetchall":
    call = call.func.value
ROLLUP_SQL = call.args[0].value
assert "product_rollup AS MATERIALIZED" in ROLLUP_SQL
assert "JOIN product_rollup r" in ROLLUP_SQL

# La ruta debe obtener least del CTE y no ejecutar otro JOIN sales/sale_items.
assert "least = [{'name': row['name'], 'qty': row['qty'], 'total': row['total']}" in SOURCE
assert "FROM sales s" not in SOURCE[SOURCE.index("least ="):SOURCE.index("debtors =")]
assert "sales_by_product" not in SOURCE
assert SOURCE.count("FROM period_sales ps") == 1

DUPLICATE_LEAST_SQL = """SELECT p.name AS name,
       COALESCE(sales_by_product.qty, 0) AS qty,
       COALESCE(sales_by_product.total, 0) AS total
FROM products p
LEFT JOIN (
    SELECT si.product_id, SUM(si.quantity) AS qty, SUM(si.line_total) AS total
    FROM sales s
    JOIN sale_items si ON si.sale_id = s.id
    WHERE s.created_at >= date(?) AND s.created_at < date(?, '+1 day')
    GROUP BY si.product_id
) AS sales_by_product ON sales_by_product.product_id = p.id
ORDER BY qty ASC, p.name ASC LIMIT 15"""

with tempfile.TemporaryDirectory(prefix="pos_v98_reports_") as tmp:
    db = sqlite3.connect(Path(tmp) / "reports.db")
    db.row_factory = sqlite3.Row
    db.executescript("""
        PRAGMA foreign_keys=ON;
        CREATE TABLE products(
            id INTEGER PRIMARY KEY, name TEXT NOT NULL, total_cost REAL NOT NULL DEFAULT 0
        );
        CREATE TABLE sales(id INTEGER PRIMARY KEY, created_at TEXT NOT NULL, total REAL NOT NULL DEFAULT 0);
        CREATE TABLE sale_items(
            id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL REFERENCES sales(id),
            product_id INTEGER NOT NULL REFERENCES products(id), product_name TEXT NOT NULL,
            quantity REAL NOT NULL, line_total REAL NOT NULL, unit_cost_at_sale REAL
        );
        CREATE INDEX idx_sales_created_at ON sales(created_at);
        CREATE INDEX idx_sale_items_sale_report
            ON sale_items(sale_id, product_id, product_name, quantity, line_total, unit_cost_at_sale);
        CREATE INDEX idx_sale_items_product_rollup
            ON sale_items(product_id, product_name, quantity, line_total);
    """)
    product_count, sale_count = 10_000, 20_000
    db.executemany(
        "INSERT INTO products(id,name,total_cost) VALUES(?,?,?)",
        [(i, f"Producto {i:05d}", 40.0 + i % 500) for i in range(1, product_count + 1)]
    )
    sales = []
    items = []
    item_id = 1
    for sale_id in range(1, sale_count + 1):
        day = sale_id % 31 + 1
        sales.append((sale_id, f"2026-10-{day:02d}T12:00:00", 500.0 + sale_id))
        for line in range(3):
            product_id = (sale_id * 7 + line * 31) % 8_000 + 1
            quantity = float((sale_id + line) % 5 + 1)
            line_total = quantity * (100.0 + product_id % 250)
            unit_cost = None if sale_id % 7 == 0 else 30.0 + product_id % 100
            # Algunos snapshots históricos con nombre anterior, como en datos reales.
            product_name = f"Producto {product_id:05d}" if sale_id % 2 else f"Anterior {product_id:05d}"
            items.append((item_id, sale_id, product_id, product_name, quantity, line_total, unit_cost))
            item_id += 1
    db.executemany("INSERT INTO sales VALUES(?,?,?)", sales)
    db.executemany("INSERT INTO sale_items VALUES(?,?,?,?,?,?,?)", items)
    db.execute("ANALYZE")
    params = ("2026-10-01", "2026-10-31")

    rows = db.execute(ROLLUP_SQL, params).fetchall()
    cte_least = [(r["name"], r["qty"], r["total"]) for r in rows if r["kind"] == "least"]
    old_least = [tuple(r) for r in db.execute(DUPLICATE_LEAST_SQL, params).fetchall()]
    assert cte_least == old_least, "El ranking menos vendidos cambió al quitar la consulta duplicada."
    assert len(cte_least) == 15

    # El reporte V97 ejecutaba ROLLUP_SQL y luego DUPLICATE_LEAST_SQL.
    # V98 ejecuta únicamente ROLLUP_SQL. Comparación informativa, misma conexión y datos.
    def median_ms(sql, count=25):
        for _ in range(5):
            db.execute(sql, params).fetchall()
        samples = []
        for _ in range(count):
            start = time.perf_counter_ns()
            db.execute(sql, params).fetchall()
            samples.append((time.perf_counter_ns() - start) / 1_000_000)
        return statistics.median(samples)

    v97_ms = median_ms(ROLLUP_SQL) + median_ms(DUPLICATE_LEAST_SQL)
    v98_ms = median_ms(ROLLUP_SQL)
    saved = max(0.0, v97_ms - v98_ms)
    improvement = (saved / v97_ms * 100.0) if v97_ms else 0.0
    print(f"V97 (rollup + ranking duplicado): {v97_ms:.2f} ms")
    print(f"V98 (rollup reutilizado): {v98_ms:.2f} ms")
    print(f"Tiempo SQL evitado: {saved:.2f} ms ({improvement:.1f}%)")

    empty_rows = db.execute(ROLLUP_SQL, ("2020-01-01", "2020-01-31")).fetchall()
    assert len([r for r in empty_rows if r["kind"] == "least"]) == 15
    assert len([r for r in empty_rows if r["kind"] == "top"]) == 0
    assert next(r["estimated_profit"] for r in empty_rows if r["kind"] == "profit") == 0
    assert db.execute("PRAGMA quick_check").fetchone()[0] == "ok"
    db.close()

print("OK: ranking equivalente; consulta duplicada eliminada; quick_check correcto.")
