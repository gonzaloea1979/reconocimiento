"""Pruebas aisladas de invariantes transaccionales de ventas/stock/caja.

Usan una SQLite temporal y no sustituyen pruebas de integración de la aplicación.
"""
import sqlite3
import tempfile
from pathlib import Path


def connect(path):
    db = sqlite3.connect(path)
    db.executescript('''
      CREATE TABLE products(id INTEGER PRIMARY KEY, stock REAL NOT NULL);
      CREATE TABLE sales(id INTEGER PRIMARY KEY, total REAL NOT NULL);
      CREATE TABLE sale_items(id INTEGER PRIMARY KEY, sale_id INTEGER, product_id INTEGER, qty REAL);
      CREATE TABLE product_movements(id INTEGER PRIMARY KEY, product_id INTEGER, qty REAL);
      CREATE TABLE purchases(id INTEGER PRIMARY KEY, total REAL NOT NULL);
      CREATE TABLE cash_movements(id INTEGER PRIMARY KEY, amount REAL NOT NULL);
      INSERT INTO products VALUES (1, 5.0);
    ''')
    return db


def create_sale(db, lines, stock_enabled=True):
    """Simula el contrato de transacción: o se guarda todo o no se guarda nada."""
    requested = {}
    for product_id, qty in lines:
        requested[product_id] = requested.get(product_id, 0) + qty
    if stock_enabled:
        for product_id, qty in requested.items():
            stock = db.execute('SELECT stock FROM products WHERE id=?', (product_id,)).fetchone()
            if not stock or qty > stock[0] + 0.00001:
                return False
    db.execute('BEGIN')
    try:
        sale_id = db.execute('INSERT INTO sales(total) VALUES (?)', (sum(q for _, q in lines),)).lastrowid
        for product_id, qty in lines:
            db.execute('INSERT INTO sale_items(sale_id, product_id, qty) VALUES (?, ?, ?)', (sale_id, product_id, qty))
            if stock_enabled:
                cur = db.execute('UPDATE products SET stock=ROUND(stock-?,2) WHERE id=? AND stock+0.000001>=?', (qty, product_id, qty))
                if cur.rowcount != 1:
                    raise RuntimeError('stock insuficiente')
                db.execute('INSERT INTO product_movements(product_id,qty) VALUES (?,?)', (product_id, -qty))
        db.commit()
        return True
    except Exception:
        db.rollback()
        return False


with tempfile.TemporaryDirectory(prefix='pos_invariants_') as tmp:
    db = connect(Path(tmp) / 'test.db')
    assert create_sale(db, [(1, 2), (1, 2)], True) is True
    assert db.execute('SELECT stock FROM products WHERE id=1').fetchone()[0] == 1
    assert db.execute('SELECT COUNT(*) FROM sale_items').fetchone()[0] == 2
    assert db.execute('SELECT COUNT(*) FROM product_movements').fetchone()[0] == 2

    # No debe quedar una cabecera parcial cuando el stock no alcanza.
    sales_before = db.execute('SELECT COUNT(*) FROM sales').fetchone()[0]
    items_before = db.execute('SELECT COUNT(*) FROM sale_items').fetchone()[0]
    assert create_sale(db, [(1, 1), (1, 1)], True) is False
    assert db.execute('SELECT COUNT(*) FROM sales').fetchone()[0] == sales_before
    assert db.execute('SELECT COUNT(*) FROM sale_items').fetchone()[0] == items_before

    # Con control desactivado, se registra la venta pero no se modifica stock.
    assert create_sale(db, [(1, 20)], False) is True
    assert db.execute('SELECT stock FROM products WHERE id=1').fetchone()[0] == 1

    # El saldo debe considerar todos los movimientos, no un límite arbitrario.
    db.executemany('INSERT INTO cash_movements(amount) VALUES (?)', [(1.0,)] * 250)
    assert db.execute('SELECT SUM(amount) FROM cash_movements').fetchone()[0] == 250.0
    db.close()

print('OK: invariantes aislados de ventas, líneas repetidas, rollback, modo sin stock y caja')
