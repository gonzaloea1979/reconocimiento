"""Verifica que las vistas previas usen el cálculo monetario decimal compartido."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
helper = (ROOT / "app" / "static" / "js" / "money_decimal.js").read_text(encoding="utf-8")
base = (ROOT / "app" / "templates" / "base.html").read_text(encoding="utf-8")
products = (ROOT / "app" / "static" / "js" / "products.js").read_text(encoding="utf-8")
purchases = (ROOT / "app" / "static" / "js" / "purchases.js").read_text(encoding="utf-8")
for marker in ("calculatePriceValues", "divideHalfUp", "roundCents", "toCentsScaled", "BigInt"):
    if marker not in helper:
        raise SystemExit(f"ERROR: falta {marker} en el helper monetario")
if "js/money_decimal.js" not in base:
    raise SystemExit("ERROR: el helper monetario no se carga desde base.html")
if "POSMoneyDecimal.calculatePriceValues" not in products:
    raise SystemExit("ERROR: Productos no utiliza el helper monetario")
if "POSMoneyDecimal.calculatePriceValues" not in purchases:
    raise SystemExit("ERROR: Compras no utiliza el helper monetario")
if "const costScaled = toCentsScaled(cost || 0)" not in helper:
    raise SystemExit("ERROR: los importes de entrada deben normalizarse directamente a centavos")
if "if (!mode || mode === 'none') return asNumber(toCentsScaled(value || 0))" not in helper:
    raise SystemExit("ERROR: el redondeo desactivado debe coincidir con la normalización monetaria del servidor")
print("OK: Productos y Compras usan cálculo decimal compartido con normalización directa a centavos")
