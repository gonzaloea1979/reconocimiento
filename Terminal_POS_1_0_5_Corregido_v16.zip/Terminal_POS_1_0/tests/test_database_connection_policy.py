"""Verifica la política compartida de conexiones SQLite del POS."""
from __future__ import annotations
import importlib.util
import sqlite3
import sys
import tempfile
import types
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
fake_flask = types.ModuleType("flask")
fake_flask.current_app = types.SimpleNamespace(config={})
fake_flask.g = types.SimpleNamespace()
old_flask = sys.modules.get("flask")
sys.modules["flask"] = fake_flask
try:
    spec = importlib.util.spec_from_file_location("_pos_db_connection_policy_test", ROOT / "app" / "db.py")
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
finally:
    if old_flask is None:
        sys.modules.pop("flask", None)
    else:
        sys.modules["flask"] = old_flask

with tempfile.TemporaryDirectory(prefix="pos_connection_policy_") as temp:
    db_path = Path(temp) / "connection.db"
    with closing(module.connect_database(db_path)) as conn:
        assert conn.execute("PRAGMA foreign_keys").fetchone()[0] == 1
        assert conn.execute("PRAGMA busy_timeout").fetchone()[0] == 15000
        assert conn.execute("PRAGMA cache_size").fetchone()[0] == -8192
        assert conn.execute("PRAGMA synchronous").fetchone()[0] == 2
        conn.execute("CREATE TABLE parent(id INTEGER PRIMARY KEY)")
        conn.execute("CREATE TABLE child(parent_id INTEGER REFERENCES parent(id))")
        try:
            conn.execute("INSERT INTO child(parent_id) VALUES(999)")
            conn.commit()
            raise AssertionError("La conexión compartida permitió una FK huérfana")
        except sqlite3.IntegrityError:
            conn.rollback()
        assert isinstance(conn.execute("SELECT 1 AS value").fetchone(), sqlite3.Row)

    with closing(module.connect_database(db_path, timeout=3, row_factory=False)) as conn:
        assert conn.execute("PRAGMA busy_timeout").fetchone()[0] == 3000
        assert isinstance(conn.execute("SELECT 1").fetchone(), tuple)

print("OK: política SQLite unificada; timeout, foreign keys y row_factory configurados")
