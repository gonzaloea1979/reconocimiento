"""Preparadores concurrentes: exclusión entre procesos y liberación al morir."""
from pathlib import Path
import os, subprocess, sys, tempfile, time
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import preparar_entorno as prepare
with tempfile.TemporaryDirectory(prefix='pos_install_lock_') as tmp:
    root=Path(tmp).resolve();marker=root/'ready';log=root/'child.log'
    with log.open('w') as out:
        proc=subprocess.Popen([sys.executable,str(ROOT/'tests/crash_worker.py'),str(root),'lock',str(marker)],stdout=out,stderr=subprocess.STDOUT)
        try:
            deadline=time.monotonic()+10
            while not marker.exists() and proc.poll() is None and time.monotonic()<deadline:time.sleep(.02)
            assert marker.exists(),log.read_text()
            with patch.object(prepare,'_prepare_environment') as actual:
                try:prepare.prepare_environment(root)
                except RuntimeError as exc:assert 'Otro proceso' in str(exc)
                else:raise AssertionError('Dos preparadores entraron en el mismo entorno')
                actual.assert_not_called()
            with prepare.installation_lock(root,build=True):pass
        finally:
            if proc.poll() is None:proc.kill()
            proc.wait(timeout=10)
    # No hay que borrar un lockfile "viejo": el bloqueo del SO ya se liberó.
    assert (root/'.venv.prepare.lock').is_file()
    with patch.object(prepare,'_prepare_environment',return_value='ok') as actual:
        assert prepare.prepare_environment(root)=='ok';actual.assert_called_once()
    print('OK: segundo preparador rechazado antes de instalar; build independiente; cierre abrupto libera bloqueo sin borrar archivos')
