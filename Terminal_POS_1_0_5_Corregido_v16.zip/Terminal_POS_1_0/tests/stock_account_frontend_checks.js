const assert = require('assert/strict');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const root = process.argv[2];
const elements = new Map();
function element(id) {
  if (!elements.has(id)) elements.set(id, {
    value: '', textContent: '', innerHTML: '', readOnly: false,
    classList: {add(){}, remove(){}}, reset(){}, focus(){}, addEventListener(){}
  });
  return elements.get(id);
}
class FormData {
  constructor() { this.values = new Map(); }
  append(key, value) { this.values.set(key, String(value)); }
  get(key) { return this.values.get(key) ?? null; }
  has(key) { return this.values.has(key); }
}
const context = {
  document: {addEventListener(){}, getElementById:element},
  window: {addEventListener(){}, location:{pathname:'/'}, POS_CURRENT_USER:{is_admin:true}},
  setTimeout(){}, clearTimeout(){}, setInterval(){}, clearInterval(){},
  AbortController, FormData, console
};
vm.createContext(context);
for (const name of ['common', 'products', 'clients']) {
  vm.runInContext(fs.readFileSync(path.join(root,'app/static/js',name+'.js'),'utf8'),context);
}
context.calculatePreview=()=>{};
context.syncGlobalRoundingControls=()=>{};
context.setProductPhotoPreview=()=>{};
context.fillForm({id:1,name:'Producto',stock:10,cost_without_tax:5});
assert.equal(context.collectForm().get('original_stock'),'10');
element('stock').value='7';
assert.equal(context.collectForm().get('stock'),'7');
assert.equal(context.collectForm().get('original_stock'),'10');
context.closeProductModal();
context.openNewProductModal();
assert.equal(context.collectForm().has('original_stock'),false);
console.log('OK: edición conserva stock original; altas nuevas no heredan la referencia');

for (const id of ['clientId','clientName','clientDocument','clientPhone','clientAddress',
  'clientNotes','clientBalance','clientPassword','clientPasswordWrap','clientMovements']) {
  context[id]=element(id);
}
context.api=async()=>[{movement_type:'Saldo inicial',amount:100,created_at_formatted:'01/01/2026',description:'Saldo pendiente'}];
async function main() {
  context.clearClientForm();
  assert.equal(element('clientBalance').readOnly,false);
  assert.equal(element('clientBalanceLabel').textContent,'Saldo inicial');
  vm.runInContext(`clients=[{id:1,name:'Cliente',balance:100}];`,context);
  await context.editClient(1);
  assert.equal(element('clientBalance').readOnly,true);
  assert.equal(element('clientBalanceLabel').textContent,'Saldo actual');
  assert.ok(element('clientMovements').innerHTML.includes('Saldo inicial'));
  context.clearClientForm();
  assert.equal(element('clientBalance').readOnly,false);
  assert.equal(element('clientBalance').value,0);
  console.log('OK: saldo inicial editable en alta; saldo actual de cliente existente solo de lectura');
}
main().catch(error=>{console.error(error);process.exit(1);});
