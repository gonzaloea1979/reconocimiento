"""Regresiones para peticiones HTTP y recursos temporales del frontend."""
from pathlib import Path
import subprocess
import shutil

ROOT = Path(__file__).resolve().parents[1]
common = (ROOT / "app" / "static" / "js" / "common.js").read_text(encoding="utf-8")
products = (ROOT / "app" / "static" / "js" / "products.js").read_text(encoding="utf-8")
clients = (ROOT / "app" / "static" / "js" / "clients.js").read_text(encoding="utf-8")
suppliers = (ROOT / "app" / "static" / "js" / "suppliers.js").read_text(encoding="utf-8")
sales = (ROOT / "app" / "static" / "js" / "sales.js").read_text(encoding="utf-8")
reports = (ROOT / "app" / "static" / "js" / "reports.js").read_text(encoding="utf-8")
purchases = (ROOT / "app" / "static" / "js" / "purchases.js").read_text(encoding="utf-8")

assert "Accept: 'application/json'" in common
assert "'Content-Type': 'application/json'" in common
assert "requestOptions.body !== undefined" in common
assert "const config = { ...requestOptions, headers }" in common

for label, source in (
    ("productos", products), ("clientes", clients),
    ("proveedores", suppliers), ("ventas", sales), ("etiquetas", reports)
):
    assert "AbortController" in source, f"{label}: falta cancelación de solicitudes"
    assert "signal: controller.signal" in source, f"{label}: no transmite AbortSignal"
assert "setTimeout(() => loadProducts(query), 180)" in products
assert "setTimeout(loadClients,180)" in clients.replace(" ", "")
assert "setTimeout(loadSuppliers,180)" in suppliers.replace(" ", "")
assert "requestVersion !== saleSearchVersion" in sales
assert "requestVersion !== labelSearchRequestVersion" in reports

assert "URL.revokeObjectURL(productPhotoObjectUrl)" in products
assert "URL.revokeObjectURL(quickPhotoObjectUrl)" in purchases

node = shutil.which("node")
if node:
    script = r"""
const fs = require('fs');
const vm = require('vm');
const source = fs.readFileSync(process.argv[1], 'utf8');
const calls = [];
const context = {
  document: { addEventListener() {}, querySelectorAll() {} },
  window: { addEventListener() {}, location: { pathname: '/' } },
  fetch: async (url, options) => {
    calls.push({url, options});
    return {ok:true, json:async()=>({ok:true})};
  },
  console, setTimeout, clearTimeout, setInterval, clearInterval, AbortController
};
vm.createContext(context);
vm.runInContext(source, context);
(async () => {
  await context.api('/api/read');
  const read = calls[0].options;
  if (read.headers['Content-Type']) throw new Error('GET no debe enviar Content-Type JSON');
  if (read.headers.Accept !== 'application/json') throw new Error('Falta Accept JSON');
  const controller = new AbortController();
  await context.api('/api/write', {method:'POST', body:'{}', signal:controller.signal, headers:{'X-Test':'1'}});
  const write = calls[1].options;
  if (write.headers['Content-Type'] !== 'application/json') throw new Error('POST debe enviar Content-Type JSON');
  if (write.headers['X-Test'] !== '1') throw new Error('Se perdió header personalizado');
  if (write.signal !== controller.signal) throw new Error('Se perdió AbortSignal');
  console.log('OK: API arma headers mínimos y conserva signal/opciones');
})().catch(err=>{ console.error(err); process.exit(1); });
"""
    result = subprocess.run([node, "-e", script, str(ROOT / "app" / "static" / "js" / "common.js")],
                            capture_output=True, text=True, timeout=8)
    assert result.returncode == 0, result.stdout + result.stderr
    print(result.stdout.strip())
else:
    print("AVISO: Node.js no disponible; se omitió la prueba dinámica de api().")

print("OK: debounce, cancelación de búsquedas obsoletas y liberación de Blob URLs.")
