"""Guardas y empaquetado Windows con salida sintética; no ejecuta un EXE."""
from pathlib import Path
import hashlib
import subprocess
import sys
import tempfile
from unittest.mock import patch
import zipfile

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from preparar_compilacion_segura import check_output
from verificar_exe_compilado import verify_distribution
from empaquetar_exe import package_distribution

with tempfile.TemporaryDirectory(prefix='pos_build_safety_') as tmp:
    base=Path(tmp); root=base/'TerminalPOS'; root.mkdir()
    for folder in ('app/templates','app/static/css','instance','backups','TICKET','logs','app/static/uploads'):
        (root/folder).mkdir(parents=True,exist_ok=True)
    (root/'TerminalPOS.exe').write_bytes(b'MZ'+b'0'*110_000)
    (root/'app/templates/base.html').write_text('plantilla de prueba')
    (root/'app/static/css/style.css').write_text('body{}')
    (root/'INICIAR_POS.bat').write_text('@echo off\nTerminalPOS.exe\n')
    check_output(root); verify_distribution(root)
    destination=base/'TerminalPOS_EXE.zip'
    package_distribution(root,destination)
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        assert 'TerminalPOS.exe' in archive.namelist()
        assert 'app/templates/base.html' in archive.namelist()
    previous=destination.read_bytes()
    for relative in ('instance/pos.db','backups/respaldo.bak','TICKET/ticket.pdf','app/static/uploads/foto.jpg','logs/uso.log','otra.sqlite'):
        private=root/relative; private.write_bytes(b'datos ficticios')
        fingerprint=hashlib.sha256(private.read_bytes()).digest()
        try:
            check_output(root)
        except ValueError: pass
        else: raise AssertionError('Se permitio borrar datos: '+relative)
        try:
            package_distribution(root,destination)
        except ValueError: pass
        else: raise AssertionError('Se empaquetaron datos: '+relative)
        assert destination.read_bytes()==previous
        assert hashlib.sha256(private.read_bytes()).digest()==fingerprint
        private.unlink()
    with patch.object(zipfile.ZipFile,'write',side_effect=OSError('disco lleno simulado')):
        try: package_distribution(root,destination)
        except OSError: pass
        else: raise AssertionError('No propago error de escritura')
    assert destination.read_bytes()==previous
    assert not list(base.glob('.pos_package_*'))
    (root/'TerminalPOS.exe').write_bytes(b'XX'+b'0'*110_000)
    result=subprocess.run([sys.executable,'-O',str(ROOT/'verificar_exe_compilado.py'),str(root)],capture_output=True,text=True,timeout=10)
    assert result.returncode!=0,result.stdout+result.stderr
script=(ROOT/'compilar_exe.bat').read_text()
assert script.index('preparar_compilacion_segura.py') < script.index('if exist "dist\\TerminalPOS" rmdir')
assert script.index('verificar_exe_compilado.py') < script.index('empaquetar_exe.py')
assert 'Compress-Archive' not in script
print('OK: compilador protege datos; verifica antes de empaquetar; fallo de disco conserva ZIP anterior sin temporales')
print('OK: verificador detecta errores también con Python -O; prueba estructural con EXE sintético, no ejecución Windows')
