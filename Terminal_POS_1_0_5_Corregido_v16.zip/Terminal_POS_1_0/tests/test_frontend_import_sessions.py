"""Ejecuta formularios reales de importación y manejo de sesiones en Node.js."""
from pathlib import Path
import shutil
import subprocess

node = shutil.which('node')
if not node:
    print('SKIP: Node.js requerido para comprobar importaciones y sesiones')
    raise SystemExit(77)
root = Path(__file__).resolve().parents[1]
result = subprocess.run([node, str(root / 'tests/import_session_frontend_checks.js'), str(root)],
                        capture_output=True, text=True, timeout=15)
assert result.returncode == 0, result.stdout + result.stderr
print(result.stdout.strip())
