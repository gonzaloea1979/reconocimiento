"""Ejecuta el generador V96 sobre una base temporal y verifica el aislamiento."""
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "prueba_carga_v96.py").read_text(encoding="utf-8")
assert "TemporaryDirectory(prefix=\"terminal_pos_v96_\")" in source
assert "No se abre ni modifica instance/pos.db" in source
assert "127.0.0.1" in source
assert "ThreadPoolExecutor" in source
assert "foreign_key_check" in source and "quick_check" in source

with tempfile.TemporaryDirectory(prefix="pos_v96_harness_test_") as tmp:
    report = Path(tmp) / "result.txt"
    result = subprocess.run(
        [sys.executable, str(ROOT / "prueba_carga_v96.py"), "--allow-sql-only",
         "--rounds", "1", "--report", str(report)],
        cwd=ROOT, capture_output=True, text=True, timeout=90,
    )
    assert result.returncode == 0, result.stdout[-4000:] + result.stderr[-2000:]
    assert report.is_file(), "No se generó el informe V96."
    content = report.read_text(encoding="utf-8")
    for expected in (
        "products: 10,000", "sales: 20,000", "sale_items: 60,000",
        "product_movements: 10,000", "purchases: 5,000", "audit_logs: 20,000",
        "quick_check: ok", "foreign_key_check: OK",
    ):
        assert expected in content, f"Falta dato esperado en el informe: {expected}"
    if "MODO: Aplicación Flask real" in content:
        assert "CONCURRENCIA HTTP" in content
        assert "ENDPOINTS HTTP LOOPBACK" in content
    else:
        assert "Prueba HTTP y concurrencia" in content

print("OK: V96 genera carga sintética aislada, valida integridad y ejecuta HTTP cuando Flask está disponible.")
