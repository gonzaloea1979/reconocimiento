"""Ensayo de centavos sobre esquema REAL de app.db; NO altera producción.

Valida compatibilidad de columnas existentes y cuantifica la pérdida por
redondeo. Las columnas *_cents_candidate solo existen en una copia temporal.
"""
from contextlib import closing
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import importlib.util
import os
import sqlite3
import sys
import tempfile
import types

ROOT = Path(__file__).resolve().parents[1]
MONEY = {
    'products': ('cost_without_tax', 'total_cost', 'sale_price'),
    'sales': ('total', 'amount_received', 'change_amount'),
    'sale_items': ('unit_price', 'line_total', 'unit_cost_at_sale'),
    'purchases': ('total',),
    'purchase_items': ('unit_cost', 'cost_without_tax', 'total_cost', 'sale_price', 'line_total'),
    'cash_sessions': ('initial_amount', 'closing_amount', 'expected_amount', 'difference'),
    'cash_movements': ('amount',),
    'clients': ('balance',),
    'client_movements': ('amount',),
}

class ConfigApp:
    config = {}

fake_flask = types.ModuleType('flask')
fake_flask.current_app = ConfigApp()
fake_flask.g = types.SimpleNamespace()
old_flask = sys.modules.get('flask')
sys.modules['flask'] = fake_flask
try:
    spec = importlib.util.spec_from_file_location('_pos_db_real_schema_money_test', ROOT / 'app' / 'db.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
finally:
    if old_flask is None:
        sys.modules.pop('flask', None)
    else:
        sys.modules['flask'] = old_flask

def cents(v):
    if v is None:
        return None
    d = Decimal(str(v))
    if not d.is_finite():
        raise ValueError('non finite monetary value')
    n = int((d * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    if not -(2**63) <= n <= 2**63 - 1:
        raise OverflowError('SQLite INTEGER overflow')
    return n

with tempfile.TemporaryDirectory(prefix='pos_money_actual_schema_') as temp:
    base = Path(temp) / 'source.db'
    candidate = Path(temp) / 'candidate.db'
    fake_flask.current_app.config = {'DATABASE': base}
    os.environ.pop('POS_SEED_DEMO_PRODUCTS', None)
    module.init_db()  # Actual production schema, not fabricated simplified tables.
    with closing(sqlite3.connect(base)) as src:
        for table, cols in MONEY.items():
            existing = {r[1] for r in src.execute(f'PRAGMA table_info("{table}")')}
            assert set(cols) <= existing, (table, set(cols) - existing)
        # Use real schema but don't invent required fields or alter business history.
        # Existing rows can be absent; candidate fields must also support empty tables.
        src.execute('PRAGMA foreign_keys=ON')
        src.commit()
        with closing(sqlite3.connect(candidate)) as dest:
            src.backup(dest)
    with closing(sqlite3.connect(candidate)) as db:
        db.execute('BEGIN')
        for table, cols in MONEY.items():
            for col in cols:
                db.execute(f'ALTER TABLE "{table}" ADD COLUMN "{col}_cents_candidate" INTEGER')
                for pk, amount in db.execute(f'SELECT id,"{col}" FROM "{table}"').fetchall():
                    db.execute(f'UPDATE "{table}" SET "{col}_cents_candidate"=? WHERE id=?', (cents(amount), pk))
        db.commit()
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert not db.execute('PRAGMA foreign_key_check').fetchall()
    with closing(sqlite3.connect(base)) as db:
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        for table, cols in MONEY.items():
            existing = {r[1] for r in db.execute(f'PRAGMA table_info("{table}")')}
            assert not any(f'{col}_cents_candidate' in existing for col in cols)
    # The difference caused by rounding is material and must be reconciled before migration.
    for amount in ['2.675', '-2.675', '0.105', '-0.105', '1.005']:
        n = cents(amount)
        delta = Decimal(n) / 100 - Decimal(amount)
        assert abs(delta) <= Decimal('0.005'), (amount, delta)
    assert cents('2.675') == 268
print('OK: esquema real de producción validado para 22 columnas; copia temporal íntegra, fuente intacta; redondeo subcentavo identificado')
