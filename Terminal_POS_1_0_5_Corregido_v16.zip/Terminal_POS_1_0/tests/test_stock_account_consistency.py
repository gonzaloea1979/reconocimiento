"""Stock de fichas antiguas y cuenta corriente: pruebas con SQLite temporal."""
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from pathlib import Path
import os
import sqlite3
import sys
import tempfile
import threading
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import xlrd
import app.config as config
import app.db as db_module
import app.route_modules.products as product_routes
from app import create_app
from app.db import get_db, update_settings

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {key: getattr(config, key) for key in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_stock_accounts_v10_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base / 'instance',
                               BACKUP_DIR=base / 'backups', DATABASE=base / 'instance' / 'pos.db',
                               UPLOAD_DIR=base / 'uploads', TICKET_DIR=base / 'tickets').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = True
        client = app.test_client()

        def query(sql, args=()):
            with app.app_context():
                return [tuple(row) for row in get_db().execute(sql, args)]

        def ledger(client_id):
            return query("SELECT COALESCE(SUM(CASE WHEN movement_type='Pago' THEN -amount ELSE amount END),0) FROM client_movements WHERE client_id=?",
                         (client_id,))[0][0]

        payload = {'name': 'Producto prueba', 'cost_without_tax': 5, 'stock': 10, 'min_stock': 2}
        product = client.post('/api/products', json=payload).json
        pid = product['id']
        assert client.post('/api/sales', json={'items': [{'product_id': pid, 'quantity': 2}]}).status_code == 200
        # El stock original y el que se envía coinciden: solo se edita el precio.
        price_edit = dict(payload, cost_without_tax=6, original_stock=10)
        edited = client.put(f'/api/products/{pid}', json=price_edit)
        assert edited.status_code == 200, edited.json
        assert edited.json['stock'] == 8 and edited.json['sale_price'] == 6
        assert query('SELECT COUNT(*) FROM product_movements WHERE product_id=?', (pid,)) == [(1,)]
        # Un cliente antiguo sin referencia debe recibir conflicto, nunca restaurar 10.
        conflict = client.put(f'/api/products/{pid}', json=dict(payload, cost_without_tax=99))
        assert conflict.status_code == 409
        assert query('SELECT stock, cost_without_tax FROM products WHERE id=?', (pid,)) == [(8, 6)]
        assert client.put(f'/api/products/{pid}', json={'name': 'Solo precio', 'cost_without_tax': 7}).status_code == 200
        assert query('SELECT stock, min_stock FROM products WHERE id=?', (pid,)) == [(8, 2)]
        # Cantidad cambiada sobre una ficha antigua: rechazar todo el guardado.
        assert client.put(f'/api/products/{pid}', json=dict(price_edit, stock=4)).status_code == 409
        adjustment = client.put(f'/api/products/{pid}', data={
            'name': 'Producto contado', 'cost_without_tax': '7', 'stock': '7', 'original_stock': '8'
        })
        assert adjustment.status_code == 200, adjustment.json
        assert query('SELECT quantity, previous_stock, new_stock FROM product_movements WHERE product_id=? ORDER BY id DESC LIMIT 1',
                     (pid,)) == [(-1, 8, 7)]
        print('OK: ficha antigua no restaura stock; ajustes explícitos quedan en el historial')

        # Dos recuentos de la misma ficha no pueden sobrescribirse silenciosamente.
        gate = threading.Barrier(2)
        def recount(amount):
            cl = app.test_client()
            gate.wait(timeout=10)
            return cl.put(f'/api/products/{pid}', json={
                'name': 'Producto contado', 'cost_without_tax': 7, 'stock': amount, 'original_stock': 7
            }).status_code
        with ThreadPoolExecutor(2) as pool:
            outcomes = list(pool.map(recount, [5, 6]))
        assert sorted(outcomes) == [200, 409], outcomes
        current = query('SELECT stock, cost_without_tax FROM products WHERE id=?', (pid,))[0]
        movements_before = query('SELECT COUNT(*) FROM product_movements WHERE product_id=?', (pid,))
        with patch.object(product_routes, 'stock_movement', side_effect=sqlite3.OperationalError('fallo simulado')), \
             patch.object(app.logger, 'exception'):
            failed = client.put(f'/api/products/{pid}', json={
                'name': 'No guardar', 'cost_without_tax': 123, 'stock': 1, 'original_stock': current[0]
            })
        assert failed.status_code == 500
        assert query('SELECT stock, cost_without_tax FROM products WHERE id=?', (pid,)) == [current]
        assert query('SELECT COUNT(*) FROM product_movements WHERE product_id=?', (pid,)) == movements_before
        with app.app_context():
            update_settings({'stock_control_enabled': '0'})
        disabled = client.put(f'/api/products/{pid}', json=dict(payload, stock=0, min_stock=0))
        assert disabled.status_code == 200 and disabled.json['stock'] == current[0]
        with app.app_context():
            update_settings({'stock_control_enabled': '1'})
        assert client.put('/api/products/999999', json=payload).status_code == 404
        print('OK: recuentos simultáneos, rollback y control de stock desactivado')

        # Validar el saldo antes de crear el cliente o su movimiento inicial.
        for value in ('abc', 'NaN', 'Infinity', -1, [], {}, True):
            assert client.post('/api/clients', json={'name': 'Inválido', 'balance': value}).status_code == 400
        assert query('SELECT COUNT(*) FROM clients') == [(0,)]
        zero = client.post('/api/clients', json={'name': 'Sin deuda'}).json
        assert zero['balance'] == 0 and ledger(zero['id']) == 0
        assert query('SELECT COUNT(*) FROM client_movements WHERE client_id=?', (zero['id'],)) == [(0,)]
        assert client.post('/api/cash/open', json={'initial_amount': 0}).status_code == 200
        cash_before = query('SELECT COUNT(*) FROM cash_movements')
        debtor = client.post('/api/clients', json={'name': 'Con deuda', 'balance': '100.00'}).json
        cid = debtor['id']
        assert ledger(cid) == debtor['balance'] == 100
        assert query('SELECT movement_type, amount FROM client_movements WHERE client_id=?', (cid,)) == [('Saldo inicial', 100)]
        assert query('SELECT COUNT(*) FROM cash_movements') == cash_before
        # Un fallo en el movimiento inicial no deja un alta parcial.
        with app.app_context():
            db = get_db()
            db.execute("CREATE TRIGGER fail_opening BEFORE INSERT ON client_movements WHEN NEW.movement_type='Saldo inicial' BEGIN SELECT RAISE(ABORT,'fallo simulado'); END")
            db.commit()
        with patch.object(app.logger, 'exception'):
            assert client.post('/api/clients', json={'name': 'Alta fallida', 'balance': 50}).status_code == 500
        assert query("SELECT COUNT(*) FROM clients WHERE name='Alta fallida'") == [(0,)]
        with app.app_context():
            db = get_db()
            db.execute('DROP TRIGGER fail_opening')
            db.commit()
        print('OK: saldo inicial validado, trazable y sin ingreso de caja ficticio; alta atómica')

        credit_product = client.post('/api/products', json=dict(payload, stock=20)).json
        assert client.post('/api/sales', json={
            'items': [{'product_id': credit_product['id'], 'quantity': 2}],
            'payment_method': 'Cuenta corriente', 'client_id': cid
        }).status_code == 200
        gate = threading.Barrier(2)
        def pay(amount):
            cl = app.test_client()
            gate.wait(timeout=10)
            return cl.post(f'/api/clients/{cid}/payment', json={'amount': amount}).status_code
        with ThreadPoolExecutor(2) as pool:
            assert list(pool.map(pay, [20, 30])) == [200, 200]
        assert ledger(cid) == query('SELECT balance FROM clients WHERE id=?', (cid,))[0][0] == 60
        # Dos pagos de 40 sobre deuda 60: solo uno puede confirmarse.
        gate = threading.Barrier(2)
        with ThreadPoolExecutor(2) as pool:
            assert sorted(pool.map(pay, [40, 40])) == [200, 400]
        assert ledger(cid) == query('SELECT balance FROM clients WHERE id=?', (cid,))[0][0] == 20
        assert client.put(f'/api/clients/{cid}', json={'name': 'Datos editados', 'balance': 999}).status_code == 200
        assert ledger(cid) == query('SELECT balance FROM clients WHERE id=?', (cid,))[0][0] == 20
        assert client.put('/api/clients/999999', json={'name': 'Inexistente'}).status_code == 404
        print('OK: saldo coincide con apertura, venta y pagos; sobrepago concurrente rechazado')

        # Exportar mientras se paga: cabecera y movimientos deben ser de la misma foto.
        read_done, resume = threading.Event(), threading.Event()
        local = threading.local()
        original_connect = db_module.connect_database

        class Cursor:
            def __init__(self, cursor):
                self.cursor = cursor
            def fetchone(self):
                row = self.cursor.fetchone()
                read_done.set()
                assert resume.wait(10)
                return row
            def __getattr__(self, name):
                return getattr(self.cursor, name)

        class Connection:
            def __init__(self, connection):
                self.connection = connection
            def execute(self, sql, *args, **kwargs):
                cursor = self.connection.execute(sql, *args, **kwargs)
                if getattr(local, 'role', '') == 'export' and sql == 'SELECT * FROM clients WHERE id=?':
                    return Cursor(cursor)
                return cursor
            def __getattr__(self, name):
                return getattr(self.connection, name)

        def connect(*args, **kwargs):
            return Connection(original_connect(*args, **kwargs))

        def export():
            local.role = 'export'
            return app.test_client().get(f'/api/clients/{cid}/export')

        with patch.object(db_module, 'connect_database', side_effect=connect):
            with ThreadPoolExecutor(1) as pool:
                job = pool.submit(export)
                try:
                    assert read_done.wait(10)
                    assert client.post(f'/api/clients/{cid}/payment', json={'amount': 10}).status_code == 200
                finally:
                    resume.set()
                exported = job.result(timeout=10)
        assert exported.status_code == 200
        book = xlrd.open_workbook(file_contents=exported.data)
        sheet = book.sheet_by_index(0)
        export_balance = sheet.cell_value(3, 1)
        export_ledger = sum((-1 if sheet.cell_value(r, 1) == 'Pago' else 1) * sheet.cell_value(r, 2)
                            for r in range(6, sheet.nrows))
        assert export_balance == export_ledger == 20
        assert ledger(cid) == query('SELECT balance FROM clients WHERE id=?', (cid,))[0][0] == 10
        assert query('PRAGMA quick_check') == [('ok',)]
        assert query('PRAGMA foreign_key_check') == []
        print('OK: Excel conserva una lectura consistente durante un pago concurrente; integridad SQLite')
finally:
    for key, value in saved.items():
        setattr(config, key, value)
