"""Audita una migracion candidata sobre el esquema real CON movimientos simulados.

No usa datos del negocio ni modifica las columnas que lee el POS. Todos los
archivos SQLite se crean en un directorio temporal.
"""
from contextlib import closing
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import importlib.util
import sqlite3
import tempfile
import types
import sys

ROOT = Path(__file__).resolve().parents[1]
MONEY = {
    'products': ('cost_without_tax', 'total_cost', 'sale_price'),
    'sales': ('total', 'amount_received', 'change_amount'),
    'sale_items': ('unit_price', 'line_total', 'unit_cost_at_sale'),
    'purchases': ('total',),
    'purchase_items': ('unit_cost', 'cost_without_tax', 'total_cost', 'sale_price', 'line_total'),
    'cash_sessions': ('initial_amount', 'closing_amount', 'expected_amount', 'difference'),
    'cash_movements': ('amount',),
    'clients': ('balance',),
    'client_movements': ('amount',),
}

fake_flask = types.ModuleType('flask')
fake_flask.current_app = types.SimpleNamespace(config={})
fake_flask.g = types.SimpleNamespace()
old_flask = sys.modules.get('flask')
sys.modules['flask'] = fake_flask
try:
    spec = importlib.util.spec_from_file_location('_db_audit_seeded', ROOT / 'app' / 'db.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
finally:
    if old_flask is None:
        sys.modules.pop('flask', None)
    else:
        sys.modules['flask'] = old_flask

def cents(value):
    if value is None:
        return None
    amount = Decimal(str(value))
    assert amount.is_finite()
    result = int((amount * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    assert -(2**63) <= result < 2**63
    return result

with tempfile.TemporaryDirectory(prefix='pos_monetary_seeded_') as temp:
    original = Path(temp) / 'original.db'
    copy = Path(temp) / 'candidate.db'
    fake_flask.current_app.config = {'DATABASE': original}
    module.init_db()
    with closing(sqlite3.connect(original)) as db:
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('INSERT INTO products (id,name,cost_without_tax,total_cost,sale_price,created_at,updated_at) VALUES (1,?,?,?,?,?,?)',
                   ('Producto prueba', 1.005, 1.005, 2.675, '2026-01-01', '2026-01-01'))
        db.execute('INSERT INTO sales (id,total,amount_received,change_amount,created_at) VALUES (1,?,?,?,?)',
                   (5.35, 10.0, 4.65, '2026-01-01'))
        for n in (1, 2):
            db.execute('INSERT INTO sale_items (sale_id,product_id,product_name,unit_price,quantity,line_total,created_at,unit_cost_at_sale) VALUES (?,?,?,?,?,?,?,?)',
                       (1, 1, 'Producto prueba', 2.675, 1, 2.675, '2026-01-01', 1.005))
        db.commit()
        before = db.execute('SELECT total FROM sales WHERE id=1').fetchone()[0]
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert not db.execute('PRAGMA foreign_key_check').fetchall()
        with closing(sqlite3.connect(copy)) as dest:
            db.backup(dest)
    with closing(sqlite3.connect(copy)) as db:
        db.execute('BEGIN')
        for table, cols in MONEY.items():
            for col in cols:
                db.execute(f'ALTER TABLE "{table}" ADD COLUMN "{col}_cents_candidate" INTEGER')
                for pk, value in db.execute(f'SELECT id,"{col}" FROM "{table}"').fetchall():
                    db.execute(f'UPDATE "{table}" SET "{col}_cents_candidate"=? WHERE id=?', (cents(value), pk))
        db.commit()
        # Detect a genuine discrepancy due to per-line HALF_UP vs historic REAL total.
        line_cents = db.execute('SELECT SUM(line_total_cents_candidate) FROM sale_items WHERE sale_id=1').fetchone()[0]
        sale_cents = db.execute('SELECT total_cents_candidate FROM sales WHERE id=1').fetchone()[0]
        assert line_cents == 536 and sale_cents == 535, (line_cents, sale_cents)
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert not db.execute('PRAGMA foreign_key_check').fetchall()
        assert db.execute('SELECT COUNT(*) FROM sale_items').fetchone()[0] == 2
    with closing(sqlite3.connect(original)) as db:
        assert db.execute('SELECT total FROM sales WHERE id=1').fetchone()[0] == before
        assert not any(r[1].endswith('_cents_candidate') for r in db.execute('PRAGMA table_info(sales)'))
print('OK: esquema real poblado; diferencia de 1 centavo entre lineas y total historico detectada; origen sin cambios')
