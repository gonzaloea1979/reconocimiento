"""Comprueba la distribución modular y que cada endpoint se registre una vez."""
import ast
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
core = ROOT / 'app' / 'route_core.py'
modules = ROOT / 'app' / 'route_modules'
entry = ROOT / 'app' / 'routes.py'
assert core.is_file() and modules.is_dir()
source = entry.read_text(encoding='utf-8')
assert 'route_core import' in source
seen = {}
count = 0
for path in sorted(modules.glob('*.py')):
    tree = ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    for fn in tree.body:
        if isinstance(fn, ast.FunctionDef):
            endpoints = [ast.unparse(d) for d in fn.decorator_list if ast.unparse(d).startswith('bp.')]
            if endpoints:
                assert fn.name not in seen, f'Nombre duplicado: {fn.name}'
                seen[fn.name] = path.name
                count += 1
assert count >= 70, f'Se encontraron solo {count} endpoints'
assert len(list(modules.glob('*.py'))) >= 12
assert len(source.splitlines()) < 60
print(f'OK: {count} handlers distribuidos en {len(list(modules.glob("*.py")))-1} módulos sin nombres duplicados')
