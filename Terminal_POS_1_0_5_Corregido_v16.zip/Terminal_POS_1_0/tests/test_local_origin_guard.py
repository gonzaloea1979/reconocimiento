"""Chequeos estáticos del límite local y protección CSRF del modo passwordless."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
app_source = (ROOT / "app" / "__init__.py").read_text(encoding="utf-8")
run_source = (ROOT / "run.py").read_text(encoding="utf-8")
assert "@app.before_request" in app_source
assert "enforce_local_origin" in app_source
assert "127.0.0.1" in app_source and "localhost" in app_source and "::1" in app_source
assert "request.headers.get('Origin')" in app_source
assert "origin_host != request.host.lower()" in app_source
assert "Sec-Fetch-Site" in app_source and "cross-site" in app_source
assert "@app.after_request" in app_source
assert "X-Content-Type-Options" in app_source and "nosniff" in app_source
assert "X-Frame-Options" in app_source and "DENY" in app_source
assert "Cache-Control" in app_source and "no-store" in app_source
assert 'HOST = "127.0.0.1"' in run_source
assert "debug=False" in run_source and "use_reloader=False" in run_source
print("OK: servidor ligado a loopback; Host externo y mutaciones cross-origin se rechazan")
