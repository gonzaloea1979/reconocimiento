"""Ejecuta las confirmaciones JS reales con red/DOM controlados en Node."""
from pathlib import Path
import shutil
import subprocess
node=shutil.which('node')
if not node:
    print('SKIP: Node.js requerido para comprobar envíos frontend')
    raise SystemExit(77)
root=Path(__file__).resolve().parents[1]
result=subprocess.run([node,str(root/'tests/frontend_submission_checks.js'),str(root)],capture_output=True,text=True,timeout=20)
assert result.returncode==0,result.stdout+result.stderr
print(result.stdout.strip())
