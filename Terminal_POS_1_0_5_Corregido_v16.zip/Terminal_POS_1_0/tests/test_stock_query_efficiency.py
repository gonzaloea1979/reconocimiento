"""Las consultas de stock deben usar el índice parcial sin alterar alertas."""
import sqlite3
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
dashboard = (ROOT / "app" / "route_modules" / "dashboard.py").read_text(encoding="utf-8")
reports = (ROOT / "app" / "route_modules" / "reports.py").read_text(encoding="utf-8")
stock_routes = (ROOT / "app" / "route_modules" / "stock.py").read_text(encoding="utf-8")

for label, source in (("dashboard", dashboard), ("reportes", reports), ("stock", stock_routes)):
    assert "min_stock > 0 AND stock <= min_stock" in source, f"{label}: predicado no coincide con el índice"
    assert "COALESCE(min_stock" not in source, f"{label}: COALESCE impide aprovechar el índice parcial"

with tempfile.TemporaryDirectory(prefix="pos_stock_query_") as tmp:
    db = sqlite3.connect(Path(tmp) / "stock.db")
    db.executescript("""
        CREATE TABLE products(
            id INTEGER PRIMARY KEY, name TEXT NOT NULL, barcode TEXT,
            stock REAL NOT NULL DEFAULT 0, min_stock REAL NOT NULL DEFAULT 0,
            sale_price REAL NOT NULL DEFAULT 0
        );
        CREATE INDEX idx_products_low_stock_priority
        ON products((stock-min_stock), name)
        WHERE min_stock > 0 AND stock <= min_stock;
    """)
    db.executemany(
        "INSERT INTO products(id,name,barcode,stock,min_stock,sale_price) VALUES(?,?,?,?,?,?)",
        [(i, f"Producto {i:06d}", str(i), float(i % 20), 8.0 if i % 4 == 0 else 0.0, 100.0)
         for i in range(1, 20001)]
    )
    db.execute("ANALYZE")

    queries = {
        "dashboard_count": (
            "SELECT COUNT(*) FROM products WHERE min_stock > 0 AND stock <= min_stock"
        ),
        "report_count": (
            "SELECT COUNT(*) FROM products WHERE min_stock > 0 AND stock <= min_stock"
        ),
        "report_low_products": (
            "SELECT name, barcode, stock, min_stock, sale_price FROM products "
            "WHERE min_stock > 0 AND stock <= min_stock "
            "ORDER BY (stock-min_stock) ASC, name ASC LIMIT 30"
        ),
        "stock_alerts": (
            "SELECT * FROM products WHERE min_stock > 0 AND stock <= min_stock "
            "ORDER BY (stock-min_stock) ASC, name ASC LIMIT 300"
        ),
    }
    for label, sql in queries.items():
        plan = " ".join(str(r) for r in db.execute("EXPLAIN QUERY PLAN " + sql).fetchall())
        assert "idx_products_low_stock_priority" in plan, f"{label} no usa índice: {plan}"

    optimized = db.execute(queries["dashboard_count"]).fetchone()[0]
    previous = db.execute(
        "SELECT COUNT(*) FROM products WHERE COALESCE(min_stock,0)>0 AND COALESCE(stock,0)<=COALESCE(min_stock,0)"
    ).fetchone()[0]
    assert optimized == previous
    db.close()

print("OK: Dashboard, reportes y alertas de stock aprovechan el índice parcial con resultados equivalentes.")
