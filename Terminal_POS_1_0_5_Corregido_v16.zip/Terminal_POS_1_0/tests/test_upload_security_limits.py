"""Límites defensivos para imágenes subidas y tramas del lector de códigos."""
import ast
import io
import os
import tempfile
import uuid
import warnings
from pathlib import Path
from types import SimpleNamespace
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
core_source = (ROOT / "app" / "route_core.py").read_text(encoding="utf-8")
products_source = (ROOT / "app" / "route_modules" / "products.py").read_text(encoding="utf-8")
core_tree = ast.parse(core_source)
wanted = {"_validate_uploaded_file_size", "save_uploaded_image"}
nodes = [
    node for node in core_tree.body
    if isinstance(node, ast.FunctionDef) and node.name in wanted
]
assert {node.name for node in nodes} == wanted

MAX_IMAGE_UPLOAD_BYTES = 30 * 1024 * 1024
MAX_IMAGE_PIXELS = 40_000_000
namespace = {
    "track_upload": lambda path: None,  # El ciclo de vida real se comprueba por HTTP.
    "os": os,
    "warnings": warnings,
    "uuid4": uuid.uuid4,
    "secure_filename": lambda value: value,
    "current_app": SimpleNamespace(config={}),
    "MAX_IMAGE_UPLOAD_BYTES": MAX_IMAGE_UPLOAD_BYTES,
    "MAX_IMAGE_PIXELS": MAX_IMAGE_PIXELS,
}
exec(compile(ast.Module(body=nodes, type_ignores=[]), "app/route_core.py", "exec"), namespace)

class FakeStorage:
    def __init__(self, filename, data):
        self.filename = filename
        self.stream = io.BytesIO(data)
        self.content_length = None
    def save(self, destination):
        destination = Path(destination)
        destination.write_bytes(self.stream.read())

class OversizedStream:
    def __init__(self, size):
        self.size = size
        self.position = 0
    def tell(self):
        return self.position
    def seek(self, offset, whence=0):
        if whence == os.SEEK_END:
            self.position = self.size
        elif whence == os.SEEK_SET:
            self.position = offset
        return self.position

# Size validation rejects an oversized file without reading it into memory.
oversized = SimpleNamespace(stream=OversizedStream(MAX_IMAGE_UPLOAD_BYTES + 1), content_length=None)
try:
    namespace["_validate_uploaded_file_size"](oversized)
except ValueError as exc:
    assert "30 MB" in str(exc)
else:
    raise AssertionError("Se aceptó una imagen por encima del límite de bytes.")

with tempfile.TemporaryDirectory(prefix="pos_image_security_") as tmp:
    upload_dir = Path(tmp) / "uploads"
    namespace["current_app"].config["UPLOAD_DIR"] = upload_dir

    output = io.BytesIO()
    Image.new("RGB", (20, 20), "white").save(output, format="JPEG")
    valid = FakeStorage("foto.jpg", output.getvalue())
    saved = namespace["save_uploaded_image"](
        valid, "producto", lambda name: name.rsplit(".", 1)[-1].lower(),
        "Extensión inválida", max_pixels=1200
    )
    assert saved.startswith("uploads/producto_")
    assert len(list(upload_dir.glob("producto_*.jpg"))) == 1

    # Las imágenes con demasiados píxeles se rechazan antes de decodificarse.
    huge_output = io.BytesIO()
    Image.new("1", (7000, 7000), 0).save(huge_output, format="PNG")
    huge = FakeStorage("gigante.png", huge_output.getvalue())
    try:
        namespace["save_uploaded_image"](
            huge, "producto", lambda name: "png", "Extensión inválida"
        )
    except ValueError as exc:
        assert "dimensiones" in str(exc).lower()
    else:
        raise AssertionError("Se aceptó una imagen que supera el límite de píxeles.")

    # Los GIF animados se verifican y conservan todos sus cuadros.
    gif_output = io.BytesIO()
    frame_a = Image.new("RGB", (8, 8), "red")
    frame_b = Image.new("RGB", (8, 8), "blue")
    frame_a.save(gif_output, format="GIF", save_all=True, append_images=[frame_b], duration=100, loop=0)
    animated = FakeStorage("animado.gif", gif_output.getvalue())
    gif_saved = namespace["save_uploaded_image"](
        animated, "producto", lambda name: "gif", "Extensión inválida"
    )
    gif_path = upload_dir / Path(gif_saved).name
    with Image.open(gif_path) as check_gif:
        assert check_gif.n_frames == 2

    invalid = FakeStorage("no_es_imagen.jpg", b"esto no es una imagen")
    try:
        namespace["save_uploaded_image"](
            invalid, "producto", lambda name: "jpg", "Extensión inválida"
        )
    except ValueError as exc:
        assert "dañada" in str(exc).lower() or "procesamiento" in str(exc).lower()
    else:
        raise AssertionError("Se aceptó un archivo que no es una imagen.")

    mismatched_output = io.BytesIO()
    Image.new("RGB", (4, 4), "white").save(mismatched_output, format="PNG")
    mismatched = FakeStorage("imagen.jpg", mismatched_output.getvalue())
    try:
        namespace["save_uploaded_image"](
            mismatched, "producto", lambda name: "jpg", "Extensión inválida"
        )
    except ValueError as exc:
        assert "extensión" in str(exc).lower()
    else:
        raise AssertionError("Se aceptó contenido PNG con extensión JPG.")

assert "MAX_IMAGE_PIXELS = 40_000_000" in core_source
assert "source_image.width" not in core_source or "width * height > MAX_IMAGE_PIXELS" in core_source
assert "source_image.load()" in core_source
assert "MAX_BARCODE_IMAGE_BYTES = 4 * 1024 * 1024" in core_source
assert "max_encoded_length" in products_source
assert "base64.b64decode(image_data, validate=True)" in products_source
assert "}), 413" in products_source
assert "if not isinstance(data, dict)" in products_source
assert "if not isinstance(image_data, str)" in products_source
assert "current_app.logger.exception" in products_source
for filename in ("auth.py", "users.py", "settings.py"):
    route_source = (ROOT / "app" / "route_modules" / filename).read_text(encoding="utf-8")
    assert "current_app.logger.exception" in route_source
    assert "Detalle: {exc}" not in route_source
for filename in ("products.py", "users.py"):
    route_source = (ROOT / "app" / "route_modules" / filename).read_text(encoding="utf-8")
    assert "Detalle: {exc}" not in route_source

print("OK: tamaño, contenido, dimensiones, lector y errores internos están protegidos.")
