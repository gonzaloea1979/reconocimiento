"""Verifica que el banco V99 mida el reporte con agregación previa en aislamiento."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "prueba_carga_v99.py").read_text(encoding="utf-8")
route = (ROOT / "app" / "route_modules" / "reports.py").read_text(encoding="utf-8")
assert 'TemporaryDirectory(prefix="terminal_pos_v99_")' in source
assert "No se abre ni modifica instance/pos.db" in source
assert "127.0.0.1" in source and "ThreadPoolExecutor" in source
assert "foreign_key_check" in source and "quick_check" in source
assert 'Cliente%2000050' in source and 'Proveedor%2000050' in source
assert 'V99' in source
assert "item_agg AS NOT MATERIALIZED" in route
assert "profit_before_fallback" in route
assert "fallback_quantity" in route
print("OK: banco V99 aislado y endpoint de reportes con agregación previa.")
