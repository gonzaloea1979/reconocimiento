"""V107: dos sesiones HTTP compran en paralelo el mismo stock, en BD temporal.

No abre instance/pos.db comercial. Requiere Flask en el equipo de prueba.
"""
from __future__ import annotations
import importlib.util
import os
import sys
import tempfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
if importlib.util.find_spec("flask") is None:
    print("SKIP: Flask no está instalado en este entorno; ejecutar en Windows con requirements.txt")
    raise SystemExit(77)

import app.config as config_module
from app import create_app
from app.db import get_db

with tempfile.TemporaryDirectory(prefix="pos_v107_two_users_") as temp:
    base = Path(temp)
    instance = base / "instance"
    for directory in (instance, base / "backups", base / "uploads", base / "TICKET"):
        directory.mkdir(parents=True, exist_ok=True)
    original_config = {
        key: getattr(config_module, key) for key in
        ("BASE_DIR", "INSTANCE_DIR", "BACKUP_DIR", "DATABASE", "UPLOAD_DIR", "TICKET_DIR")
    }
    try:
        config_module.BASE_DIR = base
        config_module.INSTANCE_DIR = instance
        config_module.BACKUP_DIR = base / "backups"
        config_module.DATABASE = instance / "pos.db"
        config_module.UPLOAD_DIR = base / "uploads"
        config_module.TICKET_DIR = base / "TICKET"
        with patch.dict(os.environ, {"POS_SEED_DEMO_PRODUCTS": "0"}):
            app = create_app()
        app.config.update(TESTING=True)

        def create_product(barcode, name, initial_stock):
            with app.app_context():
                db = get_db()
                stamp = "2026-11-01T12:00:00"
                cur = db.execute("""
                    INSERT INTO products
                      (barcode, name, detail, cost_without_tax, iva_percent,
                       gross_income_percent, total_cost, margin_percent,
                       rounding_mode, rounding_multiple, sale_price, stock,
                       expiry_date, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (barcode, name, "", 5, 0, 0, 5, 0, "none", 1,
                      10, initial_stock, None, stamp, stamp))
                db.commit()
                return cur.lastrowid

        def counts(product_id):
            with app.app_context():
                db = get_db()
                stock = db.execute("SELECT stock FROM products WHERE id=?", (product_id,)).fetchone()[0]
                sales = db.execute("SELECT COUNT(*) FROM sale_items WHERE product_id=?", (product_id,)).fetchone()[0]
                quantity = db.execute("SELECT COALESCE(SUM(quantity),0) FROM sale_items WHERE product_id=?", (product_id,)).fetchone()[0]
                return stock, sales, quantity

        def concurrent_sales(product_id, units, received):
            gate = Barrier(2)
            def sell(_index):
                with app.test_client() as client:
                    # Cada usuario virtual tiene cookies/sesión independientes.
                    login = client.get("/api/products")
                    assert login.status_code == 200, login.get_data(as_text=True)
                    gate.wait(timeout=20)
                    response = client.post("/api/sales", json={
                        "items": [{"product_id": product_id, "quantity": units}],
                        "payment_method": "Efectivo", "amount_received": received,
                    })
                    return response.status_code, response.get_json(silent=True)
            with ThreadPoolExecutor(max_workers=2) as pool:
                return list(pool.map(sell, range(2)))

        # Caso 1: ambas solicitudes son válidas en conjunto (2 + 2 <= 5).
        p1 = create_product("V107-SHARED-1", "Stock compartido válido", 5)
        results = concurrent_sales(p1, 2, 20)
        assert [r[0] for r in results] == [200, 200], results
        assert counts(p1) == (1, 2, 4), counts(p1)
        print("OK: dos ventas simultáneas aprobadas, dos tickets y stock 5 -> 1")

        # Caso 2: solamente una venta de 4 puede descontar stock inicial 5.
        p2 = create_product("V107-SHARED-2", "Stock compartido insuficiente", 5)
        results = concurrent_sales(p2, 4, 40)
        codes = sorted(code for code, _ in results)
        assert codes[0] == 200 and codes[1] in (400, 409), results
        assert counts(p2) == (1, 1, 4), counts(p2)
        print("OK: una venta rechazada sin sobrereserva ni segundo ticket")

        with app.app_context():
            db = get_db()
            assert db.execute("PRAGMA quick_check").fetchone()[0] == "ok"
            assert db.execute("PRAGMA foreign_key_check").fetchall() == []
        print("OK: SQLite quick_check y foreign_key_check")
    finally:
        for key, value in original_config.items():
            setattr(config_module, key, value)
