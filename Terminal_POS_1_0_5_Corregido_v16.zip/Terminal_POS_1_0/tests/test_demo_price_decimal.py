"""Prueba el cálculo de precios de demostración sin requerir Flask."""
import ast
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'app' / 'db.py').read_text(encoding='utf-8')
tree = ast.parse(source)
node = next((n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_calc_demo_prices'), None)
if node is None:
    raise SystemExit('ERROR: no se encontró _calc_demo_prices')
namespace = {'Decimal': Decimal, 'InvalidOperation': InvalidOperation, 'ROUND_HALF_UP': ROUND_HALF_UP}
exec(compile(ast.Module(body=[node], type_ignores=[]), str(ROOT / 'app' / 'db.py'), 'exec'), namespace)
calc = namespace['_calc_demo_prices']
cases = [
    ((0.10, 5, 0, 0), (0.11, 0.11)),
    ((2.675, 0, 0, 0), (2.68, 2.68)),
    ((19.99, 21, 3, 35), (24.79, 33.46)),
]
for args, expected in cases:
    actual = calc(*args)
    if actual != expected:
        raise SystemExit(f'ERROR: _calc_demo_prices{args!r}: esperado {expected}, obtenido {actual}')
try:
    calc('NaN', 0, 0, 0)
except ValueError:
    pass
else:
    raise SystemExit('ERROR: se deben rechazar valores no finitos')
print(f'OK: {len(cases)} cálculos de demostración decimales y rechazo de NaN')
