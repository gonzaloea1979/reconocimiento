"""Prueba redondeo monetario comercial sin importar Flask."""
from tests.route_source import read_all_routes
import ast
import math
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = read_all_routes(ROOT)
tree = ast.parse(source)
wanted = {"money", "strict_number"}
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in wanted]
if {n.name for n in nodes} != wanted:
    raise SystemExit("ERROR: faltan funciones de normalización monetaria")
namespace = {"Decimal": Decimal, "InvalidOperation": InvalidOperation, "ROUND_HALF_UP": ROUND_HALF_UP, "math": math}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(ROOT / "app" / "routes.py"), "exec"), namespace)
money = namespace["money"]
strict_number = namespace["strict_number"]
cases = [("2.675", 2.68), ("1.005", 1.01), ("-2.675", -2.68), ("12.344", 12.34), ("12.345", 12.35)]
for raw, expected in cases:
    actual = money(raw)
    if actual != expected:
        raise SystemExit(f"ERROR: money({raw!r}) esperado {expected}, obtenido {actual}")
if money("NaN") != 0.0 or money("Infinity") != 0.0:
    raise SystemExit("ERROR: money debe normalizar valores no finitos")
if strict_number("2.675", "Importe") != 2.68:
    raise SystemExit("ERROR: strict_number no aplica redondeo HALF_UP")
try:
    strict_number("NaN", "Importe")
except ValueError:
    pass
else:
    raise SystemExit("ERROR: strict_number debe rechazar NaN")
print(f"OK: {len(cases)} importes, empates HALF_UP y validación de no finitos")

# La entrada de precio del carrito debe compensar el caso binario 1.005 en JS.
js_source = (ROOT / "app" / "static" / "js" / "sales.js").read_text(encoding="utf-8")
if "window.POSMoneyDecimal.roundPrice(raw, 'none', 1)" not in js_source:
    raise SystemExit("ERROR: el precio manual de venta no usa el redondeo decimal compartido")
if "Math.round((price + Number.EPSILON) * 100) / 100" not in js_source:
    raise SystemExit("ERROR: falta el fallback de redondeo cuando el helper no está disponible")
print("OK: el precio manual de venta usa el redondeo decimal compartido y conserva fallback")
