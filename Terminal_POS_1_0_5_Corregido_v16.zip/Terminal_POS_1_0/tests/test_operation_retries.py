"""Duplicados y reintentos HTTP reales sobre datos ficticios temporales."""
import os
import sys
import sqlite3
import tempfile
from pathlib import Path
from threading import Barrier
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))
import app.config as config
from app import create_app
from app.db import get_db

keys = ('BASE_DIR','INSTANCE_DIR','BACKUP_DIR','DATABASE','UPLOAD_DIR','TICKET_DIR')
saved = {key:getattr(config,key) for key in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_operation_retries_') as tmp:
        base=Path(tmp)
        for key,value in dict(BASE_DIR=base,INSTANCE_DIR=base/'instance',BACKUP_DIR=base/'backups',
                              DATABASE=base/'instance'/'pos.db',UPLOAD_DIR=base/'uploads',TICKET_DIR=base/'TICKET').items():
            setattr(config,key,value)
        with patch.dict(os.environ,{'POS_SEED_DEMO_PRODUCTS':'0'}): app=create_app()
        app.config['TESTING']=True
        client=app.test_client(); assert client.get('/api/products').status_code==200
        product=client.post('/api/products',json={'barcode':'RETRY-1','name':'Prueba','cost_without_tax':10,'stock':100})
        assert product.status_code==201,product.json
        pid=product.json['id']
        cid=client.post('/api/clients',json={'name':'Cliente reintento','balance':100}).json['id']
        assert client.post('/api/cash/open',json={'initial_amount':100}).status_code==200
        sale={'items':[{'product_id':pid,'quantity':1}],'payment_method':'Efectivo','amount_received':10}
        purchase={'supplier_name':'Proveedor','items':[{'product_id':pid,'quantity':2,'cost_without_tax':10,'total_cost':10,'sale_price':10}]}
        payment={'amount':10,'description':'Pago de prueba'}
        def query(sql,args=()):
            with app.app_context(): return [tuple(row) for row in get_db().execute(sql,args)]
        def post(url,payload,key,cl=None):
            return (cl or client).post(url,json=payload,headers={'Idempotency-Key':key})
        cases=[('/api/sales',sale,'sales','sale_id'),('/api/purchases',purchase,'purchases','purchase_id'),
               (f'/api/clients/{cid}/payment',payment,'client_movements','balance')]
        for index,(url,payload,table,result_field) in enumerate(cases):
            key=f'retry-sequential-{index:04d}'
            before=query(f'SELECT COUNT(*) FROM {table}')[0][0]
            first=post(url,payload,key)
            assert first.status_code==200,first.json
            replay=post(url,dict(reversed(list(payload.items()))),key)
            assert replay.status_code==200 and replay.json==first.json,(first.json,replay.json)
            assert replay.headers.get('Idempotency-Replayed')=='true'
            assert query(f'SELECT COUNT(*) FROM {table}')[0][0]==before+1
            changed=dict(payload); changed['notes']='Datos distintos'
            assert post(url,changed,key).status_code==409
            assert query(f'SELECT COUNT(*) FROM {table}')[0][0]==before+1
            assert post(url,payload,key+'-new').status_code==200
            assert query(f'SELECT COUNT(*) FROM {table}')[0][0]==before+2
        print('OK: ventas/compras/pagos repetidos una sola vez; conflicto y operación idéntica nueva diferenciados')

        for index,(url,payload,table,result_field) in enumerate(cases):
            gate=Barrier(2)
            key=f'retry-concurrent-{index:04d}'
            before=query(f'SELECT COUNT(*) FROM {table}')[0][0]
            def send(_):
                cl=app.test_client(); assert cl.get('/api/products').status_code==200
                gate.wait(timeout=10)
                response=post(url,payload,key,cl)
                return response.status_code,response.json,response.headers.get('Idempotency-Replayed')
            with ThreadPoolExecutor(2) as pool: responses=list(pool.map(send,range(2)))
            assert [r[0] for r in responses]==[200,200],responses
            assert responses[0][1]==responses[1][1],responses
            assert sum(r[2]=='true' for r in responses)==1,responses
            assert query(f'SELECT COUNT(*) FROM {table}')[0][0]==before+1
        assert query('SELECT balance FROM clients WHERE id=?',(cid,))==[(70,)]
        assert query('SELECT stock FROM products WHERE id=?',(pid,))==[(103,)]
        assert query('SELECT COUNT(*) FROM cash_movements')==[(6,)]
        print('OK: dos confirmaciones simultáneas devuelven el mismo resultado y afectan stock/saldo/caja una sola vez')

        # Fallar después de las escrituras del negocio y antes de su confirmación:
        # no puede quedar una venta sin recibo que se duplique al reintentar.
        before=[query(sql) for sql in ('SELECT COUNT(*) FROM sales','SELECT stock FROM products',
                                      'SELECT COUNT(*) FROM cash_movements','SELECT COUNT(*) FROM operation_receipts')]
        with app.app_context():
            db=get_db()
            db.execute("CREATE TRIGGER fail_receipt BEFORE INSERT ON operation_receipts BEGIN SELECT RAISE(ABORT, 'fallo simulado recibo'); END")
            db.commit()
        with patch.object(app.logger,'exception'):
            failed=post('/api/sales',sale,'retry-atomic-failure')
        assert failed.status_code==500,failed.json
        after=[query(sql) for sql in ('SELECT COUNT(*) FROM sales','SELECT stock FROM products',
                                     'SELECT COUNT(*) FROM cash_movements','SELECT COUNT(*) FROM operation_receipts')]
        assert before==after,(before,after)
        with app.app_context():
            db=get_db(); db.execute('DROP TRIGGER fail_receipt'); db.commit()
        recovered=post('/api/sales',sale,'retry-atomic-failure')
        assert recovered.status_code==200,recovered.json
        print('OK: fallo al guardar confirmación revierte toda la operación; reintento posterior válido')

        invalid=post('/api/sales',{'items':[]},'retry-invalid-payload')
        assert invalid.status_code==400
        assert post('/api/sales',sale,'retry-invalid-payload').status_code==200
        assert post('/api/sales',sale,'short').status_code==400
        assert post('/api/sales',[], 'retry-not-an-object').status_code==400
        # Recrear la aplicación, con la misma base, simula reinicio del servidor.
        with patch.dict(os.environ,{'POS_SEED_DEMO_PRODUCTS':'0'}): restarted=create_app()
        restarted.config['TESTING']=True
        restarted_client=restarted.test_client()
        replay=post('/api/sales',sale,'retry-atomic-failure',restarted_client)
        assert replay.status_code==200 and replay.json==recovered.json
        assert replay.headers.get('Idempotency-Replayed')=='true'
        assert query('PRAGMA quick_check')==[('ok',)]
        assert query('PRAGMA foreign_key_check')==[]
        print('OK: errores no consumen clave; reinicio conserva confirmaciones; base íntegra')
finally:
    for key,value in saved.items(): setattr(config,key,value)
