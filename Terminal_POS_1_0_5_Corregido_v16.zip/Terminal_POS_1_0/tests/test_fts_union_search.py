"""Cada columna de búsqueda FTS5 debe usar el índice trigram y conservar resultados."""
import sqlite3
import re
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
queries = {
    "products": {
        "table": "products", "fts": "products_search", "alias": "p",
        "columns": ("barcode", "name", "detail"), "limit": 100,
    },
    "clients": {
        "table": "clients", "fts": "clients_search", "alias": "c",
        "columns": ("name", "document", "phone"), "limit": 200,
    },
    "suppliers": {
        "table": "suppliers", "fts": "suppliers_search", "alias": "s",
        "columns": ("name", "cuit", "phone", "category"), "limit": 200,
    },
}

with tempfile.TemporaryDirectory(prefix="pos_fts_union_") as tmp:
    db = sqlite3.connect(Path(tmp) / "search.db")
    db.executescript("""
        CREATE TABLE products(id INTEGER PRIMARY KEY, barcode TEXT, name TEXT, detail TEXT);
        CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT, document TEXT, phone TEXT);
        CREATE TABLE suppliers(id INTEGER PRIMARY KEY, name TEXT, cuit TEXT, phone TEXT, category TEXT);
        CREATE INDEX idx_products_name ON products(name);
        CREATE INDEX idx_clients_name ON clients(name);
        CREATE INDEX idx_suppliers_name ON suppliers(name);
    """)
    db.executemany("INSERT INTO products VALUES(?,?,?,?)",
                   [(i, f"77996{i:07d}", f"Producto {i:05d}", f"Detalle sintético {i:05d}") for i in range(1, 10001)])
    db.executemany("INSERT INTO clients VALUES(?,?,?,?)",
                   [(i, f"Cliente {i:05d}", f"200{i:07d}", f"351500{i:05d}") for i in range(1, 2001)])
    db.executemany("INSERT INTO suppliers VALUES(?,?,?,?,?)",
                   [(i, f"Proveedor {i:05d}", f"307{i:08d}", f"351400{i:05d}", "Categoría prueba") for i in range(1, 301)])

    for table, spec in queries.items():
        fts = spec["fts"]
        columns = spec["columns"]
        col_sql = ",".join(columns)
        db.execute(
            f"CREATE VIRTUAL TABLE {fts} USING fts5({col_sql}, content='{table}', content_rowid='id', tokenize='trigram')"
        )
        db.execute(f"INSERT INTO {fts}({fts}) VALUES('rebuild')")
        pattern = "%0500%"
        old_where = " OR ".join(f"fts.{column} LIKE ?" for column in columns)
        old_sql = (
            f"SELECT base.id FROM {fts} fts JOIN {table} base ON base.id=fts.rowid "
            f"WHERE {old_where} ORDER BY base.name LIMIT {spec['limit']}"
        )
        union_terms = " UNION ".join(f"SELECT rowid FROM {fts} WHERE {column} LIKE ?" for column in columns)
        new_sql = (
            f"SELECT base.id FROM {table} base JOIN ({union_terms}) matches "
            f"ON matches.rowid=base.id ORDER BY base.name LIMIT {spec['limit']}"
        )
        params = (pattern,) * len(columns)
        old_rows = db.execute(old_sql, params).fetchall()
        new_rows = db.execute(new_sql, params).fetchall()
        assert old_rows == new_rows, f"Cambió el resultado de {table}: {old_rows[:5]} != {new_rows[:5]}"
        plan = " ".join(row[3] for row in db.execute("EXPLAIN QUERY PLAN " + new_sql, params))
        assert len(re.findall(r"VIRTUAL TABLE INDEX \d+:L\d+", plan)) == len(columns), (table, plan)

    # El selector de ventas conserva su prioridad de coincidencia por prefijo.
    pattern = "%0500%"
    old_lookup = """SELECT p.id FROM products_search ps JOIN products p ON p.id=ps.rowid
        WHERE ps.barcode LIKE ? OR ps.name LIKE ? OR ps.detail LIKE ?
        ORDER BY CASE WHEN p.name LIKE ? THEN 0 ELSE 1 END,p.name LIMIT 20"""
    new_lookup = """SELECT p.id FROM products p JOIN (
        SELECT rowid FROM products_search WHERE barcode LIKE ?
        UNION SELECT rowid FROM products_search WHERE name LIKE ?
        UNION SELECT rowid FROM products_search WHERE detail LIKE ?
        ) matches ON matches.rowid=p.id
        ORDER BY CASE WHEN p.name LIKE ? THEN 0 ELSE 1 END,p.name LIMIT 20"""
    lookup_params = (pattern, pattern, pattern, "Producto 0500%")
    assert db.execute(old_lookup, lookup_params).fetchall() == db.execute(new_lookup, lookup_params).fetchall()

    product_source = (ROOT / "app" / "route_modules" / "products.py").read_text(encoding="utf-8")
    client_source = (ROOT / "app" / "route_modules" / "clients.py").read_text(encoding="utf-8")
    supplier_source = (ROOT / "app" / "route_modules" / "suppliers.py").read_text(encoding="utf-8")
    assert product_source.count("UNION") >= 4  # listado y selector de ventas
    assert "UNION" in client_source
    assert "UNION" in supplier_source
    db.close()

print("OK: búsquedas FTS5 equivalentes y cada columna utiliza su índice trigram individual.")
