"""Ejecuta la migración real de app/db.py contra una base histórica temporal.

Se sustituye únicamente el proxy mínimo de Flask que init_db necesita (current_app.config).
No se importa la aplicación ni se toca la base de datos del negocio.
"""
from __future__ import annotations
import importlib.util
import os
import sqlite3
import sys
import tempfile
import types
from pathlib import Path
from contextlib import closing

ROOT = Path(__file__).resolve().parents[1]
DB_SOURCE = ROOT / "app" / "db.py"

class FakeCurrentApp:
    config = {}

fake_flask = types.ModuleType("flask")
fake_flask.current_app = FakeCurrentApp()
fake_flask.g = types.SimpleNamespace()
old_flask = sys.modules.get("flask")
sys.modules["flask"] = fake_flask
try:
    spec = importlib.util.spec_from_file_location("_pos_db_migration_test", DB_SOURCE)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
finally:
    if old_flask is None:
        sys.modules.pop("flask", None)
    else:
        sys.modules["flask"] = old_flask

with tempfile.TemporaryDirectory(prefix="pos_migration_test_") as temp:
    db_path = Path(temp) / "legacy.db"
    fake_flask.current_app.config = {"DATABASE": db_path}
    # Esquema legado reducido, pero con las columnas base presentes en versiones anteriores.
    with closing(sqlite3.connect(db_path)) as conn:
        conn.executescript("""
            CREATE TABLE products(
                id INTEGER PRIMARY KEY AUTOINCREMENT, barcode TEXT UNIQUE, name TEXT NOT NULL,
                detail TEXT, cost_without_tax REAL NOT NULL DEFAULT 0, iva_percent REAL NOT NULL DEFAULT 0,
                gross_income_percent REAL NOT NULL DEFAULT 0, total_cost REAL NOT NULL DEFAULT 0,
                margin_percent REAL NOT NULL DEFAULT 0, sale_price REAL NOT NULL DEFAULT 0,
                stock REAL NOT NULL DEFAULT 0, expiry_date TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, total REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
            CREATE TABLE sale_items(
                id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL, unit_price REAL NOT NULL, quantity REAL NOT NULL,
                line_total REAL NOT NULL, created_at TEXT NOT NULL
            );
            CREATE TABLE purchase_items(
                id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 0, unit_cost REAL NOT NULL DEFAULT 0,
                line_total REAL NOT NULL, created_at TEXT NOT NULL
            );
            CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE);
            INSERT INTO products(barcode,name,stock,created_at,updated_at) VALUES ('OLD-1','Producto legado',7,'2025-01-01','2025-01-01');
            INSERT INTO sales(total,created_at) VALUES (125.5,'2025-01-01T10:00:00');
        """)
    os.environ.pop("POS_SEED_DEMO_PRODUCTS", None)
    module.init_db()
    module.init_db()  # Repetir la inicialización debe ser idempotente.
    with closing(sqlite3.connect(db_path)) as conn:
        assert conn.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        product = conn.execute("SELECT name, stock FROM products WHERE id=1").fetchone()
        sale = conn.execute("SELECT total FROM sales WHERE id=1").fetchone()
        assert product == ("Producto legado", 7.0), product
        assert sale == (125.5,), sale
        product_columns = {row[1] for row in conn.execute("PRAGMA table_info(products)")}
        sale_columns = {row[1] for row in conn.execute("PRAGMA table_info(sales)")}
        item_columns = {row[1] for row in conn.execute("PRAGMA table_info(sale_items)")}
        purchase_item_columns = {row[1] for row in conn.execute("PRAGMA table_info(purchase_items)")}
        user_columns = {row[1] for row in conn.execute("PRAGMA table_info(users)")}
        assert {"photo_path", "min_stock", "supplier_id", "rounding_mode", "rounding_multiple"} <= product_columns
        assert {"payment_method", "amount_received", "change_amount", "cashier_name", "client_id", "cash_session_id", "sale_type"} <= sale_columns
        assert "unit_cost_at_sale" in item_columns
        assert {"cost_without_tax", "iva_percent", "gross_income_percent", "total_cost", "margin_percent", "sale_price", "expiry_date"} <= purchase_item_columns
        assert {"full_name", "role", "password_hash", "is_active", "created_at", "updated_at"} <= user_columns
        assert conn.execute("SELECT COUNT(*) FROM products").fetchone()[0] == 1
        assert conn.execute("SELECT COUNT(*) FROM sales").fetchone()[0] == 1

print("OK: migración real de esquema legado, datos preservados e init_db idempotente")
