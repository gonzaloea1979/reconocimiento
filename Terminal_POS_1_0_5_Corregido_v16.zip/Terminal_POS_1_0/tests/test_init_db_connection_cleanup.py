"""La conexión de inicialización debe cerrarse incluso ante fallas de migración."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / 'app' / 'db.py').read_text(encoding='utf-8')
start = source.index('def init_db():')
end = source.index('\n\ndef get_settings():', start)
body = source[start:end]
assert 'try:' in body and 'finally:' in body
assert 'db.close()' in body[body.index('finally:'):]
assert body.rstrip().endswith('db.close()')
print('OK: init_db libera la conexión aunque falle una migración')
