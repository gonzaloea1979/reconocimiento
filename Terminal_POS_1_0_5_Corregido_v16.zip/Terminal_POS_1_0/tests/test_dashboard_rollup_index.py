"""El índice de cobertura acelera los rankings del Dashboard sin cambiar resultados."""
import sqlite3
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
db_source = (ROOT / "app" / "db.py").read_text(encoding="utf-8")
assert "DROP INDEX IF EXISTS idx_sale_items_product_id" in db_source
assert "idx_sale_items_product_rollup" in db_source
assert "ON sale_items(product_id, product_name, quantity, line_total)" in db_source

TOP_SQL = """SELECT product_name,SUM(quantity) qty,SUM(line_total) amount
FROM sale_items GROUP BY product_id,product_name
ORDER BY qty DESC,amount DESC LIMIT 10"""
LEAST_SQL = """SELECT p.name,COALESCE(SUM(si.quantity),0) qty,COALESCE(SUM(si.line_total),0) amount
FROM products p LEFT JOIN sale_items si ON si.product_id=p.id
GROUP BY p.id,p.name ORDER BY qty ASC,amount ASC,p.name ASC LIMIT 10"""

with tempfile.TemporaryDirectory(prefix="pos_dashboard_rollup_") as tmp:
    old_db = sqlite3.connect(Path(tmp) / "old.db")
    new_db = sqlite3.connect(Path(tmp) / "new.db")
    schema = """
        CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
        CREATE TABLE sale_items(
            id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL, quantity REAL NOT NULL, line_total REAL NOT NULL
        );
        CREATE INDEX idx_products_name ON products(name);
    """
    for db in (old_db, new_db):
        db.executescript(schema)
        db.executemany("INSERT INTO products(id,name) VALUES(?,?)",
                       [(i, f"Producto {i:05d}") for i in range(1, 1001)])
        db.executemany(
            "INSERT INTO sale_items(id,sale_id,product_id,product_name,quantity,line_total) VALUES(?,?,?,?,?,?)",
            [(i, i // 3 + 1, (i - 1) // 6 + 1, f"Producto {(i - 1) // 6 + 1:05d}",
              float((i - 1) // 6 + 1), float(((i - 1) // 6 + 1) * 250)) for i in range(1, 6001)],
        )
    old_db.execute("CREATE INDEX idx_sale_items_product_id ON sale_items(product_id)")
    new_db.execute(
        "CREATE INDEX idx_sale_items_product_rollup ON sale_items(product_id,product_name,quantity,line_total)"
    )
    old_db.commit(); new_db.commit()

    for sql in (TOP_SQL, LEAST_SQL):
        old_rows = old_db.execute(sql).fetchall()
        new_rows = new_db.execute(sql).fetchall()
        assert old_rows == new_rows, "El índice cambió el resultado de los rankings."

    top_plan = " ".join(str(row[3]) for row in new_db.execute("EXPLAIN QUERY PLAN " + TOP_SQL))
    least_plan = " ".join(str(row[3]) for row in new_db.execute("EXPLAIN QUERY PLAN " + LEAST_SQL))
    assert "idx_sale_items_product_rollup" in top_plan, top_plan
    assert "COVERING INDEX idx_sale_items_product_rollup" in top_plan, top_plan
    assert "USE TEMP B-TREE FOR GROUP BY" not in top_plan, top_plan
    assert "COVERING INDEX idx_sale_items_product_rollup" in least_plan, least_plan

    old_indexes = {row[1] for row in old_db.execute("PRAGMA index_list(sale_items)")}
    new_indexes = {row[1] for row in new_db.execute("PRAGMA index_list(sale_items)")}
    assert "idx_sale_items_product_id" in old_indexes
    assert "idx_sale_items_product_rollup" in new_indexes
    assert "idx_sale_items_product_id" not in new_indexes

    old_db.close(); new_db.close()

print("OK: rankings equivalentes; índice de cobertura utilizado y GROUP BY temporal eliminado en top productos.")
