"""Comprueba precisión textual y notación científica del helper monetario JS."""
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
node = shutil.which('node')
if not node:
    print('SKIP: Node.js no está instalado; prueba del helper JS no ejecutada')
    raise SystemExit(77)
helper = ROOT / 'app' / 'static' / 'js' / 'money_decimal.js'
script = r'''
const path = process.argv[1];
require(path);
const money = globalThis.POSMoneyDecimal;
const cases = [
  ['2.675', 2.68],
  ['2.675e0', 2.68],
  ['1.005', 1.01],
  ['1.0049999', 1.00],
  ['1e-3', 0.00],
  ['-2.675e0', -2.68],
];
for (const [input, expected] of cases) {
  const actual = money.roundPrice(input, 'none', 1);
  if (Math.abs(actual - expected) > 1e-9) {
    throw new Error(`${input}: esperado ${expected}, obtenido ${actual}`);
  }
}
const preview = money.calculatePriceValues('2.675e0', '0', '0', '0', 'none', '1');
if (preview.salePrice !== 2.68) throw new Error(`vista previa inesperada: ${preview.salePrice}`);
console.log(`OK: ${cases.length} importes exactos, notación científica y vista previa`);
'''
result = subprocess.run([node, '-e', script, str(helper)], cwd=ROOT, text=True, capture_output=True)
if result.returncode:
    print(result.stdout)
    print(result.stderr, file=sys.stderr)
    raise SystemExit(result.returncode)
print(result.stdout.strip())

purchases = (ROOT / 'app' / 'static' / 'js' / 'purchases.js').read_text(encoding='utf-8')
if "const cost = document.getElementById('purchaseCost')?.value || '0';" not in purchases:
    raise SystemExit('ERROR: la vista previa de Compras debe conservar el texto decimal original')
if 'purchaseCalculateValues(costWithoutTaxInput, ivaPercentInput, grossPercentInput, marginPercentInput)' not in purchases:
    raise SystemExit('ERROR: el alta de compra debe calcular con los textos originales')
print('OK: Compras conserva los textos decimales hasta el cálculo compartido')
