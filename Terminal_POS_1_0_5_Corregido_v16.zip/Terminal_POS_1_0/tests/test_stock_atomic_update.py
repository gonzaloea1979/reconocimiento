"""Prueba que la actualización condicional de stock no permite sobregiro concurrente."""
import sqlite3
import tempfile
from contextlib import closing
import threading
from pathlib import Path

with tempfile.TemporaryDirectory(prefix="pos_stock_race_") as temp:
    db_path = Path(temp) / "stock.db"
    # sqlite3.Connection como context manager confirma/revierte transacciones,
    # pero NO cierra la conexión. closing() garantiza liberar el archivo en Windows.
    with closing(sqlite3.connect(db_path)) as db:
        with db:
            db.execute("CREATE TABLE products (id INTEGER PRIMARY KEY, stock REAL NOT NULL)")
            db.execute("INSERT INTO products (id, stock) VALUES (1, 5)")
    barrier = threading.Barrier(2)
    outcomes = []
    lock = threading.Lock()
    def sell_four():
        conn = sqlite3.connect(db_path, timeout=5)
        try:
            barrier.wait(timeout=3)
            cur = conn.execute("UPDATE products SET stock=ROUND(stock - ?, 2) WHERE id=? AND stock + 0.000001 >= ?", (4, 1, 4))
            conn.commit()
            with lock:
                outcomes.append(cur.rowcount)
        finally:
            conn.close()
    threads = [threading.Thread(target=sell_four) for _ in range(2)]
    for thread in threads: thread.start()
    for thread in threads: thread.join(timeout=8)
    if any(thread.is_alive() for thread in threads):
        raise SystemExit("ERROR: la prueba de concurrencia quedó bloqueada")
    with closing(sqlite3.connect(db_path)) as db:
        stock = db.execute("SELECT stock FROM products WHERE id=1").fetchone()[0]
    if sorted(outcomes) != [0, 1] or stock != 1:
        raise SystemExit(f"ERROR: resultados concurrentes incorrectos: {outcomes=}, {stock=}")
print("OK: dos descuentos concurrentes de 4 con stock 5: solo uno se aplica, stock final 1")
