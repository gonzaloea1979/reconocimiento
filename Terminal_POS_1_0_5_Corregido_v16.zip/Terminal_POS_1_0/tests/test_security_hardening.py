"""Comprobaciones estáticas básicas de seguridad de sesión y credenciales nuevas."""
from tests.route_source import read_all_routes
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
routes = read_all_routes(ROOT)
config = (ROOT / 'app' / 'config.py').read_text(encoding='utf-8')
db = (ROOT / 'app' / 'db.py').read_text(encoding='utf-8')
tree = ast.parse(routes)
needed = {'current_user_role', 'current_user_is_admin'}
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in needed]
class Session(dict):
    pass
namespace = {'session': Session(local_auto_login=True, authenticated_login=False, username='admin'), 'current_user_row': lambda: {'role': 'Administrador'}}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(ROOT / 'app' / 'routes.py'), 'exec'), namespace)
assert namespace['current_user_role']() == 'Cajero'
assert namespace['current_user_is_admin']() is False
namespace['session'] = Session(local_auto_login=False, authenticated_login=False, passwordless_admin_login=True, username='admin')
assert namespace['current_user_is_admin']() is True
# La identidad y el rol se resuelven por username, no por coincidencias de nombre visible.
current_user_node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'current_user_row')
current_user_source = ast.get_source_segment(routes, current_user_node) or ''
assert 'LOWER(username)=LOWER(?)' in current_user_source
assert 'LOWER(full_name)=LOWER(?)' not in current_user_source
namespace['session'] = Session(local_auto_login=False, authenticated_login=True, username='admin')
assert namespace['current_user_is_admin']() is True
if 'admin123' in config or "generate_password_hash(current_app.config.get('ADMIN_PASSWORD'" in db:
    raise SystemExit('ERROR: se detectó una credencial predeterminada nueva')

# La ruta de cierre debe exigir sesión y solo aceptar booleano True para apagar la PC.
import ast
shutdown_node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'api_shutdown')
shutdown_source = ast.get_source_segment(routes, shutdown_node) or ''
assert "if not session.get('logged_in')" in shutdown_source, 'api_shutdown debe exigir una sesión previa sin autocrearla'
assert "if not active_admin_exists()" in shutdown_source, 'api_shutdown debe requerir configuración inicial'
assert "data.get('shutdown_pc') is True" in shutdown_source, 'apagado debe requerir booleano true'
assert "if shutdown_pc and not current_user_is_admin()" in shutdown_source, 'apagado físico debe exigir administrador'
assert "if not isinstance(data, dict)" in shutdown_source, 'payload de cierre debe validarse'

print('OK: sesión local limitada, credenciales nuevas y ruta de cierre protegida')
