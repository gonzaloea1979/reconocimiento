"""Prueba BAT/ACL/junction reales. Ejecutar únicamente en Windows con datos temporales."""
from pathlib import Path
import csv, hashlib, json, os, shutil, subprocess, sys, tempfile
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
if os.name!='nt':raise SystemExit('Esta comprobación requiere Windows real')
from preparar_entorno import prepare_environment
from preparar_compilacion_segura import check_output

def fixture(path):
    path.mkdir(parents=True)
    for name in ('preparar_entorno.py','verificar_dependencias.py','requirements.txt','instalar_dependencias.bat','ejecutar.bat'):
        shutil.copyfile(ROOT/name,path/name)
    (path/'app').mkdir();(path/'app/__init__.py').touch();(path/'logs').mkdir()
    (path/'run.py').write_text("import sys,os,json; from pathlib import Path; Path(os.environ['POS_BAT_SENTINEL']).write_text(json.dumps(dict(executable=sys.executable,prefix=sys.prefix,base_prefix=sys.base_prefix,cwd=os.getcwd())))",encoding='utf-8')
    return path

def batch(script,env,timeout=600):
    # /s elimina las comillas exteriores; las interiores protegen la ruta del BAT.
    command='cmd.exe /d /s /c ""'+str(script)+'" < nul"'
    result=subprocess.run(command,cwd=script.parent.parent,env=env,capture_output=True,encoding='utf-8',errors='replace',timeout=timeout)
    (script.parent/(script.stem+'-test-output.txt')).write_text(result.stdout+result.stderr,encoding='utf-8') if os.access(script.parent,os.W_OK) else None
    return result

with tempfile.TemporaryDirectory(prefix='pos_bat_real_') as tmp:
    base=Path(tmp).resolve();root=fixture(base/"Terminal POS ñ y apostrofe's (prueba)")
    private=root/'instance/pos.db';private.parent.mkdir();private.write_bytes(b'DATOS SINTETICOS NO ABRIR')
    digest=hashlib.sha256(private.read_bytes()).hexdigest();sentinel=base/'started.json'
    env=dict(os.environ,PYTHONUTF8='1',POS_BAT_SENTINEL=str(sentinel))
    first=batch(root/'instalar_dependencias.bat',env)
    assert first.returncode==0,first.stdout+first.stderr+(root/'logs/instalacion.log').read_text(encoding='utf-8')
    installed_log=(root/'logs/instalacion.log').read_text(encoding='utf-8');install_count=installed_log.count('Installing collected packages')
    again=batch(root/'instalar_dependencias.bat',env)
    assert again.returncode==0,again.stdout+again.stderr
    assert (root/'logs/instalacion.log').read_text(encoding='utf-8').count('Installing collected packages')==install_count
    launched=batch(root/'ejecutar.bat',env,120)
    assert launched.returncode==0,launched.stdout+launched.stderr
    actual=json.loads(sentinel.read_text());expected=(root/'.venv/Scripts/python.exe').resolve()
    assert Path(actual['executable']).resolve()==expected,actual
    assert Path(actual['cwd']).resolve()==root.resolve() and actual['prefix']!=actual['base_prefix']
    assert hashlib.sha256(private.read_bytes()).hexdigest()==digest
    print('OK BAT reales: instalación desde cero, repetición sin reinstalar y arranque con .venv; ruta con espacios/ñ/apóstrofe/paréntesis; datos preservados')
    sentinel.unlink()
    broken=fixture(base/'Entorno incompleto');(broken/'.venv').mkdir();marker=broken/'.venv/conservar.txt';marker.write_text('conservar')
    failed=batch(broken/'ejecutar.bat',env,120)
    assert failed.returncode!=0 and not sentinel.exists() and marker.read_text()=='conservar',failed.stdout+failed.stderr
    print('OK BAT real: entorno incompleto detiene arranque y conserva sus archivos')
    # Junction real: no seguir hacia directorios ajenos al preparar o limpiar.
    outside=base/'Carpeta externa';outside.mkdir();private=outside/'conservar.txt';private.write_text('no tocar')
    junction_root=fixture(base/'Con junction');junction=junction_root/'.venv'
    result=subprocess.run(['cmd.exe','/d','/c','mklink','/J',str(junction),str(outside)],capture_output=True,text=True)
    assert result.returncode==0,result.stdout+result.stderr
    try:
        try:prepare_environment(junction_root)
        except RuntimeError as exc:assert 'enlace' in str(exc),str(exc)
        else:raise AssertionError('Se aceptó .venv como junction')
        try:check_output(junction)
        except ValueError:pass
        else:raise AssertionError('Se permitió limpiar salida junction')
    finally:junction.rmdir()
    output=base/'Salida';output.mkdir();nested=output/'recursos'
    assert subprocess.run(['cmd.exe','/d','/c','mklink','/J',str(nested),str(outside)],capture_output=True).returncode==0
    try:
        try:check_output(output)
        except ValueError:pass
        else:raise AssertionError('Se permitió limpiar junction anidada')
    finally:nested.rmdir()
    assert private.read_text()=='no tocar'
    print('OK Windows: junctions reales rechazadas en .venv y salidas de compilación sin tocar el destino')
    # Denegar datos/atributos sin denegar READ_CONTROL/SYNCHRONIZE: (W) también
    # bloquea la apertura de lectura del BAT y no ejercita el diagnóstico interno.
    readonly=fixture(base/'Sin permisos de escritura')
    who=subprocess.check_output(['whoami','/user','/fo','csv','/nh'],text=True)
    sid='*'+next(csv.reader([who.strip()]))[1]  # icacls exige * para un SID numérico.
    grant=subprocess.run(['icacls',str(readonly),'/deny',sid+':(OI)(CI)(WD,AD,WEA,WA)'],capture_output=True,text=True)
    assert grant.returncode==0,grant.stdout+grant.stderr
    try:
        # No escribir salida de diagnóstico dentro de la carpeta denegada.
        command='cmd.exe /d /s /c ""'+str(readonly/'ejecutar.bat')+'" < nul"'
        failed=subprocess.run(command,cwd=base,env=env,capture_output=True,encoding='utf-8',errors='replace',timeout=120)
        assert failed.returncode!=0 and not sentinel.exists(),failed.stdout+failed.stderr
        assert 'permisos de escritura' in failed.stdout.lower(),failed.stdout+failed.stderr
        assert not (readonly/'.venv').exists()
    finally:
        restore=subprocess.run(['icacls',str(readonly),'/remove:d',sid,'/t','/c'],capture_output=True,text=True)
        assert restore.returncode==0,restore.stdout+restore.stderr
    print('OK Windows: permisos de escritura denegados detienen instalación y arranque; no se intenta elevar permisos')
