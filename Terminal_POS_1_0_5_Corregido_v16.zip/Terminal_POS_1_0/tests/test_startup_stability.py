"""Comprueba de forma estática las condiciones básicas de arranque local."""
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
run = (ROOT / "run.py").read_text(encoding="utf-8")
app = (ROOT / "app" / "__init__.py").read_text(encoding="utf-8")
assert 'HOST = "127.0.0.1"' in run
assert "use_reloader=False" in run and "debug=False" in run
assert "def _choose_port()" in run and "No se encontró un puerto libre" in run
assert "key_file = app.config['INSTANCE_DIR'] / '.session_key'" in app
assert "key_file.parent.mkdir" in app
print("OK: arranque sin reloader, puerto validado y clave de sesión persistente")

assert "len(secret_value) < 64" in app
assert "os.chmod(key_file, 0o600)" in app
assert "os.replace(temporary_key, key_file)" in app
