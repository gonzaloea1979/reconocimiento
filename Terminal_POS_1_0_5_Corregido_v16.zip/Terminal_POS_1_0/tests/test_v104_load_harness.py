"""V104 mide A/B del Dashboard y SQL real de reportes; solo 1-2 usuarios."""
from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "prueba_carga_v104.py"
spec = importlib.util.spec_from_file_location("pos_load_v104", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)
source = SCRIPT.read_text(encoding="utf-8")
assert "prueba_carga_v104.txt" in source
assert 'TemporaryDirectory(prefix="terminal_pos_v104_")' in source
assert 'for workers in (1, 2):' in source
assert 'for workers in (1, 2, 4, 8):' not in source
assert 'Dashboard rankings compartidos (actual)' in source
assert 'Dashboard top individual (diagnóstico)' in source
assert 'Dashboard menos vendidos individual (diagnóstico)' in source
assert 'Reportes resumen y pagos' in source
assert 'Reportes ranking y ganancia' in source
assert '"/api/stock/alerts?compact=1"' in source
assert '"/api/products?compact=1"' in source
assert module.format_cache_size(-8192, 4096) == "-8192 KiB (8.0 MiB)"
assert module.format_cache_size(8192, 4096) == "8192 páginas (32.0 MiB)"

# Verificar que el SQL del informe provenga de las rutas reales y sea el que mide el banco.
dash_sql = module._extract_route_assignment_sql(
    ROOT / "app/route_modules/dashboard.py", "api_dashboard", "rankings"
)
assert "product_rollup AS MATERIALIZED" in dash_sql
payment_sql = module._extract_route_assignment_sql(
    ROOT / "app/route_modules/reports.py", "api_reports", "payment_metrics"
)
rollup_sql = module._extract_route_assignment_sql(
    ROOT / "app/route_modules/reports.py", "api_reports", "report_rollups"
)
assert "GROUP BY payment_method" in payment_sql
assert "estimated_profit" in rollup_sql
print("OK: banco V104 aislado, A/B Dashboard, SQL real de reportes y concurrencia limitada a 1-2 usuarios.")
