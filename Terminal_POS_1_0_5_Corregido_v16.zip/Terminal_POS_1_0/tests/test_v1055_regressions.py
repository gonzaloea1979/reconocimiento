"""Regresión 1.0.5.5: campos de texto con tipo inválido devuelven 400, no 500.

Antes, endpoints de proveedores, clientes, usuarios, configuración, caja y
primer inicio hacían ``(data.get(...) or '').strip()``. Un JSON donde un campo
de texto llegaba como número, lista u objeto rompía con 500 (traza) en lugar de
responder 400. Ahora todos usan ``text_field`` y rechazan el tipo inválido con
un mensaje claro.

Usa una base temporal; nunca toca datos comerciales.
"""
from pathlib import Path
import os
import sys
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import app.config as config
from app import create_app

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {k: getattr(config, k) for k in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_v1055_regressions_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base / 'instance',
                               BACKUP_DIR=base / 'backups', DATABASE=base / 'instance' / 'pos.db',
                               UPLOAD_DIR=base / 'uploads', TICKET_DIR=base / 'TICKET').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = False
        app.logger.disabled = True
        client = app.test_client()
        assert client.get('/api/products').status_code == 200

        product = client.post('/api/products', json={
            'name': 'P', 'cost_without_tax': 100, 'iva_percent': 21,
            'margin_percent': 30, 'stock': 10,
        }).get_json()
        supplier = client.post('/api/suppliers', json={'name': 'S'}).get_json()
        customer = client.post('/api/clients', json={'name': 'C'}).get_json()

        # (método, ruta, cuerpo) — todos deben responder 400, nunca 500.
        cases = [
            ('post', '/api/suppliers', {'name': 'S2', 'cuit': 12345}),
            ('put', f"/api/suppliers/{supplier['id']}", {'name': 'S3', 'cuit': 12345}),
            ('post', '/api/clients', {'name': 'C2', 'document': 12345}),
            ('post', '/api/clients', {'name': 'C3', 'phone': [1, 2]}),
            ('put', f"/api/clients/{customer['id']}", {'name': 'C4', 'address': 99}),
            ('post', '/api/settings', {'business_name': 'N', 'business_cuit': 12345}),
            ('post', '/api/ticket-settings', {'ticket_footer': 99}),
            ('post', '/api/users', {'username': 'nuevo', 'role': 'Cajero',
                                    'user_password': '1234', 'full_name': 99}),
            ('post', '/api/users', {'username': 12345, 'role': 'Cajero', 'user_password': '1234'}),
            ('post', '/api/cash/movement', {'movement_type': ['Ingreso'], 'amount': 10}),
            ('post', '/api/stock/adjust', {'product_id': product['id'], 'new_stock': 5, 'notes': 99}),
            ('post', '/api/login', {'username': 12345, 'password': 'x'}),
            ('post', '/api/login', {'username': 'admin', 'password': 12345}),
        ]
        for method, path, body in cases:
            response = getattr(client, method)(path, json=body)
            assert response.status_code == 400, (method, path, response.status_code, response.get_data(as_text=True)[:120])

        # Un cuerpo de texto válido sigue funcionando (no rompimos el caso correcto).
        ok = client.post('/api/suppliers', json={'name': 'Proveedor Válido', 'cuit': '20-12345678-9'})
        assert ok.status_code == 201, ok.get_json()
        assert ok.get_json()['cuit'] == '20-12345678-9'

        print('OK: los campos de texto inválidos responden 400, no 500')
finally:
    for key, value in saved.items():
        setattr(config, key, value)
