"""Comparación JS contra Decimal en entradas sintéticas reproducibles."""
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
import json
import random
import shutil
import subprocess

node=shutil.which('node')
if not node:
    print('SKIP: Node.js requerido para comparar aritmética JS/Decimal')
    raise SystemExit(77)
root=Path(__file__).resolve().parents[1]
rng=random.Random(103)
prices=[[str(Decimal(rng.randint(1,100000))/100),str(Decimal(rng.randint(0,2100))/100),
         str(Decimal(rng.randint(0,1000))/100),str(Decimal(rng.randint(0,10000))/100)] for _ in range(12000)]
lines=[[str(Decimal(rng.randint(1,100000))/1000),str(Decimal(rng.randint(1,100000))/1000)] for _ in range(1000)]
script=r'''
require(process.argv[1]); let data='';
process.stdin.on('data',chunk=>data+=chunk);
process.stdin.on('end',()=>{
 const input=JSON.parse(data), m=POSMoneyDecimal;
 process.stdout.write(JSON.stringify({prices:input.prices.map(row=>m.calculatePriceValues(...row,'none',1)),
   lines:input.lines.map(row=>m.lineTotal(...row)),sum:m.sumAmounts(input.lines.map(row=>m.lineTotal(...row)))}));
});
'''
result=subprocess.run([node,'-e',script,str(root/'app/static/js/money_decimal.js')],input=json.dumps({'prices':prices,'lines':lines}),text=True,capture_output=True,timeout=20)
assert result.returncode==0,result.stdout+result.stderr
actual=json.loads(result.stdout)
round2=lambda value: value.quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
for row,out in zip(prices,actual['prices']):
    c,i,g,m=map(Decimal,row); cost=c+c*i/100+c*g/100; sale=cost+cost*m/100
    assert out['totalCost']==float(round2(cost)) and out['salePrice']==float(round2(sale)),(row,out,cost,sale)
expected=[]
for row,out in zip(lines,actual['lines']):
    p,q=map(Decimal,row); value=round2(round2(p)*round2(q)); expected.append(value)
    assert out==float(value),(row,out,value)
assert actual['sum']==float(sum(expected))
print('OK: 12.000 precios y 1.000 renglones/suma coinciden entre JavaScript y Decimal')
