"""Errores HTTP reales: no persistir contraseñas, cuerpos, consultas o cookies."""
from pathlib import Path
import http.cookiejar,json,logging,os,sys,tempfile,threading,urllib.error,urllib.request
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import app.config as config
from app import create_app
from app.db import get_db
from app.logging_config import configure_diagnostic_logging,DiagnosticFilter
import app.route_modules.users as users
import app.route_services.documents as documents
import app.route_services.barcodes as barcodes
keys=('BASE_DIR','INSTANCE_DIR','BACKUP_DIR','DATABASE','UPLOAD_DIR','TICKET_DIR');saved={k:getattr(config,k) for k in keys}
secret='SYNTHETIC_PRIVATE_91d2f0_no_real_credentials'
try:
    with tempfile.TemporaryDirectory(prefix='pos_diagnostic_privacy_') as tmp:
        base=Path(tmp)
        for k,v in dict(BASE_DIR=base,INSTANCE_DIR=base/'instance',BACKUP_DIR=base/'backups',DATABASE=base/'instance/pos.db',UPLOAD_DIR=base/'uploads',TICKET_DIR=base/'tickets').items():setattr(config,k,v)
        app=create_app();app.config.update(TESTING=False,PROPAGATE_EXCEPTIONS=False)
        path=base/'diagnostic.log';handler=logging.FileHandler(path,encoding='utf-8')
        handler.setFormatter(logging.Formatter('%(levelname)s %(name)s %(message)s'))
        app.logger.addHandler(handler);wz=logging.getLogger('werkzeug');wz.addHandler(handler)
        configure_diagnostic_logging(app)
        from werkzeug.serving import make_server
        server=make_server('127.0.0.1',0,app,threaded=True);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        def request(path,data=None):
            req=urllib.request.Request(f'http://127.0.0.1:{server.server_port}'+path,data=None if data is None else json.dumps(data).encode(),headers={'Content-Type':'application/json','X-Test-Private':secret})
            try:
                with client.open(req,timeout=10) as response:return response.status,json.load(response)
            except urllib.error.HTTPError as exc:
                with exc:return exc.code,json.load(exc)
        try:
            assert request('/api/products?q='+secret)[0]==200
            def failed_hash(*a,**kw):
                try:raise ValueError(secret+' inner')
                except ValueError as cause:raise RuntimeError(secret+' outer '+repr(a)) from cause
            with patch.object(users,'generate_password_hash',side_effect=failed_hash):
                status,data=request('/api/users?token='+secret,{'username':'usuario_sintetico','user_password':secret,'role':'Cajero'})
            assert status==500 and 'error' in data and secret not in json.dumps(data),(status,data)
            with app.app_context():
                db=get_db();assert db.execute("SELECT COUNT(*) FROM users WHERE username='usuario_sintetico'").fetchone()[0]==0
                assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
            assert request('/api/products',{'name':'Después del error','cost_without_tax':1})[0]==201
            wz.warning('Solicitud HTTP malformada: %s',secret)
            def fail_print(*a,**kw):raise OSError(secret)
            with patch.object(documents,'os',SimpleNamespace(name='nt',startfile=fail_print)):
                ok,message=documents.print_pdf_file(base/'synthetic.pdf')
                assert not ok and secret not in message
            with patch.object(documents.subprocess,'Popen',side_effect=OSError(secret)):
                with patch.object(documents,'os',SimpleNamespace(name='posix')):
                    ok,message=documents.print_pdf_file(base/'synthetic.pdf')
                    assert not ok and secret not in message
            fake_cv2=SimpleNamespace(IMREAD_COLOR=1,imdecode=fail_print)
            with patch.dict(sys.modules,{'cv2':fake_cv2}):
                code,message=barcodes.decode_barcode_image_bytes(b'synthetic')
                assert not code and secret not in message
        finally:
            server.shutdown();thread.join(timeout=10);server.server_close()
            handler.flush();app.logger.removeHandler(handler);wz.removeHandler(handler);handler.close()
        text=path.read_text(encoding='utf-8')
        assert secret not in text,text
        assert 'RuntimeError' in text and 'ValueError' in text and 'failed_hash' in text,text
        assert 'Solicitud HTTP: GET; estado 200' in text and 'estado 500' in text,text
        assert text.count('Error inesperado durante la solicitud HTTP')==1,text
        assert 'No se pudo imprimir el PDF' in text and 'No se pudo decodificar' in text
        # Tampoco conservar un traceback cacheado por otro handler.
        record=logging.LogRecord('app',logging.ERROR,__file__,1,'Error controlado',(),None)
        record.exc_text=secret;DiagnosticFilter().filter(record)
        assert secret not in logging.Formatter().format(record)
        record=logging.LogRecord('app',logging.ERROR,__file__,1,'Exception on /api/'+secret,(),None)
        DiagnosticFilter().filter(record)
        assert secret not in logging.Formatter().format(record)
        print('OK: fallo HTTP real revierte alta y devuelve JSON; diagnóstico conserva tipo/función/línea sin claves, cuerpo ni query; cámara/impresión sin excepción cruda')
finally:
    for k,v in saved.items():setattr(config,k,v)
