"""Prueba aislada de una eventual migracion a centavos enteros.

NO modifica la base del negocio ni cambia el esquema de produccion.
"""
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import sqlite3
from contextlib import closing
import tempfile

# Unicamente columnas que representan dinero. Cantidades, porcentajes y
# multiplicadores de redondeo no son importes y quedan deliberadamente fuera.
MONEY_COLUMNS = {
    'products': ('cost_without_tax', 'total_cost', 'sale_price'),
    'sales': ('total', 'amount_received', 'change_amount'),
    'sale_items': ('unit_price', 'line_total', 'unit_cost_at_sale'),
    'purchases': ('total',),
    'purchase_items': ('unit_cost', 'cost_without_tax', 'total_cost', 'sale_price', 'line_total'),
    'cash_sessions': ('initial_amount', 'closing_amount', 'expected_amount', 'difference'),
    'cash_movements': ('amount',),
    'clients': ('balance',),
    'client_movements': ('amount',),
}

def cents(value):
    if value is None:
        return None
    x = Decimal(str(value))
    if not x.is_finite():
        raise ValueError('non-finite monetary amount')
    n = int((x * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    if abs(n) > 9223372036854775807:
        raise OverflowError('outside SQLite integer range')
    return n

with tempfile.TemporaryDirectory(prefix='pos_cents_prototype_') as temp:
    original = Path(temp) / 'original.db'
    migrated = Path(temp) / 'copy.db'
    with closing(sqlite3.connect(original)) as db:
        for table, cols in MONEY_COLUMNS.items():
            definitions = ', '.join(f'"{c}" REAL' for c in cols)
            db.execute(f'CREATE TABLE "{table}" (id INTEGER PRIMARY KEY, {definitions})')
            vals = [2.675, 0.105, -2.675, None, 999999.999, 1.005]
            db.execute(f'INSERT INTO "{table}" ({", ".join(cols)}) VALUES ({", ".join("?" for _ in cols)})',
                       [vals[i % len(vals)] for i in range(len(cols))])
        db.commit()
    # SQLite backup and explicit close: required on Windows before cleanup.
    src = sqlite3.connect(original)
    dst = sqlite3.connect(migrated)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()

    db = sqlite3.connect(migrated)
    try:
        db.execute('BEGIN')
        changed = 0
        for table, cols in MONEY_COLUMNS.items():
            for col in cols:
                target = col + '_cents_prototype'
                db.execute(f'ALTER TABLE "{table}" ADD COLUMN "{target}" INTEGER')
                for pk, value in db.execute(f'SELECT id, "{col}" FROM "{table}"').fetchall():
                    db.execute(f'UPDATE "{table}" SET "{target}"=? WHERE id=?', (cents(value), pk))
                    got = db.execute(f'SELECT "{target}" FROM "{table}" WHERE id=?', (pk,)).fetchone()[0]
                    assert got == cents(value)
                    changed += 1
        db.commit()
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
    finally:
        db.close()

    # Base fuente intacta, incluidas columnas, datos y valores de precision sub-centavo.
    with closing(sqlite3.connect(original)) as db:
        for table, cols in MONEY_COLUMNS.items():
            actual = [row[1] for row in db.execute(f'PRAGMA table_info("{table}")')]
            assert actual == ['id', *cols]
            assert db.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0] == 1
    assert cents('2.675') == 268
    assert cents('-2.675') == -268
    assert cents('0.105') == 11
    try:
        cents('NaN')
        raise AssertionError('NaN accepted')
    except ValueError:
        pass
print(f'OK: prototipo de migracion en copia temporal; {len(MONEY_COLUMNS)} tablas, {sum(map(len, MONEY_COLUMNS.values()))} columnas; original preservado')
