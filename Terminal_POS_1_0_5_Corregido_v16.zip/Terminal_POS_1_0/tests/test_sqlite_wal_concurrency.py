"""WAL debe mejorar concurrencia sin rebajar durabilidad ni romper backups."""
import ast
import sqlite3
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "app" / "db.py").read_text(encoding="utf-8")
tree = ast.parse(source)
helper = next(
    node for node in tree.body
    if isinstance(node, ast.FunctionDef) and node.name == "_enable_wal_mode"
)
namespace = {"sqlite3": sqlite3}
exec(compile(ast.Module(body=[helper], type_ignores=[]), "app/db.py", "exec"), namespace)
enable_wal = namespace["_enable_wal_mode"]

assert "_enable_wal_mode(db)" in source[source.index("def init_db():"):source.index("def get_settings():")]
assert "synchronous=NORMAL" not in source

with tempfile.TemporaryDirectory(prefix="pos_wal_test_") as tmp:
    db_path = Path(tmp) / "pos.db"
    writer = sqlite3.connect(db_path, timeout=3)
    writer.execute("CREATE TABLE sample(id INTEGER PRIMARY KEY, value TEXT)")
    writer.execute("INSERT INTO sample(value) VALUES('original')")
    writer.commit()

    enabled = enable_wal(writer)
    mode = writer.execute("PRAGMA journal_mode").fetchone()[0].lower()
    assert enabled and mode == "wal", f"No se activó WAL: {mode}"
    assert writer.execute("PRAGMA synchronous").fetchone()[0] == 2, "No se debe rebajar synchronous FULL."

    # Un lector mantiene una transacción abierta mientras el escritor confirma.
    reader = sqlite3.connect(db_path, timeout=3)
    reader.execute("BEGIN")
    assert reader.execute("SELECT value FROM sample WHERE id=1").fetchone()[0] == "original"
    writer.execute("INSERT INTO sample(value) VALUES('nuevo')")
    writer.commit()
    # El lector conserva su snapshot y no bloquea el commit del escritor.
    assert reader.execute("SELECT COUNT(*) FROM sample").fetchone()[0] == 1
    reader.commit()
    assert reader.execute("SELECT COUNT(*) FROM sample").fetchone()[0] == 2

    # La API backup de SQLite incluye correctamente datos confirmados en WAL.
    backup_path = Path(tmp) / "backup.db"
    backup = sqlite3.connect(backup_path)
    writer.backup(backup)
    assert backup.execute("SELECT COUNT(*) FROM sample").fetchone()[0] == 2
    backup.close()
    reader.close()
    writer.close()

    # En memoria SQLite no activa WAL, pero el helper debe degradar sin error.
    memory = sqlite3.connect(":memory:")
    assert enable_wal(memory) is False
    assert memory.execute("PRAGMA journal_mode").fetchone()[0].lower() == "memory"
    memory.close()

print("OK: WAL, concurrencia lector/escritor, backup y fallback sin reducir synchronous.")
