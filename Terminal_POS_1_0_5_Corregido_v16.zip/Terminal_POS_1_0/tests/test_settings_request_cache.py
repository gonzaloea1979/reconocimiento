"""Comprueba la caché de configuración por petición y su invalidación."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'app' / 'db.py'
tree = ast.parse(SOURCE.read_text(encoding='utf-8'))
wanted = {'get_settings', 'set_setting'}
nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in wanted]
assert {node.name for node in nodes} == wanted

class FakeG:
    def __init__(self):
        object.__setattr__(self, '_values', {})
    def __getattr__(self, name):
        try:
            return self._values[name]
        except KeyError:
            raise AttributeError(name)
    def __setattr__(self, name, value):
        self._values[name] = value
    def pop(self, name, default=None):
        return self._values.pop(name, default)

class Cursor:
    def __init__(self, rows):
        self.rows = rows
    def fetchall(self):
        return [dict(row) for row in self.rows]

class FakeDB:
    def __init__(self):
        self.values = {'business_name': 'Mi negocio'}
        self.select_count = 0
    def execute(self, sql, params=()):
        if sql.startswith('SELECT key, value'):
            self.select_count += 1
            return Cursor([{'key': k, 'value': v} for k, v in self.values.items()])
        if sql.startswith('INSERT INTO app_settings'):
            self.values[params[0]] = params[1]
            return None
        raise AssertionError(f'SQL inesperado: {sql}')

g = FakeG()
db = FakeDB()
namespace = {'g': g, 'DEFAULT_SETTINGS': {'business_name': 'POS Local', 'stock_control_enabled': '1'},
             'get_db': lambda: db}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(SOURCE), 'exec'), namespace)

first = namespace['get_settings']()
second = namespace['get_settings']()
assert first['business_name'] == 'Mi negocio'
assert second['stock_control_enabled'] == '1'
assert db.select_count == 1, 'Debe leer la configuración una sola vez por petición'

first['business_name'] = 'Mutación externa'
assert namespace['get_settings']()['business_name'] == 'Mi negocio', 'La caché no debe exponerse mutable'

namespace['set_setting']('business_name', 'Nombre actualizado')
updated = namespace['get_settings']()
assert updated['business_name'] == 'Nombre actualizado'
assert db.select_count == 2, 'set_setting debe invalidar la caché'
print('OK: una lectura por petición, copias defensivas e invalidación al guardar')
