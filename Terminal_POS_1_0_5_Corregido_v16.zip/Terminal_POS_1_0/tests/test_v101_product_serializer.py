"""V101 optimiza product_to_dict sin cambiar el contrato JSON."""
from __future__ import annotations
import ast
import sqlite3
import statistics
import time
from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "app" / "route_core.py").read_text(encoding="utf-8")
tree = ast.parse(source)
node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "product_to_dict")
namespace = {}

def money(value):
    try:
        number = Decimal(str(value or 0).strip())
        if not number.is_finite():
            return 0.0
        return float(number.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
    except (InvalidOperation, TypeError, ValueError, OverflowError):
        return 0.0

def format_date_ar(value):
    if not value:
        return ""
    raw = str(value).strip()
    for fmt in ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%d/%m/%Y"):
        try:
            return datetime.strptime(raw[:19] if "T" in fmt else raw[:10], fmt).strftime("%d/%m/%Y")
        except ValueError:
            pass
    return raw

state = {"stock_enabled": True}
namespace.update({
    "money": money,
    "format_date_ar": format_date_ar,
    "stock_control_enabled": lambda: state["stock_enabled"],
    "url_for": lambda endpoint, filename: "/static/" + filename,
})
exec(compile(ast.Module(body=[node], type_ignores=[]), str(ROOT / "app" / "route_core.py"), "exec"), namespace)
optimized = namespace["product_to_dict"]

def legacy_product_to_dict(row):
    row_keys = row.keys() if hasattr(row, "keys") else []
    photo_path = ""
    try:
        photo_path = row["photo_path"] or ""
    except Exception:
        photo_path = ""
    return {
        "id": row["id"], "barcode": row["barcode"] or "", "name": row["name"],
        "detail": row["detail"] or "", "cost_without_tax": money(row["cost_without_tax"]),
        "iva_percent": money(row["iva_percent"]), "gross_income_percent": money(row["gross_income_percent"]),
        "total_cost": money(row["total_cost"]), "margin_percent": money(row["margin_percent"]),
        "rounding_mode": row["rounding_mode"] if "rounding_mode" in row_keys else "none",
        "rounding_multiple": money(row["rounding_multiple"]) if "rounding_multiple" in row_keys else 1,
        "sale_price": money(row["sale_price"]), "stock": money(row["stock"]),
        "min_stock": money(row["min_stock"]) if "min_stock" in row.keys() else 0,
        "supplier_id": row["supplier_id"] if "supplier_id" in row.keys() else None,
        "low_stock": state["stock_enabled"] and money(row["stock"]) <= (money(row["min_stock"]) if "min_stock" in row.keys() else 0)
                     and (money(row["min_stock"]) if "min_stock" in row.keys() else 0) > 0,
        "expiry_date": row["expiry_date"] or "",
        "expiry_date_formatted": format_date_ar(row["expiry_date"] or ""),
        "photo_path": photo_path,
        "photo_url": "/static/" + photo_path if photo_path else "",
    }

with sqlite3.connect(":memory:") as db:
    db.row_factory = sqlite3.Row
    db.execute("""CREATE TABLE products(
        id INTEGER PRIMARY KEY, barcode TEXT, name TEXT, detail TEXT,
        cost_without_tax REAL, iva_percent REAL, gross_income_percent REAL,
        total_cost REAL, margin_percent REAL, rounding_mode TEXT, rounding_multiple REAL,
        sale_price REAL, stock REAL, min_stock REAL, supplier_id INTEGER,
        expiry_date TEXT, photo_path TEXT)""")
    db.executemany(
        "INSERT INTO products VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [(i, str(i), f"Producto {i:05d}", "Detalle", 123.456, 21, 3, 150.123,
          30, "none", 1, 200.234, float(i % 20), 5, 1,
          "2026-12-31" if i % 4 == 0 else None, None) for i in range(1, 301)]
    )
    rows = db.execute("SELECT * FROM products ORDER BY id").fetchall()
    assert [legacy_product_to_dict(r) for r in rows] == [optimized(r) for r in rows]
    state["stock_enabled"] = False
    assert [legacy_product_to_dict(r) for r in rows] == [optimized(r) for r in rows]
    state["stock_enabled"] = True

    def bench(fn):
        for _ in range(5):
            [fn(r) for r in rows]
        samples = []
        for _ in range(80):
            start = time.perf_counter_ns()
            [fn(r) for r in rows]
            samples.append((time.perf_counter_ns() - start) / 1_000_000)
        ordered = sorted(samples)
        return statistics.median(samples), ordered[75]

    old_p50, old_p95 = bench(legacy_product_to_dict)
    new_p50, new_p95 = bench(optimized)
    print(f"Serialización 300 productos - anterior P50/P95: {old_p50:.3f}/{old_p95:.3f} ms")
    print(f"Serialización 300 productos - V101 P50/P95: {new_p50:.3f}/{new_p95:.3f} ms")
    if new_p50 < old_p50:
        print(f"Mejora P50 microbenchmark: {(old_p50-new_p50)/old_p50*100:.1f}%")

print("OK: product_to_dict conserva exactamente el JSON anterior con stock activado y desactivado.")
