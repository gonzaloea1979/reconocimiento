"""Protección de apertura simultánea en dos conexiones SQLite independientes."""
import sqlite3
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

root = Path(__file__).resolve().parents[1]
src = (root / 'app/route_modules/cash.py').read_text(encoding='utf-8')
fn = src[src.index('def api_cash_open():'):src.index("@bp.post('/api/cash/movement')")]
assert fn.index("db.execute('BEGIN IMMEDIATE')") < fn.index('if active_cash_session():') < fn.index("INSERT INTO cash_sessions")
assert 'db.rollback()' in fn

with tempfile.TemporaryDirectory(prefix='pos_v108_cash_atomic_') as tmp:
    path=Path(tmp)/'pos.db'
    db=sqlite3.connect(path)
    db.execute("CREATE TABLE cash_sessions (id INTEGER PRIMARY KEY, status TEXT NOT NULL DEFAULT 'abierta')")
    db.commit();db.close()
    for run in range(10):
        db=sqlite3.connect(path)
        db.execute('DELETE FROM cash_sessions');db.commit();db.close()
        barrier=threading.Barrier(2)
        def open_cash(_):
            conn=sqlite3.connect(path,timeout=15)
            barrier.wait(timeout=10)
            conn.execute('BEGIN IMMEDIATE')
            current=conn.execute("SELECT id FROM cash_sessions WHERE status='abierta' LIMIT 1").fetchone()
            if current:
                conn.rollback(); conn.close(); return 409
            conn.execute('INSERT INTO cash_sessions DEFAULT VALUES');conn.commit();conn.close();return 200
        with ThreadPoolExecutor(max_workers=2) as pool:
            codes=sorted(pool.map(open_cash,range(2)))
        check=sqlite3.connect(path)
        n=check.execute("SELECT COUNT(*) FROM cash_sessions WHERE status='abierta'").fetchone()[0]
        assert (codes,n)==([200,409],1),(codes,n)
        check.close()
print('OK: BEGIN IMMEDIATE antes de verificación impide dos aperturas (10 carreras).')
