"""Regresiones 1.0.5.1: contrato de stock en panel/reportes y endurecimiento de API.

Cubre tres defectos confirmados:
  1. /api/reports y /api/dashboard no devolvían stock_control_enabled, por lo que
     las pantallas mostraban siempre "Desactivado" aunque el control estuviera activo.
  2. Un pago de cuenta corriente podía superar la deuda y dejar saldo negativo.
  3. Varios endpoints respondían 500 (traza) en lugar de 400 ante cuerpos JSON
     válidos pero no-objeto, o ante campos de texto con tipos inesperados.

Usa una base temporal; nunca toca datos comerciales.
"""
from pathlib import Path
import os
import sys
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import app.config as config
from app import create_app
from app.db import get_db, update_settings

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {k: getattr(config, k) for k in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_v1051_hardening_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base / 'instance',
                               BACKUP_DIR=base / 'backups', DATABASE=base / 'instance' / 'pos.db',
                               UPLOAD_DIR=base / 'uploads', TICKET_DIR=base / 'TICKET').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = True
        client = app.test_client()
        assert client.get('/api/products').status_code == 200

        # --- 1. stock_control_enabled en panel y reportes -----------------------
        dashboard = client.get('/api/dashboard')
        assert dashboard.status_code == 200, dashboard.json
        assert 'stock_control_enabled' in dashboard.json, 'El panel debe exponer stock_control_enabled'
        assert dashboard.json['stock_control_enabled'] is True, 'Debe ser booleano real, no un string'

        reports = client.get('/api/reports')
        assert reports.status_code == 200, reports.json
        assert 'stock_control_enabled' in reports.json, 'Reportes debe exponer stock_control_enabled'
        assert reports.json['stock_control_enabled'] is True

        # Con el control desactivado, ambos endpoints deben reflejarlo.
        with app.app_context():
            update_settings({'stock_control_enabled': '0'})
        assert client.get('/api/dashboard').json['stock_control_enabled'] is False
        assert client.get('/api/reports').json['stock_control_enabled'] is False
        with app.app_context():
            update_settings({'stock_control_enabled': '1'})

        # --- 2. El pago no puede superar la deuda ------------------------------
        product = client.post('/api/products', json={
            'barcode': 'HARD-1', 'name': 'Producto prueba', 'cost_without_tax': 10, 'stock': 50,
        })
        assert product.status_code == 201, product.json
        pid = product.json['id']
        cid = client.post('/api/clients', json={'name': 'Cliente ficticio', 'balance': 0}).json['id']
        assert client.post('/api/cash/open', json={'initial_amount': 0}).status_code == 200
        sale = client.post('/api/sales', json={
            'items': [{'product_id': pid, 'quantity': 3}], 'client_id': cid,
            'payment_method': 'Cuenta corriente',
        })
        assert sale.status_code == 200, sale.json
        with app.app_context():
            debt = get_db().execute('SELECT balance FROM clients WHERE id=?', (cid,)).fetchone()['balance']
        assert debt > 0, 'La venta a cuenta corriente debe generar deuda'

        over = client.post(f'/api/clients/{cid}/payment', json={'amount': round(debt + 1, 2)})
        assert over.status_code == 400, f'El sobrepago debe rechazarse: {over.status_code} {over.json}'
        with app.app_context():
            assert get_db().execute('SELECT balance FROM clients WHERE id=?', (cid,)).fetchone()['balance'] == debt, \
                'El saldo no debe cambiar tras un pago rechazado'
            assert get_db().execute("SELECT COUNT(*) FROM client_movements WHERE client_id=? AND movement_type='Pago'", (cid,)).fetchone()[0] == 0

        # Pagar exactamente la deuda sí se permite y deja saldo cero.
        exact = client.post(f'/api/clients/{cid}/payment', json={'amount': debt})
        assert exact.status_code == 200, exact.json
        assert exact.json['balance'] == 0
        with app.app_context():
            assert get_db().execute('SELECT balance FROM clients WHERE id=?', (cid,)).fetchone()['balance'] == 0

        # --- 3. Cuerpos malformados -> 400, nunca 500 --------------------------
        bad_bodies = [[], 'texto', 123, True]
        guarded = [
            '/api/products', '/api/clients', '/api/suppliers', '/api/users',
            '/api/stock/adjust', '/api/ticket-settings', '/api/settings',
            '/api/system-keys', '/api/product-labels/pdf', '/api/product-labels/pdf-file',
        ]
        for url in guarded:
            for body in bad_bodies:
                # TESTING=True propaga excepciones: si algo falla con traza, el
                # test falla aquí en vez de enmascararse como un 500.
                response = client.post(url, json=body)
                assert response.status_code == 400, f'{url} con {body!r} devolvió {response.status_code}'

        # Campos de texto con tipos inesperados -> 400, no traza.
        assert client.post('/api/products', json={'name': 123}).status_code == 400
        assert client.post('/api/products', json={'name': ['x']}).status_code == 400
        assert client.post('/api/products', json={'name': 'x', 'expiry_date': []}).status_code == 400

        # Etiquetas con elementos que no son objetos -> 400, no traza.
        labels = client.post('/api/product-labels/pdf', json={'items': ['x']})
        assert labels.status_code == 400, labels.status_code

        # normalize_date sigue aceptando números (DDMMAAAA) y rechazando tipos inválidos.
        numeric = client.post('/api/products', json={'name': 'Con fecha', 'expiry_date': 31122026})
        assert numeric.status_code == 201, numeric.json
        assert numeric.json['expiry_date'] == '2026-12-31'

        print('OK: stock_control_enabled en panel/reportes, sobrepago rechazado y API sin 500')
finally:
    for key, value in saved.items():
        setattr(config, key, value)
