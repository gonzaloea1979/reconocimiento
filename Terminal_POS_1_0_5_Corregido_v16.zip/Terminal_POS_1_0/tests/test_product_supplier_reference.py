"""Comprueba que productos no acepten proveedores inexistentes."""
from tests.route_source import read_all_routes
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = read_all_routes(ROOT)
expected = "SELECT 1 FROM suppliers WHERE id=?"
assert source.count(expected) >= 2, 'Crear y editar productos deben validar el proveedor'
assert source.count("El proveedor seleccionado no existe") >= 2
assert "except (ValueError, TypeError):\n        return jsonify({'error': 'Proveedor inválido'}), 400" in source
print('OK: alta y edición de productos rechazan proveedores inexistentes o identificadores inválidos')
