"""Reportes/caja consistentes durante ventas y cálculos fraccionados."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
import tempfile,sys,threading
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import app.config as config
import app.db as db_module
import app.route_modules.cash as cash_routes
from app import create_app
from app.db import get_db
from app.route_core import money
keys=('BASE_DIR','INSTANCE_DIR','BACKUP_DIR','DATABASE','UPLOAD_DIR','TICKET_DIR');saved={k:getattr(config,k) for k in keys}
try:
 with tempfile.TemporaryDirectory() as tmp:
  b=Path(tmp)
  for k,v in dict(BASE_DIR=b,INSTANCE_DIR=b/'instance',BACKUP_DIR=b/'backups',DATABASE=b/'instance'/'pos.db',UPLOAD_DIR=b/'uploads',TICKET_DIR=b/'tickets').items():setattr(config,k,v)
  app=create_app();app.config['TESTING']=True;c=app.test_client()
  p=c.post('/api/products',json={'name':'Fraccionado','cost_without_tax':.05,'stock':10}).json
  cid=c.post('/api/clients',json={'name':'Deuda','balance':10}).json['id']
  assert c.post('/api/cash/open',json={'initial_amount':100}).status_code==200
  def sale(qty=.1,credit=False):
   r=c.post('/api/sales',json={'items':[{'product_id':p['id'],'quantity':qty}], 'payment_method':'Cuenta corriente' if credit else 'Efectivo','client_id':cid if credit else None})
   assert r.status_code==200,r.json
  sale();sale(credit=True)
  assert c.post(f'/api/clients/{cid}/payment',json={'amount':.01}).status_code==200
  report=c.get('/api/reports').json
  assert report['summary']['total_sales']==.02 and report['summary']['estimated_profit']==.01
  assert report['summary']['clients_debt']==10 and c.get('/api/cash/status').json['session']['expected_amount']==100.02
  with app.app_context():
   db=get_db();db.execute('UPDATE products SET total_cost=1 WHERE id=?',(p['id'],));db.commit()
  assert c.get('/api/reports').json['summary']['estimated_profit']==.01
  with app.app_context():
   db=get_db();db.execute('UPDATE sale_items SET unit_cost_at_sale=NULL WHERE id=(SELECT MIN(id) FROM sale_items)');db.commit()
  assert c.get('/api/reports').json['summary']['estimated_profit']==-.09
  original_connect=db_module.connect_database;local=threading.local();entered=threading.Event();resume=threading.Event()
  class Cursor:
   def __init__(self,cursor):self.cursor=cursor
   def fetchall(self):
    result=self.cursor.fetchall();entered.set();assert resume.wait(10);return result
   def __getattr__(self,n):return getattr(self.cursor,n)
  class Connection:
   def __init__(self,conn):self.conn=conn
   def execute(self,sql,*a,**k):
    cur=self.conn.execute(sql,*a,**k)
    return Cursor(cur) if getattr(local,'reader',False) and 'SUM(COUNT(*)) OVER ()' in sql else cur
   def __getattr__(self,n):return getattr(self.conn,n)
  def read():local.reader=True;return app.test_client().get('/api/reports')
  with patch.object(db_module,'connect_database',side_effect=lambda *a,**k:Connection(original_connect(*a,**k))):
   with ThreadPoolExecutor(1) as pool:
    job=pool.submit(read)
    try:assert entered.wait(10);sale(1)
    finally:resume.set()
    snapshot=job.result(timeout=10).json
  assert snapshot['summary']['sales_count']==2
  assert money(sum(x['total'] for x in snapshot['daily']))==snapshot['summary']['total_sales']==.02
  assert c.get('/api/reports').json['summary']['sales_count']==3
  entered.clear();resume.clear();original_active=cash_routes.active_cash_session
  def paused_active():
   row=original_active();entered.set();assert resume.wait(10);return row
  before=c.get('/api/cash/status').json['session']['expected_amount']
  with patch.object(cash_routes,'active_cash_session',side_effect=paused_active):
   with ThreadPoolExecutor(1) as pool:
    job=pool.submit(lambda:app.test_client().get('/api/cash/status'))
    try:assert entered.wait(10);sale(1)
    finally:resume.set()
    snapshot=job.result(timeout=10).json
  assert snapshot['session']['expected_amount']==before
  assert c.get('/api/cash/status').json['session']['expected_amount']==money(before+.05)
  print('OK: fracciones, deuda, efectivo, costo histórico/fallback y snapshots consistentes durante ventas concurrentes')
finally:
 for k,v in saved.items():setattr(config,k,v)
