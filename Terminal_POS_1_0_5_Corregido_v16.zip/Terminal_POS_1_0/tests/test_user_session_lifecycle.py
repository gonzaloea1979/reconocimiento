"""Sesiones estables, revocación y cambios de rol con una base temporal."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import json
import os
import re
import sqlite3
import sys
import tempfile
import threading
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import app.config as config
import app.db as db_module
import app.route_modules.users as user_routes
from app import create_app
from app.db import get_db, update_settings
from werkzeug.security import generate_password_hash

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {key: getattr(config, key) for key in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_sessions_v11_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base / 'instance', BACKUP_DIR=base / 'backups',
                               DATABASE=base / 'instance' / 'pos.db', UPLOAD_DIR=base / 'uploads', TICKET_DIR=base / 'tickets').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = True
        primary = app.test_client()

        def query(sql, args=()):
            with app.app_context():
                return [tuple(row) for row in get_db().execute(sql, args)]

        def create_user(name, role='Cajero', password='clave1234'):
            response = primary.post('/api/users', json={'username': name, 'role': role, 'user_password': password})
            assert response.status_code == 201, response.json
            return response.json

        def edit(user, **values):
            payload = dict(username=user['username'], role=user['role'], is_active=True)
            payload.update(values)
            response = primary.put(f"/api/users/{user['id']}", json=payload)
            assert response.status_code == 200, response.json
            user.update(response.json)

        def login(name, password='clave1234'):
            client = app.test_client()
            response = client.post('/api/login', json={'username': name, 'password': password})
            assert response.status_code == 200, response.json
            return client

        # Simular el esquema previo, sin reiniciar ni reemplazar datos del usuario.
        original_users = query('SELECT id, username, role, is_active, password_hash FROM users')
        with app.app_context():
            db = get_db()
            db.execute('ALTER TABLE users DROP COLUMN session_version')
            db.commit()
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            migrated = create_app()
        assert query('SELECT id, username, role, is_active, password_hash FROM users') == original_users
        assert query('SELECT session_version FROM users') == [(0,)]
        assert primary.get('/api/products').status_code == 200
        with primary.session_transaction() as sess:
            assert sess['passwordless_admin_login'] and sess['user_id'] == 1
        print('OK: migración de versión de sesión conserva usuarios; inicio local sigue disponible')

        user = create_user('cajero_roles')
        cashier = login(user['username'])
        with cashier.session_transaction() as sess:
            assert sess['user_id'] == user['id'] and sess['session_version'] == 0
        assert cashier.post('/api/admin-check', json={}).status_code == 403
        edit(user, role='Administrador')
        assert cashier.post('/api/admin-check', json={}).status_code == 200
        edit(user, role='Supervisor')
        assert cashier.post('/api/admin-check', json={}).status_code == 403
        assert cashier.get('/login').status_code == 302
        assert cashier.get('/api/products').status_code == 200
        with cashier.session_transaction() as sess:
            assert sess['username'] == 'cajero_roles' and sess['user_role'] == 'Supervisor'
        edit(user, is_active=False)
        before = query('SELECT COUNT(*) FROM sales')
        assert cashier.post('/api/sales', json={'items': []}).status_code == 401
        assert cashier.get('/api/products').status_code == 401
        assert query('SELECT COUNT(*) FROM sales') == before
        page = cashier.get('/login')
        assert page.status_code == 200 and b'loginForm' in page.data
        assert cashier.get('/api/products').status_code == 401
        edit(user, is_active=True)
        assert cashier.get('/api/products').status_code == 401
        assert cashier.post('/api/login', json={'username': user['username'], 'password': 'clave1234'}).status_code == 200
        assert cashier.get('/api/products').status_code == 200
        # La revocación también funciona si la cuenta se reactiva antes de otra petición.
        edit(user, is_active=False)
        edit(user, is_active=True)
        assert cashier.get('/api/products').status_code == 401
        print('OK: cambios de rol vigentes; desactivación revoca sin convertir la sesión en administrador')

        renamed = create_user('nombre_anterior')
        original_client = login(renamed['username'])
        edit(renamed, username='nombre_nuevo')
        replacement = create_user('nombre_anterior', role='Administrador')
        assert original_client.get('/api/products').status_code == 200
        with original_client.session_transaction() as sess:
            assert sess['user_id'] == renamed['id'] and sess['username'] == 'nombre_nuevo'
            assert sess['user_role'] == 'Cajero'
        assert original_client.post('/api/admin-check', json={}).status_code == 403
        assert primary.post('/api/users', json={'username': 'NOMBRE_NUEVO', 'role': 'Administrador', 'user_password': 'clave1234'}).status_code == 400
        assert primary.put(f"/api/users/{replacement['id']}", json={'username': 'NOMBRE_NUEVO', 'role': 'Administrador'}).status_code == 400
        edit(renamed, user_password='nueva1234')
        assert original_client.get('/api/products').status_code == 401
        assert original_client.post('/api/login', json={'username': renamed['username'], 'password': 'clave1234'}).status_code == 403
        assert original_client.post('/api/login', json={'username': renamed['username'], 'password': 'nueva1234'}).status_code == 200
        assert primary.delete(f"/api/users/{renamed['id']}", json={}).status_code == 200
        recreated = create_user('nombre_nuevo', role='Administrador', password='otra1234')
        assert recreated['id'] != renamed['id']
        assert original_client.get('/api/products').status_code == 401
        assert original_client.post('/api/login', json={'username': 'nombre_nuevo', 'password': 'nueva1234'}).status_code == 403
        print('OK: renombrar, cambiar clave, eliminar y recrear no transfieren identidad ni permisos')

        # Las cookies antiguas sin identificador requieren autenticación explícita.
        legacy_cookie = app.test_client()
        with legacy_cookie.session_transaction() as sess:
            sess.update(logged_in=True, authenticated_login=True, username='nombre_anterior', user_role='Administrador')
        assert legacy_cookie.get('/api/products').status_code == 401
        assert legacy_cookie.get('/api/products').status_code == 401

        # La clave global anterior sigue disponible, siempre con permisos de cajero.
        with app.app_context():
            update_settings({'login_username': 'alias_global', 'login_password_hash': generate_password_hash('global1234')})
        legacy = login('alias_global', 'global1234')
        alias_user = create_user('alias_global', role='Administrador')
        assert legacy.get('/api/products').status_code == 200
        assert legacy.post('/api/admin-check', json={}).status_code == 403
        page = legacy.get('/productos').get_data(as_text=True)
        visible_user = json.loads(re.search(r'window.POS_CURRENT_USER = (.*?);', page).group(1))
        assert visible_user['role'] == 'Cajero' and visible_user['is_admin'] is False
        with app.app_context():
            update_settings({'login_password_hash': generate_password_hash('global-nueva')})
        assert legacy.get('/api/products').status_code == 401
        assert primary.delete(f"/api/users/{alias_user['id']}", json={}).status_code == 200
        assert app.test_client().post('/api/login', json={'username': 'alias_global', 'password': 'global-nueva'}).status_code == 403
        print('OK: compatibilidad global sin herencia de roles; cambio de clave y eliminación revocan acceso')

        bound = create_user('clave_vinculada')
        with app.app_context():
            update_settings({'login_username': bound['username'], 'login_password_hash': generate_password_hash('global-anterior')})
        global_client = login(bound['username'], 'global-anterior')
        with app.app_context():
            update_settings({'login_password_hash': generate_password_hash('global-otra')})
        assert global_client.get('/api/products').status_code == 401
        global_client = login(bound['username'], 'global-otra')
        edit(bound, user_password='personal-nueva')
        assert global_client.get('/api/products').status_code == 401
        assert app.test_client().post('/api/login', json={'username': bound['username'], 'password': 'global-otra'}).status_code == 403
        assert login(bound['username'], 'personal-nueva').get('/api/products').status_code == 200

        # Una falla al leer al usuario no puede reutilizar permisos almacenados.
        healthy = login('nombre_anterior')
        original_connect = db_module.connect_database
        class Connection:
            def __init__(self, connection):
                self.connection = connection
            def execute(self, sql, *args, **kwargs):
                if sql.startswith('SELECT id, username, role, is_active, session_version FROM users'):
                    raise sqlite3.OperationalError('fallo simulado de autorización')
                return self.connection.execute(sql, *args, **kwargs)
            def __getattr__(self, name):
                return getattr(self.connection, name)
        with patch.object(db_module, 'connect_database', side_effect=lambda *a, **k: Connection(original_connect(*a, **k))), \
             patch.object(app.logger, 'exception'):
            assert healthy.post('/api/clients', json={'name': 'No guardar'}).status_code == 503
        assert query("SELECT COUNT(*) FROM clients WHERE name='No guardar'") == [(0,)]
        assert healthy.get('/api/products').status_code == 200

        # La ruta de cierre verifica la revocación antes de crear respaldos o hilos.
        shutdown_user = create_user('cierre_revocado')
        shutdown_client = login(shutdown_user['username'])
        edit(shutdown_user, is_active=False)
        assert shutdown_client.post('/api/shutdown', json={}).status_code == 401
        print('OK: fallo de lectura deniega cambios; sesión revocada no puede cerrar el sistema')

        # Una sesión local administrativa tampoco debe saltar a otra cuenta al perder su rol.
        another_admin = login('nombre_anterior')
        response = another_admin.put('/api/users/1', json={'username': 'admin', 'role': 'Cajero', 'is_active': True})
        assert response.status_code == 200, response.json
        assert primary.get('/api/products').status_code == 401
        automatic = app.test_client()
        assert automatic.get('/api/products').status_code == 200
        with automatic.session_transaction() as sess:
            assert sess['user_id'] != 1 and sess['user_role'] == 'Administrador'
        assert query('PRAGMA quick_check') == [('ok',)]
        assert query('PRAGMA foreign_key_check') == []
        print('OK: sesión local demovida se revoca; nuevo inicio conserva el modo local previsto')

        # Dos desactivaciones no pueden dejar la instalación sin administrador.
        race_base = base / 'concurrent_admins'
        for key, value in dict(BASE_DIR=race_base, INSTANCE_DIR=race_base / 'instance', BACKUP_DIR=race_base / 'backups',
                               DATABASE=race_base / 'instance' / 'pos.db', UPLOAD_DIR=race_base / 'uploads', TICKET_DIR=race_base / 'tickets').items():
            setattr(config, key, value)
        race_app = create_app()
        race_app.config['TESTING'] = True
        race_client = race_app.test_client()
        second = race_client.post('/api/users', json={'username': 'otro_admin', 'role': 'Administrador', 'user_password': 'clave1234'}).json
        gate = threading.Barrier(2)
        original_security = user_routes.require_security_password_from_payload
        def authorize(data):
            result = original_security(data)
            gate.wait(timeout=10)
            return result
        def deactivate(target):
            uid, username = target
            return race_app.test_client().put(f'/api/users/{uid}', json={
                'username': username, 'role': 'Administrador', 'is_active': False
            }).status_code
        with patch.object(user_routes, 'require_security_password_from_payload', side_effect=authorize):
            with ThreadPoolExecutor(2) as pool:
                results = list(pool.map(deactivate, [(1, 'admin'), (second['id'], second['username'])]))
        assert sorted(results) == [200, 400], results
        with race_app.app_context():
            assert get_db().execute("SELECT COUNT(*) FROM users WHERE role='Administrador' AND is_active=1").fetchone()[0] == 1
        print('OK: dos desactivaciones simultáneas conservan al menos un administrador activo')
finally:
    for key, value in saved.items():
        setattr(config, key, value)
