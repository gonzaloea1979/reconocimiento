"""Regresiones 1.0.1: saldos, efectivo y cierre concurrente, con BD temporal.

Ejecutable por run_all_tests.py o directamente. Nunca utiliza datos comerciales.
"""
from pathlib import Path
import os
import sys
import sqlite3
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import app.config as config
import app.db as db_module
from app import create_app
from app.db import get_db
import app.route_modules.clients as clients_routes
import app.route_modules.cash as cash_routes
import app.route_modules.sales as sales_routes

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {k: getattr(config, k) for k in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_101_regressions_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base/'instance',
                               BACKUP_DIR=base/'backups', DATABASE=base/'instance'/'pos.db',
                               UPLOAD_DIR=base/'uploads', TICKET_DIR=base/'TICKET').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = True
        client = app.test_client()
        assert client.get('/api/products').status_code == 200
        product = client.post('/api/products', json={
            'barcode':'REG-101', 'name':'Producto prueba', 'cost_without_tax':100, 'stock':100,
        })
        assert product.status_code == 201, product.json
        product_id = product.json['id']

        def sell(cl, method='Efectivo', cid=None):
            return cl.post('/api/sales', json={
                'items':[{'product_id':product_id, 'quantity':1}],
                'payment_method':method, 'amount_received':100, 'client_id':cid,
            })

        def query(sql, args=()):
            with app.app_context():
                return [tuple(row) for row in get_db().execute(sql, args)]

        assert client.post('/api/cash/open', json={'initial_amount':100}).status_code == 200
        for method in ('Transferencia','Tarjeta débito','Tarjeta crédito','Efectivo'):
            assert sell(client, method).status_code == 200
        status = client.get('/api/cash/status').json
        assert status['session']['expected_amount'] == 200, status
        assert len(status['totals']) == 4, status
        assert client.post('/api/cash/close', json={'closing_amount':200}).json['difference'] == 0
        print('OK: efectivo separado de transferencias y tarjetas; totales conservados')

        cid = client.post('/api/clients', json={'name':'Cliente prueba', 'balance':100}).json['id']
        original_connect = db_module.connect_database
        # Obligar a leer el mismo saldo antes de las dos escrituras. Una resta
        # calculada en Python sobre esa lectura pierde una de las actualizaciones.
        class Cursor:
            def __init__(self, cursor, gate): self.cursor, self.gate = cursor, gate
            def fetchone(self):
                row = self.cursor.fetchone()
                self.gate.wait(timeout=10)
                return row
            def __getattr__(self, name): return getattr(self.cursor, name)

        class Connection:
            def __init__(self, conn, gate): self.conn, self.gate = conn, gate
            def execute(self, sql, *args, **kwargs):
                cursor = self.conn.execute(sql, *args, **kwargs)
                return Cursor(cursor, self.gate) if sql.strip() == 'SELECT * FROM clients WHERE id=?' else cursor
            def __getattr__(self, name): return getattr(self.conn, name)

        def concurrent_accounts(actions):
            gate = threading.Barrier(2)
            def connect(*args, **kwargs): return Connection(original_connect(*args, **kwargs), gate)
            def run(action):
                cl = app.test_client()
                assert cl.get('/api/products').status_code == 200
                if action == 'sale': return sell(cl, 'Cuenta corriente', cid).status_code
                return cl.post(f'/api/clients/{cid}/payment', json={'amount':action}).status_code
            with patch('app.db.connect_database', side_effect=connect):
                with ThreadPoolExecutor(2) as pool:
                    assert list(pool.map(run, actions)) == [200,200]

        concurrent_accounts([10,20])
        assert query('SELECT balance FROM clients WHERE id=?', (cid,)) == [(70,)]
        concurrent_accounts(['sale','sale'])
        assert query('SELECT balance FROM clients WHERE id=?', (cid,)) == [(270,)]
        concurrent_accounts(['sale',10])
        assert query('SELECT balance FROM clients WHERE id=?', (cid,)) == [(360,)]
        assert query('SELECT COUNT(*), SUM(amount) FROM client_movements WHERE client_id=?', (cid,)) == [(7,440)]
        assert query("SELECT SUM(CASE WHEN movement_type='Pago' THEN -amount ELSE amount END) FROM client_movements WHERE client_id=?", (cid,)) == [(360,)]
        print('OK: pagos concurrentes, ventas a crédito concurrentes y pago/venta simultáneos')

        before = query('SELECT balance FROM clients WHERE id=?', (cid,))
        counts = query('SELECT COUNT(*) FROM client_movements')
        with patch.object(clients_routes, 'add_cash_movement', side_effect=sqlite3.OperationalError('fallo simulado')):
            assert client.post(f'/api/clients/{cid}/payment', json={'amount':5}).status_code == 500
        assert query('SELECT balance FROM clients WHERE id=?', (cid,)) == before
        assert query('SELECT COUNT(*) FROM client_movements') == counts
        for payload in ([], {'amount':'NaN'}, {'amount':-1}, {'amount':5,'description':[]}):
            assert client.post(f'/api/clients/{cid}/payment', json=payload).status_code == 400
        print('OK: pago inválido rechazado y fallo intermedio revierte saldo e historial')

        # Intercalar cierre y cada tipo de escritor con eventos: el segundo
        # debe esperar el bloqueo SQLite y no escribir dentro de una caja cerrada.
        local = threading.local()
        for operation in ('sale','payment','movement'):
            opened = client.post('/api/cash/open', json={'initial_amount':100})
            assert opened.status_code == 200
            cash_id = opened.json['cash_session_id']
            snapshot, resume, attempted, finished = [threading.Event() for _ in range(4)]
            original_status = cash_routes.cash_status_result
            def paused_status():
                response = original_status()
                snapshot.set()
                assert resume.wait(10), 'No se liberó el cierre'
                return response
            def traced_connect(*args, **kwargs):
                conn = original_connect(*args, **kwargs)
                def trace(sql):
                    if getattr(local, 'role', '') == 'writer' and (sql == 'BEGIN IMMEDIATE' or sql.startswith('UPDATE clients SET balance=')):
                        attempted.set()
                conn.set_trace_callback(trace)
                return conn
            def close():
                local.role = 'closer'
                cl = app.test_client(); cl.get('/api/products')
                return cl.post('/api/cash/close', json={'closing_amount':100})
            def write():
                local.role = 'writer'
                cl = app.test_client(); cl.get('/api/products')
                try:
                    if operation == 'sale': return sell(cl)
                    if operation == 'payment': return cl.post(f'/api/clients/{cid}/payment', json={'amount':1})
                    return cl.post('/api/cash/movement', json={'movement_type':'Ingreso','amount':1})
                finally:
                    finished.set()
            with patch.object(cash_routes, 'cash_status_result', side_effect=paused_status), \
                 patch('app.db.connect_database', side_effect=traced_connect):
                with ThreadPoolExecutor(2) as pool:
                    closing = pool.submit(close)
                    try:
                        assert snapshot.wait(10)
                        writing = pool.submit(write)
                        # Pagos bloquean con UPDATE; ventas/movimientos con BEGIN.
                        assert attempted.wait(10)
                        assert not finished.wait(0.25)
                    finally:
                        resume.set()
                    assert closing.result(timeout=10).status_code == 200
                    assert writing.result(timeout=10).status_code == 200
            assert query('SELECT expected_amount, difference FROM cash_sessions WHERE id=?',(cash_id,)) == [(100,0)]
            assert query('SELECT COUNT(*) FROM cash_movements WHERE cash_session_id=?',(cash_id,)) == [(0,)]
            if operation == 'sale':
                assert query('SELECT cash_session_id FROM sales ORDER BY id DESC LIMIT 1') == [(None,)]
        print('OK: cierre bloquea ventas, pagos y movimientos; no se agregan a caja cerrada')

        # Orden inverso: la venta ya estaba escribiendo cuando empieza el cierre.
        cash_id = client.post('/api/cash/open', json={'initial_amount':100}).json['cash_session_id']
        inserted, resume, attempted = [threading.Event() for _ in range(3)]
        original_add = sales_routes.add_cash_movement
        def paused_add(*args, **kwargs):
            result = original_add(*args, **kwargs)
            inserted.set()
            assert resume.wait(10)
            return result
        def traced_close_connect(*args, **kwargs):
            conn = original_connect(*args, **kwargs)
            conn.set_trace_callback(lambda sql: attempted.set() if getattr(local,'role','') == 'closer' and sql == 'BEGIN IMMEDIATE' else None)
            return conn
        def sale_first():
            local.role = 'writer'
            cl=app.test_client(); cl.get('/api/products')
            return sell(cl)
        def close_second():
            local.role = 'closer'
            cl=app.test_client(); cl.get('/api/products')
            return cl.post('/api/cash/close', json={'closing_amount':200})
        with patch.object(sales_routes,'add_cash_movement',side_effect=paused_add), \
             patch('app.db.connect_database',side_effect=traced_close_connect):
            with ThreadPoolExecutor(2) as pool:
                selling=pool.submit(sale_first)
                try:
                    assert inserted.wait(10)
                    closing=pool.submit(close_second)
                    assert attempted.wait(10)
                    assert not closing.done()
                finally:
                    resume.set()
                assert selling.result(timeout=10).status_code == 200
                closed=closing.result(timeout=10)
                assert closed.status_code == 200 and closed.json['expected_amount'] == 200, closed.json
        assert query('SELECT expected_amount, difference FROM cash_sessions WHERE id=?',(cash_id,)) == [(200,0)]
        assert query('PRAGMA quick_check') == [('ok',)]
        assert query('PRAGMA foreign_key_check') == []
        print('OK: cierre incluye venta previa concurrente; integridad y referencias válidas')
finally:
    for key, value in saved.items(): setattr(config, key, value)
