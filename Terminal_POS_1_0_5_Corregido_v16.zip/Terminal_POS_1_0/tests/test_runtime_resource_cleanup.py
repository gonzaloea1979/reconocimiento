"""Logs rotativos y limpieza segura de perfiles Chromium abandonados."""
import ast
import errno
import logging
import os
import shutil
import tempfile
import time
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "run.py").read_text(encoding="utf-8")
tree = ast.parse(source)

assert "RotatingFileHandler" in source
assert "maxBytes=5 * 1024 * 1024" in source
assert "backupCount=4" in source
assert "_cleanup_stale_browser_profiles()" in source

wanted = {"_process_is_running", "_cleanup_stale_browser_profiles"}
nodes = [
    node for node in tree.body
    if isinstance(node, ast.FunctionDef) and node.name in wanted
]
assert {node.name for node in nodes} == wanted

with tempfile.TemporaryDirectory(prefix="pos_profile_cleanup_") as tmp:
    profile_root = Path(tmp) / "browser_profile"
    profile_root.mkdir()
    old_time = time.time() - 20 * 24 * 60 * 60

    active = profile_root / "session_11111"
    stale = profile_root / "session_22222"
    recent = profile_root / "session_33333"
    malformed = profile_root / "session_unknown"
    for folder in (active, stale, recent, malformed):
        folder.mkdir()
        (folder / "Cache").write_text("test", encoding="utf-8")
    os.utime(active, (old_time, old_time))
    os.utime(stale, (old_time, old_time))
    os.utime(malformed, (old_time, old_time))

    def fake_kill(pid, sig):
        if pid == 11111:
            return None
        if pid == 22222:
            raise ProcessLookupError(errno.ESRCH, "no such process")
        if pid == 33333:
            raise ProcessLookupError(errno.ESRCH, "no such process")
        raise AssertionError(pid)

    namespace = {
        "os": os,
        "shutil": shutil,
        "time": time,
        "logging": logging,
        "PROFILE_ROOT": profile_root,
    }
    exec(compile(ast.Module(body=nodes, type_ignores=[]), "run.py", "exec"), namespace)

    with patch.object(os, "kill", side_effect=fake_kill):
        removed = namespace["_cleanup_stale_browser_profiles"](max_age_days=7)

    assert removed == 1
    assert active.exists(), "No se debe borrar un perfil con proceso activo."
    assert not stale.exists(), "El perfil antiguo de proceso muerto debe limpiarse."
    assert recent.exists(), "No se deben borrar perfiles recientes."
    assert malformed.exists(), "No se deben borrar carpetas con nombre desconocido."

print("OK: logs rotativos y limpieza limitada a perfiles antiguos de procesos terminados.")
