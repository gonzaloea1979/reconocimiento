"""El perfilador no modifica datos y limita el sondeo HTTP a GET local."""
from pathlib import Path
import importlib.util
import sqlite3
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "diagnostico_rendimiento.py"
SOURCE = SCRIPT.read_text(encoding="utf-8")

assert 'mode=ro' in SOURCE
assert 'PRAGMA query_only=ON' in SOURCE
assert 'method="GET"' in SOURCE
assert 'READ_ONLY_ENDPOINTS' in SOURCE
assert 'https://' not in SOURCE.lower()
assert 'INSERT INTO' not in SOURCE.upper()
assert 'UPDATE ' not in SOURCE.upper()
assert 'DELETE FROM' not in SOURCE.upper()

spec = importlib.util.spec_from_file_location("pos_performance_diagnostic", SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

with tempfile.TemporaryDirectory(prefix="pos_perf_test_") as tmp:
    db = Path(tmp) / "pos_test.db"
    con = sqlite3.connect(db)
    con.executescript("""
        CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT, min_stock REAL, stock REAL);
        CREATE INDEX idx_products_name ON products(name);
        CREATE TABLE sales(id INTEGER PRIMARY KEY, total REAL, created_at TEXT);
        CREATE TABLE clients(id INTEGER PRIMARY KEY, name TEXT, balance REAL);
        CREATE TABLE suppliers(id INTEGER PRIMARY KEY, name TEXT);
        CREATE TABLE product_movements(id INTEGER PRIMARY KEY);
        CREATE TABLE audit_logs(id INTEGER PRIMARY KEY);
        CREATE TABLE purchases(id INTEGER PRIMARY KEY);
        INSERT INTO products VALUES(1, 'Producto de prueba', 2, 1);
        INSERT INTO sales VALUES(1, 100, '2026-10-30');
        INSERT INTO clients VALUES(1, 'DATO_PRIVADO_NO_DEBE_APARECER', 0);
        INSERT INTO suppliers VALUES(1, 'Proveedor de prueba');
    """)
    con.commit()
    before = {
        "products": con.execute("SELECT COUNT(*) FROM products").fetchone()[0],
        "clients": con.execute("SELECT COUNT(*) FROM clients").fetchone()[0],
    }
    con.close()

    lines = []
    module._database_report(db, lines)
    content = "\\n".join(lines)
    assert "quick_check: ok" in content
    assert "Productos ordenados:" in content
    assert "DATO_PRIVADO_NO_DEBE_APARECER" not in content

    con = sqlite3.connect(db)
    after = {
        "products": con.execute("SELECT COUNT(*) FROM products").fetchone()[0],
        "clients": con.execute("SELECT COUNT(*) FROM clients").fetchone()[0],
    }
    con.close()
    assert before == after, "El diagnóstico alteró datos de prueba."

print("OK: diagnóstico SQLite de solo lectura, sin datos personales y sin escrituras.")
