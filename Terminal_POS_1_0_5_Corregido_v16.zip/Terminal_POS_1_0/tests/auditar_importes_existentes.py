"""Auditoría SOLO LECTURA de una COPIA SQLite del negocio.

Uso: python tests/auditar_importes_existentes.py "C:\\ruta\\copia_pos.db"
No migra, repara ni modifica ningún dato. No exporta importes individuales.
"""
import argparse
from collections import Counter
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
import sqlite3
import sys

ROUND = Decimal('0.01')

def cents(value):
    if value is None:
        return None
    try:
        number = Decimal(str(value))
        if not number.is_finite():
            raise ValueError('No finito')
        return int((number * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    except (ValueError, InvalidOperation, OverflowError):
        return None

def audit(db, header, detail, total_col, fk_col, detail_col):
    summary = Counter()
    samples = []
    rows = db.execute(f'SELECT h.id, h."{total_col}", d.id, d."{detail_col}" FROM "{header}" AS h LEFT JOIN "{detail}" AS d ON d."{fk_col}"=h.id ORDER BY h.id, d.id')
    prev = None
    values = []
    saved = None
    def finish(record_id, original, parts):
        if record_id is None:
            return
        summary['operations'] += 1
        if not parts:
            summary['without_details'] += 1
            return
        total_cents = cents(original)
        line_cents = [cents(v) for v in parts]
        if total_cents is None or any(v is None for v in line_cents):
            summary['invalid_amount'] += 1
            return
        difference = sum(line_cents) - total_cents
        if difference:
            summary['different_operations'] += 1
            summary['difference_cents_abs'] += abs(difference)
            summary['difference_cents_net'] += difference
            summary['difference_cents_max'] = max(summary['difference_cents_max'], abs(difference))
            if abs(difference) == 1:
                summary['one_cent_operations'] += 1
            else:
                summary['multi_cent_operations'] += 1
            if len(samples) < 10:
                samples.append((record_id, difference))
        else:
            summary['matching_operations'] += 1
    for record_id, original, detail_id, line in rows:
        if record_id != prev:
            finish(prev, saved, values)
            prev, saved, values = record_id, original, []
        if detail_id is not None:
            values.append(line)  # NULL is an invalid amount, not a missing detail
    finish(prev, saved, values)
    return summary, samples

def main():
    parser = argparse.ArgumentParser(description='Conciliación monetaria SOLO LECTURA de una COPIA SQLite')
    parser.add_argument('database', help='Ruta a una copia .db fuera de la carpeta activa del POS')
    args = parser.parse_args()
    file = Path(args.database).expanduser().resolve()
    if file.suffix.lower() not in ('.db', '.sqlite', '.sqlite3') or not file.is_file():
        parser.error('Se necesita una copia SQLite existente (.db/.sqlite/.sqlite3)')
    # No abrir accidentalmente el fichero operativo en la carpeta instance.
    if file.parent.name.lower() == 'instance' or file.name.lower() in ('pos.db', 'stock.db'):
        parser.error('Por seguridad, copiá la base a otra carpeta y renombrala COPIA_POS.db antes de auditarla')
    with sqlite3.connect(file.as_uri() + '?mode=ro', uri=True) as db:
        integrity = db.execute('PRAGMA integrity_check').fetchone()[0]
        refs = len(db.execute('PRAGMA foreign_key_check').fetchall())
        print('Auditoría SOLO LECTURA:', file.name)
        print('Integridad SQLite:', integrity, '| Referencias inválidas:', refs)
        if integrity != 'ok':
            print('ERROR: base de copia con integridad fallida; no se analizarán importes')
            return 2
        tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        checked = 0
        for title, params in [('Ventas', ('sales','sale_items','total','sale_id','line_total')),('Compras', ('purchases','purchase_items','total','purchase_id','line_total'))]:
            if not set(params[:2]).issubset(tables):
                print(title, ': tablas ausentes (omitido)')
                continue
            columns = {t: {r[1] for r in db.execute(f'PRAGMA table_info("{t}")')} for t in params[:2]}
            if params[2] not in columns[params[0]] or not {params[3], params[4]}.issubset(columns[params[1]]):
                print(title, ': columnas no compatibles (omitido)')
                continue
            checked += 1
            summary, samples = audit(db, *params)
            print('\n' + title)
            print('  Operaciones:', summary['operations'])
            print('  Coinciden:', summary['matching_operations'])
            print('  Diferencias:', summary['different_operations'])
            print('  Sin detalles:', summary['without_details'])
            print('  Importes inválidos:', summary['invalid_amount'])
            print('  Diferencias de 1 centavo:', summary['one_cent_operations'])
            print('  Diferencias de más de 1 centavo:', summary['multi_cent_operations'])
            print('  Diferencia neta (centavos):', summary['difference_cents_net'])
            print('  Suma absoluta de diferencias (centavos):', summary['difference_cents_abs'])
            print('  Mayor diferencia por operación (centavos):', summary['difference_cents_max'])
            if samples:
                print('  Primeros 10 ID y diferencias en centavos:', samples)
        if checked == 0:
            print('ERROR: no se pudo analizar ventas ni compras porque faltan tablas o columnas compatibles')
            return 3
    print('\nNo se ha modificado ningún dato ni realizado una migración.')
    return 0

if __name__ == '__main__':
    sys.exit(main())
