"""Regresiones de revisión: validación, caja, proveedores, login y stock concurrente.

Todas las escrituras usan una base temporal, sin datos del negocio.
"""
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from pathlib import Path
import os
import sys
import tempfile
import threading
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import xlwt
import app.config as config
import app.db as db_module
import app.route_modules.products as product_routes
import app.route_modules.stock as stock_routes
from app import create_app
from app.db import get_db, update_settings
from werkzeug.security import generate_password_hash

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {key: getattr(config, key) for key in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_review_corrections_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base / 'instance',
                               BACKUP_DIR=base / 'backups', DATABASE=base / 'instance' / 'pos.db',
                               UPLOAD_DIR=base / 'uploads', TICKET_DIR=base / 'tickets').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = True
        client = app.test_client()

        def query(sql, args=()):
            with app.app_context():
                return [tuple(row) for row in get_db().execute(sql, args)]

        payload = {'name': 'Producto revisión', 'cost_without_tax': 10, 'stock': 10}
        product = client.post('/api/products', json=payload).json
        pid = product['id']
        snapshot = query('SELECT cost_without_tax, sale_price, stock FROM products WHERE id=?', (pid,))
        for field in ('cost_without_tax', 'stock', 'min_stock', 'iva_percent', 'gross_income_percent', 'margin_percent'):
            for invalid in ('abc', 'NaN', 'Infinity', [], {}, True):
                data = dict(payload, **{field: invalid})
                assert client.post('/api/products', json=data).status_code == 400, (field, invalid)
                assert client.put(f'/api/products/{pid}', json=data).status_code == 400, (field, invalid)
        assert query('SELECT cost_without_tax, sale_price, stock FROM products WHERE id=?', (pid,)) == snapshot
        assert query('SELECT COUNT(*) FROM products') == [(1,)]

        # La importación no debe convertir una celda no numérica en precio cero.
        book = xlwt.Workbook()
        sheet = book.add_sheet('Precios')
        for col, value in enumerate(('Nombre', 'Precio venta', 'Precio sin impuestos')):
            sheet.write(0, col, value)
        for col, value in enumerate(('Precio válido', 20, 10)):
            sheet.write(1, col, value)
        for col, value in enumerate(('Precio inválido', 20, 'abc')):
            sheet.write(2, col, value)
        output = BytesIO()
        book.save(output)
        output.seek(0)
        invalid_import = client.post('/api/prices/import', data={'file': (output, 'precios.xls')})
        assert invalid_import.status_code == 400, invalid_import.json
        assert query('SELECT COUNT(*) FROM products') == [(1,)]

        for url in ('/api/clients', '/api/products', '/api/suppliers', '/api/users',
                    '/api/login', '/api/first-setup', '/api/settings', '/api/sales/1/ticket-pdf'):
            for body in ('null', '[]', '5', '"texto"', '{', ''):
                assert client.post(url, data=body, content_type='application/json').status_code == 400, (url, body)
        print('OK: importes inválidos y JSON sin objeto se rechazan sin cambios parciales')

        margin_payload = dict(payload, margin_percent=150)
        assert client.put(f'/api/products/{pid}', json=margin_payload).status_code == 200
        purchase = client.post('/api/purchases', json={'items': [
            {'product_id': pid, 'quantity': 1, 'cost_without_tax': 10, 'margin_percent': 150}
        ]})
        assert purchase.status_code == 200, purchase.json
        after = client.get(f'/api/products/{pid}').json
        assert after['margin_percent'] == 150 and after['sale_price'] == 25
        print('OK: margen 150% válido tanto en Productos como en Compras')

        supplier = client.post('/api/suppliers', json={'name': 'Proveedor revisión'}).json
        linked_payload = dict(payload, supplier_id=supplier['id'])
        linked = client.post('/api/products', json=linked_payload).json
        assert client.delete(f"/api/suppliers/{supplier['id']}", json={}).status_code == 409
        assert client.put(f"/api/products/{linked['id']}", json=linked_payload).status_code == 200
        assert client.put(f"/api/products/{linked['id']}", json=payload).status_code == 200
        assert client.delete(f"/api/suppliers/{supplier['id']}", json={}).status_code == 200
        assert client.post('/api/products', json=linked_payload).status_code == 400
        print('OK: proveedor asociado no se elimina; proveedor sin vínculos sí')

        # Una creación concurrente y un borrado de proveedor no dejan huérfanos.
        supplier = client.post('/api/suppliers', json={'name': 'Proveedor concurrente'}).json
        read_done, resume, attempted, finished = [threading.Event() for _ in range(4)]
        local = threading.local()
        original_connect = db_module.connect_database
        original_date = product_routes.normalize_date

        def traced_connect(*args, **kwargs):
            connection = original_connect(*args, **kwargs)
            def trace(sql):
                if getattr(local, 'role', '') == 'waiting' and sql == 'BEGIN IMMEDIATE':
                    attempted.set()
            connection.set_trace_callback(trace)
            return connection

        def paused_date(value):
            read_done.set()
            assert resume.wait(10)
            return original_date(value)

        def create_linked():
            return app.test_client().post('/api/products', json=dict(payload, supplier_id=supplier['id']))

        def delete_supplier():
            local.role = 'waiting'
            try:
                return app.test_client().delete(f"/api/suppliers/{supplier['id']}", json={})
            finally:
                finished.set()

        with patch.object(product_routes, 'normalize_date', side_effect=paused_date), \
             patch.object(db_module, 'connect_database', side_effect=traced_connect):
            with ThreadPoolExecutor(2) as pool:
                creating = pool.submit(create_linked)
                try:
                    assert read_done.wait(10)
                    deleting = pool.submit(delete_supplier)
                    assert attempted.wait(10)
                    assert not finished.wait(0.2)
                finally:
                    resume.set()
                assert creating.result(timeout=10).status_code == 201
                assert deleting.result(timeout=10).status_code == 409

        assert client.post('/api/cash/open', json={'initial_amount': 0}).status_code == 200
        movement = {'movement_type': 'Ingreso', 'amount': 100, 'description': 'Ingreso revisión'}
        retry_headers = {'Idempotency-Key': 'review-cash-retry-0001'}
        first = client.post('/api/cash/movement', json=movement, headers=retry_headers)
        replay = client.post('/api/cash/movement', json=movement, headers=retry_headers)
        assert first.status_code == replay.status_code == 200
        assert replay.headers['Idempotency-Replayed'] == 'true'
        assert client.post('/api/cash/movement', json=dict(movement, amount=200), headers=retry_headers).status_code == 409
        assert query('SELECT COUNT(*), SUM(amount) FROM cash_movements') == [(1, 100)]
        with app.app_context():
            db = get_db()
            db.execute("CREATE TRIGGER fail_review_receipt BEFORE INSERT ON operation_receipts BEGIN SELECT RAISE(ABORT, 'fallo simulado'); END")
            db.commit()
        failed_headers = {'Idempotency-Key': 'review-cash-failed-0001'}
        with patch.object(app.logger, 'exception'):
            failed = client.post('/api/cash/movement', json=movement, headers=failed_headers)
        assert failed.status_code == 500
        assert query('SELECT COUNT(*), SUM(amount) FROM cash_movements') == [(1, 100)]
        with app.app_context():
            db = get_db()
            db.execute('DROP TRIGGER fail_review_receipt')
            db.commit()
        assert client.post('/api/cash/movement', json=movement, headers=failed_headers).status_code == 200
        assert client.get('/api/cash/status').json['session']['expected_amount'] == 200
        print('OK: reintento de caja no duplica; fallo intermedio revierte movimiento y recibo juntos')

        # Un ajuste que ya leyó stock bloquea la venta hasta confirmar el historial.
        concurrent = client.post('/api/products', json=payload).json
        read_done, resume, attempted, finished = [threading.Event() for _ in range(4)]
        original_money = stock_routes.money

        def paused_money(value):
            read_done.set()
            assert resume.wait(10)
            return original_money(value)

        def adjust():
            return app.test_client().post('/api/stock/adjust', json={'product_id': concurrent['id'], 'new_stock': 5})

        def sell():
            local.role = 'waiting'
            try:
                return app.test_client().post('/api/sales', json={
                    'items': [{'product_id': concurrent['id'], 'quantity': 2}]
                }, headers={'Idempotency-Key': 'review-sale-stock-0001'})
            finally:
                finished.set()

        with patch.object(stock_routes, 'money', side_effect=paused_money), \
             patch.object(db_module, 'connect_database', side_effect=traced_connect):
            with ThreadPoolExecutor(2) as pool:
                adjusting = pool.submit(adjust)
                try:
                    assert read_done.wait(10)
                    selling = pool.submit(sell)
                    assert attempted.wait(10)
                    assert not finished.wait(0.2)
                finally:
                    resume.set()
                assert adjusting.result(timeout=10).status_code == 200
                assert selling.result(timeout=10).status_code == 200
        assert query('SELECT stock FROM products WHERE id=?', (concurrent['id'],)) == [(3,)]
        assert query('SELECT movement_type, quantity, previous_stock, new_stock FROM product_movements WHERE product_id=? ORDER BY id',
                     (concurrent['id'],)) == [('Ajuste manual', -5, 10, 5), ('Venta', -2, 5, 3)]
        print('OK: ajuste/venta concurrentes conservan stock y continuidad del historial')

        cashier = client.post('/api/users', json={
            'username': 'cajero_revision', 'role': 'Cajero', 'user_password': 'clave1234'
        }).json
        login = app.test_client()
        assert login.post('/api/login', json={'username': 'CAJERO_REVISION', 'password': 'clave1234'}).status_code == 200
        with login.session_transaction() as sess:
            assert sess['username'] == 'cajero_revision' and sess['user_role'] == 'Cajero'
            assert sess['authenticated_login'] and not sess.get('passwordless_admin_login')
        assert login.post('/api/admin-check', json={}).status_code == 403
        assert login.post('/api/settings', json={'business_name': 'Negocio revisión'}).status_code == 200
        with login.session_transaction() as sess:
            assert sess['username'] == 'cajero_revision'
        assert login.post('/api/admin-check', json={}).status_code == 403
        with app.app_context():
            update_settings({'admin_password_hash': generate_password_hash('clave-seguridad')})
        keys_response = login.post('/api/system-keys', json={
            'default_cashier_name': 'Caja mostrador', 'login_username': 'admin',
            'security_password': 'clave-seguridad'
        })
        assert keys_response.status_code == 200, keys_response.json
        assert keys_response.json['system_keys']['default_cashier_name'] == 'Caja mostrador'
        with login.session_transaction() as sess:
            assert sess['username'] == 'cajero_revision'
        assert login.post('/api/admin-check', json={}).status_code == 403
        assert login.post('/api/login', json={'username': 'cajero_revision', 'password': 'incorrecta'}).status_code == 403
        assert client.put(f"/api/users/{cashier['id']}", json={
            'username': 'cajero_revision', 'role': 'Cajero', 'is_active': False
        }).status_code == 200
        assert login.post('/api/login', json={'username': 'cajero_revision', 'password': 'clave1234'}).status_code == 403
        with app.app_context():
            update_settings({'login_password_hash': generate_password_hash('clave-global')})
        legacy = app.test_client()
        assert legacy.post('/api/login', json={'username': 'admin', 'password': 'clave-global'}).status_code == 200
        automatic = app.test_client()
        assert automatic.get('/api/products').status_code == 200
        with automatic.session_transaction() as sess:
            assert sess['passwordless_admin_login'] and sess['user_role'] == 'Administrador'
        assert query('PRAGMA quick_check') == [('ok',)]
        assert query('PRAGMA foreign_key_check') == []
        print('OK: login por usuario, rol y estado activo; acceso global y arranque local compatibles')
finally:
    for key, value in saved.items():
        setattr(config, key, value)
