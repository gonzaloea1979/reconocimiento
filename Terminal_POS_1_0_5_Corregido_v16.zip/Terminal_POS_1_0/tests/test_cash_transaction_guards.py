"""Comprueba que las operaciones de escritura de caja tengan guardas de rollback."""
from tests.route_source import read_all_routes
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / 'app' / 'routes.py'
tree = ast.parse(read_all_routes(ROOT))
required = {'api_cash_open', 'api_cash_movement', 'api_cash_close'}
found = {}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in required:
        found[node.name] = {d.id if isinstance(d, ast.Name) else getattr(d, 'attr', '') for d in node.decorator_list}
if set(found) != required:
    raise SystemExit(f'ERROR: faltan funciones de caja: {required - set(found)}')
for name, decorators in found.items():
    if 'rollback_on_db_error' not in decorators:
        raise SystemExit(f'ERROR: {name} no tiene rollback_on_db_error')
source = read_all_routes(ROOT)
for phrase in ('Los datos de apertura deben ser un objeto válido', 'Los datos del movimiento deben ser un objeto válido', 'Los datos del cierre deben ser un objeto válido'):
    if phrase not in source:
        raise SystemExit(f'ERROR: falta validación de caja: {phrase}')
print('OK: aperturas, movimientos y cierres tienen rollback y validación de payload')
