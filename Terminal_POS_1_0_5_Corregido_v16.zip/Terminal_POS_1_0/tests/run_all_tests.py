"""Ejecuta las pruebas portátiles en un único proceso, sin depender de pytest."""
from pathlib import Path
import sys
import runpy
import traceback

ROOT = Path(__file__).resolve().parents[1]
# Ensure project package imports work when launched via tests\run_all_tests.py on Windows.
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
TESTS = sorted(p for p in (ROOT / "tests").glob("test_*.py")
               if p.name != "test_runner_placeholder.py")
failures, skipped, passed = [], [], []
for index, test in enumerate(TESTS, 1):
    print(f"\n[{index}/{len(TESTS)}] {test.name}", flush=True)
    try:
        runpy.run_path(str(test), run_name="__main__")
        passed.append(test.name)
    except SystemExit as exc:
        if exc.code in (None, 0):
            passed.append(test.name)
        elif exc.code == 77:
            skipped.append(test.name)
        else:
            failures.append((test.name, f"SystemExit({exc.code})"))
    except BaseException as exc:
        if isinstance(exc, KeyboardInterrupt):
            raise
        failures.append((test.name, repr(exc)))
        traceback.print_exc()
if failures:
    print("\nFALLARON:", flush=True)
    for name, error in failures:
        print(f" - {name}: {error}", flush=True)
    raise SystemExit(1)
print(f"\nOK: {len(passed)} pruebas; omitidas por dependencia no disponible: {len(skipped)}", flush=True)
if skipped:
    print("OMITIDAS: " + ", ".join(skipped), flush=True)
