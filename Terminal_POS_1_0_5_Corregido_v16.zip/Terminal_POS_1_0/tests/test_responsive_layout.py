"""Chequeos estáticos de regresión responsive; no sustituyen captura visual real."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
css = (ROOT / 'app' / 'static' / 'css' / 'styles.css').read_text(encoding='utf-8')
required_rules = [
    '@media (max-width: 999px)',
    '@media (min-width: 1000px) and (max-height: 640px)',
    '.app-shell', '.main-content', '.module-fit-view',
    'min-width: 0;', 'overflow-x: auto;',
]
for rule in required_rules:
    if rule not in css:
        raise SystemExit(f'ERROR: falta regla responsive esperada: {rule}')

module_templates = [
    'dashboard.html', 'sales.html', 'products.html', 'purchases.html', 'cash.html',
    'stock.html', 'reports.html', 'settings.html', 'clients.html', 'suppliers.html',
    'audit.html', 'price_check.html', 'price_lists.html', 'users.html', 'ticket_design.html'
]
for name in module_templates:
    content = (ROOT / 'app' / 'templates' / name).read_text(encoding='utf-8')
    if 'module-fit-view' not in content and 'dashboard-fit-view' not in content:
        raise SystemExit(f'ERROR: el módulo {name} no declara contenedor adaptable conocido')

print(f'OK: reglas responsive y {len(module_templates)} plantillas con contenedor adaptable comprobados')
