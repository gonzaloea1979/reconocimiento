"""Compatibilidad de pruebas AST: combina módulos reales sin ejecutarlos."""
from pathlib import Path

def read_all_routes(root):
    app = Path(root) / "app"
    paths = [app / "route_core.py", *sorted((app / "route_services").glob("*.py")), *sorted((app / "route_modules").glob("*.py"))]
    return "\n\n".join(path.read_text(encoding="utf-8") for path in paths)
