"""Termina procesos reales antes/después del commit; verifica recuperación SQLite."""
from pathlib import Path
import hashlib, json, os, subprocess, sys, tempfile, time
from contextlib import closing
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import app.config as config
from app import create_app
from app.db import get_db, backup_database
import xlwt
keys=('BASE_DIR','INSTANCE_DIR','BACKUP_DIR','DATABASE','UPLOAD_DIR','TICKET_DIR');saved={k:getattr(config,k) for k in keys}
def crash(base,mode):
    marker=base/(mode+'.ready');log=base/(mode+'.log')
    with log.open('w',encoding='utf-8') as out:
        proc=subprocess.Popen([sys.executable,str(ROOT/'tests/crash_worker.py'),str(base),mode,str(marker)],stdout=out,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONUTF8='1',POS_SEED_DEMO_PRODUCTS='0'))
        try:
            deadline=time.monotonic()+20
            while not marker.exists() and proc.poll() is None and time.monotonic()<deadline:time.sleep(.02)
            assert marker.exists(), mode+': '+log.read_text(encoding='utf-8')
        finally:
            if proc.poll() is None:proc.kill()
            proc.wait(timeout=10)
        assert proc.returncode!=0
try:
    with tempfile.TemporaryDirectory(prefix='pos_crash_recovery_') as tmp:
        b=Path(tmp).resolve()
        for k,v in dict(BASE_DIR=b,INSTANCE_DIR=b/'instance',BACKUP_DIR=b/'backups',DATABASE=b/'instance/pos.db',UPLOAD_DIR=b/'uploads',TICKET_DIR=b/'tickets').items():setattr(config,k,v)
        with patch.dict(os.environ,{'POS_SEED_DEMO_PRODUCTS':'0'}):app=create_app()
        app.config['TESTING']=True;c=app.test_client()
        pid=c.post('/api/products',json={'name':'Original','cost_without_tax':10,'stock':10}).json['id']
        cid=c.post('/api/clients',json={'name':'Cuenta','balance':0}).json['id']
        payload={'items':[{'product_id':pid,'quantity':2}],'payment_method':'Cuenta corriente','client_id':cid}
        (b/'payload.json').write_text(json.dumps(payload))
        def query(sql,args=()):
            with app.app_context():return [tuple(r) for r in get_db().execute(sql,args)]
        def state():return {t:query('SELECT * FROM '+t) for t in ('products','sales','sale_items','clients','client_movements','product_movements','cash_movements','operation_receipts')}
        before=state();crash(b,'sale_before')
        assert state()==before,'Venta interrumpida dejó cambios parciales'
        assert query('PRAGMA integrity_check')==[('ok',)] and query('PRAGMA foreign_key_check')==[]
        crash(b,'sale_after')
        assert query('SELECT stock FROM products WHERE id=?',(pid,))==[(8.0,)]
        assert query('SELECT balance FROM clients WHERE id=?',(cid,))==[(20.0,)]
        committed=state()
        replay=c.post('/api/sales',json=payload,headers={'Idempotency-Key':'crash-sale-retry-001'})
        assert replay.status_code==200 and replay.headers.get('Idempotency-Replayed')=='true',replay.json
        assert state()==committed,'El reintento duplicó una venta confirmada antes del cierre'
        print('OK: proceso terminado antes del commit revierte; después del commit conserva venta/saldo/stock y reintento no duplica')
        wb=xlwt.Workbook();sheet=wb.add_sheet('Precios')
        for row,cells in enumerate([['ID','Nombre','Precio venta'],[pid,'Cambio 1',11],[pid,'Cambio 2',12]]):
            for col,value in enumerate(cells):sheet.write(row,col,value)
        wb.save(str(b/'prices.xls'));before=state();crash(b,'import')
        assert state()==before,'Importación interrumpida dejó una fila confirmada'
        with (b/'prices.xls').open('rb') as f:r=c.post('/api/prices/import',data={'file':(f,'prices.xls')})
        assert r.status_code==200,r.json
        assert query('SELECT name,sale_price FROM products WHERE id=?',(pid,))==[('Cambio 2',12.0)]
        print('OK: importación cortada tras una fila revierte archivo completo y permite importar al reiniciar')
        # Forzar más de 256 páginas para interrumpir una copia realmente parcial.
        with app.app_context():
            db=get_db();db.execute('CREATE TABLE crash_padding (value BLOB)');db.execute('INSERT INTO crash_padding VALUES (zeroblob(3000000))');db.commit()
            previous=backup_database()
        previous_hash=hashlib.sha256(previous.read_bytes()).hexdigest()
        for mode in ('backup_partial','backup_publish'):
            before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (b/'backups').glob('pos_backup_*.db')}
            crash(b,mode)
            assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (b/'backups').glob('pos_backup_*.db')}==before
            assert list((b/'backups').glob('.pos_backup_*.tmp')),'No quedó evidencia del respaldo interrumpido'
            with app.app_context():recovered=backup_database()
            import sqlite3
            with closing(sqlite3.connect(recovered)) as db:
                assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)]
                assert db.execute('PRAGMA foreign_key_check').fetchall()==[]
                assert db.execute('SELECT COUNT(*) FROM sales').fetchone()[0]==1
            assert hashlib.sha256(previous.read_bytes()).hexdigest()==previous_hash
        print('OK: respaldo cortado durante copia y antes de publicar no reemplaza copias válidas; siguiente respaldo recuperable')
finally:
    for k,v in saved.items():setattr(config,k,v)
