"""V106 SQL production vs preserved V105 baseline: synthetic database only."""
import ast, sqlite3, tempfile, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from prueba_carga_v106 import create_fallback_database, seed_database
from diagnostico_reportes_v105 import current_sql
source=(root/'app/route_modules/reports.py').read_text(encoding='utf-8')
tree=ast.parse(source)
route=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='api_reports')
node=next(n for n in ast.walk(route) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='report_rollups' for t in n.targets))
production=node.value.func.value.args[0].value
assert 'period_sales AS NOT MATERIALIZED' in production
assert 'item_agg AS NOT MATERIALIZED' in production
assert 'product_rollup AS MATERIALIZED' in production
baseline=current_sql()
assert 'period_sales AS MATERIALIZED' in baseline
assert 'item_agg AS MATERIALIZED' in baseline
with tempfile.TemporaryDirectory(prefix='pos_v106_safe_') as tmp:
    dbpath=Path(tmp)/'synthetic.db'
    create_fallback_database(dbpath); seed_database(dbpath)
    con=sqlite3.connect(dbpath)
    for rng in [('2026-10-02','2026-11-01'),('2026-10-25','2026-11-01'),('2035-01-01','2035-01-31')]:
        assert con.execute(baseline,rng).fetchall()==con.execute(production,rng).fetchall(),rng
    con.execute('SAVEPOINT snapshots')
    try:
        con.execute('UPDATE sale_items SET unit_cost_at_sale=NULL WHERE id IN (SELECT id FROM sale_items LIMIT 101)')
        for rng in [('2026-10-02','2026-11-01'),('2026-10-25','2026-11-01')]:
            assert con.execute(baseline,rng).fetchall()==con.execute(production,rng).fetchall(),rng
    finally:
        con.execute('ROLLBACK TO snapshots');con.execute('RELEASE snapshots')
    assert con.execute('PRAGMA quick_check').fetchone()[0]=='ok'
    assert not con.execute('PRAGMA foreign_key_check').fetchall()
    con.close()
print('OK: V106 matches V105 report rollups, including NULL costs, date ranges, and empty periods.')
