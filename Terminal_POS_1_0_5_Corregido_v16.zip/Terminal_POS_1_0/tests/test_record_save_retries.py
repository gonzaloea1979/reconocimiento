"""Guardados JSON/multipart: reintentos, concurrencia y rollback reales."""
from pathlib import Path
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
import sys, tempfile, threading, sqlite3
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import app.config as config
import app.route_modules.users as users
from app import create_app
from app.db import get_db
from PIL import Image
keys=('BASE_DIR','INSTANCE_DIR','BACKUP_DIR','DATABASE','UPLOAD_DIR','TICKET_DIR')
saved={k:getattr(config,k) for k in keys}
try:
 with tempfile.TemporaryDirectory() as tmp:
  b=Path(tmp)
  for k,v in dict(BASE_DIR=b,INSTANCE_DIR=b/'instance',BACKUP_DIR=b/'backups',DATABASE=b/'instance'/'pos.db',UPLOAD_DIR=b/'uploads',TICKET_DIR=b/'tickets').items():setattr(config,k,v)
  app=create_app();app.config['TESTING']=True;c=app.test_client()
  def query(sql,args=()):
   with app.app_context():return [tuple(r) for r in get_db().execute(sql,args)]
  cases=[('clients',{'name':'Cliente','balance':100}),('users',{'username':'usuario_prueba','user_password':'clave1234','role':'Cajero'}),('products',{'name':'Producto','stock':5,'cost_without_tax':10})]
  records={}
  for table,payload in cases:
   key='record-create-retry-'+table
   headers={'Idempotency-Key':key};url='/api/'+table
   first=c.post(url,json=payload,headers=headers)
   assert first.status_code==201,first.json
   replay=c.post(url,json=payload,headers=headers)
   assert replay.status_code==201 and replay.json==first.json and replay.headers['Idempotency-Replayed']=='true'
   assert c.post(url,json=dict(payload,notes='otro'),headers=headers).status_code==409
   records[table]=first.json
   gate=threading.Barrier(2)
   data=dict(payload)
   if table=='users':data['username']='usuario_concurrente'
   else:data['name']='Concurrente'
   def send(_):
    gate.wait(timeout=10)
    return app.test_client().post(url,json=data,headers={'Idempotency-Key':key+'-parallel'})
   before=query('SELECT COUNT(*) FROM '+table)[0][0]
   with ThreadPoolExecutor(2) as pool:responses=list(pool.map(send,range(2)))
   assert [r.status_code for r in responses]==[201,201]
   assert responses[0].json==responses[1].json
   assert query('SELECT COUNT(*) FROM '+table)==[(before+1,)]
  assert query("SELECT COUNT(*) FROM client_movements WHERE movement_type='Saldo inicial'")==[(2,)]
  for table,data in [('clients',{'name':'Editado'}),('users',{'username':'usuario_prueba','role':'Cajero','user_password':'nueva1234'}),('products',{'name':'Producto','cost_without_tax':12,'stock':4,'original_stock':5})]:
   url=f"/api/{table}/{records[table]['id']}";headers={'Idempotency-Key':'record-update-retry-'+table}
   a=c.put(url,json=data,headers=headers);r=c.put(url,json=data,headers=headers)
   assert a.status_code==r.status_code==200,(a.json,r.json)
   assert r.json==a.json and r.headers['Idempotency-Replayed']=='true'
  assert query('SELECT session_version FROM users WHERE id=?',(records['users']['id'],))==[(1,)]
  assert query('SELECT COUNT(*) FROM product_movements')==[(1,)]
  def png(color):
   out=BytesIO()
   with Image.new('RGB',(2,2),color) as im:im.save(out,format='PNG')
   return out.getvalue()
  def photo(raw):return c.post('/api/products',data={'name':'Foto','cost_without_tax':'1','photo':(BytesIO(raw),'foto.png')},headers={'Idempotency-Key':'record-photo-retry-001'})
  first=photo(png('red'));assert first.status_code==201,first.json
  replay=photo(png('red'));assert replay.status_code==201 and replay.json==first.json
  assert photo(png('blue')).status_code==409
  assert len(list(config.UPLOAD_DIR.glob('*')))==1
  with app.app_context():
   db=get_db();db.execute("CREATE TRIGGER fail_receipt BEFORE INSERT ON operation_receipts BEGIN SELECT RAISE(ABORT,'fallo simulado'); END");db.commit()
  before=query('SELECT COUNT(*) FROM clients')
  with patch.object(app.logger,'exception'):
   assert c.post('/api/clients',json={'name':'Rollback','balance':10},headers={'Idempotency-Key':'record-failed-retry-001'}).status_code==500
  assert query('SELECT COUNT(*) FROM clients')==before
  with app.app_context():
   db=get_db();db.execute('DROP TRIGGER fail_receipt');db.commit()
  with patch.object(users,'generate_password_hash',side_effect=sqlite3.OperationalError('fallo simulado')),patch.object(app.logger,'exception'):
   assert c.post('/api/users',json={'username':'no_guardar','user_password':'clave1234'}).status_code==500
  assert query("SELECT COUNT(*) FROM users WHERE username='no_guardar'")==[(0,)]
  assert query('PRAGMA quick_check')==[('ok',)] and query('PRAGMA foreign_key_check')==[]
  print('OK: altas/ediciones JSON, envíos concurrentes, fotos y claves repetidas no duplican registros ni movimientos')
  print('OK: cambios de contraseña se aplican una vez; fallos internos devuelven 500 y revierten datos')
finally:
 for k,v in saved.items():setattr(config,k,v)
