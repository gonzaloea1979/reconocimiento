"""Regresión 1.0.5.6: dos fuentes de error 500 en campos numéricos/con listas.

1. ``normalize_rounding_mode`` hacía ``value.strip()`` sobre el valor crudo.
   Un ``product_rounding_mode`` numérico o en lista rompía con AttributeError
   (500) al guardar la configuración. Ahora cae al valor por defecto.

2. ``build_product_labels_pdf`` convertía ``int(item['product_id'])`` sin
   proteger; un ``product_id`` en lista rompía con TypeError (500) al generar
   etiquetas. Ahora el ítem inválido se omite, como ya ocurría con los ítems
   que no son diccionario.

Usa una base temporal; nunca toca datos comerciales.
"""
from pathlib import Path
import os
import sys
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import app.config as config
from app import create_app

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {k: getattr(config, k) for k in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_v1056_regressions_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base / 'instance',
                               BACKUP_DIR=base / 'backups', DATABASE=base / 'instance' / 'pos.db',
                               UPLOAD_DIR=base / 'uploads', TICKET_DIR=base / 'TICKET').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = False
        app.logger.disabled = True
        client = app.test_client()
        assert client.get('/api/products').status_code == 200

        product = client.post('/api/products', json={
            'name': 'P', 'cost_without_tax': 100, 'iva_percent': 21,
            'margin_percent': 30, 'stock': 10,
        }).get_json()
        product_id = product['id']

        # 1. Modo de redondeo con tipo inválido: no rompe, guarda el predeterminado.
        for bad_mode in (5, ['nearest'], {'a': 1}):
            response = client.post('/api/settings', json={
                'business_name': 'Negocio', 'product_rounding_mode': bad_mode,
            })
            assert response.status_code == 200, (bad_mode, response.status_code)
            assert response.get_json()['settings']['product_rounding_mode'] == 'none'
        # Un modo válido sigue aplicándose.
        ok = client.post('/api/settings', json={
            'business_name': 'Negocio', 'product_rounding_mode': 'nearest',
            'product_rounding_multiple': 10,
        })
        assert ok.status_code == 200
        assert ok.get_json()['settings']['product_rounding_mode'] == 'nearest'

        # 2. Etiquetas con product_id inválido: 400, nunca 500.
        bad_labels = client.post('/api/product-labels/pdf', json={
            'items': [{'product_id': [1, 2], 'quantity': 1}],
        })
        assert bad_labels.status_code == 400, bad_labels.status_code
        # Un ítem válido junto a uno inválido genera el PDF con el válido.
        mixed = client.post('/api/product-labels/pdf', json={
            'items': [{'product_id': product_id, 'quantity': 1},
                      {'product_id': {'x': 1}, 'quantity': 2}],
        })
        assert mixed.status_code == 200, mixed.status_code
        assert mixed.headers['Content-Type'] == 'application/pdf'

        print('OK: campos numéricos/de lista no provocan 500')
finally:
    for key, value in saved.items():
        setattr(config, key, value)
