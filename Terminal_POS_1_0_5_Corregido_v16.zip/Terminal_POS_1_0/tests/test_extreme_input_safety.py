"""Entradas extremas: errores HTTP útiles, centavos y rollback sin datos parciales."""
from pathlib import Path
from io import BytesIO
import sys, tempfile
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app import create_app
import app.config as config
from app.db import get_db
from app.route_services.money import strict_number, money_product, money_sum, calculate_prices

for operation in [lambda: strict_number('9007199254740993', 'Importe'),
                  lambda: strict_number('1e1000000', 'Cantidad'),
                  lambda: money_product('999999999999.99', 2),
                  lambda: money_sum(['999999999999.99', '.01']),
                  lambda: calculate_prices(999999999999, 100, 0, 0)]:
    try: operation()
    except ValueError: pass
    else: raise AssertionError('Se aceptó un resultado que excede el rango seguro')
assert strict_number('999999999999.99', 'Importe') == 999999999999.99
assert money_product('0.335', 3) == 1.01
assert money_sum([.1, .2]) == .3
keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {k: getattr(config, k) for k in keys}
try:
    with tempfile.TemporaryDirectory() as tmp:
        b = Path(tmp)
        for k, v in dict(BASE_DIR=b, INSTANCE_DIR=b/'instance', BACKUP_DIR=b/'backups', DATABASE=b/'instance/pos.db', UPLOAD_DIR=b/'uploads', TICKET_DIR=b/'tickets').items(): setattr(config, k, v)
        app = create_app(); app.config['TESTING'] = True; c = app.test_client()
        def rows(sql, args=()):
            with app.app_context(): return [tuple(r) for r in get_db().execute(sql, args)]
        def counts():
            return {t: rows('SELECT COUNT(*) FROM '+t) for t in ('products','purchases','purchase_items','product_movements','sales','sale_items','client_movements','operation_receipts')}
        for extra in ({'stock': '1e100'}, {'cost_without_tax': '9007199254740993'}, {'cost_without_tax': '999999999999', 'iva_percent': 100}, {'stock': '-0.001'}, {'iva_percent': '100.004'}, {'supplier_id': 1e100}, {'supplier_id': 1.5}):
            before = counts()
            response = c.post('/api/products', json=dict(name='No guardar', **extra), headers={'Idempotency-Key':'invalid-product-'+str(len(str(extra)))})
            assert response.status_code == 400, (extra, response.status_code, response.json)
            assert counts() == before
        product = c.post('/api/products', json={'name':'Producto', 'stock':10, 'cost_without_tax':1}).json
        pid = product['id']
        assert c.get(f'/api/products/{10**100}').status_code == 400
        for resource in ('clients', 'users'):
            assert c.put(f'/api/{resource}/{10**100}', json={'name':'No guardar'}).status_code == 400
        for product_id in (10**100, 1e100, 'Infinity', 1.5, True):
            r = c.post('/api/sales', json={'items':[{'product_id':product_id, 'quantity':1}]})
            assert r.status_code == 400, (product_id, r.status_code, r.json)
        before = counts()
        r = c.post('/api/sales', json={'items':[{'product_id':pid, 'quantity':2, 'unit_price':'999999999999.99'}]}, headers={'Idempotency-Key':'extreme-sale-line'})
        assert r.status_code == 400, r.json
        assert counts() == before and rows('SELECT stock FROM products WHERE id=?',(pid,)) == [(10.0,)]
        # Fractional negatives must not be rounded into valid zero amounts.
        for url, payload in [('/api/cash/open', {'initial_amount':'-0.001'}),
                             ('/api/stock/adjust', {'product_id':pid,'new_stock':'-0.001'}),
                             ('/api/sales', {'amount_received':'-0.001','items':[{'product_id':pid,'quantity':1}]}),
                             ('/api/purchases', {'items':[{'product_id':pid,'quantity':1,'unit_cost':'-0.001'}]})]:
            before=counts()
            response=c.post(url,json=payload)
            assert response.status_code==400,(url,response.status_code,response.json)
            assert counts()==before
        # A complete Excel import must reject out-of-range cells before any write.
        import xlwt
        wb=xlwt.Workbook();sheet=wb.add_sheet('Precios')
        for row, cells in enumerate([['ID','Nombre','Precio venta'],[pid,'Cambio válido',2],[pid,'Fuera de rango','9007199254740993']]):
            for col,value in enumerate(cells):sheet.write(row,col,value)
        out=BytesIO();wb.save(out);before=rows('SELECT name,sale_price FROM products WHERE id=?',(pid,))
        response=c.post('/api/prices/import',data={'file':(BytesIO(out.getvalue()),'extremos.xls')})
        assert response.status_code==400,response.json
        assert rows('SELECT name,sale_price FROM products WHERE id=?',(pid,))==before
        # A purchase overflow after writing its header and first item must roll back both.
        with app.app_context():
            db=get_db();db.execute('UPDATE products SET stock=? WHERE id=?',(999999999999.99,pid));db.commit()
        before=counts()
        r=c.post('/api/purchases',json={'items':[{'product_id':pid,'quantity':1,'unit_cost':1}]},headers={'Idempotency-Key':'extreme-purchase-stock'})
        assert r.status_code==400,r.json
        assert counts()==before and rows('SELECT stock FROM products WHERE id=?',(pid,))==[(999999999999.99,)]
        client=c.post('/api/clients',json={'name':'Cuenta','balance':'999999999999.99'}).json
        before=counts()
        r=c.post('/api/sales',json={'payment_method':'Cuenta corriente','client_id':client['id'],'items':[{'product_id':pid,'quantity':1}]},headers={'Idempotency-Key':'extreme-client-balance'})
        assert r.status_code==400,r.json
        assert counts()==before and rows('SELECT stock FROM products WHERE id=?',(pid,))==[(999999999999.99,)]
        assert rows('SELECT balance FROM clients WHERE id=?',(client['id'],))==[(999999999999.99,)]
        # Large UTF-8 text remains intact, without truncation or a server error.
        long_name='Producto ñ <script> & ' * 500
        r=c.post('/api/products',json={'name':long_name,'detail':'Descripción á '*2000,'cost_without_tax':1})
        assert r.status_code==201,r.json
        assert r.json['name']==long_name.strip()
        assert rows('PRAGMA quick_check')==[('ok',)] and rows('PRAGMA foreign_key_check')==[]
        print('OK: extremos numéricos, IDs y centavos; rechazo 400 sin escrituras ni recibos parciales; rollback de stock/saldos; texto Unicode largo íntegro')
finally:
    for k,v in saved.items():setattr(config,k,v)
