"""Asegura rollback también ante excepciones no SQLite en operaciones críticas."""
from tests.route_source import read_all_routes
import ast
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
source = read_all_routes(ROOT)
tree = ast.parse(source)
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "rollback_on_db_error")
segment = ast.get_source_segment(source, fn) or ""
assert "except sqlite3.Error" in segment
assert "except Exception" in segment
assert segment.count("get_db().rollback()") >= 2
assert "raise" in segment
print("OK: el decorador revierte transacciones tanto ante errores SQL como ante excepciones inesperadas")
