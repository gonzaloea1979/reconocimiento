"""Verifica la optimización de consultas del Dashboard sin alterar resultados."""
import sqlite3
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "app" / "route_modules" / "dashboard.py").read_text(encoding="utf-8")

assert "daily_metrics = db.execute(" in source
assert "daily_ticket_count = daily_metrics['ticket_count']" in source
assert "COALESCE(min_stock, 0)" not in source
assert "WHERE min_stock > 0 AND stock <= min_stock" in source

with tempfile.TemporaryDirectory(prefix="pos_dashboard_opt_") as tmp:
    db = sqlite3.connect(Path(tmp) / "dashboard.db")
    db.executescript("""
        CREATE TABLE sales(id INTEGER PRIMARY KEY, created_at TEXT NOT NULL, total REAL NOT NULL);
        CREATE INDEX idx_sales_created_at ON sales(created_at);
        CREATE TABLE products(
            id INTEGER PRIMARY KEY, name TEXT NOT NULL,
            stock REAL NOT NULL DEFAULT 0, min_stock REAL NOT NULL DEFAULT 0
        );
        CREATE INDEX idx_products_low_stock_priority
        ON products((stock-min_stock), name)
        WHERE min_stock > 0 AND stock <= min_stock;
    """)
    db.executemany(
        "INSERT INTO sales(id,created_at,total) VALUES(?,?,?)",
        [(i, f"2026-10-30T{(i % 24):02d}:00:00", float(i)) for i in range(1, 5001)]
    )
    db.executemany(
        "INSERT INTO products(id,name,stock,min_stock) VALUES(?,?,?,?)",
        [(i, f"P{i:05d}", float(i % 12), 5.0 if i % 3 == 0 else 0.0) for i in range(1, 5001)]
    )
    db.execute("ANALYZE")

    combined = db.execute(
        """SELECT COALESCE(SUM(total),0), COUNT(*)
           FROM sales WHERE created_at >= ? AND created_at < date(?, '+1 day')""",
        ("2026-10-30", "2026-10-30")
    ).fetchone()
    separate_total = db.execute(
        "SELECT COALESCE(SUM(total),0) FROM sales WHERE created_at >= ? AND created_at < date(?, '+1 day')",
        ("2026-10-30", "2026-10-30")
    ).fetchone()[0]
    separate_count = db.execute(
        "SELECT COUNT(*) FROM sales WHERE created_at >= ? AND created_at < date(?, '+1 day')",
        ("2026-10-30", "2026-10-30")
    ).fetchone()[0]
    assert combined == (separate_total, separate_count), "Las métricas combinadas no coinciden con las originales."

    plan = " ".join(str(r) for r in db.execute(
        "EXPLAIN QUERY PLAN SELECT COUNT(*) FROM products WHERE min_stock > 0 AND stock <= min_stock"
    ).fetchall())
    assert "idx_products_low_stock_priority" in plan, f"El Dashboard no usa el índice parcial: {plan}"

    low_count = db.execute(
        "SELECT COUNT(*) FROM products WHERE min_stock > 0 AND stock <= min_stock"
    ).fetchone()[0]
    old_semantics_count = db.execute(
        "SELECT COUNT(*) FROM products WHERE COALESCE(min_stock,0)>0 AND COALESCE(stock,0)<=COALESCE(min_stock,0)"
    ).fetchone()[0]
    assert low_count == old_semantics_count, "Cambió el resultado de alertas de stock."
    db.close()

print("OK: Dashboard combina dos lecturas diarias en una y usa el índice parcial de stock.")
