"""Proceso auxiliar de pruebas: nunca usar sobre una instalación real."""
from pathlib import Path
import json, os, sys, threading
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
base=Path(sys.argv[1]);mode=sys.argv[2];marker=Path(sys.argv[3])
def reached():
    marker.write_text('ready',encoding='utf-8')
    threading.Event().wait(45)
    raise RuntimeError('El coordinador no terminó el proceso de prueba')
if mode=='lock':
    from preparar_entorno import installation_lock
    with installation_lock(base):reached()
    raise SystemExit(2)
import app.config as config
for key,value in dict(BASE_DIR=base,INSTANCE_DIR=base/'instance',BACKUP_DIR=base/'backups',DATABASE=base/'instance/pos.db',UPLOAD_DIR=base/'uploads',TICKET_DIR=base/'tickets').items():setattr(config,key,value)
from unittest.mock import patch
from app import create_app
# Omitir solamente el respaldo automático de arranque; la operación probada es real.
with patch('app.backup_database',return_value=None):app=create_app()
app.config['TESTING']=True
payload=json.loads((base/'payload.json').read_text()) if (base/'payload.json').exists() else {}
if mode.startswith('sale'):
    if mode=='sale_before':
        import app.route_modules.sales as routes
        original=routes.stock_movement
        def pause(*a,**kw):
            original(*a,**kw)
            reached()
        routes.stock_movement=pause
    else:
        from flask import request
        @app.after_request
        def after_commit(response):
            if request.path=='/api/sales' and response.status_code==200:reached()
            return response
    response=app.test_client().post('/api/sales',json=payload,headers={'Idempotency-Key':'crash-sale-retry-001'})
elif mode=='import':
    import app.route_modules.prices as routes
    original=routes.calculate_prices;calls=0
    def pause(*a,**kw):
        global calls
        calls+=1
        if calls==2:reached()
        return original(*a,**kw)
    routes.calculate_prices=pause
    with (base/'prices.xls').open('rb') as f:
        response=app.test_client().post('/api/prices/import',data={'file':(f,'prices.xls')})
elif mode.startswith('backup'):
    import app.db as dbmod
    if mode=='backup_publish':
        dbmod.os.replace=lambda *a,**kw:reached()
    else:
        original=dbmod.connect_database
        class Source:
            def __init__(self,conn):self.conn=conn
            def close(self):self.conn.close()
            def backup(self,target,**kwargs):
                progress=kwargs['progress']
                def pause(status,remaining,total):
                    progress(status,remaining,total)
                    if remaining>0:reached()
                kwargs['progress']=pause
                return self.conn.backup(target,**kwargs)
        def connect(path,*a,**kw):
            connection=original(path,*a,**kw)
            return Source(connection) if kw.get('read_only') else connection
        dbmod.connect_database=connect
    with app.app_context():dbmod.backup_database()
else:raise RuntimeError(mode)
raise RuntimeError('No se alcanzó el punto de interrupción: '+mode)
