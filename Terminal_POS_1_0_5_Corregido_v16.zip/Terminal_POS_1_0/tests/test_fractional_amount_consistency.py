"""Comparación real de pantalla JS, API, SQLite, ticket PDF y Excel."""
from pathlib import Path
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import date
from decimal import Decimal, ROUND_HALF_UP
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
node=shutil.which('node')
if not node:
    print('SKIP: Node.js requerido para comparar pantalla e importes')
    raise SystemExit(77)
import app.config as config
from app import create_app
from app.db import get_db
import xlrd
from reportlab.pdfgen.canvas import Canvas

cases=[[("0.05","0.1"),("0.05","0.1")],[("19.99","0.33"),("2.675","1")],
       [("0.10","0.15"),("0.10","0.15")],[("1.25","0.015"),("0.99","0.35")]]
script=r'''
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=process.argv[1],cases=JSON.parse(process.argv[2]);
const elements=new Map();
const element=id=>{if(!elements.has(id)) elements.set(id,{value:'',textContent:'',innerHTML:'',className:'',focus(){},classList:{add(){},remove(){},contains(){return true;}}});return elements.get(id);};
const c={window:{addEventListener(){},location:{pathname:'/ventas'}},document:{addEventListener(){},getElementById:element,querySelector(){return null;}},console,setTimeout,clearTimeout,setInterval,clearInterval};
vm.createContext(c);
for(const f of ['money_decimal','common','sales','purchases']) vm.runInContext(fs.readFileSync(path.join(root,'app/static/js',f+'.js'),'utf8'),c);
c.updateClientSelectorVisibility=()=>{}; c.formatDateAR=()=>'';
const out=[];
for(const rows of cases){
 c.rows=rows;
 vm.runInContext(`cart=rows.map(([p,q],i)=>({product_id:i+1,name:'Producto',unit_price:Number(p),quantity:Number(q)}));
 purchaseItems=rows.map(([p,q])=>({name:'Producto',total_cost:Number(p),quantity:Number(q)}));`,c);
 element('paymentMethod').value='Efectivo';
 const total=c.cartTotal(); c.renderCart(); c.renderPurchaseItems();
 out.push({total,purchaseText:element('purchaseTotal').textContent,ticket:element('ticketItems').innerHTML,
           cart:element('cartTable').innerHTML,received:c.getAmountReceived(total)});
}
// Una suma repetida de cantidades no acumula residuos binarios.
vm.runInContext(`cart=[{product_id:1,unit_price:1,quantity:0.1}]; renderCart=()=>{}; hideSaleList=()=>{}; stopSaleNotFoundModal=()=>{}; beep=()=>{}; setTicketActionButtonsEnabled=()=>{};`,c);
c.addToCart({id:1,sale_price:1},0.2);
if(vm.runInContext('cart[0].quantity',c)!==0.3) throw new Error('Cantidad acumulada no decimal');
vm.runInContext('showToast=()=>{}',c);
c.updateQty(1,'0.015');
if(vm.runInContext('cart[0].quantity',c)!==0.02) throw new Error('Cantidad no normalizada');
c.updateQty(1,'NaN');
if(vm.runInContext('cart[0].quantity',c)!==0.02) throw new Error('Cantidad inválida alteró el carrito');
process.stdout.write(JSON.stringify(out));
'''
result=subprocess.run([node,'-e',script,str(ROOT),json.dumps(cases)],capture_output=True,text=True,timeout=20)
assert result.returncode==0,result.stdout+result.stderr
previews=json.loads(result.stdout)
keys=('BASE_DIR','INSTANCE_DIR','BACKUP_DIR','DATABASE','UPLOAD_DIR','TICKET_DIR')
saved={key:getattr(config,key) for key in keys}
round2=lambda x: Decimal(str(x)).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
try:
    with tempfile.TemporaryDirectory(prefix='pos_fractional_amounts_') as tmp:
        b=Path(tmp)
        for key,value in dict(BASE_DIR=b,INSTANCE_DIR=b/'instance',BACKUP_DIR=b/'backups',DATABASE=b/'instance'/'pos.db',UPLOAD_DIR=b/'uploads',TICKET_DIR=b/'TICKET').items(): setattr(config,key,value)
        with patch.dict(os.environ,{'POS_SEED_DEMO_PRODUCTS':'0'}): app=create_app()
        app.config['TESTING']=True
        cl=app.test_client(); assert cl.get('/api/products').status_code==200
        ids=[]
        for i in range(2):
            response=cl.post('/api/products',json={'barcode':f'FRACT-{i}','name':f'Fraccionado {i}','cost_without_tax':.05,'stock':100})
            assert response.status_code==201,response.json
            ids.append(response.json['id'])
        totals=[]
        for rows,preview in zip(cases,previews):
            lines=[round2(round2(p)*round2(q)) for p,q in rows]
            expected=float(sum(lines))
            assert preview['total']==expected and preview['received']==expected,(rows,preview,expected)
            assert f'{expected:.2f}'.replace('.',',') in preview['purchaseText'],preview
            items=[{'product_id':pid,'unit_price':p,'quantity':q} for pid,(p,q) in zip(ids,rows)]
            sale=cl.post('/api/sales',json={'items':items,'payment_method':'Efectivo','amount_received':preview['received']})
            assert sale.status_code==200,sale.json
            assert sale.json['total']==expected
            assert [item['line_total'] for item in sale.json['items']]==list(map(float,lines))
            totals.append(round2(expected))
            drawn=[]
            original=Canvas.drawString
            original_right=Canvas.drawRightString
            def capture(self,x,y,text,*args,**kwargs):
                drawn.append(str(text)); return original(self,x,y,text,*args,**kwargs)
            def capture_right(self,x,y,text,*args,**kwargs):
                drawn.append(str(text)); return original_right(self,x,y,text,*args,**kwargs)
            with patch.object(Canvas,'drawString',capture), patch.object(Canvas,'drawRightString',capture_right):
                ticket=cl.post(f"/api/sales/{sale.json['sale_id']}/ticket-pdf",json={})
            assert ticket.status_code==200,ticket.json
            assert any(f'{expected:.2f}'.replace('.',',') in text for text in drawn),drawn
            purchase=cl.post('/api/purchases',json={'items':[{'product_id':pid,'quantity':q,'cost_without_tax':p,'total_cost':p,'sale_price':p} for pid,(p,q) in zip(ids,rows)]})
            assert purchase.status_code==200,purchase.json
            assert purchase.json['total']==expected,(rows,purchase.json,expected)
        today=date.today().isoformat(); query=f'?from={today}&to={today}'
        report=cl.get('/api/reports'+query)
        expected_total=float(sum(totals))
        assert report.status_code==200 and report.json['summary']['total_sales']==expected_total,report.json
        assert round2(sum(r['total'] for r in report.json['top_products']))==sum(totals)
        assert round2(sum(r['total'] for r in report.json['by_payment']))==sum(totals)
        excel=cl.get('/api/reports/export'+query)
        assert excel.status_code==200
        book=xlrd.open_workbook(file_contents=excel.data); sheet=book.sheet_by_index(0)
        assert sheet.cell_value(4,1)==expected_total
        book.release_resources()
        drawn=[]
        with patch.object(Canvas,'drawString',capture): pdf=cl.get('/api/reports/export-pdf'+query)
        assert pdf.status_code==200 and pdf.data.startswith(b'%PDF')
        assert any('Total:' in text and f'{expected_total:.2f}'.replace('.',',') in text for text in drawn),drawn
        with app.app_context():
            db=get_db()
            assert round2(db.execute('SELECT SUM(total) FROM sales').fetchone()[0])==sum(totals)
            assert db.execute('PRAGMA quick_check').fetchone()[0]=='ok'
            assert not db.execute('PRAGMA foreign_key_check').fetchall()
        print('OK: 4 casos fraccionados coinciden en carrito, compras, API, SQLite, ticket PDF, reportes y Excel')
        print('OK: cantidades normalizadas, suma 0.1+0.2 exacta y entradas inválidas sin alterar carrito')
finally:
    for key,value in saved.items(): setattr(config,key,value)
