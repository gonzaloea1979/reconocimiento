"""Comprueba productos y sumas de líneas con aritmética decimal exacta."""
from tests.route_source import read_all_routes
import ast
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = read_all_routes(ROOT)
tree = ast.parse(source)
wanted = {'money_product', 'money_sum'}
nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in wanted]
if {node.name for node in nodes} != wanted:
    raise SystemExit('ERROR: faltan helpers de cálculo decimal de líneas')
namespace = {
    'Decimal': Decimal,
    'InvalidOperation': InvalidOperation,
    'ROUND_HALF_UP': ROUND_HALF_UP,
}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(ROOT / 'app' / 'routes.py'), 'exec'), namespace)

product = namespace['money_product']
total = namespace['money_sum']

cases = [
    ('0.1', '0.1', 0.01),
    ('0.335', '3', 1.01),
    ('2.675', '1', 2.68),
    ('19.99', '3', 59.97),
]
for left, right, expected in cases:
    actual = product(left, right)
    if actual != expected:
        raise SystemExit(f'ERROR: {left} x {right}: esperado {expected}, obtenido {actual}')

if total([0.1, 0.2, 0.3]) != 0.60:
    raise SystemExit('ERROR: suma de líneas no conserva los centavos')
if total([1.01, 2.02, 3.03]) != 6.06:
    raise SystemExit('ERROR: total de líneas incorrecto')
for invalid in ('NaN', 'Infinity'):
    try:
        product(invalid, 2)
    except ValueError:
        pass
    else:
        raise SystemExit(f'ERROR: se aceptó un importe no finito: {invalid}')

# Confirma que ventas y compras usen los helpers en lugar de multiplicar floats.
if source.count('line = money_product(') < 2:
    raise SystemExit('ERROR: ventas y compras deben usar money_product')
if source.count('total = money_sum(line_totals)') < 2:
    raise SystemExit('ERROR: ventas y compras deben sumar líneas con money_sum')
print('OK: multiplicación y suma decimal de líneas en ventas y compras; entradas no finitas rechazadas')
