"""Verifica estáticamente el inicio automático como administrador predeterminado."""
from tests.route_source import read_all_routes
from pathlib import Path
import ast

ROOT = Path(__file__).resolve().parents[1]
db_source = (ROOT / "app" / "db.py").read_text(encoding="utf-8")
routes_source = read_all_routes(ROOT)
tree = ast.parse(routes_source)

# La inicialización solo crea/reutiliza el administrador predeterminado, no cajeros de demostración.
assert "SELECT id, username FROM users WHERE role='Administrador' AND is_active=1" in db_source
assert "INSERT INTO users (username, full_name, role, password_hash, is_active, created_at, updated_at)" in db_source
assert "('admin', 'Administrador', 'Administrador', '', stamp, stamp)" in db_source

start_fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "start_default_admin_session")
start_src = ast.get_source_segment(routes_source, start_fn) or ""
assert "passwordless_admin_login" in start_src
assert "'user_role'] = 'Administrador'" in start_src
assert "generate_password_hash" not in start_src

login_fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "login_page")
login_src = ast.get_source_segment(routes_source, login_fn) or ""
assert "start_default_admin_session()" in login_src
assert "password" not in login_src.lower(), "La ruta de inicio no debe validar ni pedir contraseña"

# Los usuarios adicionales solo se crean desde la ruta de administración de usuarios.
create_user_fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "api_create_user")
create_user_src = ast.get_source_segment(routes_source, create_user_fn) or ""
assert "INSERT INTO users" in create_user_src
assert "@login_required" in routes_source[routes_source.rfind("@bp.post('/api/users')", 0, routes_source.find('def api_create_user')):routes_source.find('def api_create_user')]

print("OK: inicio sin contraseña como administrador; no se crean usuarios extra automáticamente")
