"""Importaciones parciales, referencias de stock y operaciones concurrentes."""
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from pathlib import Path
import os
import sqlite3
import sys
import tempfile
import threading
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import xlrd
import xlwt
import app.config as config
import app.db as db_module
import app.route_modules.prices as price_routes
from app import create_app
from app.db import get_db, update_settings

keys = ('BASE_DIR', 'INSTANCE_DIR', 'BACKUP_DIR', 'DATABASE', 'UPLOAD_DIR', 'TICKET_DIR')
saved = {key: getattr(config, key) for key in keys}
try:
    with tempfile.TemporaryDirectory(prefix='pos_excel_v11_') as tmp:
        base = Path(tmp)
        for key, value in dict(BASE_DIR=base, INSTANCE_DIR=base / 'instance', BACKUP_DIR=base / 'backups',
                               DATABASE=base / 'instance' / 'pos.db', UPLOAD_DIR=base / 'uploads', TICKET_DIR=base / 'tickets').items():
            setattr(config, key, value)
        with patch.dict(os.environ, {'POS_SEED_DEMO_PRODUCTS': '0'}):
            app = create_app()
        app.config['TESTING'] = True
        client = app.test_client()

        def query(sql, args=()):
            with app.app_context():
                return [tuple(row) for row in get_db().execute(sql, args)]

        def xls(headers, rows, snapshot=None):
            book = xlwt.Workbook()
            sheet = book.add_sheet('Precios')
            for c, header in enumerate(headers):
                sheet.write(0, c, header)
            for r, row in enumerate(rows, 1):
                for c, value in enumerate(row):
                    if value is not None:
                        sheet.write(r, c, value)
            if snapshot is not None:
                meta = book.add_sheet('_POS_stock')
                meta.visibility = 1
                for r, row in enumerate([['ID', 'Stock original']] + snapshot):
                    for c, value in enumerate(row):
                        meta.write(r, c, value)
            output = BytesIO()
            book.save(output)
            return output.getvalue()

        def upload(raw, cl=None):
            return (cl or client).post('/api/prices/import', data={'file': (BytesIO(raw), 'precios.xls')})

        def edit_export(raw, changes):
            original = xlrd.open_workbook(file_contents=raw)
            book = xlwt.Workbook()
            for source in original.sheets():
                target = book.add_sheet(source.name)
                target.visibility = source.visibility
                headers = {source.cell_value(3, c): c for c in range(source.ncols)} if source.name == 'Lista de precios' else {}
                for r in range(source.nrows):
                    overrides = changes.get(int(source.cell_value(r, 0)), {}) if headers and r >= 4 else {}
                    override_cols = {headers[name]: value for name, value in overrides.items()}
                    for c in range(source.ncols):
                        target.write(r, c, override_cols.get(c, source.cell_value(r, c)))
            output = BytesIO()
            book.save(output)
            return output.getvalue()

        p = client.post('/api/products', json={
            'name': 'Producto A', 'barcode': 'EXCEL-A', 'detail': 'Detalle original',
            'cost_without_tax': 100, 'iva_percent': 21, 'gross_income_percent': 3,
            'margin_percent': 35, 'stock': 10, 'expiry_date': '31/12/2027'
        }).json
        pid = p['id']
        minimal = xls(['ID', 'Nombre', 'Precio venta'], [[pid, 'Producto A', 999]])
        assert upload(minimal).status_code == 200
        after = client.get(f'/api/products/{pid}').json
        for field in ('barcode', 'detail', 'cost_without_tax', 'iva_percent', 'gross_income_percent',
                      'margin_percent', 'total_cost', 'stock', 'expiry_date'):
            assert after[field] == p[field], (field, after[field], p[field])
        assert after['sale_price'] == 999
        for stock in (None, '', 0, 500):
            result = upload(xls(['ID', 'Nombre', 'Precio venta', 'Stock'], [[pid, 'Producto A', 888, stock]]))
            assert result.status_code == 200, result.json
            assert client.get(f'/api/products/{pid}').json['stock'] == 10
        assert result.json['stock_preserved'] == 1
        assert query('SELECT COUNT(*) FROM product_movements') == [(0,)]
        print('OK: archivo parcial/externo conserva código, costos, impuestos, detalle, vencimiento y stock')

        new_file = xls(['Código de barra', 'Nombre', 'Precio sin impuestos', 'Stock'], [['EXCEL-B', 'Producto B', 25, 4]])
        assert upload(new_file).json['created'] == 1
        p2 = next(row for row in client.get('/api/products').json if row['barcode'] == 'EXCEL-B')
        assert p2['stock'] == 4
        assert upload(xls(['ID', 'Nombre', 'Precio venta'], [[p2['id'], 'Producto B', 30]])).status_code == 200
        assert client.get(f"/api/products/{p2['id']}").json['margin_percent'] == 0
        assert upload(xls(['ID', 'Nombre', 'Precio venta'], [[p2['id'], 'Producto B', 25]])).status_code == 200
        exported = client.get('/api/prices/export').data
        reference = xlrd.open_workbook(file_contents=exported).sheet_by_name('_POS_stock')
        assert reference.visibility == 1
        assert reference.cell_value(0, 1) == 'Stock original'
        assert client.post('/api/sales', json={'items': [{'product_id': pid, 'quantity': 2}]}).status_code == 200
        result = upload(edit_export(exported, {pid: {'Precio venta': 777}}))
        assert result.status_code == 200 and result.json['stock_preserved'] == 1, result.json
        assert query('SELECT stock, sale_price FROM products WHERE id=?', (pid,)) == [(8, 777)]
        fresh = client.get('/api/prices/export').data
        result = upload(edit_export(fresh, {pid: {'Stock': 6}}))
        assert result.status_code == 200, result.json
        assert query('SELECT quantity, previous_stock, new_stock, reference FROM product_movements WHERE product_id=? ORDER BY id DESC LIMIT 1',
                     (pid,)) == [(-2, 8, 6, 'Importación Excel')]
        print('OK: exportación mantiene columnas visibles; stock sin editar conserva ventas y ajuste explícito queda registrado')

        assert client.post('/api/sales', json={'items': [{'product_id': pid, 'quantity': 1}]}).status_code == 200
        conflicting = xls(['ID', 'Nombre', 'Precio venta', 'Stock'], [
            [p2['id'], 'Producto B', 42, None], [pid, 'Producto A', 555, 3]
        ], snapshot=[[pid, 6], [p2['id'], 4]])
        result = upload(conflicting)
        assert result.status_code == 409, result.json
        assert query('SELECT stock, sale_price FROM products WHERE id=?', (pid,)) == [(5, 777)]
        assert query('SELECT stock, sale_price FROM products WHERE id=?', (p2['id'],)) == [(4, 25)]
        before = query('SELECT stock, sale_price FROM products WHERE id=?', (pid,))
        valid = xls(['ID', 'Nombre', 'Precio venta', 'Stock'], [[pid, 'Producto A', 500, 4]], snapshot=[[pid, 5]])
        with patch.object(price_routes, 'stock_movement', side_effect=sqlite3.OperationalError('fallo simulado')), \
             patch.object(app.logger, 'exception'):
            assert upload(valid).status_code == 500
        assert query('SELECT stock, sale_price FROM products WHERE id=?', (pid,)) == before
        for bad_id in (1.5, -1, 'NaN'):
            assert upload(xls(['ID', 'Nombre', 'Precio venta'], [[bad_id, 'Inválido', 1]])).status_code == 400
        assert upload(xls(['ID', 'Nombre', 'Precio venta'], [[pid, 'Producto A', 1]], snapshot=[[pid, 5], [pid, 5]])).status_code == 400
        with app.app_context():
            update_settings({'stock_control_enabled': '0'})
        assert upload(valid).status_code == 200
        assert query('SELECT stock FROM products WHERE id=?', (pid,)) == [(5,)]
        assert upload(xls(['Nombre', 'Precio venta', 'Stock'], [['Nuevo sin control', 1, 50]])).status_code == 200
        assert query("SELECT stock FROM products WHERE name='Nuevo sin control'") == [(0,)]
        with app.app_context():
            update_settings({'stock_control_enabled': '1'})
        print('OK: conflicto revierte archivo completo; fallas, referencias inválidas y control desactivado')

        # Pausar después del ajuste de importación y comprobar que la venta espera.
        entered, resume, attempted, finished = [threading.Event() for _ in range(4)]
        local = threading.local()
        original_connect = db_module.connect_database
        original_movement = price_routes.stock_movement
        def paused_movement(*args, **kwargs):
            result = original_movement(*args, **kwargs)
            entered.set()
            assert resume.wait(10)
            return result
        def connect(*args, **kwargs):
            connection = original_connect(*args, **kwargs)
            def trace(sql):
                if getattr(local, 'role', '') == 'sale' and sql == 'BEGIN IMMEDIATE':
                    attempted.set()
            connection.set_trace_callback(trace)
            return connection
        def importing():
            return upload(valid, app.test_client())
        def selling():
            local.role = 'sale'
            try:
                return app.test_client().post('/api/sales', json={'items': [{'product_id': pid, 'quantity': 2}]},
                                              headers={'Idempotency-Key': 'excel-concurrent-sale-001'})
            finally:
                finished.set()
        with patch.object(price_routes, 'stock_movement', side_effect=paused_movement), \
             patch.object(db_module, 'connect_database', side_effect=connect):
            with ThreadPoolExecutor(2) as pool:
                importing_job = pool.submit(importing)
                try:
                    assert entered.wait(10)
                    sale_job = pool.submit(selling)
                    assert attempted.wait(10)
                    assert not finished.wait(0.2)
                finally:
                    resume.set()
                assert importing_job.result(timeout=10).status_code == 200
                assert sale_job.result(timeout=10).status_code == 200
        assert query('SELECT stock FROM products WHERE id=?', (pid,)) == [(2,)]
        assert query('SELECT previous_stock, new_stock FROM product_movements WHERE product_id=? ORDER BY id DESC LIMIT 2',
                     (pid,)) == [(4, 2), (5, 4)]
        assert query('PRAGMA quick_check') == [('ok',)]
        assert query('PRAGMA foreign_key_check') == []
        print('OK: importación y venta simultáneas conservan existencias e historial continuo')
finally:
    for key, value in saved.items():
        setattr(config, key, value)
