"""Fotos nuevas: conservar confirmadas y retirar solo cargas fallidas propias."""
from pathlib import Path
from io import BytesIO
from unittest.mock import patch
import tempfile,sys,sqlite3
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from PIL import Image
import app.config as config
from app import create_app
from app.db import get_db
keys=('BASE_DIR','INSTANCE_DIR','BACKUP_DIR','DATABASE','UPLOAD_DIR','TICKET_DIR');saved={k:getattr(config,k) for k in keys}
try:
 with tempfile.TemporaryDirectory() as tmp:
  b=Path(tmp)
  for k,v in dict(BASE_DIR=b,INSTANCE_DIR=b/'instance',BACKUP_DIR=b/'backups',DATABASE=b/'instance'/'pos.db',UPLOAD_DIR=b/'uploads',TICKET_DIR=b/'tickets').items():setattr(config,k,v)
  app=create_app();app.config['TESTING']=True;c=app.test_client()
  out=BytesIO()
  with Image.new('RGB',(2,2),'red') as im:im.save(out,format='PNG')
  raw=out.getvalue()
  def send(name,key,barcode=None):
   data={'name':name,'cost_without_tax':'1','photo':(BytesIO(raw),'foto.png')}
   if barcode:data['barcode']=barcode
   return c.post('/api/products',data=data,headers={'Idempotency-Key':key})
  good=send('Confirmado','upload-clean-good-001','CODE')
  assert good.status_code==201,good.json
  confirmed=config.UPLOAD_DIR/Path(good.json['photo_path']).name
  unrelated=config.UPLOAD_DIR/'archivo_anterior.jpg';unrelated.write_bytes(b'datos anteriores')
  assert send('Duplicado','upload-clean-duplicate-001','CODE').status_code==400
  assert set(config.UPLOAD_DIR.iterdir())=={confirmed,unrelated}
  with app.app_context():
   db=get_db();db.execute("CREATE TRIGGER fail_receipt BEFORE INSERT ON operation_receipts BEGIN SELECT RAISE(ABORT,'fallo simulado'); END");db.commit()
  with patch.object(app.logger,'exception'):
   assert send('Rollback','upload-clean-failed-001').status_code==500
  assert set(config.UPLOAD_DIR.iterdir())=={confirmed,unrelated}
  assert confirmed.exists() and unrelated.read_bytes()==b'datos anteriores'
  with app.app_context():
   db=get_db();db.execute('DROP TRIGGER fail_receipt');db.commit()
  # Error después de una escritura parcial de imagen, antes de guardar en la BD.
  def fail_save(image,path,*args,**kwargs):
   Path(path).write_bytes(b'parcial');raise OSError('fallo simulado de disco')
  with patch.object(Image.Image,'save',new=fail_save):
   assert send('Disco','upload-clean-disk-001').status_code==400
  assert set(config.UPLOAD_DIR.iterdir())=={confirmed,unrelated}
  # Un fallo al armar la respuesta después de confirmar no borra el archivo vigente.
  import app.route_modules.products as routes
  with patch.object(routes,'product_to_dict',side_effect=RuntimeError('respuesta fallida')):
   try:c.post('/api/products',data={'name':'Confirmado antes del error','photo':(BytesIO(raw),'foto.png')})
   except RuntimeError:pass
  with app.app_context():
   path=get_db().execute("SELECT photo_path FROM products WHERE name='Confirmado antes del error'").fetchone()[0]
  assert (config.UPLOAD_DIR/Path(path).name).exists()
  print('OK: fotos de restricción, rollback y escritura parcial retiradas; archivos confirmados/anteriores conservados')
finally:
 for k,v in saved.items():setattr(config,k,v)
