"""Verifica que las conexiones de producción activen las FK de SQLite."""
from __future__ import annotations
from tests.route_source import read_all_routes
import importlib.util
import sqlite3
import sys
import tempfile
import types
from contextlib import closing
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class FakeG(dict):
    def __getattr__(self, name):
        try:
            return self[name]
        except KeyError as exc:
            raise AttributeError(name) from exc
    def __setattr__(self, name, value):
        self[name] = value

class FakeCurrentApp:
    config = {}

fake_flask = types.ModuleType('flask')
fake_flask.current_app = FakeCurrentApp()
fake_flask.g = FakeG()
old_flask = sys.modules.get('flask')
sys.modules['flask'] = fake_flask
try:
    spec = importlib.util.spec_from_file_location('_pos_db_fk_test', ROOT / 'app' / 'db.py')
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
finally:
    if old_flask is None:
        sys.modules.pop('flask', None)
    else:
        sys.modules['flask'] = old_flask

with tempfile.TemporaryDirectory(prefix='pos_fk_test_') as temp:
    db_path = Path(temp) / 'fk.db'
    fake_flask.current_app.config = {'DATABASE': db_path}
    fake_flask.g = FakeG()
    module.init_db()
    conn = module.get_db()
    assert conn.execute('PRAGMA foreign_keys').fetchone()[0] == 1
    stamp = '2026-01-01T10:00:00'
    product_id = conn.execute(
        "INSERT INTO products(name, created_at, updated_at) VALUES(?,?,?)",
        ('Producto FK', stamp, stamp)
    ).lastrowid
    sale_id = conn.execute(
        "INSERT INTO sales(total, created_at) VALUES(?,?)", (100, stamp)
    ).lastrowid
    conn.execute(
        "INSERT INTO sale_items(sale_id, product_id, product_name, unit_price, quantity, line_total, created_at) VALUES(?,?,?,?,?,?,?)",
        (sale_id, product_id, 'Producto FK', 100, 1, 100, stamp)
    )
    try:
        conn.execute(
            "INSERT INTO sale_items(sale_id, product_id, product_name, unit_price, quantity, line_total, created_at) VALUES(?,?,?,?,?,?,?)",
            (999999, product_id, 'Huérfano', 100, 1, 100, stamp)
        )
        conn.commit()
        raise AssertionError('La FK de sale_items.sale_id no rechazó una venta inexistente')
    except sqlite3.IntegrityError:
        conn.rollback()
    assert conn.execute('PRAGMA foreign_key_check').fetchall() == []
    module.close_db()

# Las rutas de borrado deben responder con conflicto legible en vez de 500.
routes = read_all_routes(ROOT)
assert "No se puede eliminar este producto porque tiene ventas, compras o movimientos históricos asociados." in routes
assert "No se puede eliminar este proveedor porque tiene compras históricas asociadas." in routes
print('OK: conexiones de producción activan FK; se rechazan referencias huérfanas y los borrados históricos se manejan con 409')
