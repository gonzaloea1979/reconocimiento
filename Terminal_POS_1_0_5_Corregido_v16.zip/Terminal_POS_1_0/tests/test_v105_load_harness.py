from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
s=(root/'prueba_carga_v105.py').read_text(encoding='utf-8')
assert 'evaluate_variants(db_path)' in s
assert 'prueba_carga_v105.txt' in s
assert 'for workers in (1, 2):' in s
assert 'for workers in (1, 2, 4, 8):' not in s
assert 'TemporaryDirectory(prefix="terminal_pos_v105_")' in s
assert re.fullmatch(r'(?:V[0-9]+(?:\.[0-9]+)*(?:[- ].*)?|Terminal POS [0-9]+\.[0-9]+(?:\.[0-9]+)*(?: .*)?)', (root/'VERSION.txt').read_text().strip())
print('OK: V105 ejecuta A/B con 1-2 usuarios y base temporal aislada.')
