"""Revisión de distribución: sin datos privados ni bases comerciales."""
from pathlib import Path
from zipfile import ZipFile
import ast
ROOT=Path(__file__).resolve().parents[1]
required=['run.py','ejecutar.bat','app/__init__.py','app/db.py','app/route_modules/sales.py','app/route_modules/cash.py','requirements.txt','compilar_exe.bat','INSTALAR_Y_ACTUALIZAR_SEGURO.txt','MANUAL_VALIDACION_FINAL_V110.txt']
for name in required:
    p=ROOT/name
    assert p.is_file(), 'Falta archivo indispensable: '+name
for file in ROOT.rglob('*.py'):
    if '.venv' not in file.parts:
        ast.parse(file.read_text(encoding='utf-8-sig'),str(file))
for folder in ['instance','backups','logs','TICKET','app/static/uploads']:
    p=ROOT/folder
    if p.exists():
        assert not any(p.rglob('*')), 'Distribución incluye datos en '+folder
assert not list(ROOT.rglob('*.db')),'Distribución incluye una base de datos'
print('OK: archivos esenciales presentes, sintaxis Python válida, distribución sin bases comerciales')
