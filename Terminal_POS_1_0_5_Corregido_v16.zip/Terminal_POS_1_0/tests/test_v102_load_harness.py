"""El diagnóstico V102 interpreta correctamente PRAGMA cache_size."""
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "prueba_carga_v102.py"
spec = importlib.util.spec_from_file_location("pos_load_v102", SCRIPT)
module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(module)

assert module.format_cache_size(-8192, 4096) == "-8192 KiB (8.0 MiB)"
assert module.format_cache_size(-16384, 4096) == "-16384 KiB (16.0 MiB)"
assert module.format_cache_size(8192, 4096) == "8192 páginas (32.0 MiB)"
assert 'prueba_carga_v102.txt' in (SCRIPT).read_text(encoding="utf-8")
assert 'TemporaryDirectory(prefix="terminal_pos_v102_")' in SCRIPT.read_text(encoding="utf-8")
assert 'for workers in (1, 2):' in SCRIPT.read_text(encoding="utf-8")
assert 'for workers in (1, 2, 4, 8):' not in SCRIPT.read_text(encoding="utf-8")
assert 'Dashboard rankings compartidos' in SCRIPT.read_text(encoding="utf-8")

print("OK: cache_size negativo en KiB, positivo en páginas; banco V102 limitado a 1-2 usuarios.")
