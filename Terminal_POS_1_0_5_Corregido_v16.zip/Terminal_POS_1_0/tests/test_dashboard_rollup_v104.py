"""V104 mide por separado ambos rankings y comprueba el resultado del CTE compartido."""
from __future__ import annotations
import ast
import sqlite3
import tempfile
import time
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "app" / "route_modules" / "dashboard.py").read_text(encoding="utf-8")
tree = ast.parse(source)
route = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "api_dashboard")
assignment = next(
    n for n in ast.walk(route)
    if isinstance(n, ast.Assign)
    and any(isinstance(t, ast.Name) and t.id == "rankings" for t in n.targets)
)
call = assignment.value
if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "fetchall":
    call = call.func.value
assert isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute) and call.func.attr == "execute"
OPTIMIZED_SQL = call.args[0].value
assert "WITH item_rollup AS MATERIALIZED" in OPTIMIZED_SQL
assert "product_rollup AS MATERIALIZED" in OPTIMIZED_SQL
assert "GROUP BY product_id, product_name" in OPTIMIZED_SQL
assert "LEFT JOIN product_rollup" in OPTIMIZED_SQL
assert "ORDER BY section," in OPTIMIZED_SQL

OLD_TOP = """SELECT product_name AS name, SUM(quantity) AS qty, SUM(line_total) AS amount
FROM sale_items GROUP BY product_id, product_name
ORDER BY qty DESC, amount DESC LIMIT 10"""
OLD_LEAST = """SELECT p.name, COALESCE(SUM(si.quantity), 0) AS qty, COALESCE(SUM(si.line_total), 0) AS amount
FROM products p LEFT JOIN sale_items si ON si.product_id = p.id
GROUP BY p.id, p.name ORDER BY qty ASC, amount ASC, p.name ASC LIMIT 10"""

with tempfile.TemporaryDirectory(prefix="pos_dashboard_v104_") as tmp:
    db = sqlite3.connect(Path(tmp) / "dashboard.db")
    db.row_factory = sqlite3.Row
    db.executescript("""
        CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT NOT NULL);
        CREATE TABLE sale_items(
            id INTEGER PRIMARY KEY, product_id INTEGER NOT NULL,
            product_name TEXT NOT NULL, quantity REAL NOT NULL, line_total REAL NOT NULL
        );
        CREATE INDEX idx_products_name ON products(name);
        CREATE INDEX idx_sale_items_product_rollup
            ON sale_items(product_id, product_name, quantity, line_total);
    """)
    products = [(i, f"Producto {i:02d}") for i in range(1, 31)]
    db.executemany("INSERT INTO products(id,name) VALUES(?,?)", products)
    items = []
    row_id = 1
    for product_id in range(1, 24):
        for sale_no in range(1, (product_id % 5) + 2):
            # Algunos artículos conservan un nombre anterior, como en ventas reales.
            snapshot = f"Nombre anterior {product_id:02d}" if product_id in (2, 5, 9) and sale_no == 1 else f"Producto {product_id:02d}"
            qty = float((product_id * sale_no) % 7 + 1)
            items.append((row_id, product_id, snapshot, qty, qty * (100 + product_id)))
            row_id += 1
    db.executemany(
        "INSERT INTO sale_items(id,product_id,product_name,quantity,line_total) VALUES(?,?,?,?,?)",
        items,
    )
    db.execute("ANALYZE")

    old_top = [tuple(r) for r in db.execute(OLD_TOP).fetchall()]
    old_least = [tuple(r) for r in db.execute(OLD_LEAST).fetchall()]
    rows = db.execute(OPTIMIZED_SQL).fetchall()
    new_top = [(r["name"], r["qty"], r["amount"]) for r in rows if r["kind"] == "top"]
    new_least = [(r["name"], r["qty"], r["amount"]) for r in rows if r["kind"] == "least"]
    assert new_top == old_top, "El ranking superior o sus nombres históricos cambiaron."
    assert new_least == old_least, "El ranking inferior o sus nombres actuales cambiaron."
    assert len(new_top) == 10 and len(new_least) == 10

    plan = " | ".join(r[3] for r in db.execute("EXPLAIN QUERY PLAN " + OPTIMIZED_SQL))
    assert "idx_sale_items_product_rollup" in plan, plan

    # Benchmark A/B con la misma conexión y los mismos datos.
    def median_ms(sql, count=50):
        for _ in range(5):
            db.execute(sql).fetchall()
        samples = []
        for _ in range(count):
            start = time.perf_counter_ns()
            db.execute(sql).fetchall()
            samples.append((time.perf_counter_ns() - start) / 1_000_000)
        return statistics.median(samples)

    top_ms = median_ms(OLD_TOP)
    least_ms = median_ms(OLD_LEAST)
    shared_ms = median_ms(OPTIMIZED_SQL)
    print(f"Dashboard rankings: compartido {shared_ms:.3f} ms; top individual {top_ms:.3f} ms; menos vendidos individual {least_ms:.3f} ms; suma individual {(top_ms + least_ms):.3f} ms")

    # Sin ventas, top queda vacío y el ranking inferior conserva productos con cero.
    db.execute("DELETE FROM sale_items")
    empty = db.execute(OPTIMIZED_SQL).fetchall()
    assert not [r for r in empty if r["kind"] == "top"]
    empty_least = [r for r in empty if r["kind"] == "least"]
    assert len(empty_least) == 10
    assert all(r["qty"] == 0 and r["amount"] == 0 for r in empty_least)
    db.close()

print("OK: V104 conserva rankings, nombres históricos, productos sin ventas e índice de cobertura; mide cada ranking por separado.")
