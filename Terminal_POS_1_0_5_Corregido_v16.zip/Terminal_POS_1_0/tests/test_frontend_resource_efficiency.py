"""Evita fugas de recursos y ráfagas de consultas en la interfaz."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
common = (ROOT / 'app' / 'static' / 'js' / 'common.js').read_text(encoding='utf-8')
scanner = (ROOT / 'app' / 'static' / 'js' / 'barcode_scanner.js').read_text(encoding='utf-8')
clients = (ROOT / 'app' / 'static' / 'js' / 'clients.js').read_text(encoding='utf-8')
suppliers = (ROOT / 'app' / 'static' / 'js' / 'suppliers.js').read_text(encoding='utf-8')

assert 'oscillator.onended' in common and 'ctx.close()' in common
assert 'this.stop(false);' in scanner[scanner.index('} catch (err) {', scanner.index('async start()')):]
assert 'setTimeout(loadClients,180)' in clients.replace(' ', '')
assert 'setTimeout(loadSuppliers,180)' in suppliers.replace(' ', '')
print('OK: audio liberado, cámara detenida ante errores y búsquedas con debounce')
