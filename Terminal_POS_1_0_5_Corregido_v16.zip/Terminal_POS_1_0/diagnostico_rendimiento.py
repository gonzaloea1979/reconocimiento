#!/usr/bin/env python3
"""Diagnóstico de rendimiento de Terminal POS. Solo lectura sobre la base de datos."""
from __future__ import annotations

import argparse
import os
import platform
import shutil
import sqlite3
import statistics
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import http.cookiejar
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_DB = BASE_DIR / "instance" / "pos.db"
DEFAULT_REPORT = BASE_DIR / "logs" / "diagnostico_rendimiento.txt"

# Solo endpoints GET: el diagnóstico no crea, modifica ni elimina operaciones del negocio.
READ_ONLY_ENDPOINTS = (
    "/api/dashboard",
    "/api/products",
    "/api/suppliers",
    "/api/stock/alerts",
    "/api/stock/movements",
    "/api/purchases",
    "/api/cash/status",
    "/api/clients",
    "/api/reports",
    "/api/audit",
)


def _fmt_bytes(value: int | float | None) -> str:
    if value is None:
        return "No disponible"
    size = float(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


def _system_memory() -> tuple[int | None, int | None]:
    """Devuelve memoria total y disponible sin instalar dependencias externas."""
    if os.name == "nt":
        try:
            import ctypes

            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]

            status = MEMORYSTATUSEX()
            status.dwLength = ctypes.sizeof(status)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
                return int(status.ullTotalPhys), int(status.ullAvailPhys)
        except Exception:
            pass

    meminfo = Path("/proc/meminfo")
    if meminfo.exists():
        try:
            values = {}
            for line in meminfo.read_text(encoding="ascii").splitlines():
                key, raw = line.split(":", 1)
                values[key] = int(raw.strip().split()[0]) * 1024
            return values.get("MemTotal"), values.get("MemAvailable")
        except Exception:
            pass

    try:
        page_size = os.sysconf("SC_PAGE_SIZE")
        total = os.sysconf("SC_PHYS_PAGES") * page_size
        available = os.sysconf("SC_AVPHYS_PAGES") * page_size
        return int(total), int(available)
    except (AttributeError, OSError, ValueError):
        return None, None


def _cpu_usage_sample() -> float | None:
    """Muestra breve del uso global de CPU; no representa solo al POS."""
    if os.name == "nt":
        try:
            import ctypes

            class FILETIME(ctypes.Structure):
                _fields_ = [("dwLowDateTime", ctypes.c_ulong), ("dwHighDateTime", ctypes.c_ulong)]

            def value(ft):
                return (ft.dwHighDateTime << 32) | ft.dwLowDateTime

            def sample():
                idle, kernel, user = FILETIME(), FILETIME(), FILETIME()
                ok = ctypes.windll.kernel32.GetSystemTimes(
                    ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)
                )
                if not ok:
                    return None
                return value(idle), value(kernel) + value(user)

            first = sample()
            time.sleep(0.35)
            second = sample()
            if not first or not second:
                return None
            idle_delta = second[0] - first[0]
            total_delta = second[1] - first[1]
            return max(0.0, min(100.0, (1 - idle_delta / total_delta) * 100)) if total_delta else None
        except Exception:
            return None

    stat = Path("/proc/stat")
    if stat.exists():
        try:
            def sample():
                fields = [int(x) for x in stat.read_text().splitlines()[0].split()[1:]]
                idle = fields[3] + (fields[4] if len(fields) > 4 else 0)
                return idle, sum(fields)

            first = sample()
            time.sleep(0.35)
            second = sample()
            total_delta = second[1] - first[1]
            idle_delta = second[0] - first[0]
            return max(0.0, min(100.0, (1 - idle_delta / total_delta) * 100)) if total_delta else None
        except Exception:
            return None
    return None


def _readonly_connection(db_path: Path) -> sqlite3.Connection:
    # URI mode=ro + query_only: impide escrituras desde este diagnóstico.
    normalized = db_path.resolve().as_posix()
    uri = "file:" + urllib.parse.quote(normalized, safe="/:") + "?mode=ro"
    connection = sqlite3.connect(uri, uri=True, timeout=3)
    connection.execute("PRAGMA query_only=ON")
    return connection


def _database_report(db_path: Path, lines: list[str]) -> None:
    lines.append("")
    lines.append("BASE DE DATOS SQLITE (LECTURA SOLAMENTE)")
    lines.append("-" * 58)
    if not db_path.is_file():
        lines.append(f"[AVISO] No se encontró la base: {db_path}")
        return

    lines.append(f"Archivo: {db_path.name}")
    lines.append(f"Tamaño: {_fmt_bytes(db_path.stat().st_size)}")
    for suffix in ("-wal", "-shm"):
        sidecar = Path(str(db_path) + suffix)
        if sidecar.exists():
            lines.append(f"{suffix}: {_fmt_bytes(sidecar.stat().st_size)}")

    try:
        con = _readonly_connection(db_path)
    except Exception as exc:
        lines.append(f"[ERROR] No se pudo abrir en modo de solo lectura: {type(exc).__name__}: {exc}")
        lines.append("Si el POS está abierto, volvé a intentar. No se intentó reparar ni modificar la base.")
        return

    try:
        lines.append(f"SQLite: {sqlite3.sqlite_version}")
        for pragma, label in (
            ("page_size", "Tamaño de página"),
            ("page_count", "Páginas usadas"),
            ("freelist_count", "Páginas libres"),
            ("cache_size", "Cache SQLite (páginas)"),
        ):
            try:
                value = con.execute(f"PRAGMA {pragma}").fetchone()[0]
                lines.append(f"{label}: {value}")
            except sqlite3.Error:
                pass

        try:
            quick = con.execute("PRAGMA quick_check").fetchone()[0]
            lines.append(f"quick_check: {quick}")
        except sqlite3.Error as exc:
            lines.append(f"[AVISO] quick_check: {exc}")

        tables = {
            row[0] for row in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            )
        }
        priority = (
            "products", "sales", "sale_items", "purchases", "purchase_items",
            "suppliers", "clients", "client_movements", "product_movements",
            "cash_sessions", "cash_movements", "users", "audit_logs",
        )
        lines.append("")
        lines.append("Registros por tabla (solo cantidades):")
        for table in priority:
            if table not in tables:
                continue
            count = con.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
            lines.append(f"  {table}: {count:,}")

        try:
            sizes = con.execute(
                "SELECT name, SUM(pgsize) FROM dbstat "
                "GROUP BY name ORDER BY SUM(pgsize) DESC LIMIT 8"
            ).fetchall()
            if sizes:
                lines.append("")
                lines.append("Objetos que más espacio ocupan:")
                for name, size in sizes:
                    lines.append(f"  {name}: {_fmt_bytes(size)}")
        except sqlite3.Error:
            lines.append("[INFO] SQLite no ofrece dbstat en esta instalación; se omite el desglose por tabla.")

        columns = {}
        for table in tables:
            try:
                columns[table] = {row[1] for row in con.execute(f'PRAGMA table_info("{table}")')}
            except sqlite3.Error:
                columns[table] = set()

        checks = [
            ("Productos ordenados", "products",
             "SELECT id FROM products ORDER BY name ASC LIMIT 200", ()),
            ("Ventas recientes", "sales",
             "SELECT id, total FROM sales ORDER BY id DESC LIMIT 100", ()),
            ("Ventas últimos 30 días", "sales",
             "SELECT COUNT(*), COALESCE(SUM(total),0) FROM sales "
             "WHERE created_at >= date('now','-30 day')", ()),
            ("Alertas de stock", "products",
             "SELECT id FROM products WHERE min_stock > 0 AND stock <= min_stock "
             "ORDER BY (stock - min_stock) ASC, name ASC LIMIT 30", ()),
            ("Clientes con saldo", "clients",
             "SELECT id FROM clients WHERE balance > 0 ORDER BY balance DESC LIMIT 20", ()),
            ("Proveedores ordenados", "suppliers",
             "SELECT id FROM suppliers ORDER BY name ASC LIMIT 100", ()),
            ("Movimientos recientes", "product_movements",
             "SELECT id FROM product_movements ORDER BY id DESC LIMIT 100", ()),
            ("Auditoría reciente", "audit_logs",
             "SELECT id FROM audit_logs ORDER BY id DESC LIMIT 100", ()),
            ("Compras recientes", "purchases",
             "SELECT id FROM purchases ORDER BY id DESC LIMIT 100", ()),
        ]

        lines.append("")
        lines.append("Consultas de referencia (tiempo mediano de 3 lecturas):")
        for label, table, sql, params in checks:
            if table not in tables:
                continue
            # Evita reportar errores por columnas que una instalación antigua aún no tenga.
            referenced = {
                "products": {"id", "name", "min_stock", "stock"},
                "sales": {"id", "total", "created_at"},
                "clients": {"id", "balance"},
                "suppliers": {"id", "name"},
                "product_movements": {"id"},
                "audit_logs": {"id"},
                "purchases": {"id"},
            }.get(table, set())
            if not referenced.issubset(columns.get(table, set())):
                lines.append(f"  {label}: omitida (esquema anterior/incompleto)")
                continue
            try:
                durations = []
                for _ in range(3):
                    started = time.perf_counter()
                    con.execute(sql, params).fetchall()
                    durations.append((time.perf_counter() - started) * 1000)
                median = statistics.median(durations)
                try:
                    plan_rows = con.execute("EXPLAIN QUERY PLAN " + sql, params).fetchall()
                    plan = " | ".join(str(row[3]) for row in plan_rows)
                except sqlite3.Error:
                    plan = "plan no disponible"
                lines.append(f"  {label}: {median:.2f} ms")
                lines.append(f"    Plan: {plan[:240]}")
            except sqlite3.Error as exc:
                lines.append(f"  {label}: no se pudo medir ({exc})")
    finally:
        con.close()


def _http_report(base_dir: Path, lines: list[str], disabled: bool) -> None:
    lines.append("")
    lines.append("RESPUESTA DEL POS EN EJECUCIÓN (SOLO GET)")
    lines.append("-" * 58)
    if disabled:
        lines.append("[INFO] Medición HTTP omitida por opción --no-http.")
        return

    url_file = base_dir / "logs" / "pos_url.txt"
    if not url_file.is_file():
        lines.append("[INFO] No existe logs/pos_url.txt. Abrí el POS y volvé a ejecutar el diagnóstico.")
        return

    try:
        base_url = url_file.read_text(encoding="utf-8").strip().rstrip("/")
        parsed = urllib.parse.urlsplit(base_url)
        if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
            lines.append("[AVISO] URL local inválida; por seguridad no se realizaron solicitudes.")
            return
    except Exception as exc:
        lines.append(f"[AVISO] No se pudo leer la URL local: {exc}")
        return

    cookie_jar = http.cookiejar.CookieJar()
    opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))
    try:
        # La portada establece la sesión local; todas las siguientes peticiones son GET.
        opener.open(base_url + "/", timeout=3).read(1024)
    except Exception as exc:
        lines.append(f"[AVISO] El POS no respondió en {base_url}: {type(exc).__name__}: {exc}")
        return

    lines.append(f"Servidor local: {base_url}")
    lines.append("Cada endpoint: 1 calentamiento + 2 mediciones GET. No se guardan respuestas.")
    for endpoint in READ_ONLY_ENDPOINTS:
        times = []
        statuses = []
        errors = []
        for attempt in range(3):
            request = urllib.request.Request(
                base_url + endpoint,
                headers={"Accept": "application/json", "Cache-Control": "no-cache"},
                method="GET",
            )
            started = time.perf_counter()
            try:
                with opener.open(request, timeout=8) as response:
                    response.read(256 * 1024)
                    status = response.status
            except urllib.error.HTTPError as exc:
                status = exc.code
                try:
                    exc.read(4096)
                except Exception:
                    pass
            except Exception as exc:
                errors.append(type(exc).__name__)
                continue
            elapsed = (time.perf_counter() - started) * 1000
            statuses.append(status)
            if attempt > 0:
                times.append(elapsed)
        if times:
            median = statistics.median(times)
            status_text = "/".join(str(x) for x in statuses[-2:])
            lines.append(f"  {endpoint}: {median:.1f} ms mediana | HTTP {status_text}")
            if median >= 1000:
                lines.append("    [REVISAR] Respuesta superior a 1 segundo.")
            elif median >= 300:
                lines.append("    [OBSERVAR] Respuesta superior a 300 ms.")
        else:
            lines.append(f"  {endpoint}: sin medición válida ({', '.join(errors) or 'sin respuesta'})")


def main() -> int:
    parser = argparse.ArgumentParser(description="Diagnóstico de rendimiento seguro y de solo lectura.")
    parser.add_argument("--db", type=Path, default=DEFAULT_DB, help="Ruta alternativa a pos.db (solo lectura).")
    parser.add_argument("--report", type=Path, default=DEFAULT_REPORT, help="Ruta del informe de texto.")
    parser.add_argument("--no-http", action="store_true", help="No medir endpoints del POS.")
    args = parser.parse_args()

    lines = [
        "TERMINAL POS - DIAGNÓSTICO DE RENDIMIENTO",
        f"Fecha: {datetime.now().astimezone().isoformat(timespec='seconds')}",
        f"Versión: {(BASE_DIR / 'VERSION.txt').read_text(encoding='utf-8').strip() if (BASE_DIR / 'VERSION.txt').exists() else 'No identificada'}",
        "",
        "EQUIPO Y ENTORNO",
        "-" * 58,
        f"Sistema: {platform.platform()}",
        f"Python: {sys.version.split()[0]}",
        f"Procesadores lógicos: {os.cpu_count() or 'No disponible'}",
    ]

    total, available = _system_memory()
    lines.append(f"RAM total: {_fmt_bytes(total)}")
    lines.append(f"RAM disponible: {_fmt_bytes(available)}")
    if total and available is not None:
        lines.append(f"RAM ocupada aproximada: {(total - available) / total * 100:.1f}%")

    cpu = _cpu_usage_sample()
    lines.append(f"CPU global (muestra breve): {cpu:.1f}%" if cpu is not None else "CPU global: No disponible")

    try:
        usage = shutil.disk_usage(BASE_DIR)
        lines.append(f"Disco libre en la unidad del POS: {_fmt_bytes(usage.free)}")
    except OSError as exc:
        lines.append(f"Disco: No disponible ({exc})")

    _database_report(args.db, lines)
    _http_report(BASE_DIR, lines, args.no_http)

    lines.extend([
        "",
        "PRIVACIDAD Y ALCANCE",
        "-" * 58,
        "- La base se abrió en modo de solo lectura y con PRAGMA query_only=ON.",
        "- No se ejecutaron INSERT, UPDATE, DELETE, migraciones ni reparaciones.",
        "- Las mediciones HTTP usan exclusivamente GET contra la dirección loopback del POS.",
        "- El informe contiene métricas, cantidades y planes SQL; no incluye nombres, teléfonos, ventas ni datos de clientes.",
        "- La muestra de CPU es global del equipo, no exclusiva del proceso POS.",
        "",
        "Interpretación: los tiempos dependen del tamaño de la base, el equipo y la carga del momento.",
        "Usá este informe para decidir qué optimizar; no representa por sí solo una garantía de rendimiento.",
    ])

    report = "\n".join(lines) + "\n"
    print(report)
    try:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(report, encoding="utf-8")
        print(f"Informe guardado en: {args.report}")
    except OSError as exc:
        print(f"No se pudo guardar el informe: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
