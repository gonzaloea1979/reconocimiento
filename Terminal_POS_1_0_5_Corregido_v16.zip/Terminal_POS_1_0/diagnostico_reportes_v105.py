"""Diagnóstico A/B SQL. Jamás abre instance/pos.db: recibe solo ruta temporal del banco."""
import ast
from datetime import date, timedelta
from pathlib import Path
import sqlite3
import statistics
import time

ROOT = Path(__file__).resolve().parent


def current_sql():
    # Referencia congelada anterior a V106 para comparar sin cambiar los criterios A/B.
    return (ROOT / 'reportes_sql_v105_referencia.sql').read_text(encoding='utf-8')


def variants(sql):
    return {
        'original_V104': sql,
        'periodo_sin_materializar': sql.replace('period_sales AS MATERIALIZED', 'period_sales AS NOT MATERIALIZED'),
        'items_sin_materializar': sql.replace('item_agg AS MATERIALIZED', 'item_agg AS NOT MATERIALIZED'),
        'ambas_sin_materializar': sql.replace('period_sales AS MATERIALIZED', 'period_sales AS NOT MATERIALIZED').replace('item_agg AS MATERIALIZED', 'item_agg AS NOT MATERIALIZED'),
        'producto_sin_materializar': sql.replace('product_rollup AS MATERIALIZED', 'product_rollup AS NOT MATERIALIZED'),
    }


def evaluate_variants(db_path, rounds=35):
    """Retorna renglones de informe. Verifica equivalencia antes de medir."""
    result = ['DIAGNÓSTICO A/B REPORTES V105 (SOLO BASE TEMPORAL):']
    con = sqlite3.connect(db_path)
    try:
        sqls = variants(current_sql())
        assert len(set(sqls.values())) == len(sqls), 'Una variante no cambió el SQL'
        con.execute('PRAGMA foreign_keys=ON')
        today = date.today()
        ranges = [((today-timedelta(days=30)).isoformat(),today.isoformat()),
                  ((today-timedelta(days=7)).isoformat(),today.isoformat()),
                  ('2035-01-01','2035-01-31')]
        for args in ranges:
            original = con.execute(sqls['original_V104'],args).fetchall()
            for label, sql in sqls.items():
                if con.execute(sql,args).fetchall() != original:
                    raise AssertionError(f'La variante {label} cambia resultados para {args}')
        # Los cambios de snapshot históricos se realizan exclusivamente en la base sintética.
        con.execute('SAVEPOINT v105_snapshot')
        try:
            con.execute('UPDATE sale_items SET unit_cost_at_sale=NULL WHERE id IN (SELECT id FROM sale_items LIMIT 101)')
            for args in ranges:
                original=con.execute(sqls['original_V104'],args).fetchall()
                for label,sql in sqls.items():
                    if con.execute(sql,args).fetchall()!=original:
                        raise AssertionError(f'Ganancia/resultado diferente con costos NULL: {label}')
        finally:
            con.execute('ROLLBACK TO v105_snapshot')
            con.execute('RELEASE v105_snapshot')
        result.append('  Equivalencia: OK (30 días, 7 días, período vacío y costos históricos NULL).')
        args=ranges[0]
        samples={label:[] for label in sqls}
        names=list(sqls)
        for label,sql in sqls.items():
            for _ in range(3):con.execute(sql,args).fetchall()
        # Rotar variantes: comparar con el mismo cache y evitar sesgo de orden fijo.
        for i in range(rounds):
            for j in range(len(names)):
                label=names[(i+j)%len(names)]
                t=time.perf_counter_ns()
                con.execute(sqls[label],args).fetchall()
                samples[label].append((time.perf_counter_ns()-t)/1_000_000)
        baseline=statistics.median(samples['original_V104'])
        for label in names:
            values=sorted(samples[label]); p95=values[max(0,int((len(values)-1)*.95))]
            median=statistics.median(values)
            result.append(f'  {label}: P50 {median:.2f} ms | P95 {p95:.2f} ms | diferencia vs original {100*(median/baseline-1):+.1f}%')
        result.append('  V106 utiliza ambas_sin_materializar; las otras variantes siguen siendo solo diagnósticas.')
        result.append('  Verificar rendimiento HTTP de V106 frente a V105 en Windows; mantener rollback disponible.')
        assert con.execute('PRAGMA quick_check').fetchone()[0]=='ok'
        assert not con.execute('PRAGMA foreign_key_check').fetchall()
        return result
    finally:
        con.close()


if __name__=='__main__':
    raise SystemExit('Usar prueba_carga_v105.py: crea y elimina una base sintética temporal.')
