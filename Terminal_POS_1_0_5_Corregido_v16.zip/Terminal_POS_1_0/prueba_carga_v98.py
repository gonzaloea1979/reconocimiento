#!/usr/bin/env python3
"""Prueba de carga aislada V98 para Terminal POS.

Crea una aplicación y una base SQLite temporales. Nunca abre ni modifica
instance/pos.db, backups, uploads o datos comerciales del proyecto.
En Windows con las dependencias del POS ejecuta también pruebas HTTP reales
sobre loopback y concurrencia. Sin Flask, conserva la prueba SQL y lo informa.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import http.cookiejar
import importlib
import os
import random
import sqlite3
import statistics
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_REPORT = BASE_DIR / "logs" / "prueba_carga_v98.txt"
PRODUCTS = 10_000
SALES = 20_000
SALE_ITEMS_PER_SALE = 3
PRODUCT_MOVEMENTS = 10_000
CLIENTS = 2_000
SUPPLIERS = 300
PURCHASES = 5_000
PURCHASE_ITEMS_PER_PURCHASE = 3
CASH_SESSIONS = 250
CASH_MOVEMENTS = 10_000
CLIENT_MOVEMENTS = 5_000
AUDIT_LOGS = 20_000
ENDPOINTS = (
    "/api/dashboard",
    "/api/products",
    "/api/suppliers",
    "/api/stock/alerts",
    "/api/stock/movements",
    "/api/purchases",
    "/api/cash/status",
    "/api/clients",
    f"/api/reports?from={(date.today() - timedelta(days=30)).isoformat()}&to={date.today().isoformat()}",
    "/api/audit",
    "/api/products?q=Producto%200500",
    "/api/clients?q=Cliente%2000050",
    "/api/suppliers?q=Proveedor%2000050",
)

SCHEMA_SQL = r"""
CREATE TABLE products (
 id INTEGER PRIMARY KEY AUTOINCREMENT, barcode TEXT UNIQUE, name TEXT NOT NULL,
 detail TEXT, cost_without_tax REAL NOT NULL DEFAULT 0, iva_percent REAL NOT NULL DEFAULT 0,
 gross_income_percent REAL NOT NULL DEFAULT 0, total_cost REAL NOT NULL DEFAULT 0,
 margin_percent REAL NOT NULL DEFAULT 0, rounding_mode TEXT NOT NULL DEFAULT 'none',
 rounding_multiple REAL NOT NULL DEFAULT 1, sale_price REAL NOT NULL DEFAULT 0,
 stock REAL NOT NULL DEFAULT 0, expiry_date TEXT, photo_path TEXT,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 min_stock REAL NOT NULL DEFAULT 0, supplier_id INTEGER
);
CREATE TABLE sales (
 id INTEGER PRIMARY KEY AUTOINCREMENT, total REAL NOT NULL DEFAULT 0,
 payment_method TEXT NOT NULL DEFAULT 'Efectivo', amount_received REAL NOT NULL DEFAULT 0,
 change_amount REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL,
 cashier_name TEXT NOT NULL DEFAULT '', client_id INTEGER, cash_session_id INTEGER,
 sale_type TEXT NOT NULL DEFAULT 'Contado'
);
CREATE TABLE sale_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
 product_name TEXT NOT NULL, unit_price REAL NOT NULL, quantity REAL NOT NULL,
 line_total REAL NOT NULL, created_at TEXT NOT NULL, unit_cost_at_sale REAL,
 FOREIGN KEY(sale_id) REFERENCES sales(id), FOREIGN KEY(product_id) REFERENCES products(id)
);
CREATE TABLE suppliers (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, cuit TEXT DEFAULT '',
 phone TEXT DEFAULT '', address TEXT DEFAULT '', category TEXT DEFAULT '', notes TEXT DEFAULT '',
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE purchases (
 id INTEGER PRIMARY KEY AUTOINCREMENT, supplier_id INTEGER, supplier_name TEXT DEFAULT '',
 total REAL NOT NULL DEFAULT 0, notes TEXT DEFAULT '', created_at TEXT NOT NULL,
 FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
);
CREATE TABLE purchase_items (
 id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
 product_name TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 0, unit_cost REAL NOT NULL DEFAULT 0,
 cost_without_tax REAL NOT NULL DEFAULT 0, iva_percent REAL NOT NULL DEFAULT 0,
 gross_income_percent REAL NOT NULL DEFAULT 0, total_cost REAL NOT NULL DEFAULT 0,
 margin_percent REAL NOT NULL DEFAULT 0, sale_price REAL NOT NULL DEFAULT 0,
 expiry_date TEXT, line_total REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL,
 FOREIGN KEY(purchase_id) REFERENCES purchases(id), FOREIGN KEY(product_id) REFERENCES products(id)
);
CREATE TABLE product_movements (
 id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL, product_name TEXT NOT NULL,
 movement_type TEXT NOT NULL, quantity REAL NOT NULL DEFAULT 0,
 previous_stock REAL NOT NULL DEFAULT 0, new_stock REAL NOT NULL DEFAULT 0,
 reference TEXT DEFAULT '', notes TEXT DEFAULT '', created_at TEXT NOT NULL,
 FOREIGN KEY(product_id) REFERENCES products(id)
);
CREATE TABLE cash_sessions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, opened_at TEXT NOT NULL, closed_at TEXT,
 initial_amount REAL NOT NULL DEFAULT 0, closing_amount REAL NOT NULL DEFAULT 0,
 expected_amount REAL NOT NULL DEFAULT 0, difference REAL NOT NULL DEFAULT 0,
 status TEXT NOT NULL DEFAULT 'abierta', cashier_name TEXT DEFAULT '', notes TEXT DEFAULT ''
);
CREATE TABLE cash_movements (
 id INTEGER PRIMARY KEY AUTOINCREMENT, cash_session_id INTEGER, movement_type TEXT NOT NULL,
 amount REAL NOT NULL DEFAULT 0, description TEXT DEFAULT '', payment_method TEXT DEFAULT 'Efectivo',
 sale_id INTEGER, created_at TEXT NOT NULL,
 FOREIGN KEY(cash_session_id) REFERENCES cash_sessions(id), FOREIGN KEY(sale_id) REFERENCES sales(id)
);
CREATE TABLE clients (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, document TEXT DEFAULT '',
 phone TEXT DEFAULT '', address TEXT DEFAULT '', notes TEXT DEFAULT '',
 balance REAL NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE client_movements (
 id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER NOT NULL,
 movement_type TEXT NOT NULL, amount REAL NOT NULL DEFAULT 0, description TEXT DEFAULT '',
 sale_id INTEGER, created_at TEXT NOT NULL,
 FOREIGN KEY(client_id) REFERENCES clients(id), FOREIGN KEY(sale_id) REFERENCES sales(id)
);
CREATE TABLE audit_logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_name TEXT DEFAULT '', action TEXT NOT NULL,
 module TEXT DEFAULT '', detail TEXT DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT '');
CREATE TABLE users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE,
 full_name TEXT NOT NULL DEFAULT '', role TEXT NOT NULL DEFAULT 'Cajero',
 password_hash TEXT NOT NULL DEFAULT '', is_active INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX idx_sales_created_at ON sales(created_at);
CREATE INDEX idx_sales_client_id ON sales(client_id);
CREATE INDEX idx_purchase_items_purchase_id_id ON purchase_items(purchase_id, id ASC);
CREATE INDEX idx_sale_items_sale_report ON sale_items(sale_id, product_id, product_name, quantity, line_total, unit_cost_at_sale);
CREATE INDEX idx_sale_items_product_rollup ON sale_items(product_id, product_name, quantity, line_total);
CREATE INDEX idx_cash_movements_session_id_id ON cash_movements(cash_session_id, id DESC);
CREATE INDEX idx_product_movements_product_id_id ON product_movements(product_id, id DESC);
CREATE INDEX idx_client_movements_client_id_id ON client_movements(client_id, id DESC);
CREATE INDEX idx_products_name ON products(name);
CREATE INDEX idx_products_low_stock_priority ON products((stock-min_stock), name)
 WHERE min_stock > 0 AND stock <= min_stock;
CREATE INDEX idx_products_expiry_date ON products(date(expiry_date));
CREATE INDEX idx_clients_name ON clients(name);
CREATE INDEX idx_clients_balance_desc ON clients(balance DESC);
CREATE INDEX idx_suppliers_name ON suppliers(name);
CREATE INDEX idx_cash_sessions_status_id ON cash_sessions(status, id DESC);
CREATE INDEX idx_users_active_role_lower_username ON users(is_active, role, LOWER(username));
"""


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, int((p / 100.0) * (len(ordered) - 1) + 0.999999)))
    return ordered[index]


def stats(values: list[float]) -> dict[str, float]:
    return {
        "n": len(values),
        "p50": percentile(values, 50),
        "p95": percentile(values, 95),
        "p99": percentile(values, 99),
        "max": max(values) if values else 0.0,
        "avg": statistics.fmean(values) if values else 0.0,
    }


def fmt_ms(value: float) -> str:
    return f"{value:.2f} ms"


def process_rss_bytes() -> int | None:
    try:
        import psutil  # optional; the POS does not depend on it
        return int(psutil.Process(os.getpid()).memory_info().rss)
    except Exception:
        pass
    if os.name == "nt":
        try:
            import ctypes
            from ctypes import wintypes

            class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
                _fields_ = [
                    ("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                    ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t),
                ]
            counters = PROCESS_MEMORY_COUNTERS()
            counters.cb = ctypes.sizeof(counters)
            kernel32 = ctypes.windll.kernel32
            psapi = ctypes.windll.psapi
            kernel32.GetCurrentProcess.restype = wintypes.HANDLE
            psapi.GetProcessMemoryInfo.argtypes = [
                wintypes.HANDLE, ctypes.POINTER(PROCESS_MEMORY_COUNTERS), wintypes.DWORD
            ]
            psapi.GetProcessMemoryInfo.restype = wintypes.BOOL
            handle = kernel32.GetCurrentProcess()
            if psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters), counters.cb):
                return int(counters.WorkingSetSize)
        except Exception:
            return None
    try:
        import resource
        rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return int(rss * (1024 if sys.platform != "darwin" else 1))
    except Exception:
        return None


def make_isolated_app(root: Path):
    """Crea la aplicación real apuntando toda su persistencia a una carpeta temporal."""
    try:
        importlib.import_module("flask")
        config = importlib.import_module("app.config")
        replacements = {
            "BASE_DIR": root,
            "INSTANCE_DIR": root / "instance",
            "BACKUP_DIR": root / "backups",
            "DATABASE": root / "instance" / "pos.db",
            "UPLOAD_DIR": root / "app_static" / "uploads",
            "TICKET_DIR": root / "TICKET",
        }
        previous = {key: getattr(config, key) for key in replacements}
        for key, value in replacements.items():
            setattr(config, key, value)
        os.environ.pop("POS_SEED_DEMO_PRODUCTS", None)
        from app import create_app
        application = create_app()
        application.config["TESTING"] = True
        application.config["PROPAGATE_EXCEPTIONS"] = False
        return application, application.config["DATABASE"], previous, config
    except ImportError as exc:
        raise RuntimeError(f"Flask no está disponible para probar la aplicación HTTP: {exc}") from exc


def create_fallback_database(db_path: Path) -> None:
    """Esquema espejo para validar el generador SQL cuando Flask no está instalado."""
    con = sqlite3.connect(db_path)
    con.execute("PRAGMA foreign_keys=ON")
    con.executescript(SCHEMA_SQL)
    stamp = datetime.now().astimezone().isoformat(timespec="seconds")
    con.execute(
        "INSERT INTO users(username,full_name,role,created_at,updated_at) VALUES(?,?,?,?,?)",
        ("admin", "Administrador", "Administrador", stamp, stamp),
    )
    # Reproducir el índice de búsqueda opcional de V95 cuando el SQLite local
    # dispone de FTS5/trigram. Si no, las consultas de prueba usan LIKE clásico.
    try:
        for table, columns in {
            "products": ("barcode", "name", "detail"),
            "clients": ("name", "document", "phone"),
            "suppliers": ("name", "cuit", "phone", "category"),
        }.items():
            fts = f"{table}_search"
            cols = ", ".join(columns)
            con.execute(
                f"CREATE VIRTUAL TABLE {fts} USING fts5({cols}, content='{table}', content_rowid='id', tokenize='trigram')"
            )
            con.execute(
                f"INSERT INTO {fts}({fts}) VALUES ('rebuild')"
            )
            con.execute(
                f"CREATE TRIGGER {fts}_ai AFTER INSERT ON {table} BEGIN "
                f"INSERT INTO {fts}(rowid,{cols}) VALUES (new.id,{','.join('new.' + c for c in columns)}); END"
            )
            con.execute(
                f"CREATE TRIGGER {fts}_ad AFTER DELETE ON {table} BEGIN "
                f"INSERT INTO {fts}({fts},rowid,{cols}) VALUES ('delete',old.id,{','.join('old.' + c for c in columns)}); END"
            )
            con.execute(
                f"CREATE TRIGGER {fts}_au AFTER UPDATE ON {table} BEGIN "
                f"INSERT INTO {fts}({fts},rowid,{cols}) VALUES ('delete',old.id,{','.join('old.' + c for c in columns)}); "
                f"INSERT INTO {fts}(rowid,{cols}) VALUES (new.id,{','.join('new.' + c for c in columns)}); END"
            )
    except sqlite3.OperationalError:
        for table in ("products", "clients", "suppliers"):
            con.execute(f"DROP TABLE IF EXISTS {table}_search")
        for table in ("products", "clients", "suppliers"):
            for suffix in ("ai", "ad", "au"):
                con.execute(f"DROP TRIGGER IF EXISTS {table}_search_{suffix}")
    con.commit()
    con.close()


def seed_database(db_path: Path) -> dict[str, int]:
    rng = random.Random(9601)
    con = sqlite3.connect(db_path, timeout=30)
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA busy_timeout=30000")
    now = datetime.now().astimezone().replace(microsecond=0)
    today = date.today()
    iso = lambda days=0, seconds=0: (now - timedelta(days=days, seconds=seconds)).isoformat(timespec="seconds")

    # Datos sintéticos claramente identificables; ninguna persona o negocio real.
    suppliers = [
        (f"Proveedor {i:05d}", f"30{700000000 + i:09d}", f"351{4000000 + i:07d}",
         "Zona de prueba", "Indumentaria" if i % 2 else "Almacén", "Registro sintético", iso(700), iso(0))
        for i in range(1, SUPPLIERS + 1)
    ]
    clients = [
        (f"Cliente {i:05d}", f"{20000000 + i}", f"351{5000000 + i:07d}",
         "Dirección de prueba", "Dato sintético", float((i % 11) * 1250 if i % 5 == 0 else 0), iso(600), iso(0))
        for i in range(1, CLIENTS + 1)
    ]
    con.executemany(
        "INSERT INTO suppliers(name,cuit,phone,address,category,notes,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
        suppliers,
    )
    con.executemany(
        "INSERT INTO clients(name,document,phone,address,notes,balance,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
        clients,
    )
    products = []
    for i in range(1, PRODUCTS + 1):
        stock = float(rng.randrange(0, 80))
        minimum = float(rng.choice([0, 0, 0, 5, 10, 15]))
        expiry = (today + timedelta(days=rng.randrange(-15, 180))).isoformat() if i % 4 == 0 else None
        products.append((f"77996{i:07d}", f"Producto {i:05d}", f"Artículo sintético de prueba {i:05d}",
                         100 + i % 900, 21, 3, 124 + i % 1100, 30, "none", 1,
                         180 + i % 1800, stock, expiry, None, iso(700), iso(0), minimum, rng.randrange(1, SUPPLIERS + 1)))
    con.executemany(
        """INSERT INTO products(barcode,name,detail,cost_without_tax,iva_percent,gross_income_percent,
        total_cost,margin_percent,rounding_mode,rounding_multiple,sale_price,stock,expiry_date,photo_path,
        created_at,updated_at,min_stock,supplier_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        products,
    )

    sessions = []
    for i in range(1, CASH_SESSIONS + 1):
        opened = iso(i % 120, rng.randrange(0, 3600))
        is_open = i == CASH_SESSIONS
        sessions.append((opened, None if is_open else iso(max(0, i % 120 - 1)), 50000 + i * 100,
                          0 if is_open else 60000 + i * 100, 0 if is_open else 60000 + i * 100,
                          0, "abierta" if is_open else "cerrada", f"Cajero prueba {i % 12:02d}", "Sesión sintética"))
    con.executemany(
        """INSERT INTO cash_sessions(opened_at,closed_at,initial_amount,closing_amount,expected_amount,
        difference,status,cashier_name,notes) VALUES(?,?,?,?,?,?,?,?,?)""", sessions
    )

    sales = []
    payment_methods = ("Efectivo", "Transferencia", "Débito", "Crédito")
    for i in range(1, SALES + 1):
        day = rng.randrange(0, 120)
        created = iso(day, rng.randrange(0, 86400))
        total = float(rng.randrange(1500, 45000))
        sales.append((total, rng.choice(payment_methods), total + rng.randrange(0, 10000),
                      max(0, rng.randrange(0, 10000)), created, f"Cajero prueba {i % 12:02d}",
                      rng.randrange(1, CLIENTS + 1) if i % 3 == 0 else None,
                      rng.randrange(1, CASH_SESSIONS + 1), "Contado"))
    con.executemany(
        """INSERT INTO sales(total,payment_method,amount_received,change_amount,created_at,cashier_name,
        client_id,cash_session_id,sale_type) VALUES(?,?,?,?,?,?,?,?,?)""", sales
    )

    sale_items = []
    for sale_id in range(1, SALES + 1):
        sale_created = sales[sale_id - 1][4]
        for line in range(SALE_ITEMS_PER_SALE):
            product_id = rng.randrange(1, PRODUCTS + 1)
            qty = float(rng.randrange(1, 5))
            unit_price = float(180 + product_id % 1800)
            sale_items.append((sale_id, product_id, f"Producto {product_id:05d}", unit_price,
                               qty, round(unit_price * qty, 2), sale_created,
                               float(124 + product_id % 1100)))
    con.executemany(
        """INSERT INTO sale_items(sale_id,product_id,product_name,unit_price,quantity,line_total,
        created_at,unit_cost_at_sale) VALUES(?,?,?,?,?,?,?,?)""", sale_items
    )

    purchases = []
    for i in range(1, PURCHASES + 1):
        purchases.append((rng.randrange(1, SUPPLIERS + 1), f"Proveedor {rng.randrange(1, SUPPLIERS + 1):05d}",
                          float(rng.randrange(10000, 150000)), "Compra sintética", iso(rng.randrange(0, 120))))
    con.executemany(
        "INSERT INTO purchases(supplier_id,supplier_name,total,notes,created_at) VALUES(?,?,?,?,?)", purchases
    )
    purchase_items = []
    for purchase_id in range(1, PURCHASES + 1):
        for _ in range(PURCHASE_ITEMS_PER_PURCHASE):
            product_id = rng.randrange(1, PRODUCTS + 1)
            qty = float(rng.randrange(1, 30))
            unit_cost = float(100 + product_id % 900)
            purchase_items.append((purchase_id, product_id, f"Producto {product_id:05d}", qty, unit_cost,
                                   unit_cost, 21, 3, unit_cost * 1.24, 30,
                                   float(180 + product_id % 1800), None, qty * unit_cost * 1.24, iso(rng.randrange(0, 120))))
    con.executemany(
        """INSERT INTO purchase_items(purchase_id,product_id,product_name,quantity,unit_cost,cost_without_tax,
        iva_percent,gross_income_percent,total_cost,margin_percent,sale_price,expiry_date,line_total,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""", purchase_items
    )

    product_movements = []
    for i in range(1, PRODUCT_MOVEMENTS + 1):
        product_id = rng.randrange(1, PRODUCTS + 1)
        previous = float(rng.randrange(0, 100))
        quantity = float(rng.randrange(-20, 21))
        product_movements.append((product_id, f"Producto {product_id:05d}",
                                  "Entrada" if quantity >= 0 else "Salida", quantity,
                                  previous, max(0, previous + quantity), f"REF-{i:07d}",
                                  "Movimiento sintético", iso(rng.randrange(0, 120))))
    con.executemany(
        """INSERT INTO product_movements(product_id,product_name,movement_type,quantity,previous_stock,
        new_stock,reference,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?)""", product_movements
    )

    cash_movements = []
    for i in range(1, CASH_MOVEMENTS + 1):
        session_id = rng.randrange(1, CASH_SESSIONS + 1)
        sale_id = rng.randrange(1, SALES + 1) if i % 3 == 0 else None
        movement_type = rng.choice(("Ingreso", "Venta", "Retiro"))
        cash_movements.append((session_id, movement_type, float(rng.randrange(500, 25000)),
                               "Movimiento de caja sintético", rng.choice(payment_methods), sale_id,
                               iso(rng.randrange(0, 120))))
    con.executemany(
        """INSERT INTO cash_movements(cash_session_id,movement_type,amount,description,payment_method,
        sale_id,created_at) VALUES(?,?,?,?,?,?,?)""", cash_movements
    )

    client_movements = []
    for i in range(1, CLIENT_MOVEMENTS + 1):
        client_movements.append((rng.randrange(1, CLIENTS + 1), rng.choice(("Venta", "Pago", "Ajuste")),
                                 float(rng.randrange(500, 20000)), "Movimiento de cliente sintético",
                                 rng.randrange(1, SALES + 1) if i % 2 == 0 else None,
                                 iso(rng.randrange(0, 120))))
    con.executemany(
        """INSERT INTO client_movements(client_id,movement_type,amount,description,sale_id,created_at)
        VALUES(?,?,?,?,?,?)""", client_movements
    )

    audit = []
    actions = ("Crear producto", "Registrar venta", "Registrar compra", "Ajustar stock", "Abrir caja", "Cerrar caja")
    modules = ("Productos", "Ventas", "Compras", "Stock", "Caja")
    for i in range(1, AUDIT_LOGS + 1):
        audit.append((f"Usuario prueba {i % 12:02d}", rng.choice(actions), rng.choice(modules),
                      f"Evento sintético {i:07d}", iso(rng.randrange(0, 120))))
    con.executemany(
        "INSERT INTO audit_logs(user_name,action,module,detail,created_at) VALUES(?,?,?,?,?)", audit
    )
    con.commit()
    con.execute("ANALYZE")
    con.commit()

    counts = {}
    for table in ("products", "sales", "sale_items", "product_movements", "clients", "suppliers",
                  "purchases", "purchase_items", "cash_sessions", "cash_movements", "client_movements", "audit_logs"):
        counts[table] = int(con.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0])
    fk_errors = con.execute("PRAGMA foreign_key_check").fetchall()
    quick = con.execute("PRAGMA quick_check").fetchone()[0]
    con.close()
    if fk_errors:
        raise RuntimeError(f"Falló foreign_key_check: {fk_errors[:3]}")
    if quick != "ok":
        raise RuntimeError(f"Falló quick_check: {quick}")
    return counts


def benchmark_sql(db_path: Path) -> tuple[list[dict], list[tuple[str, str]]]:
    con = sqlite3.connect(db_path, timeout=15)
    queries = {
        "Productos ordenados": ("SELECT id FROM products ORDER BY name ASC LIMIT 200", ()),
        "Ventas recientes": ("SELECT id,total FROM sales ORDER BY id DESC LIMIT 100", ()),
        "Ventas 30 días": ("SELECT COUNT(*),COALESCE(SUM(total),0) FROM sales WHERE created_at>=date('now','-30 day')", ()),
        "Alertas stock": ("SELECT id FROM products WHERE min_stock>0 AND stock<=min_stock ORDER BY (stock-min_stock),name LIMIT 30", ()),
        "Movimientos recientes": ("SELECT id FROM product_movements ORDER BY id DESC LIMIT 100", ()),
        "Auditoría reciente": ("SELECT id FROM audit_logs ORDER BY id DESC LIMIT 100", ()),
        "Compras recientes": ("SELECT id FROM purchases ORDER BY id DESC LIMIT 100", ()),
        "Dashboard top productos": ("SELECT product_name,SUM(quantity) qty,SUM(line_total) amount FROM sale_items GROUP BY product_id,product_name ORDER BY qty DESC,amount DESC LIMIT 10", ()),
        "Dashboard menos vendidos": ("SELECT p.name,COALESCE(SUM(si.quantity),0) qty,COALESCE(SUM(si.line_total),0) amount FROM products p LEFT JOIN sale_items si ON si.product_id=p.id GROUP BY p.id,p.name ORDER BY qty ASC,amount ASC,p.name ASC LIMIT 10", ()),
        "Búsqueda productos parcial": ("SELECT p.id FROM products p JOIN (SELECT rowid FROM products_search WHERE barcode LIKE ? UNION SELECT rowid FROM products_search WHERE name LIKE ? UNION SELECT rowid FROM products_search WHERE detail LIKE ?) matches ON matches.rowid=p.id ORDER BY p.name LIMIT 100", ("%0500%", "%0500%", "%0500%")),
    }
    available_fts = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='products_search'").fetchone()
    if not available_fts:
        queries.pop("Búsqueda productos parcial")
        queries["Búsqueda productos LIKE"] = (
            "SELECT id FROM products WHERE barcode LIKE ? OR name LIKE ? OR detail LIKE ? ORDER BY name LIMIT 100",
            ("%0500%", "%0500%", "%0500%"),
        )
    rows, plans = [], []
    for label, (sql, params) in queries.items():
        for _ in range(5):
            con.execute(sql, params).fetchall()
        timings = []
        for _ in range(35):
            start = time.perf_counter_ns()
            con.execute(sql, params).fetchall()
            timings.append((time.perf_counter_ns() - start) / 1_000_000)
        plan = " | ".join(str(item[3]) for item in con.execute("EXPLAIN QUERY PLAN " + sql, params).fetchall())
        rows.append({"name": label, **stats(timings)})
        plans.append((label, plan))
    con.close()
    return rows, plans


def http_get(opener, base_url: str, path: str, timeout: float = 20.0) -> tuple[int, float, int]:
    request = urllib.request.Request(base_url + path, headers={"Accept": "application/json", "Connection": "keep-alive"})
    start = time.perf_counter_ns()
    try:
        with opener.open(request, timeout=timeout) as response:
            body = response.read()
            elapsed = (time.perf_counter_ns() - start) / 1_000_000
            return response.status, elapsed, len(body)
    except urllib.error.HTTPError as exc:
        body = exc.read()
        elapsed = (time.perf_counter_ns() - start) / 1_000_000
        return exc.code, elapsed, len(body)
    except (urllib.error.URLError, TimeoutError, OSError):
        elapsed = (time.perf_counter_ns() - start) / 1_000_000
        return 0, elapsed, 0


def make_opener():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))


def benchmark_http(app, rounds: int = 12) -> tuple[list[dict], list[dict], list[str]]:
    from werkzeug.serving import WSGIRequestHandler, make_server

    class QuietRequestHandler(WSGIRequestHandler):
        def log(self, type, message, *args):
            return

    server = make_server("127.0.0.1", 0, app, threaded=True, request_handler=QuietRequestHandler)
    server_thread = threading.Thread(target=server.serve_forever, name="v98-loopback-server", daemon=True)
    server_thread.start()
    base_url = f"http://127.0.0.1:{server.server_port}"
    endpoint_rows, errors = [], []
    try:
        opener = make_opener()
        for path in ENDPOINTS:
            # Calentamiento: establece cookie local y prepara cachés del intérprete.
            status, _, _ = http_get(opener, base_url, path)
            if status != 200:
                errors.append(f"Calentamiento {path}: HTTP {status}")
            timings, sizes = [], []
            for _ in range(rounds):
                status, elapsed, size = http_get(opener, base_url, path)
                timings.append(elapsed)
                sizes.append(size)
                if status != 200:
                    errors.append(f"{path}: HTTP {status}")
            endpoint_rows.append({"path": path, **stats(timings), "response_bytes_avg": int(statistics.fmean(sizes)) if sizes else 0})

        concurrency_rows = []
        for workers in (1, 2, 4, 8):
            per_user_rounds = 4
            all_timings = []
            status_failures = []

            def worker(worker_id: int):
                worker_opener = make_opener()
                local = []
                local_errors = []
                for cycle in range(per_user_rounds):
                    # Distribuir endpoints entre usuarios virtuales, conservando
                    # sesiones HTTP independientes para cada usuario.
                    for offset in range(len(ENDPOINTS)):
                        path = ENDPOINTS[(worker_id + cycle + offset) % len(ENDPOINTS)]
                        status, elapsed, _ = http_get(worker_opener, base_url, path)
                        local.append(elapsed)
                        if status != 200:
                            local_errors.append(f"usuario {worker_id + 1} {path}: HTTP {status}")
                return local, local_errors

            started = time.perf_counter()
            with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
                futures = [pool.submit(worker, index) for index in range(workers)]
                for future in concurrent.futures.as_completed(futures):
                    values, failures = future.result()
                    all_timings.extend(values)
                    status_failures.extend(failures)
            elapsed_total = time.perf_counter() - started
            concurrency_rows.append({
                "users": workers, **stats(all_timings),
                "requests_per_second": len(all_timings) / elapsed_total if elapsed_total else 0,
                "wall_seconds": elapsed_total,
                "errors": len(status_failures),
            })
            errors.extend(status_failures)
        return endpoint_rows, concurrency_rows, errors
    finally:
        server.shutdown()
        server.server_close()
        server_thread.join(timeout=5)


def write_report(path: Path, lines: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run(args) -> int:
    lines = [
        "TERMINAL POS - PRUEBA DE CARGA V98",
        f"Fecha: {datetime.now().astimezone().isoformat(timespec='seconds')}",
        f"Python: {sys.version.split()[0]} | SQLite: {sqlite3.sqlite_version}",
        f"Volumen: {PRODUCTS:,} productos | {SALES:,} ventas | {SALES * SALE_ITEMS_PER_SALE:,} artículos de venta",
        "ALCANCE: base temporal sintética. No se abre ni modifica instance/pos.db.",
        "",
    ]
    rss_before = process_rss_bytes()
    cpu_before = time.process_time()
    api_rows, concurrency_rows, api_errors = [], [], []
    with tempfile.TemporaryDirectory(prefix="terminal_pos_v98_") as tmp:
        sandbox = Path(tmp)
        app = None
        config_previous = None
        config_module = None
        try:
            app, db_path, config_previous, config_module = make_isolated_app(sandbox)
            mode = "Aplicación Flask real + base temporal aislada"
        except RuntimeError as exc:
            if not args.allow_sql_only:
                raise
            db_path = sandbox / "pos.db"
            create_fallback_database(db_path)
            mode = f"Solo SQLite (API omitida: {exc})"
        seed_started = time.perf_counter()
        counts = seed_database(db_path)
        seed_seconds = time.perf_counter() - seed_started
        rss_after_seed = process_rss_bytes()
        lines.append("MODO: " + mode)
        lines.append(f"Carga de datos: {seed_seconds:.2f} s")
        lines.append(f"Tamaño de base temporal: {db_path.stat().st_size / (1024**2):.2f} MB")
        lines.append("REGISTROS SINTÉTICOS:")
        for table, count in counts.items():
            lines.append(f"  {table}: {count:,}")
        lines.append("")

        sql_rows, plans = benchmark_sql(db_path)
        lines.append("CONSULTAS SQL (35 mediciones por consulta; tiempos en ms):")
        for row in sql_rows:
            lines.append(
                f"  {row['name']}: P50 {fmt_ms(row['p50'])} | P95 {fmt_ms(row['p95'])} | "
                f"P99 {fmt_ms(row['p99'])} | máx. {fmt_ms(row['max'])}"
            )
        lines.append("PLANES SQL:")
        for label, plan in plans:
            lines.append(f"  {label}: {plan}")

        if app is not None:
            lines.append("")
            lines.append("ENDPOINTS HTTP LOOPBACK (calentamiento + mediciones; solo GET):")
            http_started = time.perf_counter()
            api_rows, concurrency_rows, api_errors = benchmark_http(app, rounds=args.rounds)
            http_seconds = time.perf_counter() - http_started
            rss_after_http = process_rss_bytes()
            lines.append(f"Duración HTTP + concurrencia: {http_seconds:.2f} s")
            lines.append(f"RAM RSS tras carga de datos: {rss_after_seed / (1024**2):.1f} MB" if rss_after_seed else "RAM RSS tras carga de datos: No disponible")
            lines.append(f"RAM RSS tras HTTP: {rss_after_http / (1024**2):.1f} MB" if rss_after_http else "RAM RSS tras HTTP: No disponible")
            for row in api_rows:
                lines.append(
                    f"  {row['path']}: P50 {fmt_ms(row['p50'])} | P95 {fmt_ms(row['p95'])} | "
                    f"P99 {fmt_ms(row['p99'])} | respuesta media {row['response_bytes_avg']:,} bytes"
                )
            lines.append("")
            lines.append("CONCURRENCIA HTTP (usuarios virtuales, sesiones separadas):")
            for row in concurrency_rows:
                lines.append(
                    f"  {row['users']} usuarios: P50 {fmt_ms(row['p50'])} | P95 {fmt_ms(row['p95'])} | "
                    f"P99 {fmt_ms(row['p99'])} | {row['requests_per_second']:.1f} req/s | "
                    f"{row['errors']} errores HTTP"
                )
        else:
            lines.append("")
            lines.append(f"RAM RSS tras carga de datos: {rss_after_seed / (1024**2):.1f} MB" if rss_after_seed else "RAM RSS tras carga de datos: No disponible")
            lines.append("[OMITIDO] Prueba HTTP y concurrencia de rutas: instalar dependencias de requirements.txt.")

        con = sqlite3.connect(db_path)
        quick = con.execute("PRAGMA quick_check").fetchone()[0]
        fk = con.execute("PRAGMA foreign_key_check").fetchall()
        journal = con.execute("PRAGMA journal_mode").fetchone()[0]
        con.close()
        lines.extend([
            "",
            "INTEGRIDAD DE LA BASE TEMPORAL:",
            f"  quick_check: {quick}",
            f"  foreign_key_check: {'OK' if not fk else 'FALLO'}",
            f"  journal_mode: {journal}",
        ])
        if quick != "ok" or fk:
            raise RuntimeError("La base temporal no superó las comprobaciones de integridad.")

        rss_after = process_rss_bytes()
        cpu_after = time.process_time()
        lines.extend([
            "",
            "RECURSOS DEL PROCESO DE PRUEBA (incluye carga de datos y mediciones):",
            f"  CPU de proceso consumida: {cpu_after - cpu_before:.2f} s",
            f"  RAM RSS inicial: {rss_before / (1024**2):.1f} MB" if rss_before else "  RAM RSS inicial: No disponible",
            f"  RAM RSS final: {rss_after / (1024**2):.1f} MB" if rss_after else "  RAM RSS final: No disponible",
            "",
            "ERRORES HTTP:",
            *(tuple(f"  {error}" for error in api_errors) if api_errors else
              (("  Ninguno",) if app is not None else ("  No aplica: prueba HTTP omitida",))),
            "",
            "INTERPRETACIÓN:",
            "  Comparar P95/P99 y concurrencia antes de cambiar código. No agregar índices solo por ver SCAN:",
            "  en tablas rowid, ORDER BY id DESC LIMIT N puede recorrer desde el final sin ordenar toda la tabla.",
            "  La carga es sintética; no reproduce exactamente el hardware Windows del usuario.",
            "  La carpeta temporal y su base se eliminan automáticamente al terminar.",
        ])
    report_path = Path(args.report).resolve() if args.report else DEFAULT_REPORT
    write_report(report_path, lines)
    print("\n".join(lines))
    print(f"\nInforme guardado en: {report_path}")
    return 0


def parse_args():
    parser = argparse.ArgumentParser(description="Prueba de carga aislada de Terminal POS V98")
    parser.add_argument("--rounds", type=int, default=12, help="mediciones por endpoint (predeterminado: 12)")
    parser.add_argument("--report", default=str(DEFAULT_REPORT), help="ruta del informe TXT")
    parser.add_argument("--allow-sql-only", action="store_true", help="permitir modo SQL si Flask no está instalado")
    args = parser.parse_args()
    if not 1 <= args.rounds <= 100:
        parser.error("--rounds debe estar entre 1 y 100")
    return args


if __name__ == "__main__":
    raise SystemExit(run(parse_args()))
