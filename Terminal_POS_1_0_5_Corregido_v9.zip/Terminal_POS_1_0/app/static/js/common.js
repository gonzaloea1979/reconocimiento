const moneyFormatter = new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' });

// Escapado único para cualquier dato dinámico insertado en plantillas HTML.
function escapeHTML(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function formatMoney(value) {
  return moneyFormatter.format(Number(value || 0));
}

function formatDateAR(value) {
  if (!value) return '-';
  const raw = String(value).trim();

  const arMatch = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})/);
  if (arMatch) return `${arMatch[1]}/${arMatch[2]}/${arMatch[3]}`;

  const isoMatch = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (isoMatch) return `${isoMatch[3]}/${isoMatch[2]}/${isoMatch[1]}`;

  const parsed = new Date(raw);
  if (!Number.isNaN(parsed.getTime())) {
    return parsed.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  }
  return raw;
}

function normalizeDateToISO(value) {
  if (!value) return '';
  let raw = String(value).trim();

  const isoMatch = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (isoMatch) return raw;

  // Formato corto para carga rápida: DDMMAA.
  // Ejemplo: 200626 => 20/06/2026.
  const shortMatch = raw.match(/^(\d{2})(\d{2})(\d{2})$/);
  if (shortMatch) raw = `${shortMatch[1]}/${shortMatch[2]}/20${shortMatch[3]}`;

  // También acepta DDMMYYYY.
  const compactMatch = raw.match(/^(\d{2})(\d{2})(\d{4})$/);
  if (compactMatch) raw = `${compactMatch[1]}/${compactMatch[2]}/${compactMatch[3]}`;

  const arMatch = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!arMatch) return null;

  const day = Number(arMatch[1]);
  const month = Number(arMatch[2]);
  const year = Number(arMatch[3]);
  const date = new Date(year, month - 1, day);

  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return null;
  return `${year.toString().padStart(4, '0')}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
}


function currentUserIsAdmin() {
  return Boolean(window.POS_CURRENT_USER && window.POS_CURRENT_USER.is_admin);
}

function currentUserRole() {
  return (window.POS_CURRENT_USER && window.POS_CURRENT_USER.role) || 'Cajero';
}

function securityPasswordOrEmpty(inputId) {
  if (currentUserIsAdmin()) return '';
  const el = document.getElementById(inputId);
  return el ? el.value : '';
}

function markAdminBypassUI(root = document) {
  if (!currentUserIsAdmin()) return;
  root.querySelectorAll('[data-admin-bypass-note]').forEach(el => {
    el.textContent = 'Administrador activo: no se solicita contraseña para modificar.';
  });
  root.querySelectorAll('.admin-password-optional, .security-password-field').forEach(el => {
    el.classList.add('admin-bypass-hidden');
  });
}

function showToast(message, isError = false) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.style.background = isError ? 'rgba(239,68,68,.96)' : 'rgba(17,24,39,.92)';
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2800);
}

async function api(url, options = {}) {
  const { headers: suppliedHeaders = {}, ...requestOptions } = options;
  const headers = {
    Accept: 'application/json',
    ...(requestOptions.body !== undefined && requestOptions.body !== null
      ? { 'Content-Type': 'application/json' }
      : {}),
    ...suppliedHeaders,
  };
  const config = { ...requestOptions, headers };
  const res = await fetch(url, config);
  let data;
  try {
    data = await res.json();
  } catch (cause) {
    throw new Error('No se pudo confirmar la respuesta. Reintentá sin cambiar los datos para comprobar la misma operación.');
  }
  if (!res.ok) {
    const error = new Error(data.error || 'Ocurrió un error');
    error.status = res.status;
    throw error;
  }
  return data;
}

// Un único envío por acción, incluso si llega por teclado y mouse juntos.
const pendingOperations = new Map();
function withOperationLock(name, selector, callback) {
  if (pendingOperations.has(name)) return pendingOperations.get(name);
  const buttons = Array.from(document.querySelectorAll(selector));
  const states = buttons.map(button => button.disabled);
  buttons.forEach(button => { button.disabled = true; });
  const pending = Promise.resolve().then(callback).finally(() => {
    buttons.forEach((button, index) => { button.disabled = states[index]; });
    pendingOperations.delete(name);
  });
  pendingOperations.set(name, pending);
  return pending;
}

// La misma confirmación conserva su clave si se pierde la respuesta. Una
// respuesta válida termina el intento y permite otra operación idéntica real.
const operationAttempts = new Map();
async function postOperation(url, payload) {
  const body = JSON.stringify(payload);
  const user = window.POS_CURRENT_USER?.username || 'local';
  const storageKey = 'pos-operation:' + user + ':' + url;
  let attempt = operationAttempts.get(storageKey);
  if (!attempt) {
    try { attempt = JSON.parse(sessionStorage.getItem(storageKey) || 'null'); } catch (_) {}
  }
  if (!attempt || attempt.body !== body || !/^[A-Za-z0-9_-]{16,128}$/.test(attempt.key)) {
    const bytes = new Uint8Array(16);
    window.crypto.getRandomValues(bytes);
    attempt = { body, key: Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('') };
  }
  operationAttempts.set(storageKey, attempt);
  try { sessionStorage.setItem(storageKey, JSON.stringify(attempt)); } catch (_) {}
  function clearAttempt() {
    if (operationAttempts.get(storageKey) !== attempt) return;
    operationAttempts.delete(storageKey);
    try { sessionStorage.removeItem(storageKey); } catch (_) {}
  }
  try {
    const result = await api(url, { method: 'POST', body, headers: { 'Idempotency-Key': attempt.key } });
    if (result.ok !== true) {
      throw new Error('La respuesta no confirmó la operación. Reintentá sin cambiar los datos.');
    }
    clearAttempt();
    return result;
  } catch (error) {
    // Errores de red/JSON/servidor conservan la clave. No reintentar solos:
    // el usuario decide cuándo repetir la confirmación.
    if (error.status >= 400 && error.status < 500) clearAttempt();
    throw error;
  }
}

function beep() {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = new AudioContext();
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.type = 'sine';
    oscillator.frequency.value = 880;
    gain.gain.setValueAtTime(0.0001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.16, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.15);
    oscillator.connect(gain);
    gain.connect(ctx.destination);
    oscillator.onended = () => {
      // Los lectores pueden emitir muchos pitidos seguidos; cerrar el contexto
      // evita acumular AudioContext abiertos durante jornadas largas.
      ctx.close().catch(() => {});
    };
    oscillator.start();
    oscillator.stop(ctx.currentTime + 0.16);
  } catch (e) {}
}

function renderSelectableList(container, products, activeIndex, onSelect) {
  container.innerHTML = '';
  if (!products.length) {
    container.innerHTML = '<div class="empty-state">No se encontraron productos</div>';
    return;
  }
  products.forEach((p, index) => {
    const option = document.createElement('div');
    option.className = 'select-option' + (index === activeIndex ? ' active' : '');
    option.innerHTML = `<div>${escapeHTML(p.name)}<small>${escapeHTML(p.barcode || 'Sin código')} · Stock ${escapeHTML(p.stock)}</small></div><strong>${formatMoney(p.sale_price)}</strong>`;
    option.addEventListener('click', () => onSelect(p));
    container.appendChild(option);
  });
}

let systemExitInProgress = false;
let systemExitCountdownInterval = null;
let systemExitCountdownTimeout = null;

function ensureSystemExitModal() {
  let modal = document.getElementById('systemExitModal');
  if (modal) return modal;

  modal = document.createElement('div');
  modal.id = 'systemExitModal';
  modal.className = 'system-exit-modal hidden';
  modal.setAttribute('aria-live', 'assertive');
  modal.setAttribute('aria-modal', 'true');
  modal.setAttribute('role', 'dialog');
  modal.innerHTML = `
    <div class="system-exit-card">
      <div class="system-exit-icon">⏻</div>
      <h2 id="systemExitTitle">Cerrando el sistema</h2>
      <strong id="systemExitCountdown">5</strong>
      <p id="systemExitMessage">Aguardá un momento...</p>
    </div>
  `;
  document.body.appendChild(modal);
  return modal;
}

function showSystemExitModal(seconds = 5, message = 'Cerrando servidor local y ventana del navegador...', title = 'Cerrando el sistema') {
  const modal = ensureSystemExitModal();
  const counter = document.getElementById('systemExitCountdown');
  const msg = document.getElementById('systemExitMessage');
  const titleEl = document.getElementById('systemExitTitle');
  if (titleEl) titleEl.textContent = title;
  if (counter) counter.textContent = String(seconds);
  if (msg) msg.textContent = message;
  modal.classList.remove('hidden');
  modal.classList.add('show');
}

function updateSystemExitCountdown(seconds) {
  const counter = document.getElementById('systemExitCountdown');
  if (counter) counter.textContent = String(Math.max(seconds, 0));
}

function showSystemClosedScreen() {
  document.body.innerHTML = `
    <div class="system-closed-screen">
      <div class="system-closed-card glass-card">
        <div class="system-closed-icon">⏻</div>
        <h1>Sistema cerrado</h1>
        <p>El servidor local POS se cerró correctamente.</p>
        <small>Si esta pestaña no se cerró sola, podés cerrarla manualmente. Para volver a usarlo, ejecutá nuevamente <strong>ejecutar.bat</strong>.</small>
      </div>
    </div>
  `;
}

function tryCloseBrowserWindow() {
  try {
    window.open('', '_self');
    window.close();
  } catch (e) {}

  // Algunos navegadores bloquean window.close() si la pestaña no fue abierta por script.
  // En ese caso dejamos una pantalla clara de sistema cerrado.
  setTimeout(() => {
    if (!window.closed) {
      showSystemClosedScreen();
    }
  }, 700);
}

async function shutdownServerAndCloseWindow(shutdownPc = false) {
  const msg = document.getElementById('systemExitMessage');
  if (msg) msg.textContent = shutdownPc ? 'Cerrando sistema y preparando apagado de la PC...' : 'Cerrando sistema...';

  // En la edición de escritorio cerramos la ventana nativa mediante el puente de
  // pywebview. Esto evita usar window.close() y os._exit(), que pertenecían a la
  // versión navegador y podían dejar cierres bruscos o funciones a medio terminar.
  try {
    if (window.pywebview && window.pywebview.api && typeof window.pywebview.api.close_app === 'function') {
      await window.pywebview.api.close_app(Boolean(shutdownPc));
      return;
    }
  } catch (e) {
    console.error('No se pudo cerrar mediante el puente de escritorio:', e);
  }

  // Respaldo para la versión web/navegador.
  try {
    await fetch('/api/shutdown', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ shutdown_pc: Boolean(shutdownPc) })
    });
  } catch (e) {}

  if (msg) msg.textContent = shutdownPc ? 'Apagando la PC...' : 'Cerrando ventana...';
  setTimeout(tryCloseBrowserWindow, 250);
}

async function startSystemExitFlow({ shutdownPc = false } = {}) {
  if (systemExitInProgress) return;
  systemExitInProgress = true;

  if (systemExitCountdownInterval) clearInterval(systemExitCountdownInterval);
  if (systemExitCountdownTimeout) clearTimeout(systemExitCountdownTimeout);

  let seconds = 5;
  const title = shutdownPc ? 'Apagando la PC' : 'Cerrando el sistema';
  const message = shutdownPc
    ? 'Se cerrará el POS y se apagará la computadora automáticamente...'
    : 'Cerrando el sistema automáticamente...';
  showSystemExitModal(seconds, message, title);

  systemExitCountdownInterval = setInterval(() => {
    seconds -= 1;
    updateSystemExitCountdown(seconds);
  }, 1000);

  systemExitCountdownTimeout = setTimeout(async () => {
    clearInterval(systemExitCountdownInterval);
    systemExitCountdownInterval = null;
    updateSystemExitCountdown(0);
    await shutdownServerAndCloseWindow(shutdownPc);
  }, 5000);
}

async function exitSystem() {
  return startSystemExitFlow({ shutdownPc: false });
}

async function powerOffSystem() {
  return startSystemExitFlow({ shutdownPc: true });
}

// Compatibilidad con versiones anteriores: el botón viejo ya no se usa.
async function logoutSystem() {
  return exitSystem();
}


function installModuleFunctionShortcuts() {
  const moduleShortcuts = {
    F1: '/',
    F2: '/ventas',
    F3: '/consulta-precio',
    F4: '/productos',
    F5: '/compras',
    F6: '/configuracion',
  };

  const functionKey = (event) => {
    const key = String(event.key || '').toUpperCase();
    const code = String(event.code || '').toUpperCase();
    if (/^F(?:[1-9]|1[0-2])$/.test(key)) return key;
    if (/^F(?:[1-9]|1[0-2])$/.test(code)) return code;
    return key;
  };

  // Se usa fase bubble (no capture) para que cada módulo procese primero sus
  // teclas propias. Esto es esencial en Venta (F6-F9), modales y búsquedas.
  window.addEventListener('keydown', (event) => {
    if (event.ctrlKey || event.altKey || event.shiftKey || event.metaKey) return;
    if (event.repeat) return;

    const key = functionKey(event);

    if (key === 'F10') {
      event.preventDefault();
      exitSystem();
      return;
    }

    if (key === 'F12') {
      event.preventDefault();
      powerOffSystem();
      return;
    }

    if (window.POS_SETUP_MODE || event.defaultPrevented) return;

    // En Venta estas teclas tienen funciones operativas locales.
    if (window.location.pathname === '/ventas' && ['F6', 'F7', 'F8', 'F9'].includes(key)) return;

    const targetPath = moduleShortcuts[key];
    if (!targetPath) return;

    event.preventDefault();
    const currentPath = window.location.pathname;
    if (currentPath !== targetPath) window.location.href = targetPath;
  }, false);
}

installModuleFunctionShortcuts();


/* Navegación global por teclado
   - Flechas: mover foco entre controles visibles.
   - Enter: activar el control enfocado.
   - Escape: cerrar modal visible si el módulo no lo manejó antes.
   Se ejecuta en fase bubble y respeta los handlers propios de cada módulo
   (venta, precios, selectores, etc.) cuando ya hicieron preventDefault(). */
(function installGlobalArrowNavigation() {
  const NAV_SELECTOR = [
    'a[href]',
    'button:not([disabled])',
    'input:not([disabled]):not([type="hidden"])',
    'select:not([disabled])',
    'textarea:not([disabled])',
    '[tabindex]:not([tabindex="-1"])',
    '[onclick]',
    '.advanced-item',
    '.purchase-search-option',
    '.client-select-option',
    '.select-option',
    '.rank-item',
    '.expiry-item'
  ].join(',');

  const AUTO_TAB_SELECTOR = [
    '[onclick]:not(a):not(button):not(input):not(select):not(textarea)',
    '.advanced-item',
    '.purchase-search-option',
    '.client-select-option',
    '.select-option',
    '.rank-item',
    '.expiry-item'
  ].join(',');

  function isVisible(el) {
    if (!el || el.disabled) return false;
    if (el.closest('.hidden')) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function prepareKeyboardTargets(root = document) {
    root.querySelectorAll(AUTO_TAB_SELECTOR).forEach(el => {
      if (!el.hasAttribute('tabindex')) el.setAttribute('tabindex', '0');
      el.classList.add('keyboard-nav-item');
      if (!el.hasAttribute('role') && !el.matches('button,a,input,select,textarea')) {
        el.setAttribute('role', 'button');
      }
    });
  }

  function getTopVisibleOverlay() {
    const candidates = Array.from(document.querySelectorAll([
      '.modal:not(.hidden)',
      '.sale-client-modal:not(.hidden)',
      '.sale-operation-overlay:not(.hidden)',
      '.system-exit-modal.show:not(.hidden)',
      '#quickProductPanel:not(.hidden)'
    ].join(','))).filter(isVisible);
    return candidates[candidates.length - 1] || null;
  }

  function getNavigationScope() {
    const overlay = getTopVisibleOverlay();
    if (overlay) return overlay;
    return document.querySelector('.app-shell') || document.body;
  }

  function getFocusableElements(scope = getNavigationScope()) {
    prepareKeyboardTargets(scope);
    const items = Array.from(scope.querySelectorAll(NAV_SELECTOR))
      .filter(isVisible)
      .filter(el => !el.matches('[aria-hidden="true"] *'))
      .filter(el => el.tabIndex !== -1);

    // Evita duplicados cuando un elemento matchea varios selectores.
    return Array.from(new Set(items));
  }

  function centerOf(rect) {
    return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
  }

  function distanceScore(fromRect, toRect, direction) {
    const from = centerOf(fromRect);
    const to = centerOf(toRect);
    const dx = to.x - from.x;
    const dy = to.y - from.y;

    const minStep = 2;
    if (direction === 'ArrowDown' && dy < minStep) return Infinity;
    if (direction === 'ArrowUp' && dy > -minStep) return Infinity;
    if (direction === 'ArrowRight' && dx < minStep) return Infinity;
    if (direction === 'ArrowLeft' && dx > -minStep) return Infinity;

    const primary = (direction === 'ArrowDown' || direction === 'ArrowUp') ? Math.abs(dy) : Math.abs(dx);
    const secondary = (direction === 'ArrowDown' || direction === 'ArrowUp') ? Math.abs(dx) : Math.abs(dy);

    // Penaliza mucho los elementos que están lejos del eje natural.
    return primary * 1000 + secondary * 2;
  }

  function moveFocus(direction) {
    const scope = getNavigationScope();
    const items = getFocusableElements(scope);
    if (!items.length) return false;

    const active = document.activeElement;
    if (!items.includes(active)) {
      items[0].focus({ preventScroll: false });
      activeKeyboardMode();
      return true;
    }

    const activeRect = active.getBoundingClientRect();
    let best = null;
    let bestScore = Infinity;

    for (const item of items) {
      if (item === active) continue;
      const score = distanceScore(activeRect, item.getBoundingClientRect(), direction);
      if (score < bestScore) {
        bestScore = score;
        best = item;
      }
    }

    // Si no hay elemento en la dirección solicitada, usa recorrido lineal.
    if (!best || bestScore === Infinity) {
      const index = items.indexOf(active);
      const step = (direction === 'ArrowUp' || direction === 'ArrowLeft') ? -1 : 1;
      const nextIndex = (index + step + items.length) % items.length;
      best = items[nextIndex];
    }

    if (best) {
      best.focus({ preventScroll: false });
      try { best.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (e) {}
      activeKeyboardMode();
      return true;
    }
    return false;
  }

  function activeKeyboardMode() {
    document.body.classList.add('keyboard-nav-active');
  }

  function clickFocusedElement() {
    const el = document.activeElement;
    if (!el || el === document.body || el === document.documentElement) return false;

    if (el.matches('textarea')) return false;
    if (el.matches('input')) {
      const type = String(el.getAttribute('type') || 'text').toLowerCase();
      if (!['button', 'submit', 'checkbox', 'radio'].includes(type)) return false;
    }
    if (el.matches('select')) return false;

    if (typeof el.click === 'function') {
      el.click();
      return true;
    }
    return false;
  }

  function closeVisibleOverlayFallback() {
    const overlay = getTopVisibleOverlay();
    if (!overlay) return false;
    const closeBtn = overlay.querySelector([
      '[data-close]',
      '.round-button',
      '.modal-close',
      '.tiny-button.delete',
      'button[aria-label="Cerrar"]'
    ].join(','));
    if (closeBtn && isVisible(closeBtn)) {
      closeBtn.click();
      return true;
    }
    overlay.classList.add('hidden');
    return true;
  }

  function setInitialFocus() {
    if (document.activeElement && document.activeElement !== document.body) return;
    const main = document.querySelector('.main-content') || document.body;
    const preferred = main.querySelector([
      'input:not([disabled]):not([type="hidden"]):not([readonly])',
      'select:not([disabled])',
      'textarea:not([disabled]):not([readonly])',
      'button:not([disabled])',
      'a[href]'
    ].join(','));
    if (preferred && isVisible(preferred)) {
      preferred.focus({ preventScroll: true });
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    prepareKeyboardTargets(document);
    setTimeout(setInitialFocus, 180);

    const observer = new MutationObserver(mutations => {
      for (const mutation of mutations) {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === 1) prepareKeyboardTargets(node);
        });
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
  });

  document.addEventListener('mousedown', () => document.body.classList.remove('keyboard-nav-active'), true);

  function isTextEditingControl(el) {
    if (!el) return false;
    if (el.matches('textarea')) return true;
    if (!el.matches('input')) return false;
    const type = String(el.getAttribute('type') || 'text').toLowerCase();
    return [
      'text', 'search', 'email', 'url', 'tel', 'password',
      'number', 'date', 'time', 'datetime-local', 'month', 'week'
    ].includes(type);
  }

  function shouldKeepArrowInsideTextField(event) {
    const el = event.target;
    if (!isTextEditingControl(el) || el.readOnly) return false;

    // En campos de texto, las flechas izquierda/derecha deben mover el cursor
    // dentro del texto escrito. Esto permite editar nombres de productos largos
    // sin que la navegación global cambie el foco a otro control.
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') return true;

    // En textarea también se respetan arriba/abajo para navegar por líneas.
    if (el.matches('textarea') && (event.key === 'ArrowUp' || event.key === 'ArrowDown')) return true;

    return false;
  }

  document.addEventListener('keydown', event => {
    if (event.defaultPrevented) return;
    if (event.ctrlKey || event.altKey || event.shiftKey || event.metaKey) return;

    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.key)) {
      if (shouldKeepArrowInsideTextField(event)) return;
      if (moveFocus(event.key)) {
        event.preventDefault();
        event.stopPropagation();
      }
      return;
    }

    if (event.key === 'Enter') {
      if (clickFocusedElement()) {
        event.preventDefault();
        event.stopPropagation();
      }
      return;
    }

    if (event.key === 'Escape') {
      if (closeVisibleOverlayFallback()) {
        event.preventDefault();
        event.stopPropagation();
      }
    }
  });
})();

// Pantalla completa para todos los módulos.
// Cualquier módulo distinto del Panel principal ocupa toda la pantalla del POS.
// Escape vuelve siempre al Panel principal.
(function installFullscreenModuleMode() {
  function activeModuleName() {
    return String(window.POS_ACTIVE_MODULE || '').trim();
  }

  function isFullscreenModule() {
    const active = activeModuleName();
    return Boolean(active && active !== 'dashboard' && !window.POS_SETUP_MODE);
  }

  function goToDashboardFromModule() {
    if (!isFullscreenModule()) return false;
    if (window.location.pathname === '/') return false;
    window.location.href = '/';
    return true;
  }

  function ensureModuleExitButton() {
    if (!isFullscreenModule()) return;
    if (activeModuleName() === 'sales') return; // Venta ya tiene su propio botón Esc Salir.
    if (document.getElementById('moduleFullscreenExitBtn')) return;

    const btn = document.createElement('button');
    btn.id = 'moduleFullscreenExitBtn';
    btn.className = 'module-fullscreen-exit-button module-fullscreen-exit-inline';
    btn.type = 'button';
    btn.innerHTML = '<kbd>Esc</kbd> Panel principal';
    btn.addEventListener('click', goToDashboardFromModule);

    // El botón debe formar parte de la pantalla del módulo, no quedar flotando
    // sobre el contenido. Primero intenta colocarlo dentro del encabezado real
    // del módulo; si no existe, lo deja dentro del contenedor principal.
    const moduleRoot = document.querySelector('.main-content > .module-fit-view') || document.querySelector('.module-fit-view');
    // Buscar también encabezados anidados. En Productos el header vive dentro de
    // .products-content-stack; si el botón se agregaba directo al grid principal,
    // rompía la distribución de pantalla completa.
    const header = moduleRoot?.querySelector(':scope > .page-header, .page-header') || document.querySelector('.main-content > .page-header');
    const actions = header?.querySelector('.header-actions');

    if (actions) {
      actions.appendChild(btn);
    } else if (header) {
      header.appendChild(btn);
    } else if (moduleRoot) {
      moduleRoot.prepend(btn);
    } else {
      document.body.appendChild(btn);
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    if (isFullscreenModule()) {
      document.body.classList.add('module-fullscreen-mode');
      document.body.classList.add(`pos-active-${activeModuleName()}`);
      ensureModuleExitButton();
    }
  });

  window.addEventListener('keydown', event => {
    if (event.key !== 'Escape') return;
    if (event.ctrlKey || event.altKey || event.shiftKey || event.metaKey) return;
    if (!isFullscreenModule()) return;

    // Los módulos y modales reciben Escape primero. Solo volvemos al Panel si
    // ningún control interno ya consumió la tecla.
    if (event.defaultPrevented) return;
    const overlayOpen = Array.from(document.querySelectorAll(
      '.modal:not(.hidden), .sale-client-modal:not(.hidden), .sale-operation-overlay:not(.hidden), #quickProductPanel:not(.hidden), #barcodeScannerModal:not(.hidden)'
    )).some(el => {
      const style = window.getComputedStyle(el);
      return style.display !== 'none' && style.visibility !== 'hidden';
    });
    if (overlayOpen) return;

    event.preventDefault();
    goToDashboardFromModule();
  }, false);
})();

