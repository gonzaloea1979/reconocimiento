from .route_services.money import money, money_product, money_sum, strict_number, normalize_rounding_mode, apply_price_rounding, calculate_prices, get_global_product_rounding
from .route_services.dates import now_iso, format_date_ar, format_datetime_ar, normalize_date
from .route_services.iterators import iter_repeated_items
from datetime import datetime, date, timedelta

import base64
import hashlib
import json

import re

import os

import math

import warnings

from decimal import Decimal, InvalidOperation, ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_UP

import subprocess

import sqlite3

import sys

import threading

import time

from functools import wraps

from io import BytesIO

from uuid import uuid4


from flask import Blueprint, make_response, current_app, g, jsonify, redirect, render_template, request, send_file, session, url_for

from werkzeug.exceptions import RequestEntityTooLarge

from werkzeug.security import check_password_hash, generate_password_hash

from werkzeug.utils import secure_filename


from .db import get_db, get_settings, update_settings, public_settings, backup_database

bp = Blueprint('main', __name__)

ALLOWED_LOGO_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}

ALLOWED_PRODUCT_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}
MAX_IMAGE_UPLOAD_BYTES = 30 * 1024 * 1024
MAX_IMAGE_PIXELS = 40_000_000
MAX_BARCODE_IMAGE_BYTES = 4 * 1024 * 1024

EXCEL_HEADERS = [
    'ID', 'Código de barra', 'Nombre', 'Detalle', 'Precio sin impuestos',
    'IVA %', 'Ingresos brutos %', 'Costo total', 'Margen ganancia %',
    'Precio venta', 'Stock', 'Fecha vencimiento'
]

def stock_control_enabled():
    """Indica si las operaciones deben controlar y actualizar existencias."""
    cache_key = '_pos_stock_control_enabled'
    if not hasattr(g, cache_key):
        raw = str(get_settings().get('stock_control_enabled', '1')).strip().lower()
        setattr(g, cache_key, raw in ('1', 'true', 'on', 'yes', 'si', 'sí'))
    return bool(getattr(g, cache_key))

def rollback_on_db_error(view):
    """Revierte la operación si falla una escritura SQL antes del commit."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        try:
            return view(*args, **kwargs)
        except sqlite3.Error:
            try:
                get_db().rollback()
            except Exception:
                pass
            current_app.logger.exception('Error de base de datos en %s; operación revertida', view.__name__)
            return jsonify({'error': 'No se pudo completar la operación por un error de base de datos. No se guardaron los cambios; intentá nuevamente.'}), 500
        except Exception:
            # También revertir excepciones de lógica inesperadas antes de que
            # Flask genere el 500. Así no queda una transacción abierta en g.
            try:
                get_db().rollback()
            except Exception:
                pass
            current_app.logger.exception('Error inesperado en %s; transacción revertida', view.__name__)
            raise
    return wrapped

def require_json_object(view):
    """Rechaza con 400 un cuerpo JSON que sea válido pero no un objeto.

    Sin esta comprobación, un cuerpo como [] o "texto" llega a ``data.get(...)``
    y termina en un 500 con traza. Los endpoints que aceptan formulario
    (multipart) no se ven afectados porque se omite la validación.
    """
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not (request.files or request.form):
            data = request.get_json(silent=True)
            if not isinstance(data, dict):
                return jsonify({'error': 'El cuerpo de la solicitud debe ser un objeto JSON válido.'}), 400
        return view(*args, **kwargs)
    return wrapped

def commit_operation(db):
    # Cuando existe clave de reintento, la respuesta y los cambios de negocio
    # se confirman juntos en idempotent_operation.
    if not getattr(g, '_pos_idempotent_operation', False):
        db.commit()


def idempotent_operation(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        key = request.headers.get('Idempotency-Key')
        if key is None:
            return view(*args, **kwargs)  # Compatibilidad con clientes anteriores.
        if not re.fullmatch(r'[A-Za-z0-9_-]{16,128}', key):
            return jsonify({'error': 'Identificador de operación inválido'}), 400
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({'error': 'Los datos de la operación deben ser un objeto válido'}), 400
        payload_hash = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':'),
                                                  ensure_ascii=True).encode('utf-8')).hexdigest()
        scope = request.method + ':' + request.path + ':' + current_user_name()
        db = get_db()
        db.execute('BEGIN IMMEDIATE')
        try:
            receipt = db.execute('''SELECT payload_hash, response_json, status_code
                                   FROM operation_receipts WHERE scope=? AND request_key=?''',
                                 (scope, key)).fetchone()
            if receipt:
                db.rollback()
                if receipt['payload_hash'] != payload_hash:
                    return jsonify({'error': 'La operación ya fue confirmada con otros datos. Revisá el registro antes de reintentar.'}), 409
                response = current_app.response_class(receipt['response_json'], status=receipt['status_code'],
                                                      mimetype='application/json')
                response.headers['Idempotency-Replayed'] = 'true'
                return response
            g._pos_idempotent_operation = True
            response = make_response(view(*args, **kwargs))
            if 200 <= response.status_code < 300:
                if not db.in_transaction:
                    raise RuntimeError('La operación se confirmó fuera de su transacción')
                db.execute('''INSERT INTO operation_receipts
                    (scope, request_key, payload_hash, response_json, status_code, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)''',
                    (scope, key, payload_hash, response.get_data(as_text=True), response.status_code, now_iso()))
                db.commit()
            else:
                db.rollback()
            return response
        except Exception:
            db.rollback()
            raise
        finally:
            g._pos_idempotent_operation = False
    return wrapped


def password_matches(raw_password, stored_value):
    raw_password = raw_password or ''
    stored_value = stored_value or ''
    if not stored_value:
        return False
    if stored_value.startswith(('scrypt:', 'pbkdf2:', 'argon2:')):
        try:
            return check_password_hash(stored_value, raw_password)
        except ValueError:
            return False
    # Compatibilidad por si alguna base antigua tenía la clave en texto.
    return raw_password == stored_value

def active_admin_exists():
    try:
        row = get_db().execute(
            "SELECT COUNT(*) AS c FROM users WHERE role='Administrador' AND is_active=1"
        ).fetchone()
        return bool(row and row['c'] > 0)
    except Exception:
        return False

def create_first_admin(username, password):
    stamp = now_iso()
    db = get_db()
    cur = db.execute('''
        INSERT INTO users (username, full_name, role, password_hash, is_active, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        username, 'Administrador', 'Administrador', generate_password_hash(password), 1, stamp, stamp
    ))
    update_settings({
        'login_username': username,
        'default_cashier_name': username,
        'login_password_hash': generate_password_hash(password),
        'admin_password_hash': generate_password_hash(password),
    })
    db.commit()
    return cur.lastrowid

def start_default_admin_session():
    """Inicia la sesión local como el administrador predeterminado, sin contraseña."""
    row = get_db().execute(
        """
        SELECT username FROM users
        WHERE role='Administrador' AND is_active=1
        ORDER BY CASE WHEN LOWER(username)='admin' THEN 0 ELSE 1 END, id
        LIMIT 1
        """
    ).fetchone()
    if not row:
        return False
    session.clear()
    session['logged_in'] = True
    session['authenticated_login'] = False
    session['local_auto_login'] = False
    session['passwordless_admin_login'] = True
    session['username'] = row['username']
    session['user_role'] = 'Administrador'
    return True

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        # La configuración inicial crea un administrador local predeterminado.
        if not active_admin_exists():
            if request.path.startswith('/api/'):
                return jsonify({'error': 'No se encontró un administrador activo.', 'setup_required': True}), 428
            return redirect(url_for('main.first_setup_page'))

        # Inicio local automático como administrador, sin pedir contraseña.
        # También migra cookies de versiones anteriores que eran sesiones de cajero.
        needs_default_admin = (
            not session.get('logged_in')
            or session.get('local_auto_login')
            or (
                not session.get('authenticated_login')
                and not session.get('passwordless_admin_login')
            )
        )
        if needs_default_admin:
            if not start_default_admin_session():
                if request.path.startswith('/api/'):
                    return jsonify({'error': 'No se encontró un administrador activo.'}), 428
                return redirect(url_for('main.first_setup_page'))

        # Volver a validar el rol en cada petición para respetar cambios de usuario.
        if session.get('passwordless_admin_login'):
            row = get_db().execute(
                "SELECT role FROM users WHERE is_active=1 AND role='Administrador' AND LOWER(username)=LOWER(?) LIMIT 1",
                (session.get('username'),)
            ).fetchone()
            if not row:
                if not start_default_admin_session():
                    session.clear()
                    return jsonify({'error': 'No se encontró un administrador activo.'}), 428
                row = get_db().execute(
                    "SELECT role FROM users WHERE is_active=1 AND role='Administrador' AND LOWER(username)=LOWER(?) LIMIT 1",
                    (session.get('username'),)
                ).fetchone()
            session['user_role'] = row['role'] if row else 'Administrador'
        else:
            try:
                row = get_db().execute(
                    """
                    SELECT role FROM users
                    WHERE is_active=1 AND LOWER(username)=LOWER(?)
                    LIMIT 1
                    """,
                    (session.get('username'),)
                ).fetchone()
                session['user_role'] = row['role'] if row else 'Cajero'
            except Exception:
                session['user_role'] = session.get('user_role') or 'Cajero'
        return fn(*args, **kwargs)
    return wrapper

def admin_password_ok(password):
    settings = get_settings()
    return password_matches(password, settings.get('admin_password_hash'))

def current_user_name():
    return session.get('username') or get_settings().get('default_cashier_name') or 'admin'

def current_cashier_display_name():
    """Respeta el nombre de cajero configurado en tickets durante el autoingreso admin."""
    if session.get('passwordless_admin_login'):
        return get_settings().get('default_cashier_name') or current_user_name()
    return current_user_name()

def current_user_row():
    # La sesión passwordless predeterminada se asocia al administrador activo
    # almacenado en la base; las sesiones locales antiguas se migran en login_required.
    if session.get('local_auto_login') and not session.get('authenticated_login'):
        return None
    name = current_user_name()
    try:
        return get_db().execute(
            """
            SELECT * FROM users
            WHERE is_active=1 AND LOWER(username)=LOWER(?)
            LIMIT 1
            """,
            (name,)
        ).fetchone()
    except Exception:
        return None

def current_user_role():
    if session.get('local_auto_login') and not session.get('authenticated_login'):
        return 'Cajero'
    row = current_user_row()
    if row:
        return row['role'] or 'Cajero'
    return session.get('user_role') or 'Cajero'

def current_user_is_admin():
    return current_user_role() == 'Administrador'

def clean_detected_barcode(value):
    raw = str(value or '').strip()
    if not raw:
        return ''
    # Quita caracteres de control que pueden aparecer en algunas lecturas.
    raw = re.sub(r'[\x00-\x1f\x7f]+', '', raw).strip()
    return raw[:128]

def _decode_1d_candidates(result):
    """Extrae los textos que devuelve ``detectAndDecode``.

    El resultado varía entre versiones de OpenCV: puede ser un string, una tupla
    o una tupla con listas internas. Normalizarlo en un solo lugar evita repetir
    el mismo bucle en cada intento de decodificación.
    """
    if isinstance(result, str):
        return [result]
    if not isinstance(result, tuple):
        return []
    candidates = []
    for part in result:
        if isinstance(part, str):
            candidates.append(part)
        elif isinstance(part, (list, tuple)):
            candidates.extend(x for x in part if isinstance(x, str))
    return candidates

def _decode_barcode_frame(cv2, frame):
    """Intenta decodificar un frame (1D, QR y reintento en gris). Devuelve el código o ''."""
    try:
        detector = cv2.barcode_BarcodeDetector()
        result = detector.detectAndDecode(frame)
        for candidate in _decode_1d_candidates(result):
            code = clean_detected_barcode(candidate)
            if code:
                return code
    except Exception:
        pass

    # QR como apoyo adicional.
    try:
        qr_detector = cv2.QRCodeDetector()
        qr_code, _points, _straight = qr_detector.detectAndDecode(frame)
        qr_code = clean_detected_barcode(qr_code)
        if qr_code:
            return qr_code
    except Exception:
        pass

    # Segundo intento con escala de grises y contraste suave.
    try:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.equalizeHist(gray)
        detector = cv2.barcode_BarcodeDetector()
        result = detector.detectAndDecode(cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR))
        for candidate in _decode_1d_candidates(result):
            code = clean_detected_barcode(candidate)
            if code:
                return code
    except Exception:
        pass

    return ''

def decode_barcode_image_bytes(raw_bytes):
    """Decodifica un frame enviado desde el navegador.

    Usa OpenCV si está instalado. Se mantiene dentro de la app local para que el
    lector funcione aun cuando el navegador no soporte BarcodeDetector.
    """
    if not raw_bytes:
        return '', 'No llegó imagen para decodificar.'
    try:
        import numpy as np
        import cv2
    except Exception:
        return '', 'Instalá opencv-python para activar el respaldo local por servidor.'

    try:
        data = np.frombuffer(raw_bytes, dtype=np.uint8)
        frame = cv2.imdecode(data, cv2.IMREAD_COLOR)
        if frame is None:
            return '', 'No se pudo leer la imagen enviada por la cámara.'
        return _decode_barcode_frame(cv2, frame), ''
    except Exception as exc:
        return '', f'Error al decodificar la imagen: {exc}'

def product_to_dict(row):
    """Serializa un producto evitando conversiones y lecturas repetidas por fila."""
    row_keys = row.keys() if hasattr(row, 'keys') else ()
    has_rounding_mode = 'rounding_mode' in row_keys
    has_rounding_multiple = 'rounding_multiple' in row_keys
    has_min_stock = 'min_stock' in row_keys
    has_supplier_id = 'supplier_id' in row_keys

    try:
        photo_path = row['photo_path'] or ''
    except Exception:
        photo_path = ''

    # Reutilizar valores ya normalizados evita repetir Decimal/quantize
    # en el cálculo de low_stock para cada uno de los 200-300 productos.
    stock = money(row['stock'])
    min_stock = money(row['min_stock']) if has_min_stock else 0
    expiry_date = row['expiry_date'] or ''
    low_stock = stock_control_enabled() and stock <= min_stock and min_stock > 0

    return {
        'id': row['id'],
        'barcode': row['barcode'] or '',
        'name': row['name'],
        'detail': row['detail'] or '',
        'cost_without_tax': money(row['cost_without_tax']),
        'iva_percent': money(row['iva_percent']),
        'gross_income_percent': money(row['gross_income_percent']),
        'total_cost': money(row['total_cost']),
        'margin_percent': money(row['margin_percent']),
        'rounding_mode': row['rounding_mode'] if has_rounding_mode else 'none',
        'rounding_multiple': money(row['rounding_multiple']) if has_rounding_multiple else 1,
        'sale_price': money(row['sale_price']),
        'stock': stock,
        'min_stock': min_stock,
        'supplier_id': row['supplier_id'] if has_supplier_id else None,
        'low_stock': low_stock,
        'expiry_date': expiry_date,
        'expiry_date_formatted': format_date_ar(expiry_date),
        'photo_path': photo_path,
        'photo_url': url_for('static', filename=photo_path) if photo_path else '',
    }

def settings_response():
    settings = public_settings(get_settings())
    logo_path = settings.get('logo_path') or ''
    settings['logo_url'] = url_for('static', filename=logo_path) if logo_path else ''
    return settings

def _close_dedicated_browser_window(base_dir=None):
    """Intenta cerrar solo la ventana dedicada del POS abierta por run.py."""
    try:
        if base_dir is None:
            base_dir = current_app.config.get('BASE_DIR') or os.path.abspath(os.path.join(current_app.root_path, os.pardir))
        pid_file = os.path.join(str(base_dir), 'logs', 'browser_pid.txt')
        if not os.path.exists(pid_file):
            return
        raw_pid = open(pid_file, 'r', encoding='utf-8').read().strip()
        if not raw_pid.isdigit():
            return
        pid = int(raw_pid)
        if os.name == 'nt':
            subprocess.run(['taskkill', '/PID', str(pid), '/T', '/F'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            try:
                os.kill(pid, 15)
            except Exception:
                pass
    except Exception:
        pass

def _shutdown_pc():
    """Apaga la computadora cuando el usuario lo solicita con F12."""
    try:
        if os.name == 'nt':
            subprocess.Popen(['shutdown', '/s', '/f', '/t', '0'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif sys.platform == 'darwin':
            subprocess.Popen(['osascript', '-e', 'tell app "System Events" to shut down'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            # En Linux puede requerir permisos de administrador según la distribución.
            subprocess.Popen(['shutdown', '-h', 'now'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass

def logo_extension(filename):
    if not filename or '.' not in filename:
        return ''
    ext = filename.rsplit('.', 1)[1].lower()
    return ext if ext in ALLOWED_LOGO_EXTENSIONS else ''

def product_image_extension(filename):
    if not filename or '.' not in filename:
        return ''
    ext = filename.rsplit('.', 1)[1].lower()
    return ext if ext in ALLOWED_PRODUCT_IMAGE_EXTENSIONS else ''

def _validate_uploaded_file_size(file_storage, max_bytes=MAX_IMAGE_UPLOAD_BYTES):
    """Mide el archivo sin cargarlo completo en RAM y rechaza cargas excesivas."""
    stream = getattr(file_storage, 'stream', None)
    size = None
    if stream is not None:
        try:
            position = stream.tell()
            stream.seek(0, os.SEEK_END)
            size = stream.tell()
            stream.seek(position, os.SEEK_SET)
        except (AttributeError, OSError, ValueError):
            size = None
    if size is None:
        size = getattr(file_storage, 'content_length', None)
    if size is None or int(size) <= 0:
        raise ValueError('El archivo está vacío o no se pudo verificar su tamaño.')
    if int(size) > int(max_bytes):
        raise ValueError('La imagen supera el límite permitido de 30 MB.')
    return int(size)


def save_uploaded_image(file_storage, prefix, allowed_ext_func, error_message, max_pixels=1200):
    """Guarda una imagen local y la optimiza para evitar archivos enormes.

    Acepta fotos grandes tomadas desde celular. Para PNG/JPG/JPEG/WEBP intenta
    redimensionar y comprimir; para GIF conserva el archivo original.
    """
    if not file_storage or not file_storage.filename:
        return ''
    ext = allowed_ext_func(file_storage.filename)
    if not ext:
        raise ValueError(error_message)
    _validate_uploaded_file_size(file_storage)

    upload_dir = current_app.config['UPLOAD_DIR']
    upload_dir.mkdir(parents=True, exist_ok=True)

    try:
        from PIL import Image
    except ImportError:
        Image = None

    # GIF animado de productos: se guarda sin procesar para no romper la animación.
    # En logos conviene convertir incluso GIF/WEBP/JPG a PNG para que el ticket
    # PDF los inserte con mejor calidad y con transparencia cuando exista.
    if Image is None:
        # Pillow es dependencia del paquete, pero se conserva el fallback de
        # instalaciones mínimas; el límite de bytes sigue siendo obligatorio.
        filename = secure_filename(f'{prefix}_{uuid4().hex}.{ext}')
        file_storage.save(upload_dir / filename)
        return f'uploads/{filename}'

    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(file_storage.stream) as source_image:
                expected_formats = {
                    'jpg': {'JPEG'}, 'jpeg': {'JPEG'}, 'png': {'PNG'},
                    'webp': {'WEBP'}, 'gif': {'GIF'},
                }
                if source_image.format not in expected_formats.get(ext, set()):
                    raise ValueError('El contenido real de la imagen no coincide con su extensión.')
                width, height = source_image.size
                if width <= 0 or height <= 0 or width * height > MAX_IMAGE_PIXELS:
                    raise ValueError('La imagen tiene dimensiones superiores al límite permitido.')
                # GIF animado de productos: verificar y conservar el original
                # antes de decodificar el primer frame para no perder animación.
                if ext == 'gif' and prefix != 'logo':
                    source_image.verify()
                    file_storage.stream.seek(0)
                    filename = secure_filename(f'{prefix}_{uuid4().hex}.{ext}')
                    file_storage.save(upload_dir / filename)
                    return f'uploads/{filename}'

                # Fuerza la decodificación para detectar archivos truncados o corruptos.
                source_image.load()
                source_image.thumbnail((max_pixels, max_pixels), Image.LANCZOS)

                # Los logos se guardan en PNG para conservar transparencia.
                if prefix == 'logo':
                    filename = secure_filename(f'{prefix}_{uuid4().hex}.png')
                    output_path = upload_dir / filename
                    output_image = source_image if source_image.mode in ('RGBA', 'LA') else source_image.convert('RGBA')
                    try:
                        output_image.save(output_path, format='PNG', optimize=True)
                    finally:
                        if output_image is not source_image:
                            output_image.close()
                    return f'uploads/{filename}'

                filename = secure_filename(f'{prefix}_{uuid4().hex}.jpg')
                output_path = upload_dir / filename
                output_image = source_image if source_image.mode in ('RGB', 'L') else source_image.convert('RGB')
                try:
                    output_image.save(output_path, format='JPEG', quality=86, optimize=True)
                finally:
                    if output_image is not source_image:
                        output_image.close()
                return f'uploads/{filename}'
    except ValueError:
        raise
    except (OSError, SyntaxError, Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
        raise ValueError('La imagen está dañada o supera los límites de procesamiento.') from exc

def save_logo_image(file_storage):
    return save_uploaded_image(
        file_storage,
        'logo',
        logo_extension,
        'El logo debe ser PNG, JPG, JPEG, WEBP o GIF',
        max_pixels=1400,
    )

def save_product_photo(file_storage):
    return save_uploaded_image(
        file_storage,
        'producto',
        product_image_extension,
        'La foto del producto debe ser PNG, JPG, JPEG, WEBP o GIF',
        max_pixels=1200,
    )

def product_payload():
    if request.files or request.form:
        return request.form
    return request.get_json(force=True)

def text_field(value, default=''):
    """Normaliza un campo de texto y rechaza tipos que no sean texto.

    Antes, un número o una lista llegaban a ``.strip()`` y provocaban un 500 con
    traza. Ahora un valor no textual se traduce en ValueError, que el endpoint
    convierte en 400 con un mensaje claro.
    """
    if value is None:
        return default
    if isinstance(value, str):
        return value.strip()
    raise ValueError('El valor de texto no es válido')

def non_negative_amount(value, label):
    """Convierte un importe y rechaza valores negativos.

    Las compras ya validaban sus importes; los productos no, y permitían guardar
    un costo negativo que producía un precio de venta negativo imposible de vender.
    """
    number = strict_number(value, label, default=0)
    if number < 0:
        raise ValueError(f'{label}: no puede ser negativo')
    return number

def percent_amount(value, label):
    """Convierte un porcentaje y lo limita al rango 0-100."""
    number = strict_number(value, label, default=0)
    if number < 0:
        raise ValueError(f'{label}: no puede ser negativo')
    if number > 100:
        raise ValueError(f'{label}: no puede superar 100')
    return number

LIKE_ESCAPE = '\\'

def like_contains(value):
    """Patrón LIKE 'contiene' con comodines escapados.

    Sin escapar, un término como '50%' o 'a_b' se interpreta como comodín y
    devuelve resultados que no coinciden con el texto buscado. El patrón debe
    usarse junto a ``ESCAPE '\\'`` en la consulta.
    """
    return '%' + escape_like_value(value) + '%'

def like_prefix(value):
    """Patrón LIKE 'empieza con' con comodines escapados."""
    return escape_like_value(value) + '%'

def escape_like_value(value):
    text = str(value)
    for char in (LIKE_ESCAPE, '%', '_'):
        text = text.replace(char, LIKE_ESCAPE + char)
    return text

def user_to_dict(row):
    return {
        'id': row['id'],
        'username': row['username'],
        'full_name': row['full_name'] or '',
        'role': row['role'] or 'Cajero',
        'is_active': bool(row['is_active']),
        'created_at': row['created_at'] or '',
        'updated_at': row['updated_at'] or '',
    }

def require_security_password_from_payload(data):
    # Administrador activo: no se solicita contraseña para modificaciones.
    # Otros usuarios deben ingresar la clave de seguridad.
    if current_user_is_admin():
        return True
    # Un valor no textual (número/lista) no es una contraseña válida: se rechaza
    # sin romper con 500 al llamar a .strip().
    raw_password = data.get('security_password')
    if raw_password is None:
        raw_password = data.get('password')
    password = raw_password.strip() if isinstance(raw_password, str) else ''
    if not admin_password_ok(password):
        return False
    return True

def log_audit(action, module='', detail=''):
    try:
        get_db().execute(
            'INSERT INTO audit_logs (user_name, action, module, detail, created_at) VALUES (?, ?, ?, ?, ?)',
            (current_user_name(), str(action)[:120], str(module)[:80], str(detail)[:500], now_iso())
        )
    except Exception:
        pass

def active_cash_session():
    return get_db().execute(
        "SELECT * FROM cash_sessions WHERE status='abierta' ORDER BY id DESC LIMIT 1"
    ).fetchone()

def add_cash_movement(movement_type, amount, description='', payment_method='Efectivo', sale_id=None, cash_session_id=None):
    db = get_db()
    # Compartir el bloqueo con el cierre hasta el commit del llamador.
    if not db.in_transaction:
        db.execute('BEGIN IMMEDIATE')
    if cash_session_id:
        session_row = db.execute("SELECT * FROM cash_sessions WHERE id=? AND status='abierta'", (cash_session_id,)).fetchone()
        if not session_row:
            raise ValueError('La caja indicada ya no está abierta')
    else:
        session_row = active_cash_session()
    session_id = session_row['id'] if session_row else None
    db.execute('''
        INSERT INTO cash_movements (cash_session_id, movement_type, amount, description, payment_method, sale_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (session_id, movement_type, money(amount), description, payment_method, sale_id, now_iso()))
    return session_id

def stock_movement(product, movement_type, qty, previous_stock, new_stock, reference='', notes=''):
    # No ocultar fallas: el llamador revierte la transacción para que el stock
    # y su historial nunca queden desincronizados.
    get_db().execute('''
        INSERT INTO product_movements (product_id, product_name, movement_type, quantity, previous_stock, new_stock, reference, notes, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (product['id'], product['name'], movement_type, money(qty), money(previous_stock), money(new_stock), reference, notes, now_iso()))

def excel_text(value):
    if value is None:
        return ''
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()

def excel_number(value):
    if value is None or value == '':
        return 0.0
    if isinstance(value, (int, float)):
        return strict_number(value, 'Valor numérico de Excel')
    raw = str(value).strip().replace('$', '').replace(' ', '')
    # Permite formato argentino 1.234,56 y formato simple 1234.56.
    if ',' in raw and '.' in raw:
        raw = raw.replace('.', '').replace(',', '.')
    elif ',' in raw:
        raw = raw.replace(',', '.')
    elif '.' in raw:
        parts = raw.split('.')
        if len(parts) > 1 and all(len(part) == 3 for part in parts[1:]):
            raw = ''.join(parts)
    return strict_number(raw, 'Valor numérico de Excel')

def read_xls_date(book, sheet, row_index, col_index):
    import xlrd

    if col_index is None or col_index >= sheet.ncols:
        return None
    cell = sheet.cell(row_index, col_index)
    value = cell.value
    if value in ('', None):
        return None
    if cell.ctype == xlrd.XL_CELL_DATE:
        try:
            return xlrd.xldate_as_datetime(value, book.datemode).date().isoformat()
        except Exception:
            pass
    if isinstance(value, float) and value.is_integer() and value > 20000:
        try:
            return xlrd.xldate_as_datetime(value, book.datemode).date().isoformat()
        except Exception:
            pass
    return normalize_date(str(value).strip())

def write_xls_products(rows):
    import xlwt

    workbook = xlwt.Workbook(encoding='utf-8')
    sheet = workbook.add_sheet('Lista de precios')

    title_style = xlwt.easyxf(
        'font: bold on, colour white, height 320;'
        'pattern: pattern solid, fore_colour ocean_blue;'
        'alignment: horiz center, vert center;'
    )
    header_style = xlwt.easyxf(
        'font: bold on, colour white;'
        'pattern: pattern solid, fore_colour dark_blue;'
        'alignment: horiz center, vert center;'
        'borders: left thin, right thin, top thin, bottom thin;'
    )
    text_style = xlwt.easyxf('borders: left thin, right thin, top thin, bottom thin; alignment: vert center;')
    money_style = xlwt.easyxf('borders: left thin, right thin, top thin, bottom thin; alignment: vert center;', num_format_str='$ #,##0.00')
    percent_style = xlwt.easyxf('borders: left thin, right thin, top thin, bottom thin; alignment: vert center;', num_format_str='0.00')
    number_style = xlwt.easyxf('borders: left thin, right thin, top thin, bottom thin; alignment: vert center;', num_format_str='0.00')
    date_style = xlwt.easyxf('borders: left thin, right thin, top thin, bottom thin; alignment: vert center;', num_format_str='DD/MM/YYYY')

    sheet.write_merge(0, 0, 0, len(EXCEL_HEADERS)-1, 'LISTA DE PRECIOS - POS LOCAL', title_style)
    sheet.write_merge(1, 1, 0, len(EXCEL_HEADERS)-1, 'No cambies el nombre de las columnas. Para actualizar, editá precios y volvé a importar este archivo.', text_style)

    widths = [10, 22, 34, 40, 18, 12, 18, 18, 18, 18, 12, 18]
    for idx, width in enumerate(widths):
        sheet.col(idx).width = int(width * 256)

    header_row = 3
    for col, header in enumerate(EXCEL_HEADERS):
        sheet.write(header_row, col, header, header_style)

    for r_idx, row in enumerate(rows, start=header_row + 1):
        product = product_to_dict(row)
        values = [
            product['id'], product['barcode'], product['name'], product['detail'],
            product['cost_without_tax'], product['iva_percent'], product['gross_income_percent'],
            product['total_cost'], product['margin_percent'], product['sale_price'], product['stock'],
            product['expiry_date']
        ]
        for c_idx, value in enumerate(values):
            if c_idx in (4, 7, 9):
                sheet.write(r_idx, c_idx, value, money_style)
            elif c_idx in (5, 6, 8):
                sheet.write(r_idx, c_idx, value, percent_style)
            elif c_idx == 10:
                sheet.write(r_idx, c_idx, value, number_style)
            elif c_idx == 11:
                if value:
                    try:
                        sheet.write(r_idx, c_idx, datetime.strptime(value, '%Y-%m-%d'), date_style)
                    except Exception:
                        sheet.write(r_idx, c_idx, format_date_ar(value), text_style)
                else:
                    sheet.write(r_idx, c_idx, '', text_style)
            else:
                sheet.write(r_idx, c_idx, value, text_style)

    out = BytesIO()
    workbook.save(out)
    out.seek(0)
    return out

def ar_currency(value):
    try:
        value = float(value or 0)
    except (TypeError, ValueError):
        value = 0.0
    formatted = f"$ {value:,.2f}"
    return formatted.replace(',', 'X').replace('.', ',').replace('X', '.')

def safe_pdf_text(value):
    return str(value or '').replace('\n', ' ').strip()

def sale_pdf_filename(sale_id):
    return f"ticket_T-{int(sale_id):06d}.pdf"

def fetch_sale_for_ticket(sale_id):
    db = get_db()
    sale = db.execute('''
        SELECT s.*, COALESCE(c.name, '') AS client_name
        FROM sales s
        LEFT JOIN clients c ON c.id = s.client_id
        WHERE s.id=?
    ''', (sale_id,)).fetchone()
    if not sale:
        return None, []
    items = db.execute('''
        SELECT product_id, product_name, unit_price, quantity, line_total
        FROM sale_items
        WHERE sale_id=?
        ORDER BY id ASC
    ''', (sale_id,)).fetchall()
    return sale, items

def ticket_flag(settings, key, default='1'):
    return str(settings.get(key, default)).lower() in ('1', 'true', 'on', 'yes', 'si', 'sí')

def ticket_number_value(settings, key, default, min_value, max_value):
    try:
        value = float(str(settings.get(key, default)).replace(',', '.'))
    except (TypeError, ValueError):
        value = float(default)
    return max(min_value, min(max_value, value))

def ticket_page_size(settings):
    from reportlab.lib.pagesizes import A5
    from reportlab.lib.units import mm

    size = (settings.get('ticket_pdf_size') or 'A5').strip()
    if size == '80mm':
        return 80 * mm, 210 * mm, '80mm'
    if size == '58mm':
        return 58 * mm, 210 * mm, '58mm'
    return A5[0], A5[1], 'A5'

def ticket_font_multiplier(settings):
    scale = (settings.get('ticket_font_scale') or 'normal').lower()
    if scale == 'chico':
        return 0.88
    if scale == 'grande':
        return 1.14
    return 1.0

def ticket_accent(settings):
    from reportlab.lib import colors

    raw = (settings.get('ticket_accent_color') or '#0F172A').strip()
    try:
        return colors.HexColor(raw)
    except Exception:
        return colors.HexColor('#0F172A')

def draw_qr_on_pdf(canvas_obj, value, x, y, size):
    from reportlab.graphics.barcode import qr
    from reportlab.graphics.shapes import Drawing
    from reportlab.graphics import renderPDF

    if not value:
        return False
    try:
        qr_widget = qr.QrCodeWidget(value)
        bounds = qr_widget.getBounds()
        qr_width = bounds[2] - bounds[0]
        qr_height = bounds[3] - bounds[1]
        drawing = Drawing(size, size, transform=[size / qr_width, 0, 0, size / qr_height, 0, 0])
        drawing.add(qr_widget)
        renderPDF.draw(drawing, canvas_obj, x, y)
        return True
    except Exception:
        return False

def ticket_qr_value(settings):
    value = (settings.get('ticket_qr_value') or '').strip()
    if value:
        return value
    phone = ''.join(ch for ch in (settings.get('business_phone') or '') if ch.isdigit())
    if phone:
        # Si el comercio cargó teléfono, el QR abre WhatsApp o queda como número simple si no corresponde.
        return f'https://wa.me/{phone}'
    return ''

def build_a5_ticket_pdf(sale_id):
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas
    from reportlab.lib.utils import ImageReader

    """Genera el PDF del ticket según la configuración elegida en el módulo Configuración > Diseño ticket."""
    sale, items = fetch_sale_for_ticket(sale_id)
    if not sale:
        raise ValueError('Venta no encontrada')

    settings = public_settings(get_settings())
    ticket_dir = current_app.config['TICKET_DIR']
    ticket_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = ticket_dir / sale_pdf_filename(sale_id)

    width, height, page_mode = ticket_page_size(settings)
    design = (settings.get('ticket_design') or 'moderno').lower()
    font_mul = ticket_font_multiplier(settings)
    margin_mm = ticket_number_value(settings, 'ticket_margin_mm', 12 if page_mode == 'A5' else 5, 3, 18)
    if page_mode in ('80mm', '58mm'):
        margin_mm = min(margin_mm, 6)
    margin = margin_mm * mm
    accent = ticket_accent(settings)

    c = canvas.Canvas(str(pdf_path), pagesize=(width, height))
    y = height - margin
    page_bottom = margin
    line_h = (5.2 if design != 'compacto' else 4.4) * mm * font_mul

    def fs(size):
        return max(5, round(size * font_mul, 1))

    def draw_center(text_value, y_pos, font='Helvetica', size=10, bold=False):
        c.setFont('Helvetica-Bold' if bold else font, fs(size))
        c.drawCentredString(width / 2, y_pos, safe_pdf_text(text_value))

    def draw_left(text_value, y_pos, x=None, font='Helvetica', size=8, bold=False):
        c.setFont('Helvetica-Bold' if bold else font, fs(size))
        c.drawString(x if x is not None else margin, y_pos, safe_pdf_text(text_value))

    def draw_right(text_value, y_pos, x=None, font='Helvetica', size=8, bold=False):
        c.setFont('Helvetica-Bold' if bold else font, fs(size))
        c.drawRightString(x or (width - margin), y_pos, safe_pdf_text(text_value))

    def new_page_if_needed(required=22*mm):
        nonlocal y
        if y - required < page_bottom:
            c.showPage()
            y = height - margin
            draw_center(f"Ticket T-{sale_id:06d} - continuación", y, size=8, bold=True)
            y -= 8 * mm

    def draw_separator(offset=0):
        c.setStrokeColor(colors.HexColor('#D1D5DB'))
        c.line(margin, y + offset, width - margin, y + offset)
        c.setStrokeColor(colors.black)

    narrow = page_mode in ('80mm', '58mm')
    logo_path = settings.get('logo_path') or ''
    if ticket_flag(settings, 'ticket_show_logo') and logo_path:
        candidate = current_app.root_path + '/static/' + logo_path.replace('\\', '/')
        if os.path.exists(candidate):
            try:
                logo_limit = ticket_number_value(settings, 'ticket_logo_size_mm', 22, 8, 45) * mm
                if narrow:
                    logo_limit = min(logo_limit, 22 * mm)

                img_reader = ImageReader(candidate)
                img_w_px, img_h_px = img_reader.getSize()
                if img_w_px > 0 and img_h_px > 0:
                    aspect = img_w_px / img_h_px
                    max_h = logo_limit
                    max_w = min(width - (2 * margin), logo_limit * (2.85 if not narrow else 2.15))
                    draw_w = max_w
                    draw_h = draw_w / aspect
                    if draw_h > max_h:
                        draw_h = max_h
                        draw_w = draw_h * aspect

                    x_logo = (width - draw_w) / 2
                    c.drawImage(img_reader, x_logo, y - draw_h, width=draw_w, height=draw_h, mask='auto')
                    y -= draw_h + (2 if narrow else 3) * mm
            except Exception:
                pass

    if ticket_flag(settings, 'ticket_show_business_name'):
        draw_center(settings.get('business_name') or 'POS Local', y, size=14 if narrow else 16, bold=True)
        y -= (5 if narrow else 6) * mm
    if ticket_flag(settings, 'ticket_show_cuit') and settings.get('business_cuit'):
        draw_center(f"CUIT: {settings.get('business_cuit')}", y, size=7 if narrow else 8)
        y -= (3.5 if narrow else 4) * mm
    if ticket_flag(settings, 'ticket_show_address') and settings.get('business_address'):
        draw_center(settings.get('business_address'), y, size=7 if narrow else 8)
        y -= (3.5 if narrow else 4) * mm
    if ticket_flag(settings, 'ticket_show_phone') and settings.get('business_phone'):
        draw_center(f"Tel: {settings.get('business_phone')}", y, size=7 if narrow else 8)
        y -= (3.5 if narrow else 4) * mm
    if ticket_flag(settings, 'ticket_show_email') and settings.get('business_email'):
        draw_center(settings.get('business_email'), y, size=7 if narrow else 8)
        y -= (3.5 if narrow else 4) * mm

    y -= (2 if narrow else 3) * mm
    draw_separator()
    y -= (5 if narrow else 7) * mm

    ticket_title = settings.get('ticket_title') or 'TICKET DE COMPRA'
    draw_center(ticket_title, y, size=10 if narrow else 13, bold=True)
    y -= (5 if narrow else 6) * mm
    draw_left('N°:', y, size=7 if narrow else 8, bold=True)
    draw_left(f"T-{sale_id:06d}", y, x=margin+(8 if narrow else 12)*mm, size=7 if narrow else 8)
    draw_right(format_datetime_ar(sale['created_at']), y, size=7 if narrow else 8)
    y -= (4 if narrow else 5) * mm
    if ticket_flag(settings, 'ticket_show_cashier'):
        draw_left('Cajero:', y, size=7 if narrow else 8, bold=True)
        draw_left(sale['cashier_name'] if 'cashier_name' in sale.keys() and sale['cashier_name'] else session.get('username', 'admin'), y, x=margin+(13 if narrow else 17)*mm, size=7 if narrow else 8)
        y -= (4 if narrow else 5) * mm
    if ticket_flag(settings, 'ticket_show_payment'):
        draw_left('Pago:', y, size=7 if narrow else 8, bold=True)
        draw_left(sale['payment_method'], y, x=margin+(10 if narrow else 16)*mm, size=7 if narrow else 8)
        y -= (4 if narrow else 5) * mm

    client_name = sale['client_name'] if 'client_name' in sale.keys() and sale['client_name'] else 'Consumidor final'
    draw_left('Cliente:', y, size=7 if narrow else 8, bold=True)
    draw_left(client_name, y, x=margin+(14 if narrow else 18)*mm, size=7 if narrow else 8)
    y -= (5 if narrow else 7) * mm

    header_h = (6 if narrow else 7) * mm
    if design == 'moderno':
        c.setFillColor(colors.HexColor('#F3F4F6'))
        c.roundRect(margin, y-header_h+1*mm, width-2*margin, header_h, 1.5*mm, fill=1, stroke=0)
        c.setFillColor(colors.black)
    else:
        draw_separator(offset=-1*mm)

    if narrow:
        qty_x = width - margin - 24*mm
        unit_x = width - margin - 12*mm
        total_x = width - margin
        draw_left('Producto', y-3*mm, size=7, bold=True)
        draw_right('Cant', y-3*mm, x=qty_x, size=7, bold=True)
        draw_right('Total', y-3*mm, x=total_x, size=7, bold=True)
    else:
        qty_x = width - 57*mm
        unit_x = width - 31*mm
        total_x = width - margin
        draw_left('Producto', y-2.8*mm, size=8, bold=True)
        draw_right('Cant.', y-2.8*mm, x=qty_x, size=8, bold=True)
        draw_right('Unit.', y-2.8*mm, x=unit_x, size=8, bold=True)
        draw_right('Total', y-2.8*mm, x=total_x, size=8, bold=True)
    y -= (8 if narrow else 10) * mm

    def wrap_pdf_text(text_value, max_width, font_name='Helvetica', font_size=8):
        """Divide el texto en todas las líneas necesarias sin cortar el nombre del producto."""
        text_value = safe_pdf_text(text_value)
        if not text_value:
            return ['']

        lines = []
        current_line = ''

        for word in text_value.split():
            candidate = word if not current_line else f"{current_line} {word}"
            if c.stringWidth(candidate, font_name, font_size) <= max_width:
                current_line = candidate
                continue

            if current_line:
                lines.append(current_line)
                current_line = ''

            # Si una palabra sola es demasiado larga, se parte por caracteres
            # para que tampoco se pierda información del producto.
            if c.stringWidth(word, font_name, font_size) <= max_width:
                current_line = word
            else:
                chunk = ''
                for char in word:
                    test_chunk = f"{chunk}{char}"
                    if not chunk or c.stringWidth(test_chunk, font_name, font_size) <= max_width:
                        chunk = test_chunk
                    else:
                        lines.append(chunk)
                        chunk = char
                current_line = chunk

        if current_line:
            lines.append(current_line)

        return lines or ['']

    for item in items:
        product_font_size = fs(7 if narrow else 8)
        product_col_width = max(18*mm, qty_x - margin - (3*mm if narrow else 4*mm))
        name_lines = wrap_pdf_text(item['product_name'], product_col_width, 'Helvetica', product_font_size)
        required_height = max(line_h, len(name_lines) * line_h) + 2*mm
        new_page_if_needed(required_height + (2*mm if len(name_lines) > 1 else 0))

        qty = float(item['quantity'] or 0)
        qty_txt = str(int(qty)) if qty.is_integer() else f"{qty:.2f}".replace('.', ',')

        # Primera línea: nombre + cantidades/importes.
        draw_left(name_lines[0], y, size=7 if narrow else 8)
        draw_right(qty_txt, y, x=qty_x, size=7 if narrow else 8)
        if not narrow:
            draw_right(ar_currency(item['unit_price']), y, x=unit_x, size=8)
        draw_right(ar_currency(item['line_total']), y, x=total_x, size=7 if narrow else 8, bold=True)
        y -= line_h

        # Líneas siguientes: continúan el nombre completo del producto.
        for extra_line in name_lines[1:]:
            new_page_if_needed(line_h + 2*mm)
            draw_left(extra_line, y, size=7 if narrow else 8)
            y -= line_h

        if len(name_lines) > 1:
            y -= 1*mm

    y -= 2 * mm
    new_page_if_needed(38*mm if not narrow else 32*mm)
    draw_separator()
    y -= (6 if narrow else 7) * mm

    if ticket_flag(settings, 'ticket_show_received_change'):
        draw_left('Recibido', y, size=8 if narrow else 9)
        draw_right(ar_currency(sale['amount_received']), y, size=8 if narrow else 9)
        y -= (4.5 if narrow else 5) * mm
        draw_left('Vuelto', y, size=8 if narrow else 9)
        draw_right(ar_currency(sale['change_amount']), y, size=8 if narrow else 9)
        y -= (6 if narrow else 8) * mm

    total_box_h = (12 if narrow else 14) * mm
    if design == 'clasico':
        c.setFillColor(colors.black)
        draw_left('TOTAL', y-7*mm, x=margin, size=10 if narrow else 11, bold=True)
        draw_right(ar_currency(sale['total']), y-7.5*mm, x=width-margin, size=14 if narrow else 16, bold=True)
        y -= total_box_h + 4 * mm
    else:
        c.setFillColor(accent)
        c.roundRect(margin, y-total_box_h+2*mm, width-2*margin, total_box_h, 2*mm, fill=1, stroke=0)
        c.setFillColor(colors.white)
        draw_left('TOTAL', y-7.5*mm, x=margin+3*mm, size=9 if narrow else 11, bold=True)
        draw_right(ar_currency(sale['total']), y-8*mm, x=width-margin-3*mm, size=14 if narrow else 16, bold=True)
        y -= total_box_h + 5 * mm

    c.setFillColor(colors.black)

    qr_value = ticket_qr_value(settings)
    if ticket_flag(settings, 'ticket_show_qr', '0') and qr_value:
        qr_size = (20 if narrow else 24) * mm
        new_page_if_needed(qr_size + (13 if narrow else 15) * mm)
        x_qr = (width - qr_size) / 2
        if draw_qr_on_pdf(c, qr_value, x_qr, y - qr_size, qr_size):
            y -= qr_size + (3 if narrow else 4) * mm
            label = settings.get('ticket_qr_label') or 'Escaneá para contactarnos'
            draw_center(label, y, size=6.5 if narrow else 7.5)
            y -= (5 if narrow else 6) * mm

    if ticket_flag(settings, 'ticket_show_footer'):
        footer = settings.get('ticket_footer') or 'Gracias por su compra'
        draw_center(footer, max(y, page_bottom + 5*mm), size=7 if narrow else 8)
    c.save()
    return pdf_path

def print_pdf_file(pdf_path):
    path = str(pdf_path)
    if os.name == 'nt':
        try:
            os.startfile(path, 'print')  # type: ignore[attr-defined]
            return True, 'Enviado a la impresora predeterminada de Windows.'
        except Exception as exc:
            return False, f'No se pudo imprimir automáticamente: {exc}'
    try:
        subprocess.Popen(['lp', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True, 'Enviado a impresión con lp.'
    except Exception as exc:
        return False, f'PDF guardado, pero la impresión automática no está disponible en este sistema: {exc}'

def supplier_to_dict(row):
    return {
        'id': row['id'], 'name': row['name'], 'cuit': row['cuit'] or '',
        'phone': row['phone'] or '', 'address': row['address'] or '',
        'category': row['category'] or '', 'notes': row['notes'] or '',
        'created_at': row['created_at'], 'updated_at': row['updated_at'],
    }

def client_to_dict(row):
    return {
        'id': row['id'], 'name': row['name'], 'document': row['document'] or '',
        'phone': row['phone'] or '', 'address': row['address'] or '',
        'notes': row['notes'] or '', 'balance': money(row['balance']),
        'created_at': row['created_at'], 'updated_at': row['updated_at'],
    }

def clamp_int(value, default, min_value, max_value):
    try:
        value = int(float(str(value).replace(',', '.')))
    except (TypeError, ValueError):
        value = default
    return max(min_value, min(max_value, value))

def clamp_float(value, default, min_value, max_value):
    try:
        value = float(str(value).replace(',', '.'))
    except (TypeError, ValueError):
        value = default
    return max(min_value, min(max_value, value))

LABEL_FONT_MAP = {
    'helvetica': ('Helvetica', 'Helvetica-Bold', 'Helvetica / Arial'),
    'arial': ('Helvetica', 'Helvetica-Bold', 'Helvetica / Arial'),
    'times': ('Times-Roman', 'Times-Bold', 'Times / Serif'),
    'times-roman': ('Times-Roman', 'Times-Bold', 'Times / Serif'),
    'courier': ('Courier', 'Courier-Bold', 'Courier / Monoespaciada'),
}

def label_font_pair(font_family):
    key = str(font_family or 'Helvetica').strip().lower()
    return LABEL_FONT_MAP.get(key, LABEL_FONT_MAP['helvetica'])

def best_label_grid(labels_per_sheet):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm

    """Devuelve columnas y filas para repartir etiquetas en una hoja A4 vertical.
    Prioriza que la cantidad de celdas sea exactamente la pedida; si no existe una
    distribución cómoda, usa la capacidad inmediata superior y deja celdas vacías.
    """
    labels_per_sheet = clamp_int(labels_per_sheet, 24, 1, 80)
    # En A4 vertical las etiquetas de precio suelen funcionar mejor anchas que altas.
    target_ratio = 1.65
    candidates = []
    for rows in range(1, labels_per_sheet + 1):
        cols = math.ceil(labels_per_sheet / rows)
        capacity = rows * cols
        if capacity < labels_per_sheet or capacity > labels_per_sheet + max(4, labels_per_sheet // 5):
            continue
        page_w, page_h = A4
        usable_w = page_w - 16 * mm
        usable_h = page_h - 16 * mm
        label_w = usable_w / cols
        label_h = usable_h / rows
        ratio = label_w / label_h if label_h else 1
        exact_penalty = 0 if capacity == labels_per_sheet else 2 + (capacity - labels_per_sheet) * 0.2
        skinny_penalty = 0 if 0.72 <= ratio <= 3.2 else 1.5
        score = abs(ratio - target_ratio) + exact_penalty + skinny_penalty
        candidates.append((score, cols, rows, capacity))
    if not candidates:
        return 3, 8, 24
    candidates.sort(key=lambda x: (x[0], x[3], x[2]))
    _, cols, rows, capacity = candidates[0]
    return cols, rows, capacity

def wrap_pdf_text(text, max_width, font_name='Helvetica', font_size=10):
    from reportlab.pdfbase import pdfmetrics

    text = safe_pdf_text(text)
    if not text:
        return ['']
    words = text.split()
    lines = []
    current = ''
    # pdfmetrics evita crear un Canvas temporal en cada llamada.
    for word in words:
        candidate = word if not current else f'{current} {word}'
        if pdfmetrics.stringWidth(candidate, font_name, font_size) <= max_width:
            current = candidate
        else:
            if current:
                lines.append(current)
            # Si la palabra sola no entra, la partimos sin cortar el flujo.
            if pdfmetrics.stringWidth(word, font_name, font_size) > max_width:
                chunk = ''
                for char in word:
                    candidate_chunk = f'{chunk}{char}'
                    if not chunk or pdfmetrics.stringWidth(candidate_chunk, font_name, font_size) <= max_width:
                        chunk = candidate_chunk
                    else:
                        lines.append(chunk)
                        chunk = char
                current = chunk
            else:
                current = word
    if current:
        lines.append(current)
    return lines or ['']

def build_product_labels_pdf(items, labels_per_sheet=24, show_guides=True, font_family='Helvetica', name_font_size=10, price_font_size=18):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.pdfgen import canvas

    if not items:
        raise ValueError('Agregá al menos un producto para imprimir etiquetas.')

    db = get_db()

    def valid_label_groups():
        # Consultar y expandir de manera perezosa: no se crea una lista con una
        # referencia por etiqueta, incluso cuando se solicitan muchas copias.
        for item in items:
            if not isinstance(item, dict):
                continue
            try:
                product_id = int(item.get('product_id') or 0)
            except (TypeError, ValueError):
                continue
            quantity = clamp_int(item.get('quantity'), 1, 1, 999)
            product = db.execute(
                'SELECT id, barcode, name, sale_price FROM products WHERE id=?',
                (product_id,)
            ).fetchone()
            if product:
                yield product, quantity

    label_iterator = iter(iter_repeated_items(valid_label_groups()))
    sentinel = object()
    pending_product = next(label_iterator, sentinel)
    if pending_product is sentinel:
        raise ValueError('No se encontraron productos válidos para imprimir.')

    labels_per_sheet = clamp_int(labels_per_sheet, 24, 1, 80)
    body_font, bold_font, _font_label = label_font_pair(font_family)
    configured_name_font = clamp_float(name_font_size, 10, 6, 28)
    configured_price_font = clamp_float(price_font_size, 18, 8, 42)
    cols, rows, capacity = best_label_grid(labels_per_sheet)
    page_w, page_h = A4
    margin = 8 * mm
    gap = 2 * mm
    usable_w = page_w - (2 * margin) - (gap * (cols - 1))
    usable_h = page_h - (2 * margin) - (gap * (rows - 1))
    label_w = usable_w / cols
    label_h = usable_h / rows

    output = BytesIO()
    c = canvas.Canvas(output, pagesize=A4)
    c.setTitle('Etiquetas de productos')

    def draw_label(product, x, y, w, h):
        inner = 3 * mm
        if show_guides:
            c.setStrokeColor(colors.HexColor('#CBD5E1'))
            c.setLineWidth(0.35)
            c.roundRect(x, y, w, h, 2 * mm, stroke=1, fill=0)

        name = safe_pdf_text(product['name']).upper()
        price = ar_currency(product['sale_price'])
        code = safe_pdf_text(product['barcode'])
        center_x = x + (w / 2)

        max_name_font = max(6.5, min(28, h / mm * 0.28))
        max_price_font = max(8, min(42, h / mm * 0.48))
        name_font = min(configured_name_font, max_name_font)
        price_font = min(configured_price_font, max_price_font)
        code_font = max(5.2, min(7.4, h / mm * 0.11))

        name_lines = wrap_pdf_text(name, w - 2 * inner, bold_font, name_font)[:3]
        total_name_height = len(name_lines) * (name_font + 1.8)
        price_height = price_font + 4
        code_height = code_font + 2 if code else 0
        block_height = total_name_height + price_height + code_height + 4
        start_y = y + (h + block_height) / 2 - name_font

        c.setFillColor(colors.black)
        c.setFont(bold_font, name_font)
        yy = start_y
        for line in name_lines:
            c.drawCentredString(center_x, yy, line)
            yy -= name_font + 1.8

        yy -= 1.5
        c.setFont(bold_font, price_font)
        c.drawCentredString(center_x, yy - price_font * 0.25, price)
        yy -= price_font + 2

        if code:
            c.setFillColor(colors.HexColor('#475569'))
            c.setFont(body_font, code_font)
            c.drawCentredString(center_x, max(y + inner, yy), code)
            c.setFillColor(colors.black)

    # Aunque la grilla pueda tener alguna celda extra para mantener buenas proporciones,
    # se imprimen como máximo las etiquetas configuradas por hoja. Así la vista previa
    # y el PDF respetan exactamente la cantidad que eligió el usuario.
    while pending_product is not sentinel:
        printed_on_page = 0
        for row in range(rows):
            for col in range(cols):
                cell_number = (row * cols) + col
                if cell_number >= labels_per_sheet:
                    continue
                if pending_product is sentinel:
                    break
                x = margin + col * (label_w + gap)
                y = page_h - margin - (row + 1) * label_h - row * gap
                draw_label(pending_product, x, y, label_w, label_h)
                printed_on_page += 1
                pending_product = next(label_iterator, sentinel)
            if pending_product is sentinel:
                break
        if printed_on_page == 0:
            break
        if pending_product is not sentinel:
            c.showPage()

    c.save()
    output.seek(0)
    return output

__all__ = [name for name in globals() if not name.startswith("__")]

