"""Compila mediante el BAT distribuido y prueba el EXE real con datos sintéticos."""
from pathlib import Path
import http.cookiejar,json,os,subprocess,sys,time,urllib.request,zipfile
ROOT=Path(__file__).resolve().parents[1]
if os.name!='nt':raise SystemExit('Requiere Windows real')
# El BAT elige Python y prepara su propio .venv_build, sin reemplazar .venv.
(ROOT/'logs').mkdir(exist_ok=True)
command='cmd.exe /d /s /c ""'+str(ROOT/'compilar_exe.bat')+'" < nul"'
result=subprocess.run(command,cwd=ROOT.parent,env=dict(os.environ,PYTHONUTF8='1'),capture_output=True,encoding='utf-8',errors='replace',timeout=900)
(ROOT/'logs/bat-build-output.txt').write_text(result.stdout+result.stderr,encoding='utf-8')
assert result.returncode==0,(result.stdout+result.stderr)[-12000:]
output=ROOT/'dist/TerminalPOS';exe=output/'TerminalPOS.exe'
assert exe.is_file() and (ROOT/'dist/TerminalPOS_EXE.zip').is_file()
with zipfile.ZipFile(ROOT/'dist/TerminalPOS_EXE.zip') as z:assert z.testzip() is None
print('OK: compilar_exe.bat real preparó entorno, compiló, verificó y empaquetó el EXE',flush=True)
proc=subprocess.Popen([str(exe)],cwd=output,env=dict(os.environ,POS_PORT='5127',POS_SEED_DEMO_PRODUCTS='0'))
client=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def request(path,data=None):
    raw=None if data is None else json.dumps(data).encode('utf-8')
    req=urllib.request.Request('http://127.0.0.1:5127'+path,data=raw,headers={'Content-Type':'application/json'})
    with client.open(req,timeout=10) as response:return json.load(response)
try:
    deadline=time.monotonic()+30;ready=False
    while time.monotonic()<deadline and proc.poll() is None:
        try:request('/api/products');ready=True;break
        except Exception:time.sleep(.25)
    assert ready,'EXE no respondió: '+str(list((output/'logs').glob('*')))
    p=request('/api/products',{'name':'Prueba Windows V15','cost_without_tax':1,'stock':2})
    sale=request('/api/sales',{'items':[{'product_id':p['id'],'quantity':1}]})
    pdf=request('/api/sales/'+str(sale['sale_id'])+'/ticket-pdf',{'print':False})
    assert Path(pdf['path']).is_file(),pdf
    backup=request('/api/backup/create',{})
    assert backup['ok'] and (output/'backups'/backup['filename']).is_file(),backup
    print('OK: EXE real arranca, registra producto/venta, genera PDF y crea respaldo; impresión física no probada',flush=True)
finally:
    subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True)
    proc.wait(timeout=10)
