"""Instalación local repetible: rutas, versiones, fallos y datos preservados."""
from pathlib import Path
import hashlib
import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
def load(name):
    spec=importlib.util.spec_from_file_location('_test_'+name,ROOT/(name+'.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
prepare=load('preparar_entorno'); checker=load('verificar_dependencias')

# Todos los requerimientos activos, incluidos los transitivos y herramientas,
# tienen versión exacta; las ramas de numpy preservan compatibilidad metadata.
for version,expected_numpy in [('3.10','2.2.6'),('3.11','2.2.6'),('3.12','2.5.4'),('3.13','2.5.4')]:
    target={'python_version':version,'python_full_version':version+'.0','sys_platform':'win32','os_name':'nt'}
    reqs=checker.read_requirements(ROOT/'requirements-build.txt',target)
    numpy=[req for req in reqs if req.name=='numpy']
    assert len(numpy)==1 and str(numpy[0].specifier)=='=='+expected_numpy
    assert any(req.name=='pefile' for req in reqs) and any(req.name=='pywin32-ctypes' for req in reqs)
    assert not any(req.name=='macholib' for req in reqs)
    assert all('==' in str(req.specifier) and '*' not in str(req.specifier) and req.url is None for req in reqs)
with tempfile.TemporaryDirectory(prefix='pos_install_paths_') as tmp:
    root=Path(tmp)/"Terminal POS con espacios, ñ y apostrofe's";root.mkdir()
    root=root.resolve()  # Comparar rutas canónicas también cuando TEMP usa nombres 8.3.
    (root/'requirements.txt').write_text('example==1.0\n')
    (root/'requirements-build.txt').write_text('-r requirements.txt\nexample-build==1.0\n')
    (root/'verificar_dependencias.py').write_text('')
    data=root/'instance'/'pos.db';data.parent.mkdir();data.write_bytes(b'no abrir ni reemplazar')
    before=hashlib.sha256(data.read_bytes()).hexdigest()
    env=root/'.venv';env.mkdir();(env/'archivo_usuario.txt').write_text('conservar')
    with patch.object(prepare.subprocess,'run') as run:
        try:prepare.prepare_environment(root)
        except RuntimeError:pass
        else:raise AssertionError('Se aceptó un entorno incompleto')
        run.assert_not_called()
    assert (env/'archivo_usuario.txt').read_text()=='conservar'
    python=prepare.environment_python(env);python.parent.mkdir(parents=True,exist_ok=True);python.touch()
    # Entorno saludable: comprobar localmente, sin instalar ni actualizar.
    calls=[]
    def healthy(args,**kwargs): calls.append(args);return SimpleNamespace(returncode=0)
    with patch.object(prepare.subprocess,'run',side_effect=healthy):
        assert prepare.prepare_environment(root)==python
    assert len(calls)==2 and all('install' not in c and 'venv' not in c and 'upgrade' not in c for c in calls)
    assert calls[-1]==[str(python),str(root/'verificar_dependencias.py')]
    # Dependencia ausente: instalar solo dentro del entorno y verificar después.
    calls=[]
    def install_needed(args,**kwargs):
        calls.append(args)
        if args==[str(python),str(root/'verificar_dependencias.py')]:
            return SimpleNamespace(returncode=1 if sum(c==args for c in calls)==1 else 0)
        return SimpleNamespace(returncode=0)
    with patch.object(prepare.subprocess,'run',side_effect=install_needed):
        assert prepare.prepare_environment(root)==python
    installs=[c for c in calls if 'install' in c]
    assert len(installs)==1 and installs[0][0]==str(python) and '--only-binary=:all:' in installs[0]
    assert installs[0][-1]==str(root/'requirements.txt')
    # Fallo real del subproceso: propagar y nunca iniciar run.py ni tocar datos.
    calls=[]
    def failed_install(args,**kwargs):
        calls.append(args)
        if 'install' in args:raise subprocess.CalledProcessError(1,args)
        return SimpleNamespace(returncode=1 if str(root/'verificar_dependencias.py') in args else 0)
    with patch.object(prepare.subprocess,'run',side_effect=failed_install):
        try:prepare.prepare_environment(root)
        except subprocess.CalledProcessError:pass
        else:raise AssertionError('Se ocultó fallo de instalación')
    assert all('run.py' not in c for c in calls)
    assert hashlib.sha256(data.read_bytes()).hexdigest()==before
    assert (env/'archivo_usuario.txt').read_text()=='conservar'
    # El grupo de compilación tiene su propio entorno y no sustituye .venv.
    build_env=root/'.venv_build';bp=prepare.environment_python(build_env);bp.parent.mkdir(parents=True);bp.touch()
    calls=[]
    with patch.object(prepare.subprocess,'run',side_effect=healthy):assert prepare.prepare_environment(root,True)==bp
    assert calls[-1][-1]=='--build' and calls[-1][0]==str(bp)

for name in ('ejecutar.bat','instalar_dependencias.bat','compilar_exe.bat'):
    script=(ROOT/name).read_text()
    assert 'preparar_entorno.py' in script
    assert 'pip install --upgrade' not in script and 'rmdir /s /q ".venv' not in script
    assert 'Test-Path \'%LOG_FILE%\'' not in script
shell=(ROOT/'ejecutar_linux_mac.sh').read_text()
assert 'set -euo pipefail' in shell and 'exec .venv/bin/python run.py' in shell
print('OK: versiones fijas y ramas Python; instalación local, repetición sin install y fallos sin iniciar ni tocar datos')
print('OK: rutas con espacios/apóstrofe, entornos separados e incompletos conservados; comprobación BAT estructural, no ejecución Windows')

# Comprobar el flujo real del lanzador shell sin arrancar un servidor ni instalar.
if os.name != 'nt' and shutil.which('bash'):
    with tempfile.TemporaryDirectory(prefix='pos_shell_install_') as tmp:
        base=Path(tmp);root=base/'Ruta con espacios ñ';root.mkdir()
        script=root/'ejecutar_linux_mac.sh';shutil.copyfile(ROOT/'ejecutar_linux_mac.sh',script)
        binaries=base/'bin';binaries.mkdir()
        bootstrap=binaries/'python3';bootstrap.write_text('#!/bin/sh\nexit "$POS_TEST_BOOTSTRAP_RC"\n');bootstrap.chmod(0o755)
        runner=root/'.venv/bin/python';runner.parent.mkdir(parents=True)
        runner.write_text('#!/bin/sh\nprintf "%s:%s" "$PWD" "$*" > "$POS_TEST_STARTED"\n');runner.chmod(0o755)
        started=base/'started.txt';environment=os.environ.copy()
        environment.update(PATH=str(binaries)+os.pathsep+environment.get('PATH',''),POS_TEST_BOOTSTRAP_RC='7',POS_TEST_STARTED=str(started))
        failed=subprocess.run(['bash',str(script)],cwd=base,env=environment,capture_output=True,text=True)
        assert failed.returncode==7 and not started.exists()
        environment['POS_TEST_BOOTSTRAP_RC']='0'
        success=subprocess.run(['bash',str(script)],cwd=base,env=environment,capture_output=True,text=True)
        assert success.returncode==0 and started.read_text()==str(root)+':run.py'
    print('OK: lanzador shell desde otra carpeta no arranca tras un fallo y usa .venv al preparar correctamente')

# Un python suelto dentro de .venv no debe habilitar pip sobre el Python global.
if os.name != 'nt':
    with tempfile.TemporaryDirectory(prefix='pos_unmanaged_python_') as tmp:
        root=Path(tmp)
        (root/'requirements.txt').write_text('example==1.0\n')
        (root/'verificar_dependencias.py').write_text('raise RuntimeError("no ejecutar")')
        python=prepare.environment_python(root/'.venv');python.parent.mkdir(parents=True)
        python.symlink_to(sys.executable)
        original_run=subprocess.run;calls=[]
        def observed(args,**kwargs):
            calls.append(args)
            if 'pip' in args:raise AssertionError('Se intento modificar Python global')
            return original_run(args,**kwargs)
        with patch.object(prepare.subprocess,'run',side_effect=observed):
            try:prepare.prepare_environment(root)
            except RuntimeError:pass
            else:raise AssertionError('Se acepto Python sin entorno virtual')
        assert len(calls)==1
    print('OK: python global camuflado en .venv se rechaza antes de cualquier instalacion')

# Pillow 13 requiere Python 3.11; fallar antes de instalar con Python 3.10.
with patch.object(prepare.sys, 'version_info', (3, 10, 12)), patch.object(prepare.subprocess, 'run') as run:
    try: prepare.prepare_environment(ROOT)
    except RuntimeError as exc: assert '3.11' in str(exc)
    else: raise AssertionError('Se aceptó Python 3.10 con Pillow 13')
    run.assert_not_called()
