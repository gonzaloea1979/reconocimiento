@echo off
chcp 65001 >nul
setlocal EnableExtensions
set "PYTHONUTF8=1"
cd /d "%~dp0"
title Terminal POS - Preparar dependencias
if not exist "logs" mkdir "logs"
set "LOG_FILE=logs\instalacion.log"
set "PY_CMD="
call :check_python py -3.12
if defined PY_CMD goto :python_ok
call :check_python py -3.11
if defined PY_CMD goto :python_ok
if defined PY_CMD goto :python_ok
call :check_python py -3
if defined PY_CMD goto :python_ok
call :check_python python
if defined PY_CMD goto :python_ok
call :check_python python3
if defined PY_CMD goto :python_ok

echo ERROR: No se encontro Python 3.11 o superior funcionando.
echo.
echo Solucion recomendada:
echo 1^) Instala Python desde python.org
echo 2^) En la instalacion marca: Add Python to PATH
echo 3^) Cierra esta ventana y vuelve a ejecutar ejecutar.bat
echo.
echo Tambien podes probar en CMD:
echo   py -3 --version
echo   python --version
echo.
>>"%LOG_FILE%" echo ERROR: Python 3.11+ no encontrado.
pause
exit /b 1

:python_ok
echo Preparando entorno local. Detalle en logs\instalacion.log
%PY_CMD% "preparar_entorno.py" >>"%LOG_FILE%" 2>&1
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
    echo No se completo la preparacion. Conservar la instalacion anterior.
    type "%LOG_FILE%"
) else (
    echo Entorno preparado y verificado. Para iniciar, ejecutar ejecutar.bat.
)
pause
exit /b %RC%

:check_python
%* -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)" >nul 2>&1
if not errorlevel 1 set "PY_CMD=%*"
exit /b 0
