const assert = require('assert/strict');
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const crypto = require('crypto').webcrypto;
const root = process.argv[2];
function setup(extra=[]) {
  const elements = new Map();
  function element(id) {
    if (!elements.has(id)) elements.set(id, {value:'',disabled:false,innerHTML:'',textContent:'',focus(){},
      classList:{add(){},remove(){},contains(){return false;}},setAttribute(){},addEventListener(){}});
    return elements.get(id);
  }
  const button = element('testButton');
  const storage = new Map();
  const context = {document:{addEventListener(){},querySelectorAll(){return [button];},getElementById:element},
    window:{crypto,addEventListener(){},location:{pathname:'/'},POS_CURRENT_USER:{username:'admin'}},
    sessionStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},
    console,setTimeout,clearTimeout,setInterval,clearInterval,AbortController,Uint8Array};
  vm.createContext(context);
  for (const file of ['common',...extra]) vm.runInContext(fs.readFileSync(path.join(root,'app/static/js',file+'.js'),'utf8'),context);
  return {context,element,button,storage};
}
const tick = () => new Promise(resolve=>setImmediate(resolve));
async function main() {
  // Doble clic/atajo antes del primer await de cada función real.
  for (const name of ['sales','purchases','clients']) {
    const {context:c,element,button}=setup([name]);
    let sends=0, resolveSend;
    c.postOperation=()=>{sends++; return new Promise(resolve=>resolveSend=resolve);};
    c.showToast=()=>{};
    if(name==='sales') {
      vm.runInContext(`cart=[{product_id:1,quantity:1,unit_price:10}];
        cartTotal=()=>10; getCurrentClientId=()=>null; getAmountReceived=()=>10;
        waitForOperationModalPaint=async()=>{}; showSaleOperationModal=()=>{};
        renderCompletedTicket=sale=>{lastTicket=sale;}; startSaleResetCountdown=()=>{};`,c);
      element('paymentMethod').value='Efectivo';
    } else if(name==='purchases') {
      vm.runInContext(`purchaseItems=[{product_id:1,quantity:1}]; renderPurchaseItems=()=>{}; loadPurchasesModule=async()=>{};`,c);
    } else {
      c.clientId=element('clientId'); c.clientId.value='1';
      c.clientPaymentAmount=element('amount'); c.clientPaymentAmount.value='10';
      c.clientPaymentDescription=element('description'); c.clientPaymentDescription.value='Pago';
      c.loadClients=async()=>{}; c.editClient=async()=>{};
    }
    const fn=c[name==='sales'?'finishSale':name==='purchases'?'savePurchase':'registerClientPayment'];
    const first=fn(); const second=fn();
    assert.equal(first,second); assert.equal(button.disabled,true);
    await tick(); assert.equal(sends,1);
    resolveSend({ok:true,sale_id:1,ticket_number:'T-1',total:10});
    await Promise.all([first,second]);
    assert.equal(button.disabled,false); assert.equal(sends,1);
  }
  console.log('OK: ventas/compras/pagos reales bloquean doble clic antes del primer await y liberan botones');

  const {context:c,storage}=setup();
  const sent=[]; let mode='lost';
  c.fetch=async(url,options)=>{
    sent.push(options.headers['Idempotency-Key']);
    if(mode==='lost') throw new Error('respuesta perdida');
    if(mode==='badjson') return {ok:true,status:200,json:async()=>{throw new Error('respuesta cortada');}};
    if(mode==='rejected') return {ok:false,status:400,json:async()=>({error:'Dato inválido'})};
    return {ok:true,status:200,json:async()=>({ok:true,sale_id:1})};
  };
  await assert.rejects(c.postOperation('/api/sales',{items:[1]}));
  mode='badjson'; await assert.rejects(c.postOperation('/api/sales',{items:[1]}));
  mode='ok'; await c.postOperation('/api/sales',{items:[1]});
  assert.equal(sent[0],sent[1]); assert.equal(sent[1],sent[2]); assert.equal(storage.size,0);
  await c.postOperation('/api/sales',{items:[1]});
  assert.notEqual(sent[2],sent[3]);
  mode='rejected'; await assert.rejects(c.postOperation('/api/sales',{items:[1]}));
  mode='ok'; await c.postOperation('/api/sales',{items:[1]});
  assert.notEqual(sent[4],sent[5]);
  // Un contexto nuevo del navegador reutiliza el intento guardado en la pestaña.
  mode='lost'; await assert.rejects(c.postOperation('/api/sales',{items:[2]}));
  const next=setup().context;
  next.sessionStorage=c.sessionStorage; next.fetch=c.fetch;
  mode='ok'; await next.postOperation('/api/sales',{items:[2]});
  assert.equal(sent[6],sent[7]);
  const previousFetch=c.fetch;
  c.fetch=async(url,options)=>{
    if(mode==='missingok') {
      sent.push(options.headers['Idempotency-Key']);
      return {ok:true,status:200,json:async()=>({})};
    }
    return previousFetch(url,options);
  };
  mode='missingok'; await assert.rejects(c.postOperation('/api/sales',{items:[3]}));
  mode='ok'; await c.postOperation('/api/sales',{items:[3]});
  assert.equal(sent[sent.length-1],sent[sent.length-2]);
  console.log('OK: red/JSON perdidos y recarga conservan clave; éxito/validación permiten otra operación');

  // Error de ticket no debe afirmar guardado ni impresión exitosa.
  const pdf=setup(['sales']).context; let countdown=0, stopped=0;
  vm.runInContext(`lastTicket={sale_id:1}; waitForOperationModalPaint=async()=>{};
    showSaleOperationModal=()=>{}; showToast=()=>{};`,pdf);
  pdf.startSaleResetCountdown=()=>{countdown++;}; pdf.stopSaleResetCountdown=()=>{stopped++;};
  pdf.api=async()=>{throw new Error('fallo PDF');};
  await pdf.emitTicketPdf(true);
  assert.equal(countdown,0); assert.ok(stopped>0);
  let message=''; pdf.startSaleResetCountdown=text=>{message=text;};
  pdf.api=async()=>({filename:'ticket.pdf',printed:false});
  await pdf.emitTicketPdf(true);
  assert.ok(message.includes('Impresión no confirmada')); assert.ok(!message.includes('impresión enviada'));
  console.log('OK: fallo PDF conserva venta; impresión no confirmada se informa sin falso éxito');
}
main().catch(error=>{console.error(error);process.exit(1);});
