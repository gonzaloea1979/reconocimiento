"""Rutas de purchases."""
from ..route_core import *

@bp.get('/api/purchases')
@login_required
def api_purchases():
    rows = get_db().execute('''
        SELECT
            p.*,
            COALESCE(s.name, p.supplier_name) AS supplier_display,
            (
                SELECT GROUP_CONCAT(
                    pi.product_name || ' x' ||
                    CASE
                        WHEN pi.quantity = CAST(pi.quantity AS INTEGER) THEN CAST(CAST(pi.quantity AS INTEGER) AS TEXT)
                        ELSE REPLACE(printf('%.2f', pi.quantity), '.', ',')
                    END,
                    ' · '
                )
                FROM purchase_items pi
                WHERE pi.purchase_id = p.id
            ) AS items_summary
        FROM purchases p LEFT JOIN suppliers s ON s.id=p.supplier_id
        ORDER BY p.id DESC LIMIT 200
    ''').fetchall()
    result = []
    for r in rows:
        data = dict(r)
        summary = data.get('items_summary') or ''
        if len(summary) > 180:
            summary = summary[:177] + '...'
        data['items_summary'] = summary
        data['created_at_formatted'] = format_datetime_ar(r['created_at'])
        data['total'] = money(r['total'])
        result.append(data)
    return jsonify(result)

@bp.get('/api/purchases/<int:purchase_id>')
@login_required
def api_purchase_detail(purchase_id):
    p = get_db().execute('SELECT * FROM purchases WHERE id=?', (purchase_id,)).fetchone()
    if not p:
        return jsonify({'error': 'Compra no encontrada'}), 404
    items = get_db().execute('SELECT * FROM purchase_items WHERE purchase_id=? ORDER BY id ASC', (purchase_id,)).fetchall()
    return jsonify({'purchase': {**dict(p), 'created_at_formatted': format_datetime_ar(p['created_at'])}, 'items': [dict(i) for i in items]})

@bp.post('/api/purchases')
@login_required
@rollback_on_db_error
@idempotent_operation
def api_create_purchase():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({'error': 'Los datos de la compra deben ser un objeto válido'}), 400
    try:
        supplier_id = int(data.get('supplier_id') or 0) or None
    except (TypeError, ValueError):
        return jsonify({'error': 'Proveedor inválido'}), 400
    supplier = get_db().execute('SELECT * FROM suppliers WHERE id=?', (supplier_id,)).fetchone() if supplier_id else None
    if supplier_id and supplier is None:
        return jsonify({'error': 'El proveedor seleccionado no existe'}), 404
    raw_supplier_name = data.get('supplier_name')
    if raw_supplier_name is not None and not isinstance(raw_supplier_name, str):
        return jsonify({'error': 'Nombre de proveedor inválido'}), 400
    supplier_name = supplier['name'] if supplier else (raw_supplier_name or '').strip()
    raw_notes = data.get('notes')
    if raw_notes is not None and not isinstance(raw_notes, str):
        return jsonify({'error': 'Notas de compra inválidas'}), 400
    items = data.get('items')
    if not isinstance(items, list) or not items:
        return jsonify({'error': 'Agregá al menos un producto válido a la compra'}), 400
    stamp = now_iso()
    db = get_db()
    stock_enabled = stock_control_enabled()
    line_totals = []
    normalized = []
    rounding_mode, rounding_multiple = get_global_product_rounding()
    # Reutilizar la lectura inicial cuando un producto aparece en varias líneas.
    products_by_id = {}
    for item in items:
        if not isinstance(item, dict):
            return jsonify({'error': 'Producto de compra inválido'}), 400
        try:
            product_id = int(item.get('product_id') or 0)
            qty = strict_number(item.get('quantity'), 'Cantidad')
            for field, label in [('cost_without_tax', 'Costo sin impuestos'), ('unit_cost', 'Costo unitario'), ('iva_percent', 'IVA'), ('gross_income_percent', 'Ingresos brutos'), ('margin_percent', 'Margen'), ('total_cost', 'Costo total'), ('sale_price', 'Precio de venta')]:
                if field in item and item[field] not in (None, ''):
                    value = strict_number(item[field], label)
                    if value < 0:
                        raise ValueError(f'{label}: no puede ser negativo')
        except (ValueError, TypeError) as exc:
            return jsonify({'error': str(exc)}), 400
        raw_expiry = item.get('expiry_date')
        if raw_expiry is not None and not isinstance(raw_expiry, str):
            return jsonify({'error': 'Fecha de vencimiento inválida'}), 400
        cost_without_tax = money(item.get('cost_without_tax', item.get('unit_cost')))
        iva = money(item.get('iva_percent'))
        gross = money(item.get('gross_income_percent'))
        margin = money(item.get('margin_percent'))
        total_cost = money(item.get('total_cost'))
        sale_price = money(item.get('sale_price'))
        try:
            item_expiry_date = normalize_date(item.get('expiry_date')) if (item.get('expiry_date') or '').strip() else None
        except ValueError as exc:
            return jsonify({'error': str(exc)}), 400
        if qty <= 0:
            return jsonify({'error': 'La cantidad debe ser mayor a cero'}), 400
        if product_id not in products_by_id:
            products_by_id[product_id] = db.execute(
                'SELECT * FROM products WHERE id=?', (product_id,)
            ).fetchone()
        product = products_by_id[product_id]
        if not product:
            return jsonify({'error': 'Producto no encontrado en la compra'}), 404

        # Si el frontend no envió algún porcentaje, usa los valores actuales del producto.
        if iva == 0 and not str(item.get('iva_percent', '')).strip():
            iva = money(product['iva_percent'])
        if gross == 0 and not str(item.get('gross_income_percent', '')).strip():
            gross = money(product['gross_income_percent'])
        if margin == 0 and not str(item.get('margin_percent', '')).strip():
            margin = money(product['margin_percent'])
        if cost_without_tax <= 0:
            cost_without_tax = money(product['cost_without_tax'])

        calculated_total_cost, calculated_sale_price = calculate_prices(cost_without_tax, iva, gross, margin, rounding_mode, rounding_multiple)
        if total_cost <= 0:
            total_cost = calculated_total_cost
        if sale_price <= 0:
            sale_price = calculated_sale_price

        line = money_product(qty, total_cost)
        line_totals.append(line)
        normalized.append((product, qty, cost_without_tax, iva, gross, total_cost, margin, sale_price, item_expiry_date, line))
    total = money_sum(line_totals)
    cur = db.execute('INSERT INTO purchases (supplier_id, supplier_name, total, notes, created_at) VALUES (?, ?, ?, ?, ?)',
                     (supplier_id, supplier_name, total, (raw_notes or '').strip(), stamp))
    purchase_id = cur.lastrowid
    for product, qty, cost_without_tax, iva, gross, total_cost, margin, sale_price, item_expiry_date, line in normalized:
        current = db.execute('SELECT stock FROM products WHERE id=?', (product['id'],)).fetchone()
        previous = money(current['stock'])
        new_stock = money(previous + qty) if stock_enabled else previous
        db.execute('''
            INSERT INTO purchase_items (
                purchase_id, product_id, product_name, quantity, unit_cost,
                cost_without_tax, iva_percent, gross_income_percent, total_cost,
                margin_percent, sale_price, expiry_date, line_total, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            purchase_id, product['id'], product['name'], qty, cost_without_tax,
            cost_without_tax, iva, gross, total_cost, margin, sale_price, item_expiry_date, line, stamp
        ))
        # Actualiza costo/precio siempre; las existencias solo cambian si el
        # control de stock está activado en Configuración.
        db.execute('''
            UPDATE products
            SET stock=?, cost_without_tax=?, iva_percent=?, gross_income_percent=?,
                total_cost=?, margin_percent=?, rounding_mode=?, rounding_multiple=?,
                sale_price=?, expiry_date=COALESCE(?, expiry_date), supplier_id=COALESCE(?, supplier_id), updated_at=?
            WHERE id=?
        ''', (
            new_stock, cost_without_tax, iva, gross,
            total_cost, margin, rounding_mode, rounding_multiple,
            sale_price, item_expiry_date, supplier_id, stamp, product['id']
        ))
        if stock_enabled:
            stock_movement(product, 'Compra', qty, previous, new_stock, f'Compra #{purchase_id}', supplier_name)
    log_audit('Registrar compra', 'Compras', f'Compra #{purchase_id} total {total}')
    commit_operation(db)
    return jsonify({'ok': True, 'purchase_id': purchase_id, 'total': total})

