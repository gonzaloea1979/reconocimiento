from datetime import datetime, date, timedelta

def now_iso():
    return datetime.now().isoformat(timespec='seconds')

def format_date_ar(value):
    if not value:
        return ''
    raw = str(value).strip()
    # Las fechas ISO son las que guarda SQLite. Evitar strptime y sus tablas
    # de formato por cada fila del historial; conservar el fallback histórico.
    prefix = raw[:10]
    if len(prefix) == 10 and prefix[4] == '-' and prefix[7] == '-':
        try:
            return date.fromisoformat(prefix).strftime('%d/%m/%Y')
        except ValueError:
            pass
    for fmt in ('%Y-%m-%d', '%Y-%m-%dT%H:%M:%S', '%d/%m/%Y'):
        try:
            return datetime.strptime(raw[:19] if 'T' in fmt else raw[:10], fmt).strftime('%d/%m/%Y')
        except ValueError:
            pass
    return raw

def format_datetime_ar(value):
    if not value:
        return ''
    raw = str(value).strip()
    prefix = raw[:19]
    if (len(prefix) == 19 and prefix[4] == '-' and prefix[7] == '-'
            and prefix[10] in ('T', ' ') and prefix[13] == ':' and prefix[16] == ':'):
        try:
            return datetime.fromisoformat(prefix).strftime('%d/%m/%Y %H:%M')
        except ValueError:
            pass
    if len(raw) == 10 and raw[4] == '-' and raw[7] == '-':
        try:
            return date.fromisoformat(raw).strftime('%d/%m/%Y')
        except ValueError:
            pass
    for fmt in ('%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d'):
        try:
            parsed = datetime.strptime(raw[:19], fmt)
            if fmt == '%Y-%m-%d':
                return parsed.strftime('%d/%m/%Y')
            return parsed.strftime('%d/%m/%Y %H:%M')
        except ValueError:
            pass
    return raw

def normalize_date(value):
    raw = (value or '').strip()
    if not raw:
        return None

    # Formato corto para carga rápida: DDMMAA.
    # Ejemplo: 200626 => 20/06/2026.
    if raw.isdigit() and len(raw) == 6:
        raw = f'{raw[0:2]}/{raw[2:4]}/20{raw[4:6]}'

    # También acepta DDMMYYYY por comodidad.
    if raw.isdigit() and len(raw) == 8:
        raw = f'{raw[0:2]}/{raw[2:4]}/{raw[4:8]}'

    for fmt in ('%Y-%m-%d', '%d/%m/%Y'):
        try:
            return datetime.strptime(raw, fmt).date().isoformat()
        except ValueError:
            pass
    raise ValueError('La fecha debe tener formato DD/MM/AAAA o DDMMAA. Ejemplo: 31/12/2026 o 200626')
