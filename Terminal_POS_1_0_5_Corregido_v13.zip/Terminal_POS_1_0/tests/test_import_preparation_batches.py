"""Preparación fuera del bloqueo y caché transaccional para filas repetidas."""
from pathlib import Path
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch
import tempfile,sys,threading
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import xlwt
import app.config as config
import app.route_modules.prices as routes
import app.db as dbmod
from app import create_app
from app.db import get_db
keys=('BASE_DIR','INSTANCE_DIR','BACKUP_DIR','DATABASE','UPLOAD_DIR','TICKET_DIR');saved={k:getattr(config,k) for k in keys}
try:
 with tempfile.TemporaryDirectory() as tmp:
  b=Path(tmp)
  for k,v in dict(BASE_DIR=b,INSTANCE_DIR=b/'instance',BACKUP_DIR=b/'backups',DATABASE=b/'instance'/'pos.db',UPLOAD_DIR=b/'uploads',TICKET_DIR=b/'tickets').items():setattr(config,k,v)
  app=create_app();app.config['TESTING']=True;c=app.test_client()
  p=c.post('/api/products',json={'name':'Existente','cost_without_tax':1,'stock':10}).json
  def xls(headers,rows):
   wb=xlwt.Workbook();s=wb.add_sheet('Precios')
   for r,row in enumerate([headers]+rows):
    for col,value in enumerate(row):
     if value is not None:s.write(r,col,value)
   out=BytesIO();wb.save(out);return out.getvalue()
  raw=xls(['ID','Nombre','Precio venta'],[[p['id'],'Existente',2]])
  entered,resume=threading.Event(),threading.Event();original=routes.excel_number
  def paused(value):entered.set();assert resume.wait(10);return original(value)
  def uploading():return app.test_client().post('/api/prices/import',data={'file':(BytesIO(raw),'lista.xls')})
  with patch.object(routes,'excel_number',side_effect=paused):
   with ThreadPoolExecutor(1) as pool:
    job=pool.submit(uploading)
    try:
     assert entered.wait(10)
     assert c.post('/api/sales',json={'items':[{'product_id':p['id'],'quantity':1}]},headers={'Idempotency-Key':'preparation-sale-001'}).status_code==200
    finally:resume.set()
    assert job.result(timeout=10).status_code==200
  assert c.get(f"/api/products/{p['id']}").json['stock']==9
  # Una fila posterior debe ver el producto creado o modificado antes en el mismo archivo.
  raw=xls(['Código de barra','Nombre','Precio sin impuestos','Precio venta','Stock'],[['CACHE','Creado',10,10,5],['CACHE','Editado',None,20,77]])
  result=c.post('/api/prices/import',data={'file':(BytesIO(raw),'lista.xls')})
  assert result.status_code==200 and result.json['created']==result.json['updated']==1,result.json
  with app.app_context():
   row=get_db().execute("SELECT name,stock,cost_without_tax,sale_price FROM products WHERE barcode='CACHE'").fetchone()
   assert tuple(row)==('Editado',5,10,20)
  print('OK: una venta puede confirmar durante preparación del Excel; caché respeta filas anteriores y stock')
finally:
 for k,v in saved.items():setattr(config,k,v)
