"""Preparación de Excel fuera del bloqueo de escritura y lecturas por lotes."""
def prepare_price_rows(book, sheet, headers, text, number, nonnegative, percent, date_value):
    from decimal import Decimal
    rows, errors = {}, []
    numeric = {'Precio sin impuestos', 'IVA %', 'Ingresos brutos %', 'Costo total',
               'Margen ganancia %', 'Precio venta', 'Stock'}
    for r in range(headers['__row__'] + 1, sheet.nrows):
        cells = {h: sheet.cell_value(r, c) for h, c in headers.items() if h != '__row__'}
        rows[r] = cells
        if not text(cells.get('Nombre')):
            continue
        try:
            raw_id = text(cells.get('ID'))
            if raw_id:
                value = Decimal(raw_id)
                if not value.is_finite() or value <= 0 or value != value.to_integral_value():
                    raise ValueError('El ID debe ser un entero positivo')
                cells['ID'] = int(value)
            else:
                cells['ID'] = None
            for h in numeric.intersection(cells):
                if cells[h] not in ('', None):
                    validator = percent if h in ('IVA %', 'Ingresos brutos %') else nonnegative
                    cells[h] = validator(number(cells[h]), h)
            if 'Fecha vencimiento' in cells:
                cells['Fecha vencimiento'] = date_value(book, sheet, r, headers['Fecha vencimiento'])
        except Exception as exc:
            errors.append(f'Fila {r + 1}: {exc}')
            if len(errors) >= 10:
                break
    return rows, errors

def load_import_products(db, rows, text):
    ids = {v.get('ID') for v in rows.values() if v.get('ID')}
    codes = {text(v.get('Código de barra')) for v in rows.values() if text(v.get('Código de barra'))}
    by_id, by_code = {}, {}
    for field, values in (('id', ids), ('barcode', codes)):
        values = list(values)
        for start in range(0, len(values), 400):
            chunk = values[start:start + 400]
            for row in db.execute(f'SELECT * FROM products WHERE {field} IN ({",".join("?" for _ in chunk)})', chunk):
                product = dict(row)
                by_id[product['id']] = product
                if product['barcode']:
                    by_code[product['barcode']] = product
    return by_id, by_code
