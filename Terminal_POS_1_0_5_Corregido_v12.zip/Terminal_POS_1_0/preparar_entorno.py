"""Preparar .venv o .venv_build del proyecto, sin tocar datos comerciales."""
from pathlib import Path
import argparse
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def environment_python(environment):
    return Path(environment) / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')


def prepare_environment(root=ROOT, build=False):
    root = Path(root).resolve()
    if sys.version_info < (3, 10):
        raise RuntimeError('Se requiere Python 3.10 o superior. Recomendado: Python 3.12 de 64 bits.')
    requirements = root / ('requirements-build.txt' if build else 'requirements.txt')
    checker = root / 'verificar_dependencias.py'
    if not requirements.is_file() or not checker.is_file():
        raise RuntimeError('Faltan archivos de instalacion. Descomprimir el paquete completo.')
    environment = root / ('.venv_build' if build else '.venv')
    python = environment_python(environment)
    if environment.is_symlink():
        raise RuntimeError('El entorno virtual no puede ser un enlace. Preparar una carpeta nueva.')
    if environment.exists() and not python.is_file():
        raise RuntimeError(f'{environment.name} esta incompleto. Renombrar esa carpeta y reintentar; no se eliminara automaticamente.')
    if not environment.exists():
        subprocess.run([sys.executable, '-m', 'venv', str(environment)], check=True)
    result = subprocess.run([str(python), '-c',
        'import sys; from pathlib import Path; raise SystemExit(0 if sys.version_info >= (3,10) and sys.prefix != sys.base_prefix and Path(sys.prefix).resolve() == Path(sys.argv[1]).resolve() else 1)',
        str(environment)], check=False)
    if result.returncode:
        raise RuntimeError('El interprete no pertenece a este entorno o no funciona. Conservarlo y preparar otra carpeta con Python 3.12.')
    command = [str(python), str(checker)] + (['--build'] if build else [])
    # Si el entorno ya es correcto, no ejecutar install/upgrade ni consultar red.
    if subprocess.run(command, check=False).returncode == 0:
        return python
    if subprocess.run([str(python), '-m', 'pip', '--disable-pip-version-check', '--version'], check=False).returncode:
        subprocess.run([str(python), '-m', 'ensurepip'], check=True)
    subprocess.run([str(python), '-m', 'pip', '--disable-pip-version-check', 'install',
                    '--only-binary=:all:', '-r', str(requirements)], check=True)
    if subprocess.run(command, check=False).returncode:
        raise RuntimeError('Las dependencias no aprobaron la comprobacion. No se iniciara el POS.')
    return python


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true')
    try:
        python = prepare_environment(build=parser.parse_args().build)
    except (OSError, RuntimeError, subprocess.CalledProcessError) as exc:
        print('ERROR:', exc)
        print('Los datos comerciales no fueron migrados ni reemplazados por este preparador.')
        raise SystemExit(1)
    print('Entorno listo:', python)
