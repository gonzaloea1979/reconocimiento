@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
title Terminal POS - Pruebas de regresion
set "PYTHON_CMD="
if exist ".venv\Scripts\python.exe" set "PYTHON_CMD=.venv\Scripts\python.exe"
if not defined PYTHON_CMD if exist ".venv_build\Scripts\python.exe" set "PYTHON_CMD=.venv_build\Scripts\python.exe"
if not defined PYTHON_CMD (
  py -3.12 -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=py -3.12"
)
if not defined PYTHON_CMD (
  where py >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=py -3"
)
if not defined PYTHON_CMD (
  where python >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
  echo ERROR: No se encontro Python. Instala Python 3.10 o superior.
  pause
  exit /b 1
)
echo Ejecutando pruebas aisladas. No se modifican intencionalmente los datos del negocio.
echo.
%PYTHON_CMD% tests\run_all_tests.py
if errorlevel 1 (
  echo.
  echo ALGUNAS PRUEBAS FALLARON. No uses esta salida como certificacion de produccion.
  pause
  exit /b 1
)
echo.
echo BATERIA DE PRUEBAS FINALIZADA. Revisa arriba si hubo pruebas omitidas.
echo La prueba visual y funcional completa aun requiere validacion en Windows.
pause
