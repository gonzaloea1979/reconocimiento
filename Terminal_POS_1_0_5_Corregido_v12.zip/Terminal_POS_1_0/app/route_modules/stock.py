"""Rutas de stock."""
from ..route_core import *

@bp.get('/api/stock/alerts')
@login_required
def api_stock_alerts():
    compact = request.args.get('compact') == '1'
    if compact:
        rows = get_db().execute('''
            SELECT id, name, stock, min_stock FROM products
            WHERE min_stock > 0 AND stock <= min_stock
            ORDER BY (stock - min_stock) ASC, name ASC
            LIMIT 300
        ''').fetchall()
        # La pantalla de stock solo muestra nombre, existencia y mínimo.
        return jsonify([{
            'id': r['id'],
            'name': r['name'],
            'stock': money(r['stock']),
            'min_stock': money(r['min_stock']),
        } for r in rows])

    rows = get_db().execute('''
        SELECT * FROM products
        WHERE min_stock > 0 AND stock <= min_stock
        ORDER BY (stock - min_stock) ASC, name ASC
        LIMIT 300
    ''').fetchall()
    return jsonify([product_to_dict(r) for r in rows])

@bp.get('/api/stock/movements')
@login_required
def api_stock_movements():
    product_id = request.args.get('product_id')
    q = 'SELECT * FROM product_movements'
    args = []
    if product_id:
        q += ' WHERE product_id=?'
        args.append(product_id)
    q += ' ORDER BY id DESC LIMIT 300'
    rows = get_db().execute(q, args).fetchall()
    return jsonify([{**dict(r), 'created_at_formatted': format_datetime_ar(r['created_at'])} for r in rows])

@bp.post('/api/stock/adjust')
@login_required
@rollback_on_db_error
@require_json_object
def api_stock_adjust():
    if not stock_control_enabled():
        return jsonify({'error': 'El control de stock está desactivado. Activálo desde Configuración para ajustar existencias.'}), 409
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403
    try:
        product_id = int(data.get('product_id') or 0)
        new_stock = strict_number(data.get('new_stock'), 'Nuevo stock')
    except (ValueError, TypeError) as exc:
        return jsonify({'error': str(exc)}), 400
    if new_stock < 0:
        return jsonify({'error': 'El stock no puede ser negativo'}), 400
    if data.get('notes') is not None and not isinstance(data.get('notes'), str):
        return jsonify({'error': 'Las notas del ajuste deben ser texto'}), 400
    notes = (data.get('notes') or '').strip()
    # Leer el stock bajo el mismo bloqueo que protege el ajuste y su historial.
    db = get_db()
    db.execute('BEGIN IMMEDIATE')
    product = db.execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone()
    if not product:
        db.rollback()
        return jsonify({'error': 'Producto no encontrado'}), 404
    previous = money(product['stock'])
    get_db().execute('UPDATE products SET stock=?, updated_at=? WHERE id=?', (new_stock, now_iso(), product_id))
    stock_movement(product, 'Ajuste manual', new_stock - previous, previous, new_stock, 'Ajuste', notes)
    log_audit('Ajuste stock', 'Stock', f"{product['name']}: {previous} -> {new_stock}")
    get_db().commit()
    return jsonify({'ok': True, 'product': product_to_dict(get_db().execute('SELECT * FROM products WHERE id=?', (product_id,)).fetchone())})

