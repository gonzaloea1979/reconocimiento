"""Rutas de pages."""
from ..route_core import *

@bp.route('/')
@login_required
def dashboard():
    return render_template('dashboard.html', active='dashboard')

@bp.route('/productos')
@login_required
def products_page():
    return render_template('products.html', active='products')

@bp.route('/consulta-precio')
@login_required
def price_check_page():
    return render_template('price_check.html', active='price')

@bp.route('/ventas')
@login_required
def sales_page():
    return render_template('sales.html', active='sales')

@bp.route('/configuracion')
@login_required
def settings_page():
    return render_template('settings.html', active='settings')

@bp.route('/ticket')
@login_required
def ticket_design_page():
    return redirect('/configuracion#ticket')

@bp.route('/usuarios')
@login_required
def users_page():
    return redirect('/configuracion#usuarios')

@bp.route('/lista-precios')
@login_required
def price_list_page():
    return redirect('/reportes#precios')

@bp.route('/stock')
@login_required
def stock_page():
    return render_template('stock.html', active='stock')

@bp.route('/proveedores')
@login_required
def suppliers_page():
    return render_template('suppliers.html', active='suppliers')

@bp.route('/compras')
@login_required
def purchases_page():
    return render_template('purchases.html', active='purchases')

@bp.route('/caja')
@login_required
def cash_page():
    return render_template('cash.html', active='cash')

@bp.route('/reportes')
@login_required
def reports_page():
    return render_template('reports.html', active='reports')

@bp.route('/clientes')
@login_required
def clients_page():
    return render_template('clients.html', active='clients')

@bp.route('/historial')
@login_required
def audit_page():
    return render_template('audit.html', active='audit')

