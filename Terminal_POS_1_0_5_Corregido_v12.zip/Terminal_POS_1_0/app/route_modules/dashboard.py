"""Rutas de dashboard."""
from ..route_core import *

@bp.get('/api/dashboard')
@login_required
def api_dashboard():
    db = get_db()
    today = date.today().isoformat()
    month_start = date.today().replace(day=1).isoformat()
    next_30 = (date.today() + timedelta(days=30)).isoformat()

    # Una sola lectura obtiene el importe diario y la cantidad de tickets.
    # Ambas métricas usan exactamente el mismo rango temporal e índice.
    daily_metrics = db.execute(
        """SELECT COALESCE(SUM(total),0) AS total, COUNT(*) AS ticket_count
           FROM sales
           WHERE created_at >= ? AND created_at < date(?, '+1 day')""",
        (today, today),
    ).fetchone()
    daily = daily_metrics['total']
    monthly = db.execute(
        "SELECT COALESCE(SUM(total),0) AS total FROM sales WHERE created_at >= ?",
        (month_start,),
    ).fetchone()['total']
    daily_ticket_count = daily_metrics['ticket_count']
    # stock y min_stock son NOT NULL en el esquema vigente y en sus migraciones.
    # La condición coincide con el índice parcial idx_products_low_stock_priority.
    low_stock_count = db.execute('''
        SELECT COUNT(*) AS c
        FROM products
        WHERE min_stock > 0 AND stock <= min_stock
    ''').fetchone()['c']

    # Los dos rankings recorrían sale_items por separado. Este rollup común
    # agrupa las líneas una sola vez y reutiliza el resultado para el top y
    # para los productos menos vendidos, conservando el nombre histórico de
    # cada línea en el ranking superior y el nombre actual en el inferior.
    rankings = db.execute('''
        WITH item_rollup AS MATERIALIZED (
            SELECT product_id, product_name,
                   SUM(quantity) AS qty,
                   SUM(line_total) AS amount
            FROM sale_items
            GROUP BY product_id, product_name
        ), product_rollup AS MATERIALIZED (
            SELECT product_id, SUM(qty) AS qty, SUM(amount) AS amount
            FROM item_rollup
            GROUP BY product_id
        )
        SELECT kind, name, qty, amount
        FROM (
            SELECT 'top' AS kind, name, qty, amount, 1 AS section
            FROM (
                SELECT product_name AS name, qty, amount
                FROM item_rollup
                ORDER BY qty DESC, amount DESC
                LIMIT 10
            )
            UNION ALL
            SELECT 'least' AS kind, name, qty, amount, 2 AS section
            FROM (
                SELECT p.name AS name,
                       COALESCE(r.qty, 0) AS qty,
                       COALESCE(r.amount, 0) AS amount
                FROM products p
                LEFT JOIN product_rollup r ON r.product_id = p.id
                ORDER BY qty ASC, amount ASC, p.name ASC
                LIMIT 10
            )
        )
        ORDER BY section,
                 CASE WHEN section=1 THEN qty END DESC,
                 CASE WHEN section=2 THEN qty END ASC,
                 CASE WHEN section=1 THEN amount END DESC,
                 CASE WHEN section=2 THEN amount END ASC,
                 CASE WHEN section=2 THEN name END ASC
    ''').fetchall()
    top = [r for r in rankings if r['kind'] == 'top']
    least = [r for r in rankings if r['kind'] == 'least']

    expiring_rows = db.execute('''
        SELECT id, barcode, name, expiry_date,
               CAST(julianday(expiry_date) - julianday(?) AS INTEGER) AS days_left
        FROM products
        WHERE expiry_date IS NOT NULL
          AND expiry_date != ''
          AND date(expiry_date) >= date(?)
          AND date(expiry_date) <= date(?)
        ORDER BY date(expiry_date) ASC
        LIMIT 50
    ''', (today, today, next_30)).fetchall()

    expiring = []
    for r in expiring_rows:
        days = int(r['days_left'])
        if days <= 15:
            level = 'red'
        elif days <= 21:
            level = 'orange'
        else:
            level = 'yellow'
        expiring.append({
            'id': r['id'],
            'barcode': r['barcode'] or '',
            'name': r['name'],
            'expiry_date': r['expiry_date'],
            'expiry_date_formatted': format_date_ar(r['expiry_date']),
            'days_left': days,
            'level': level,
        })

    return jsonify({
        'daily_sales': money(daily),
        'monthly_sales': money(monthly),
        'daily_ticket_count': int(daily_ticket_count or 0),
        'low_stock_count': int(low_stock_count or 0),
        # Booleano real: el panel decide con esto si muestra el conteo o
        # "Desactivado". Un string '0' sería verdadero en JavaScript.
        'stock_control_enabled': stock_control_enabled(),
        'expiring_count': len(expiring),
        'top_products': [{'name': r['name'], 'qty': money(r['qty']), 'amount': money(r['amount'])} for r in top],
        'least_products': [{'name': r['name'], 'qty': money(r['qty']), 'amount': money(r['amount'])} for r in least],
        'expiring_products': expiring,
    })

@bp.get('/api/audit')
@login_required
def api_audit():
    rows = get_db().execute('SELECT * FROM audit_logs ORDER BY id DESC LIMIT 500').fetchall()
    return jsonify([{**dict(r), 'created_at_formatted': format_datetime_ar(r['created_at'])} for r in rows])

