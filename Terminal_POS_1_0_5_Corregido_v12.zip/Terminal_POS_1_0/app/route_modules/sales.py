"""Rutas de sales."""
from ..route_core import *

@bp.post('/api/sales')
@login_required
@rollback_on_db_error
@idempotent_operation
def api_create_sale():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({'error': 'Los datos de la venta deben ser un objeto válido'}), 400
    items = data.get('items')
    if not isinstance(items, list) or not items:
        return jsonify({'error': 'No hay productos válidos cargados en la venta'}), 400

    raw_payment_method = data.get('payment_method')
    if raw_payment_method is not None and not isinstance(raw_payment_method, str):
        return jsonify({'error': 'Medio de pago inválido'}), 400
    payment_method = (raw_payment_method or 'Efectivo').strip() or 'Efectivo'
    try:
        amount_received = strict_number(data.get('amount_received'), 'Importe recibido', default=0)
        client_id = int(data.get('client_id') or 0) or None
    except (ValueError, TypeError) as exc:
        return jsonify({'error': str(exc)}), 400

    if amount_received < 0:
        return jsonify({'error': 'El importe recibido no puede ser negativo'}), 400
    db = get_db()
    stock_enabled = stock_control_enabled()
    stamp = now_iso()
    line_totals = []
    normalized = []

    requested_stock = {}
    # Reutilizar la lectura del producto cuando aparece en varias líneas.
    # Evita consultas SQL repetidas sin cambiar el detalle ni los movimientos.
    products_by_id = {}
    for item in items:
        if not isinstance(item, dict):
            return jsonify({'error': 'Producto de venta inválido'}), 400
        try:
            product_id = int(item.get('product_id'))
            qty = strict_number(item.get('quantity', 1), 'Cantidad')
        except (ValueError, TypeError) as exc:
            return jsonify({'error': str(exc)}), 400
        if qty <= 0:
            return jsonify({'error': 'La cantidad debe ser mayor a cero'}), 400
        if product_id not in products_by_id:
            products_by_id[product_id] = db.execute(
                'SELECT * FROM products WHERE id=?', (product_id,)
            ).fetchone()
        product = products_by_id[product_id]
        if not product:
            return jsonify({'error': f'Producto no encontrado: {product_id}'}), 404
        custom_unit = item.get('unit_price', None)
        try:
            unit = strict_number(custom_unit, 'Precio unitario') if custom_unit not in (None, '') else money(product['sale_price'])
        except ValueError as exc:
            return jsonify({'error': str(exc)}), 400
        if unit <= 0:
            return jsonify({'error': f'El precio de {product["name"]} debe ser mayor a cero'}), 400
        requested_stock[product_id] = requested_stock.get(product_id, 0) + qty
        if stock_enabled and requested_stock[product_id] > money(product['stock']) + 0.00001:
            return jsonify({'error': f'Stock insuficiente de {product["name"]}. Disponible: {money(product["stock"])}'}), 400
        line = money_product(unit, qty)
        line_totals.append(line)
        normalized.append((product, qty, unit, line))

    total = money_sum(line_totals)
    if payment_method.lower() == 'efectivo' and amount_received > 0 and amount_received < total:
        return jsonify({'error': 'El importe recibido no puede ser menor al total de la venta'}), 400
    if payment_method.lower() != 'efectivo' and amount_received <= 0:
        amount_received = total
    if payment_method.lower() == 'efectivo' and amount_received <= 0:
        amount_received = total
    change_amount = money(max(0, amount_received - total))

    client = None
    if client_id:
        client = db.execute('SELECT * FROM clients WHERE id=?', (client_id,)).fetchone()
        if not client:
            return jsonify({'error': 'Cliente no encontrado'}), 404

    sale_type = 'Contado'
    if payment_method.lower() == 'cuenta corriente':
        sale_type = 'Cuenta corriente'
        if not client_id or not client:
            return jsonify({'error': 'Seleccioná un cliente para vender en cuenta corriente'}), 400
        amount_received = 0
        change_amount = 0

    # Serializar la selección de caja con su cierre y los demás escritores.
    if not db.in_transaction:
        db.execute('BEGIN IMMEDIATE')
    cash_session = active_cash_session()
    cash_session_id = cash_session['id'] if cash_session else None
    cashier_name = current_cashier_display_name()

    cur = db.execute(
        '''INSERT INTO sales (total, payment_method, amount_received, change_amount, cashier_name, client_id, cash_session_id, sale_type, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
        (total, payment_method, amount_received, change_amount, cashier_name, client_id, cash_session_id, sale_type, stamp)
    )
    sale_id = cur.lastrowid
    response_items = []
    for product, qty, unit, line in normalized:
        db.execute("""
            INSERT INTO sale_items (sale_id, product_id, product_name, unit_price, quantity, line_total, created_at, unit_cost_at_sale)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (sale_id, product['id'], product['name'], unit, qty, line, stamp, money(product['total_cost'])))
        if stock_enabled:
            # La validación y el descuento quedan dentro de la misma transacción.
            updated = db.execute('''
                UPDATE products SET stock=ROUND(stock - ?, 2), updated_at=?
                WHERE id=? AND stock + 0.000001 >= ?
            ''', (qty, stamp, product['id'], qty))
            if updated.rowcount != 1:
                db.rollback()  # Revierte cabecera, líneas y demás movimientos de esta venta.
                return jsonify({'error': f'Stock insuficiente de {product["name"]}. Reintentá la venta'}), 409
            current = db.execute('SELECT stock FROM products WHERE id=?', (product['id'],)).fetchone()
            new_stock = money(current['stock'])
            previous_stock = money(new_stock + qty)
            stock_movement(product, 'Venta', -qty, previous_stock, new_stock, f'Venta #{sale_id}', payment_method)
        response_items.append({
            'product_id': product['id'],
            'barcode': product['barcode'] or '',
            'name': product['name'],
            'quantity': qty,
            'unit_price': unit,
            'line_total': line,
        })
    if payment_method.lower() != 'cuenta corriente':
        add_cash_movement('Venta', total, f'Venta T-{sale_id:06d}', payment_method, sale_id=sale_id, cash_session_id=cash_session_id)
    else:
        db.execute('UPDATE clients SET balance=ROUND(balance + ?, 2), updated_at=? WHERE id=?',
                   (total, stamp, client_id))
        db.execute('''
            INSERT INTO client_movements (client_id, movement_type, amount, description, sale_id, created_at)
            VALUES (?, 'Venta cuenta corriente', ?, ?, ?, ?)
        ''', (client_id, total, f'Venta T-{sale_id:06d}', sale_id, stamp))

    log_audit('Cerrar venta', 'Ventas', f'T-{sale_id:06d} {payment_method} {total}')
    commit_operation(db)

    return jsonify({
        'ok': True,
        'sale_id': sale_id,
        'ticket_number': f'T-{sale_id:06d}',
        'total': total,
        'payment_method': payment_method,
        'amount_received': amount_received,
        'change_amount': change_amount,
        'created_at': stamp,
        'created_at_formatted': format_datetime_ar(stamp),
        'items': response_items,
        'settings': settings_response(),
        'cashier': cashier_name,
        'client_id': client_id,
        'client_name': client['name'] if client else '',
    })

@bp.post('/api/sales/<int:sale_id>/ticket-pdf')
@login_required
@require_json_object
def api_sale_ticket_pdf(sale_id):
    data = request.get_json(silent=True) or {}
    should_print = bool(data.get('print'))
    try:
        pdf_path = build_a5_ticket_pdf(sale_id)
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 404
    except Exception:
        current_app.logger.exception('No se pudo generar el PDF de venta')
        return jsonify({'error': 'No se pudo generar el PDF de venta. Intentá nuevamente.'}), 500

    printed = False
    print_message = ''
    if should_print:
        printed, print_message = print_pdf_file(pdf_path)

    return jsonify({
        'ok': True,
        'sale_id': sale_id,
        'ticket_number': f'T-{sale_id:06d}',
        'filename': pdf_path.name,
        'folder': str(pdf_path.parent),
        'path': str(pdf_path),
        'printed': printed,
        'print_message': print_message,
    })

@bp.get('/api/sales/last')
@login_required
def api_last_sale():
    sale = get_db().execute('SELECT * FROM sales ORDER BY id DESC LIMIT 1').fetchone()
    if not sale:
        return jsonify({'error': 'No hay ventas registradas'}), 404
    return jsonify({'sale_id': sale['id'], 'ticket_number': f"T-{sale['id']:06d}"})

