"""Respaldo descargado restaura negocio y claves de reintento, con base temporal."""
from pathlib import Path
import errno
import hashlib
import os
import sqlite3
import sys
import tempfile
from contextlib import closing
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
import app.config as config
from app import create_app
from app.db import get_db
import app.route_modules.settings as settings_routes
import app.route_modules.auth as auth_routes

keys=('BASE_DIR','INSTANCE_DIR','BACKUP_DIR','DATABASE','UPLOAD_DIR','TICKET_DIR')
saved={key:getattr(config,key) for key in keys}
def set_paths(base):
    for key,value in dict(BASE_DIR=base,INSTANCE_DIR=base/'instance',BACKUP_DIR=base/'backups',DATABASE=base/'instance'/'pos.db',UPLOAD_DIR=base/'uploads',TICKET_DIR=base/'TICKET').items(): setattr(config,key,value)
try:
    with tempfile.TemporaryDirectory(prefix='pos_http_backup_recovery_') as tmp:
        base=Path(tmp)/'original'; base.mkdir(); set_paths(base)
        with patch.dict(os.environ,{'POS_SEED_DEMO_PRODUCTS':'0'}): app=create_app()
        app.config['TESTING']=True
        client=app.test_client(); assert client.get('/api/products').status_code==200
        product=client.post('/api/products',json={'barcode':'RECOVER-104','name':'Producto ficticio','cost_without_tax':10,'stock':10})
        assert product.status_code==201,product.json
        pid=product.json['id']
        assert client.post('/api/cash/open',json={'initial_amount':100}).status_code==200
        cid=client.post('/api/clients',json={'name':'Cliente ficticio','balance':0}).json['id']
        payload={'items':[{'product_id':pid,'quantity':2}],'payment_method':'Cuenta corriente','client_id':cid}
        headers={'Idempotency-Key':'recover-sale-104-unique'}
        sale=client.post('/api/sales',json=payload,headers=headers)
        assert sale.status_code==200,sale.json
        payment=client.post(f'/api/clients/{cid}/payment',json={'amount':5},headers={'Idempotency-Key':'recover-payment-104-unique'})
        assert payment.status_code==200,payment.json
        tables=('products','sales','sale_items','clients','client_movements','cash_sessions','cash_movements','operation_receipts')
        with app.app_context():
            expected={table:[tuple(row) for row in get_db().execute(f'SELECT * FROM {table} ORDER BY id' if table!='operation_receipts' else 'SELECT * FROM operation_receipts ORDER BY scope,request_key')] for table in tables}
        backup=client.post('/api/backup/create',json={})
        assert backup.status_code==200 and backup.json['ok'],backup.json
        filename=backup.json['filename']
        listing=client.get('/api/backup/list')
        assert listing.status_code==200 and any(row['filename']==filename for row in listing.json)
        downloaded=client.get('/api/backup/download/'+filename)
        assert downloaded.status_code==200 and downloaded.data.startswith(b'SQLite format 3\0')
        assert f'filename={filename}' in downloaded.headers['Content-Disposition']
        # Una venta posterior no debe aparecer en la restauración del respaldo.
        later=client.post('/api/sales',json={'items':[{'product_id':pid,'quantity':1}],'payment_method':'Efectivo','amount_received':10})
        assert later.status_code==200,later.json
        restored_base=Path(tmp)/'restored'; (restored_base/'instance').mkdir(parents=True)
        restored_file=restored_base/'instance'/'pos.db'; restored_file.write_bytes(downloaded.data)
        with closing(sqlite3.connect(restored_file)) as db:
            assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)]
            assert not db.execute('PRAGMA foreign_key_check').fetchall()
            for table in tables:
                sql=f'SELECT * FROM {table} ORDER BY id' if table!='operation_receipts' else 'SELECT * FROM operation_receipts ORDER BY scope,request_key'
                assert db.execute(sql).fetchall()==expected[table],table
        set_paths(restored_base)
        with patch.dict(os.environ,{'POS_SEED_DEMO_PRODUCTS':'0'}): restored=create_app()
        restored.config['TESTING']=True
        restored_client=restored.test_client()
        replay=restored_client.post('/api/sales',json=payload,headers=headers)
        assert replay.status_code==200 and replay.json==sale.json and replay.headers.get('Idempotency-Replayed')=='true'
        with restored.app_context():
            assert get_db().execute('SELECT stock FROM products WHERE id=?',(pid,)).fetchone()[0]==8
            assert get_db().execute('SELECT balance FROM clients WHERE id=?',(cid,)).fetchone()[0]==15
            assert get_db().execute('SELECT COUNT(*) FROM sales').fetchone()[0]==1
        print('OK: respaldo HTTP descargado restaura productos, ventas, deudas, caja y recibos sin duplicar reintentos')

        # Fallos manuales: JSON claro, sin falso éxito ni alterar copias existentes.
        backups=base/'backups'
        before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in backups.glob('pos_backup_*.db')}
        failures=[OSError(errno.ENOSPC,'disco lleno simulado'),PermissionError('bloqueado simulado'),TimeoutError('tiempo simulado'),sqlite3.DatabaseError('copia invalida simulada')]
        for failure in failures:
            with patch.object(settings_routes,'backup_database',side_effect=failure),patch.object(app.logger,'exception') as logged:
                failed=client.post('/api/backup/create',json={})
                assert failed.status_code==503 and failed.is_json and 'error' in failed.json and not failed.json.get('ok'),failed.data
                logged.assert_called_once()
        assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in backups.glob('pos_backup_*.db')}==before
        assert client.post('/api/backup/create',json=[]).status_code==400
        with patch.object(auth_routes,'backup_database',side_effect=TimeoutError('bloqueo simulado')),patch.object(app.logger,'exception'),patch.object(auth_routes.threading,'Thread') as thread:
            shutdown=client.post('/api/shutdown',json={'shutdown_pc':False})
            assert shutdown.status_code==503 and not shutdown.json.get('ok')
            thread.assert_not_called()
        print('OK: disco lleno/bloqueo/timeout/integridad devuelven JSON 503; no cierran el sistema ni alteran respaldos')

        # Archivos que desaparecen durante el listado/descarga generan resultado controlado.
        removed=backups/'pos_backup_race.db'; removed.write_bytes(downloaded.data)
        stat_original=Path.stat
        def raced_stat(path,*args,**kwargs):
            if path==removed: raise FileNotFoundError('retencion simulada')
            return stat_original(path,*args,**kwargs)
        with patch.object(Path,'stat',raced_stat):
            result=client.get('/api/backup/list')
            assert result.status_code==200 and not any(row['filename']==removed.name for row in result.json)
        with patch.object(settings_routes,'send_file',side_effect=FileNotFoundError('retencion simulada')):
            assert client.get('/api/backup/download/'+filename).status_code==404
        print('OK: retención concurrente al listado/descarga no genera error 500')
finally:
    for key,value in saved.items(): setattr(config,key,value)
