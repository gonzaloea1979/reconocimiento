"""Comprueba que exportaciones y etiquetas no creen listas intermedias innecesarias."""
from __future__ import annotations

from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[1]
ITERATORS_PATH = ROOT / "app" / "route_services" / "iterators.py"
spec = importlib.util.spec_from_file_location("_pos_memory_iterators", ITERATORS_PATH)
iterators_module = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(iterators_module)
iter_repeated_items = iterators_module.iter_repeated_items


# El iterador debe repetir referencias de forma perezosa y avanzar grupo a grupo.
first = object()
second = object()
visited = []

def groups():
    visited.append("first")
    yield first, 3
    visited.append("second")
    yield second, 2

iterator = iter(iter_repeated_items(groups()))
assert next(iterator) is first
assert visited == ["first"]
assert next(iterator) is first
assert next(iterator) is first
assert visited == ["first"]
assert next(iterator) is second
assert visited == ["first", "second"]
assert list(iterator) == [second]

# Exportaciones: el cursor se recorre directamente, sin duplicar todas las filas.
prices = (ROOT / "app" / "route_modules" / "prices.py").read_text(encoding="utf-8")
clients = (ROOT / "app" / "route_modules" / "clients.py").read_text(encoding="utf-8")
core = (ROOT / "app" / "route_core.py").read_text(encoding="utf-8")

price_export = prices.split("def api_export_prices():", 1)[1].split("@bp.get", 1)[0]
assert ".fetchall()" not in price_export
assert "write_xls_products(rows)" in price_export

client_export = clients.split("def api_clients_export():", 1)[1].split("@bp.get", 1)[0]
assert ".fetchall()" not in client_export
statement_export = clients.split("def api_client_statement_export", 1)[1]
assert ".fetchall()" not in statement_export
assert "for ridx, movement in enumerate(movements" in statement_export

labels = core.split("def build_product_labels_pdf", 1)[1]
assert "expanded = []" not in labels
assert "iter_repeated_items(valid_label_groups())" in labels
assert "pending_product = next(label_iterator, sentinel)" in labels

# Las imágenes procesadas deben cerrar el recurso fuente incluso ante errores de guardado.
assert "with Image.open(file_storage.stream) as source_image:" in core
print("OK: iteración perezosa de etiquetas, exportaciones sin fetchall y cierre explícito de imágenes")
