"""Rutas de settings."""
from ..route_core import *

@bp.get('/api/settings')
@login_required
def api_get_settings():
    return jsonify(settings_response())

@bp.get('/api/ticket-settings')
@login_required
def api_get_ticket_settings():
    return jsonify(settings_response())

@bp.post('/api/ticket-settings')
@login_required
def api_save_ticket_settings():
    data = request.get_json(force=True)
    allowed_sizes = {'A5', '80mm', '58mm'}
    allowed_designs = {'moderno', 'clasico', 'compacto'}
    allowed_font_scales = {'chico', 'normal', 'grande'}

    pdf_size = (data.get('ticket_pdf_size') or 'A5').strip()
    design = (data.get('ticket_design') or 'moderno').strip().lower()
    font_scale = (data.get('ticket_font_scale') or 'normal').strip().lower()
    if pdf_size not in allowed_sizes:
        return jsonify({'error': 'Tamaño inválido. Usá A5, 80mm o 58mm.'}), 400
    if design not in allowed_designs:
        return jsonify({'error': 'Diseño inválido.'}), 400
    if font_scale not in allowed_font_scales:
        return jsonify({'error': 'Tamaño de texto inválido.'}), 400

    accent = (data.get('ticket_accent_color') or '#0F172A').strip()
    if not accent.startswith('#') or len(accent) not in (4, 7):
        accent = '#0F172A'

    def bool_value(key, default='1'):
        value = data.get(key, default)
        return '1' if str(value).lower() in ('1', 'true', 'on', 'yes', 'si', 'sí') else '0'

    def numeric_text(key, default, min_value, max_value):
        try:
            n = float(str(data.get(key, default)).replace(',', '.'))
        except (TypeError, ValueError):
            n = float(default)
        n = max(min_value, min(max_value, n))
        return str(int(n)) if float(n).is_integer() else str(n)

    values = {
        'ticket_pdf_size': pdf_size,
        'ticket_design': design,
        'ticket_title': (data.get('ticket_title') or 'TICKET DE COMPRA').strip()[:80],
        'ticket_accent_color': accent,
        'ticket_font_scale': font_scale,
        'ticket_margin_mm': numeric_text('ticket_margin_mm', '12', 3, 18),
        'ticket_logo_size_mm': numeric_text('ticket_logo_size_mm', '22', 8, 45),
        'ticket_show_logo': bool_value('ticket_show_logo'),
        'ticket_show_business_name': bool_value('ticket_show_business_name'),
        'ticket_show_cuit': bool_value('ticket_show_cuit'),
        'ticket_show_address': bool_value('ticket_show_address'),
        'ticket_show_phone': bool_value('ticket_show_phone'),
        'ticket_show_email': bool_value('ticket_show_email'),
        'ticket_show_cashier': bool_value('ticket_show_cashier'),
        'ticket_show_payment': bool_value('ticket_show_payment'),
        'ticket_show_received_change': bool_value('ticket_show_received_change'),
        'ticket_show_footer': bool_value('ticket_show_footer'),
        'ticket_show_qr': bool_value('ticket_show_qr', '0'),
        'ticket_qr_label': (data.get('ticket_qr_label') or 'Escaneá para contactarnos').strip()[:80],
        'ticket_qr_value': (data.get('ticket_qr_value') or '').strip()[:300],
        'ticket_footer': (data.get('ticket_footer') or '').strip()[:200],
    }
    update_settings(values)
    return jsonify({'ok': True, 'settings': settings_response()})

@bp.post('/api/ticket-logo')
@login_required
def api_save_ticket_logo():
    """Guarda el logo usado por el sistema y por el ticket.

    Se separa del endpoint de diseño para permitir multipart/form-data y
    mejorar la calidad del archivo antes de insertarlo en el PDF.
    """
    try:
        values = {}
        if str(request.form.get('remove_logo') or '').lower() in ('1', 'true', 'on', 'yes'):
            values['logo_path'] = ''

        logo = request.files.get('logo') if request.files else None
        if logo and logo.filename:
            values['logo_path'] = save_logo_image(logo)

        if not values:
            return jsonify({'ok': True, 'settings': settings_response()})

        update_settings(values)
        return jsonify({'ok': True, 'settings': settings_response()})
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    except Exception:
        current_app.logger.exception('No se pudo guardar el logo del ticket')
        return jsonify({'error': 'No se pudo guardar el logo del ticket. Revisá el archivo e intentá nuevamente.'}), 500

@bp.post('/api/settings')
@login_required
def api_save_settings():
    try:
        # Acepta formulario multipart/form-data para poder guardar logo,
        # y también JSON para futuras integraciones.
        if request.files or request.form:
            data = request.form
        else:
            data = request.get_json(silent=True) or {}

        # Configuración general ya no administra usuarios/claves.
        # Esos datos se gestionan desde el módulo Usuarios / Contraseñas.
        business_name = (data.get('business_name') or 'POS Local').strip()
        if not business_name:
            return jsonify({'error': 'Ingresá el nombre del negocio.'}), 400

        rounding_mode = normalize_rounding_mode(data.get('product_rounding_mode') or 'none')
        rounding_multiple = money(data.get('product_rounding_multiple')) or 1
        allowed_multiples = {1, 5, 10, 50, 100, 500, 1000}
        if int(rounding_multiple) not in allowed_multiples:
            rounding_multiple = 1

        values = {
            'business_name': business_name[:120],
            'business_cuit': (data.get('business_cuit') or '').strip()[:80],
            'business_address': (data.get('business_address') or '').strip()[:180],
            'business_phone': (data.get('business_phone') or '').strip()[:80],
            'business_email': (data.get('business_email') or '').strip()[:120],
            'ticket_footer': (data.get('ticket_footer') or '').strip()[:240],
            'product_rounding_mode': rounding_mode,
            'product_rounding_multiple': str(int(rounding_multiple)),
        }

        if 'stock_control_enabled' in data:
            raw_stock_control = str(data.get('stock_control_enabled') or '').strip().lower()
            if raw_stock_control in ('1', 'true', 'on', 'yes', 'si', 'sí'):
                values['stock_control_enabled'] = '1'
            elif raw_stock_control in ('0', 'false', 'off', 'no'):
                values['stock_control_enabled'] = '0'
            else:
                return jsonify({'error': 'Seleccioná una opción válida para el control de stock.'}), 400

        if str(data.get('remove_logo') or '').lower() in ('1', 'true', 'on', 'yes'):
            values['logo_path'] = ''

        logo = request.files.get('logo') if request.files else None
        if logo and logo.filename:
            try:
                values['logo_path'] = save_logo_image(logo)
            except ValueError as exc:
                return jsonify({'error': str(exc)}), 400

        update_settings(values)
        updated = get_settings()
        session['username'] = updated.get('default_cashier_name') or updated.get('login_username') or 'admin'
        return jsonify({'ok': True, 'message': 'Configuración guardada correctamente', 'settings': settings_response()})
    except Exception:
        current_app.logger.exception('No se pudo guardar la configuración')
        return jsonify({'error': 'No se pudo guardar la configuración. Intentá nuevamente.'}), 500

@bp.get('/api/system-keys')
@login_required
def api_get_system_keys():
    settings = get_settings()
    return jsonify({
        'default_cashier_name': settings.get('default_cashier_name') or settings.get('login_username') or 'admin',
        'login_username': settings.get('login_username') or 'admin',
        'security_key_configured': bool(settings.get('admin_password_hash')),
        'access_key_configured': bool(settings.get('login_password_hash')),
    })

@bp.post('/api/system-keys')
@login_required
def api_save_system_keys():
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad actual incorrecta'}), 403

    values = {}
    default_cashier_name = (data.get('default_cashier_name') or '').strip()
    login_username = (data.get('login_username') or '').strip()
    new_access_password = (data.get('new_access_password') or '').strip()
    new_security_password = (data.get('new_security_password') or '').strip()

    if default_cashier_name:
        values['default_cashier_name'] = default_cashier_name
        values['login_username'] = login_username or default_cashier_name
    elif login_username:
        values['login_username'] = login_username
        values['default_cashier_name'] = login_username

    if new_access_password:
        if len(new_access_password) < 4:
            return jsonify({'error': 'La clave de acceso debe tener al menos 4 caracteres'}), 400
        values['login_password_hash'] = generate_password_hash(new_access_password)
    if new_security_password:
        if len(new_security_password) < 4:
            return jsonify({'error': 'La clave de seguridad debe tener al menos 4 caracteres'}), 400
        values['admin_password_hash'] = generate_password_hash(new_security_password)

    if not values:
        return jsonify({'error': 'No hay cambios para guardar'}), 400

    update_settings(values)
    updated = get_settings()
    session['username'] = updated.get('default_cashier_name') or updated.get('login_username') or 'admin'
    return jsonify({'ok': True, 'settings': settings_response(), 'system_keys': {
        'default_cashier_name': session['username'],
        'login_username': updated.get('login_username') or 'admin',
        'security_key_configured': bool(updated.get('admin_password_hash')),
        'access_key_configured': bool(updated.get('login_password_hash')),
    }})

@bp.post('/api/backup/create')
@login_required
def api_backup_create():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({'error': 'Los datos del respaldo deben ser un objeto válido'}), 400
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403
    try:
        path = backup_database()
    except (OSError, sqlite3.Error):
        current_app.logger.exception('No se pudo completar o verificar el respaldo manual')
        return jsonify({'error': 'No se pudo completar o verificar el respaldo. Revisá espacio libre, permisos y si la base está bloqueada. Las copias anteriores se conservan.'}), 503
    if not path:
        return jsonify({'error': 'No se pudo crear el backup'}), 500
    log_audit('Crear backup', 'Configuración', path.name)
    get_db().commit()
    return jsonify({'ok': True, 'filename': path.name, 'path': str(path), 'created_at': format_datetime_ar(now_iso())})

@bp.get('/api/backup/list')
@login_required
def api_backup_list():
    backup_dir = current_app.config['BACKUP_DIR']
    backup_dir.mkdir(exist_ok=True)
    files = []
    for path in backup_dir.glob('pos_backup_*.db'):
        try:
            info = path.stat()
        except OSError:
            continue  # La retencion puede quitar una copia mientras se lista.
        files.append((info.st_mtime_ns, path.name, info))
    files.sort(key=lambda item: (item[0], item[1]), reverse=True)
    rows = []
    for _, name, info in files[:50]:
        stamp = datetime.fromtimestamp(info.st_mtime).isoformat(timespec='seconds')
        rows.append({
            'filename': name,
            'size_bytes': info.st_size,
            'created_at': stamp,
            'created_at_formatted': format_datetime_ar(stamp),
        })
    return jsonify(rows)

@bp.get('/api/backup/download/<path:filename>')
@login_required
def api_backup_download(filename):
    safe = secure_filename(filename)
    if safe != filename or not filename.startswith('pos_backup_') or not filename.endswith('.db'):
        return jsonify({'error': 'Archivo inválido'}), 400
    path = current_app.config['BACKUP_DIR'] / filename
    if not path.exists():
        return jsonify({'error': 'Backup no encontrado'}), 404
    try:
        return send_file(path, as_attachment=True, download_name=filename, mimetype='application/octet-stream')
    except FileNotFoundError:
        return jsonify({'error': 'Backup no encontrado; puede haber sido retirado por la retención.'}), 404

