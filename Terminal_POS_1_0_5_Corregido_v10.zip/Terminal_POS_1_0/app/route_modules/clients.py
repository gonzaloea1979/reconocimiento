"""Rutas de clients."""
from ..route_core import *

@bp.get('/api/clients')
@login_required
def api_clients():
    q = (request.args.get('q') or '').strip()
    if q:
        like = like_contains(q)
        db = get_db()
        has_trigram = len(q) >= 3 and db.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='clients_search'"
        ).fetchone()
        if has_trigram:
            try:
                rows = db.execute('''
                    SELECT c.* FROM clients c
                    JOIN (
                        SELECT rowid FROM clients_search WHERE name LIKE ? ESCAPE '\\'
                        UNION
                        SELECT rowid FROM clients_search WHERE document LIKE ? ESCAPE '\\'
                        UNION
                        SELECT rowid FROM clients_search WHERE phone LIKE ? ESCAPE '\\'
                    ) matches ON matches.rowid=c.id
                    ORDER BY c.name ASC LIMIT 200
                ''', (like, like, like)).fetchall()
            except sqlite3.OperationalError:
                rows = db.execute('''
                    SELECT * FROM clients WHERE name LIKE ? ESCAPE '\\' OR document LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\'
                    ORDER BY name ASC LIMIT 200
                ''', (like, like, like)).fetchall()
        else:
            rows = db.execute('''
                SELECT * FROM clients WHERE name LIKE ? ESCAPE '\\' OR document LIKE ? ESCAPE '\\' OR phone LIKE ? ESCAPE '\\'
                ORDER BY name ASC LIMIT 200
            ''', (like, like, like)).fetchall()
    else:
        rows = get_db().execute('SELECT * FROM clients ORDER BY name ASC LIMIT 300').fetchall()
    return jsonify([client_to_dict(r) for r in rows])

@bp.post('/api/clients')
@login_required
@rollback_on_db_error
@require_json_object
def api_create_client():
    data = request.get_json(force=True)
    try:
        name = text_field(data.get('name'))
        document = text_field(data.get('document'))
        phone = text_field(data.get('phone'))
        address = text_field(data.get('address'))
        notes = text_field(data.get('notes'))
        balance = non_negative_amount(data.get('balance'), 'Saldo inicial')
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    if not name:
        return jsonify({'error': 'Ingresá el nombre del cliente'}), 400
    stamp = now_iso()
    db = get_db()
    cur = db.execute('''
        INSERT INTO clients (name, document, phone, address, notes, balance, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (name, document, phone, address, notes, balance, stamp, stamp))
    if balance > 0:
        db.execute('''
            INSERT INTO client_movements (client_id, movement_type, amount, description, created_at)
            VALUES (?, 'Saldo inicial', ?, 'Saldo pendiente al dar de alta al cliente', ?)
        ''', (cur.lastrowid, balance, stamp))
    log_audit('Crear cliente', 'Clientes', name)
    db.commit()
    return jsonify(client_to_dict(get_db().execute('SELECT * FROM clients WHERE id=?', (cur.lastrowid,)).fetchone())), 201

@bp.put('/api/clients/<int:client_id>')
@login_required
@rollback_on_db_error
@require_json_object
def api_update_client(client_id):
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403
    try:
        name = text_field(data.get('name'))
        document = text_field(data.get('document'))
        phone = text_field(data.get('phone'))
        address = text_field(data.get('address'))
        notes = text_field(data.get('notes'))
    except ValueError as exc:
        return jsonify({'error': str(exc)}), 400
    if not name:
        return jsonify({'error': 'Ingresá el nombre del cliente'}), 400
    db = get_db()
    db.execute('BEGIN IMMEDIATE')
    if not db.execute('SELECT 1 FROM clients WHERE id=?', (client_id,)).fetchone():
        db.rollback()
        return jsonify({'error': 'Cliente no encontrado'}), 404
    db.execute('''
        UPDATE clients SET name=?, document=?, phone=?, address=?, notes=?, updated_at=? WHERE id=?
    ''', (name, document, phone, address, notes, now_iso(), client_id))
    log_audit('Editar cliente', 'Clientes', name)
    get_db().commit()
    row = get_db().execute('SELECT * FROM clients WHERE id=?', (client_id,)).fetchone()
    return jsonify(client_to_dict(row))

@bp.post('/api/clients/<int:client_id>/payment')
@login_required
@rollback_on_db_error
@idempotent_operation
def api_client_payment(client_id):
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({'error': 'Los datos del pago deben ser un objeto válido'}), 400
    if data.get('description') is not None and not isinstance(data['description'], str):
        return jsonify({'error': 'La descripción del pago debe ser texto'}), 400
    try:
        amount = strict_number(data.get('amount'), 'Importe del pago')
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    if amount <= 0:
        return jsonify({'error': 'El importe debe ser mayor a cero'}), 400
    client = get_db().execute('SELECT * FROM clients WHERE id=?', (client_id,)).fetchone()
    if not client:
        return jsonify({'error': 'Cliente no encontrado'}), 404
    # Un pago no puede superar la deuda vigente: dejaría un saldo negativo que
    # el POS no interpreta como crédito a favor. Se valida bajo el mismo bloqueo
    # que la resta para que el saldo concurrente no permita un sobrepago.
    updated = get_db().execute(
        'UPDATE clients SET balance=ROUND(balance - ?, 2), updated_at=? WHERE id=? AND balance + 0.005 >= ?',
        (amount, now_iso(), client_id, amount))
    if updated.rowcount != 1:
        get_db().rollback()
        return jsonify({'error': f'El importe no puede superar el saldo pendiente del cliente ({money(client["balance"])}).'}), 400
    new_balance = money(get_db().execute('SELECT balance FROM clients WHERE id=?', (client_id,)).fetchone()['balance'])
    get_db().execute('''
        INSERT INTO client_movements (client_id, movement_type, amount, description, created_at)
        VALUES (?, 'Pago', ?, ?, ?)
    ''', (client_id, amount, (data.get('description') or 'Pago de cuenta corriente').strip(), now_iso()))
    add_cash_movement('Ingreso', amount, f'Pago cliente {client["name"]}', 'Efectivo')
    log_audit('Pago cliente', 'Clientes', f'{client["name"]}: {amount}')
    commit_operation(get_db())
    return jsonify({'ok': True, 'balance': new_balance})

@bp.get('/api/clients/<int:client_id>/movements')
@login_required
def api_client_movements(client_id):
    rows = get_db().execute('SELECT * FROM client_movements WHERE client_id=? ORDER BY id DESC LIMIT 200', (client_id,)).fetchall()
    return jsonify([{**dict(r), 'created_at_formatted': format_datetime_ar(r['created_at'])} for r in rows])

@bp.get('/api/clients/export')
@login_required
def api_clients_export():
    import xlwt

    rows = get_db().execute('SELECT * FROM clients ORDER BY balance DESC, name ASC')
    book = xlwt.Workbook()
    sheet = book.add_sheet('Clientes')
    headers = ['ID', 'Nombre', 'DNI/CUIT', 'Teléfono', 'Dirección', 'Saldo', 'Notas']
    for cidx, h in enumerate(headers):
        sheet.write(0, cidx, h)
    for ridx, row in enumerate(rows, start=1):
        values = [row['id'], row['name'], row['document'], row['phone'], row['address'], money(row['balance']), row['notes']]
        for cidx, value in enumerate(values):
            sheet.write(ridx, cidx, value)
    output = BytesIO(); book.save(output); output.seek(0)
    return send_file(output, as_attachment=True, download_name=f'clientes_cuenta_corriente_{date.today().strftime("%d-%m-%Y")}.xls', mimetype='application/vnd.ms-excel')

@bp.get('/api/clients/<int:client_id>/export')
@login_required
def api_client_statement_export(client_id):
    import xlwt

    db = get_db()
    # Saldo de cabecera y movimientos deben pertenecer a la misma lectura,
    # aunque otro cajero registre un pago mientras se genera el archivo.
    db.execute('BEGIN')
    client = db.execute('SELECT * FROM clients WHERE id=?', (client_id,)).fetchone()
    if not client:
        db.rollback()
        return jsonify({'error': 'Cliente no encontrado'}), 404
    movements = db.execute('SELECT * FROM client_movements WHERE client_id=? ORDER BY id ASC', (client_id,))
    book = xlwt.Workbook(); sheet = book.add_sheet('Cuenta corriente')
    header_rows = [
        ['Cliente', client['name']], ['DNI/CUIT', client['document'] or ''], ['Teléfono', client['phone'] or ''], ['Saldo actual', money(client['balance'])], [],
        ['Fecha', 'Tipo', 'Importe', 'Detalle']
    ]
    for r, row in enumerate(header_rows):
        for cidx, value in enumerate(row):
            sheet.write(r, cidx, value)
    for ridx, movement in enumerate(movements, start=len(header_rows)):
        values = [format_datetime_ar(movement['created_at']), movement['movement_type'], money(movement['amount']), movement['description'] or '']
        for cidx, value in enumerate(values):
            sheet.write(ridx, cidx, value)
    db.rollback()  # Fin de la lectura consistente; no hubo escrituras.
    output = BytesIO(); book.save(output); output.seek(0)
    safe_name = secure_filename(client['name']) or 'cliente'
    return send_file(output, as_attachment=True, download_name=f'cuenta_corriente_{safe_name}_{date.today().strftime("%d-%m-%Y")}.xls', mimetype='application/vnd.ms-excel')

