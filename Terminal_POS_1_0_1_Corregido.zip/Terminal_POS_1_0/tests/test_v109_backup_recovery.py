"""Prueba integral aislada del mecanismo real de respaldo, restauración y errores.
No abre ni modifica instance/pos.db del negocio.
"""
import importlib.util
import sqlite3
import sys
import tempfile
import types
from contextlib import closing
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
class FakeApp:
    config={}
fake=types.ModuleType('flask')
fake.current_app=FakeApp()
fake.g=types.SimpleNamespace()
prior=sys.modules.get('flask')
sys.modules['flask']=fake
try:
    spec=importlib.util.spec_from_file_location('pos_v109_db_test',ROOT/'app/db.py')
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
finally:
    if prior is None:sys.modules.pop('flask',None)
    else:sys.modules['flask']=prior

with tempfile.TemporaryDirectory(prefix='pos_v109_recovery_') as tmp:
    base=Path(tmp)
    source=base/'source_sintetica.db'
    backups=base/'respaldos'
    backups.mkdir()
    with closing(sqlite3.connect(source)) as db:
        db.execute('PRAGMA journal_mode=WAL')
        db.execute('PRAGMA foreign_keys=ON')
        db.executescript('''
        CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT NOT NULL, stock REAL NOT NULL);
        CREATE TABLE sales(id INTEGER PRIMARY KEY, total REAL NOT NULL);
        CREATE TABLE sale_items(id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL REFERENCES sales(id),product_id INTEGER NOT NULL REFERENCES products(id),quantity REAL NOT NULL);
        CREATE TABLE cash_sessions(id INTEGER PRIMARY KEY,status TEXT NOT NULL,initial_amount REAL NOT NULL);
        CREATE TABLE cash_movements(id INTEGER PRIMARY KEY,cash_session_id INTEGER NOT NULL REFERENCES cash_sessions(id),amount REAL NOT NULL);
        INSERT INTO products VALUES(1,'Articulo ficticio',7);
        INSERT INTO sales VALUES(1,42.50);
        INSERT INTO sale_items VALUES(1,1,1,2);
        INSERT INTO cash_sessions VALUES(1,'abierta',100);
        INSERT INTO cash_movements VALUES(1,1,42.50);
        ''')
        db.commit()
        expected={name:db.execute(f'SELECT * FROM {name}').fetchall() for name in ('products','sales','sale_items','cash_sessions','cash_movements')}
        fake.current_app.config={'DATABASE':source,'BACKUP_DIR':backups}
        snapshot=mod.backup_database()
        assert snapshot.is_file(), 'No se creó el respaldo'
        # Cambiar origen DESPUÉS del respaldo para comprobar recuperación histórica.
        db.execute("UPDATE products SET stock=1 WHERE id=1")
        db.execute("INSERT INTO sales VALUES(2,999)")
        db.commit()
    restored=base/'restaurada.db'
    with closing(sqlite3.connect(snapshot)) as previous,closing(sqlite3.connect(restored)) as target:
        previous.backup(target)
    with closing(sqlite3.connect(restored)) as db:
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        assert db.execute('PRAGMA foreign_key_check').fetchall()==[]
        for name,rows in expected.items():
            assert db.execute(f'SELECT * FROM {name}').fetchall()==rows, f'Datos distintos después de restaurar {name}'
    print('OK: restauración fiel de ventas, stock y movimientos de caja, con integridad SQLite')

    before={p.name:p.stat().st_size for p in backups.glob('pos_backup_*.db')}
    original_backup=sqlite3.Connection.backup
    # Sustituir SOLO el conector del módulo probado por un origen cuyo backup falla.
    original_connect=mod.connect_database
    class BrokenSource:
        def __enter__(self):return self
        def __exit__(self,*args):return False
        def close(self):pass
        def backup(self,_target):raise sqlite3.OperationalError('fallo simulado de copia')
    def fail_source(path,*args,**kwargs):
        if Path(path)==source:return BrokenSource()
        return original_connect(path,*args,**kwargs)
    with patch.object(mod,'connect_database',side_effect=fail_source):
        try:mod.backup_database()
        except sqlite3.OperationalError as e: assert 'fallo simulado' in str(e)
        else:raise AssertionError('Se informó éxito tras un fallo de respaldo')
    after={p.name:p.stat().st_size for p in backups.glob('pos_backup_*.db')}
    assert before==after, 'El respaldo fallido publicó o modificó un archivo'
    assert not list(backups.glob('.pos_backup_*.tmp')), 'Quedaron temporales de un respaldo fallido'
    with closing(sqlite3.connect(source)) as db:
        assert db.execute('SELECT stock FROM products WHERE id=1').fetchone()[0]==1
        assert db.execute('SELECT COUNT(*) FROM sales').fetchone()[0]==2
    print('OK: un respaldo fallido no genera archivo final, no borra copias previas y no modifica origen')

print('OK: prueba V109 completada únicamente con datos sintéticos temporales')
