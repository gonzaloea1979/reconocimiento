from pathlib import Path
root=Path(__file__).resolve().parents[1]
s=(root/'prueba_carga_v105.py').read_text(encoding='utf-8')
assert 'evaluate_variants(db_path)' in s
assert 'prueba_carga_v105.txt' in s
assert 'for workers in (1, 2):' in s
assert 'for workers in (1, 2, 4, 8):' not in s
assert 'TemporaryDirectory(prefix="terminal_pos_v105_")' in s
assert (root/'VERSION.txt').read_text().strip() in ('V105','V106','V107','V108','V108.1 - CORRECCION APERTURA ATOMICA DE CAJA','V109 - RESPALDOS Y RECUPERACION AISLADA','V109.1 - CIERRE CONEXIONES EN PRUEBAS WINDOWS','V110-RC1 - CANDIDATA FINAL TERMINAL POS 1.0','Terminal POS 1.0 - paquete de compilacion Windows (candidato final)','Terminal POS 1.0.1 - correcciones de saldos y cierre de caja')
print('OK: V105 ejecuta A/B con 1-2 usuarios y base temporal aislada.')
