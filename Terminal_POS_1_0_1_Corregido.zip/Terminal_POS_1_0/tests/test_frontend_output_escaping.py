"""Regresiones para evitar XSS almacenado en las pantallas del POS."""
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[1]
COMMON = (ROOT / 'app' / 'static' / 'js' / 'common.js').read_text(encoding='utf-8')

assert 'function escapeHTML(value)' in COMMON
assert 'escapeHTML(p.name)' in COMMON
assert "escapeHTML(p.barcode || 'Sin código')" in COMMON

checks = {
    'clients.js': ["escapeHTML(c.name)", "escapeHTML(m.description||'')"],
    'suppliers.js': ['escapeHTML(s.name)', "escapeHTML(s.phone||'')"],
    'audit.js': ['escapeHTML(r.user_name||\'\')', 'escapeHTML(r.detail||\'\')'],
    'stock.js': ['escapeHTML(p.name)', 'escapeHTML(r.product_name)'],
    'cash.js': ['escapeHTML(m.description||\'\')'],
    'users.js': ['escapeHTML(user.username)', 'escapeHTML(role)'],
    'price_check.js': ['escapeHTML(product.name)', "escapeHTML(product.barcode || 'Sin código')"],
    'price_lists.js': ['escapeHTML(error)', 'escapeHTML(d)'],
    'ticket_design.js': ['escapeHTML(versionedUrl)'],
    'reports.js': ['escapeHTML(title)', 'escapeHTML(subtitle)'],
    'purchases.js': ['escapeHTML(i.product_name)', 'escapeHTML(items)'],
    'products.js': ['escapeHTML(p.photo_url)', 'escapeHTML(p.name)'],
    'settings.js': ['escapeHTML(row.filename)', 'escapeHTML(err.message)'],
}
for filename, fragments in checks.items():
    source = (ROOT / 'app' / 'static' / 'js' / filename).read_text(encoding='utf-8')
    for fragment in fragments:
        assert fragment in source, f'{filename}: falta escape en {fragment}'

node = shutil.which('node')
if node:
    script = """
const fs = require('fs');
const vm = require('vm');
const source = fs.readFileSync(process.argv[1], 'utf8');
const context = {
  document: { addEventListener() {}, querySelectorAll() { return []; } },
  window: { addEventListener() {}, location: { pathname: '/' } },
  console, setTimeout, clearTimeout, setInterval, clearInterval
};
vm.createContext(context);
vm.runInContext(source, context);
const input = `<img src=x onerror='alert(1)'>&`;
const output = context.escapeHTML(input);
if (output !== '&lt;img src=x onerror=&#039;alert(1)&#039;&gt;&amp;') {
  throw new Error('escapeHTML no neutraliza etiquetas, comillas y ampersands: ' + output);
}
console.log('OK: helper HTML escapa etiquetas y atributos');
"""
    result = subprocess.run([node, '-e', script, str(ROOT / 'app' / 'static' / 'js' / 'common.js')],
                            capture_output=True, text=True)
    assert result.returncode == 0, result.stdout + result.stderr
    print(result.stdout.strip())
else:
    print('AVISO: Node.js no está disponible; se omitió la prueba dinámica del helper.')

print('OK: datos persistidos escapados en los principales módulos de interfaz')
