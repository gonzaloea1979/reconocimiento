"""Verificación de artefacto de Windows en carpeta de salida, solo lectura."""
from pathlib import Path
import sys
root = Path(sys.argv[1] if len(sys.argv) > 1 else 'dist/TerminalPOS')
exe=root/'TerminalPOS.exe'
assert exe.is_file() and exe.stat().st_size>100_000, f'No existe un EXE compilado valido: {exe}'
with exe.open('rb') as f: assert f.read(2)==b'MZ', 'El archivo no tiene cabecera PE/DOS (MZ)'
assert (root/'app/templates').is_dir(), 'Faltan templates externos'
assert (root/'app/static').is_dir(), 'Faltan recursos estaticos externos'
assert (root/'INICIAR_POS.bat').exists(), 'Falta lanzador'
for path in root.rglob('*'):
    if path.is_file():
        name=path.name.lower()
        assert name not in {'pos.db','pos.db-wal','pos.db-shm','.session_key'}, f'Dato privado en distribucion: {path}'
        if 'uploads' in [part.lower() for part in path.relative_to(root).parts]:
            raise AssertionError(f'Foto privada incluida: {path}')
print('OK: EXE Windows MZ, recursos presentes, sin base comercial ni uploads externos')
print('AVISO: este chequeo estructural NO reemplaza abrir el EXE y probar ventas/caja.')
