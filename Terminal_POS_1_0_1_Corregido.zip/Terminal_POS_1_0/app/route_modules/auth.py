"""Rutas de auth."""
from ..route_core import *

@bp.get('/primer-inicio')
def first_setup_page():
    if active_admin_exists():
        return redirect(url_for('main.dashboard'))
    return render_template('first_setup.html')

@bp.post('/api/first-setup')
def api_first_setup():
    if active_admin_exists():
        return jsonify({'ok': True, 'already_configured': True})

    data = request.get_json(force=True)
    username = (data.get('username') or 'admin').strip()
    password = (data.get('password') or '').strip()
    confirm_password = (data.get('confirm_password') or '').strip()

    if not username:
        return jsonify({'error': 'Ingresá el usuario administrador'}), 400
    if len(username) < 3:
        return jsonify({'error': 'El usuario debe tener al menos 3 caracteres'}), 400
    if len(password) < 4:
        return jsonify({'error': 'La contraseña debe tener al menos 4 caracteres'}), 400
    if password != confirm_password:
        return jsonify({'error': 'Las contraseñas no coinciden'}), 400

    try:
        create_first_admin(username, password)
    except Exception:
        current_app.logger.exception('No se pudo crear el administrador inicial')
        return jsonify({'error': 'No se pudo crear el administrador. Verificá el usuario e intentá nuevamente.'}), 400

    session.clear()
    session['logged_in'] = True
    session['authenticated_login'] = True
    session['local_auto_login'] = False
    session['username'] = username
    session['user_role'] = 'Administrador'
    return jsonify({'ok': True, 'redirect': url_for('main.dashboard')})

@bp.get('/login')
def login_page():
    # El inicio local no solicita contraseña: utiliza el administrador activo.
    if not active_admin_exists():
        return redirect(url_for('main.first_setup_page'))
    if not start_default_admin_session():
        return redirect(url_for('main.first_setup_page'))
    return redirect(url_for('main.dashboard'))

@bp.post('/api/login')
def api_login():
    data = request.get_json(force=True)
    username = (data.get('username') or '').strip()
    password = data.get('password') or ''
    settings = get_settings()
    valid_user = username.lower() == (settings.get('login_username') or 'admin').lower()
    valid_password = password_matches(password, settings.get('login_password_hash'))
    if not valid_user or not valid_password:
        return jsonify({'error': 'Usuario o contraseña incorrectos'}), 403
    session.clear()
    session['logged_in'] = True
    session['authenticated_login'] = True
    session['local_auto_login'] = False
    session['username'] = username
    try:
        row = get_db().execute("SELECT role FROM users WHERE is_active=1 AND LOWER(username)=LOWER(?) LIMIT 1", (username,)).fetchone()
        session['user_role'] = row['role'] if row else 'Cajero'
    except Exception:
        session['user_role'] = 'Cajero'
    return jsonify({'ok': True})

@bp.post('/api/logout')
@login_required
def api_logout():
    session.clear()
    return jsonify({'ok': True})

@bp.post('/api/shutdown')
def api_shutdown():
    """Cierra el POS solo desde una sesión ya establecida en la interfaz."""
    # No usar login_required aquí: ese decorador crea una sesión local automática
    # para cualquier solicitud. Para esta acción destructiva exigimos una sesión
    # que ya exista antes de recibir la petición.
    if not active_admin_exists():
        return jsonify({'error': 'Primero tenés que configurar el administrador.', 'setup_required': True}), 428
    if not session.get('logged_in'):
        return jsonify({'error': 'La sesión no está iniciada.'}), 401
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({'error': 'Solicitud de cierre inválida'}), 400
    # No convertir cadenas como "false" o "0" en una orden de apagado.
    shutdown_pc = data.get('shutdown_pc') is True
    # Apagar físicamente la computadora es una acción administrativa.
    # El cierre normal del POS sigue disponible para una sesión válida.
    if shutdown_pc and not current_user_is_admin():
        return jsonify({'error': 'Solo un administrador puede apagar la computadora.'}), 403
    base_dir = current_app.config.get('BASE_DIR') or os.path.abspath(os.path.join(current_app.root_path, os.pardir))

    try:
        backup_path = backup_database()
        if backup_path is None:
            raise RuntimeError('No se encontró la base de datos para respaldar.')
    except Exception:
        current_app.logger.exception('No se pudo crear el respaldo previo al cierre del POS.')
        return jsonify({
            'error': 'No se pudo crear el respaldo de seguridad. El sistema permanece abierto para proteger los datos.'
        }), 503

    def delayed_shutdown():
        # Dejamos que el navegador reciba la respuesta, luego cerramos la ventana dedicada,
        # apagamos la PC si corresponde y finalmente detenemos el servidor local.
        time.sleep(0.8)
        _close_dedicated_browser_window(base_dir)
        if shutdown_pc:
            time.sleep(0.2)
            _shutdown_pc()
        time.sleep(0.2)
        os._exit(0)

    threading.Thread(target=delayed_shutdown, daemon=True).start()
    return jsonify({'ok': True, 'message': 'Sistema cerrado correctamente', 'shutdown_pc': shutdown_pc})

