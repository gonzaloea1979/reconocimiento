"""Rutas de clients."""
from ..route_core import *

@bp.get('/api/clients')
@login_required
def api_clients():
    q = (request.args.get('q') or '').strip()
    if q:
        like = f'%{q}%'
        db = get_db()
        has_trigram = len(q) >= 3 and db.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='clients_search'"
        ).fetchone()
        if has_trigram:
            try:
                rows = db.execute('''
                    SELECT c.* FROM clients c
                    JOIN (
                        SELECT rowid FROM clients_search WHERE name LIKE ?
                        UNION
                        SELECT rowid FROM clients_search WHERE document LIKE ?
                        UNION
                        SELECT rowid FROM clients_search WHERE phone LIKE ?
                    ) matches ON matches.rowid=c.id
                    ORDER BY c.name ASC LIMIT 200
                ''', (like, like, like)).fetchall()
            except sqlite3.OperationalError:
                rows = db.execute('''
                    SELECT * FROM clients WHERE name LIKE ? OR document LIKE ? OR phone LIKE ?
                    ORDER BY name ASC LIMIT 200
                ''', (like, like, like)).fetchall()
        else:
            rows = db.execute('''
                SELECT * FROM clients WHERE name LIKE ? OR document LIKE ? OR phone LIKE ?
                ORDER BY name ASC LIMIT 200
            ''', (like, like, like)).fetchall()
    else:
        rows = get_db().execute('SELECT * FROM clients ORDER BY name ASC LIMIT 300').fetchall()
    return jsonify([client_to_dict(r) for r in rows])

@bp.post('/api/clients')
@login_required
def api_create_client():
    data = request.get_json(force=True)
    name = (data.get('name') or '').strip()
    if not name:
        return jsonify({'error': 'Ingresá el nombre del cliente'}), 400
    stamp = now_iso()
    cur = get_db().execute('''
        INSERT INTO clients (name, document, phone, address, notes, balance, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (name, (data.get('document') or '').strip(), (data.get('phone') or '').strip(),
          (data.get('address') or '').strip(), (data.get('notes') or '').strip(), money(data.get('balance')), stamp, stamp))
    log_audit('Crear cliente', 'Clientes', name)
    get_db().commit()
    return jsonify(client_to_dict(get_db().execute('SELECT * FROM clients WHERE id=?', (cur.lastrowid,)).fetchone())), 201

@bp.put('/api/clients/<int:client_id>')
@login_required
def api_update_client(client_id):
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403
    name = (data.get('name') or '').strip()
    if not name:
        return jsonify({'error': 'Ingresá el nombre del cliente'}), 400
    get_db().execute('''
        UPDATE clients SET name=?, document=?, phone=?, address=?, notes=?, updated_at=? WHERE id=?
    ''', (name, (data.get('document') or '').strip(), (data.get('phone') or '').strip(),
          (data.get('address') or '').strip(), (data.get('notes') or '').strip(), now_iso(), client_id))
    log_audit('Editar cliente', 'Clientes', name)
    get_db().commit()
    row = get_db().execute('SELECT * FROM clients WHERE id=?', (client_id,)).fetchone()
    return jsonify(client_to_dict(row))

@bp.post('/api/clients/<int:client_id>/payment')
@login_required
@rollback_on_db_error
def api_client_payment(client_id):
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({'error': 'Los datos del pago deben ser un objeto válido'}), 400
    if data.get('description') is not None and not isinstance(data['description'], str):
        return jsonify({'error': 'La descripción del pago debe ser texto'}), 400
    try:
        amount = strict_number(data.get('amount'), 'Importe del pago')
    except (TypeError, ValueError) as exc:
        return jsonify({'error': str(exc)}), 400
    if amount <= 0:
        return jsonify({'error': 'El importe debe ser mayor a cero'}), 400
    client = get_db().execute('SELECT * FROM clients WHERE id=?', (client_id,)).fetchone()
    if not client:
        return jsonify({'error': 'Cliente no encontrado'}), 404
    # Restar sobre el saldo vigente bajo bloqueo, no sobre la lectura previa.
    get_db().execute('UPDATE clients SET balance=ROUND(balance - ?, 2), updated_at=? WHERE id=?',
                     (amount, now_iso(), client_id))
    new_balance = money(get_db().execute('SELECT balance FROM clients WHERE id=?', (client_id,)).fetchone()['balance'])
    get_db().execute('''
        INSERT INTO client_movements (client_id, movement_type, amount, description, created_at)
        VALUES (?, 'Pago', ?, ?, ?)
    ''', (client_id, amount, (data.get('description') or 'Pago de cuenta corriente').strip(), now_iso()))
    add_cash_movement('Ingreso', amount, f'Pago cliente {client["name"]}', 'Efectivo')
    log_audit('Pago cliente', 'Clientes', f'{client["name"]}: {amount}')
    get_db().commit()
    return jsonify({'ok': True, 'balance': new_balance})

@bp.get('/api/clients/<int:client_id>/movements')
@login_required
def api_client_movements(client_id):
    rows = get_db().execute('SELECT * FROM client_movements WHERE client_id=? ORDER BY id DESC LIMIT 200', (client_id,)).fetchall()
    return jsonify([{**dict(r), 'created_at_formatted': format_datetime_ar(r['created_at'])} for r in rows])

@bp.get('/api/clients/export')
@login_required
def api_clients_export():
    import xlwt

    rows = get_db().execute('SELECT * FROM clients ORDER BY balance DESC, name ASC')
    book = xlwt.Workbook()
    sheet = book.add_sheet('Clientes')
    headers = ['ID', 'Nombre', 'DNI/CUIT', 'Teléfono', 'Dirección', 'Saldo', 'Notas']
    for cidx, h in enumerate(headers):
        sheet.write(0, cidx, h)
    for ridx, row in enumerate(rows, start=1):
        values = [row['id'], row['name'], row['document'], row['phone'], row['address'], money(row['balance']), row['notes']]
        for cidx, value in enumerate(values):
            sheet.write(ridx, cidx, value)
    output = BytesIO(); book.save(output); output.seek(0)
    return send_file(output, as_attachment=True, download_name=f'clientes_cuenta_corriente_{date.today().strftime("%d-%m-%Y")}.xls', mimetype='application/vnd.ms-excel')

@bp.get('/api/clients/<int:client_id>/export')
@login_required
def api_client_statement_export(client_id):
    import xlwt

    client = get_db().execute('SELECT * FROM clients WHERE id=?', (client_id,)).fetchone()
    if not client:
        return jsonify({'error': 'Cliente no encontrado'}), 404
    movements = get_db().execute('SELECT * FROM client_movements WHERE client_id=? ORDER BY id ASC', (client_id,))
    book = xlwt.Workbook(); sheet = book.add_sheet('Cuenta corriente')
    header_rows = [
        ['Cliente', client['name']], ['DNI/CUIT', client['document'] or ''], ['Teléfono', client['phone'] or ''], ['Saldo actual', money(client['balance'])], [],
        ['Fecha', 'Tipo', 'Importe', 'Detalle']
    ]
    for r, row in enumerate(header_rows):
        for cidx, value in enumerate(row):
            sheet.write(r, cidx, value)
    for ridx, movement in enumerate(movements, start=len(header_rows)):
        values = [format_datetime_ar(movement['created_at']), movement['movement_type'], money(movement['amount']), movement['description'] or '']
        for cidx, value in enumerate(values):
            sheet.write(ridx, cidx, value)
    output = BytesIO(); book.save(output); output.seek(0)
    safe_name = secure_filename(client['name']) or 'cliente'
    return send_file(output, as_attachment=True, download_name=f'cuenta_corriente_{safe_name}_{date.today().strftime("%d-%m-%Y")}.xls', mimetype='application/vnd.ms-excel')

