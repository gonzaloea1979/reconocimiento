"""Rutas de prices."""
from ..route_core import *

@bp.get('/api/prices/export')
@login_required
def api_export_prices():
    rows = get_db().execute('SELECT * FROM products ORDER BY name ASC')
    output = write_xls_products(rows)
    filename = f'lista_precios_{date.today().strftime("%d-%m-%Y")}.xls'
    return send_file(
        output,
        as_attachment=True,
        download_name=filename,
        mimetype='application/vnd.ms-excel'
    )

@bp.get('/api/prices/template')
@login_required
def api_prices_template():
    output = write_xls_products([])
    return send_file(
        output,
        as_attachment=True,
        download_name='plantilla_lista_precios.xls',
        mimetype='application/vnd.ms-excel'
    )

@bp.post('/api/prices/import')
@login_required
def api_import_prices():
    import xlrd

    if not require_security_password_from_payload(request.form):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403

    file = request.files.get('file')
    if not file or not file.filename:
        return jsonify({'error': 'Tenés que seleccionar un archivo .xls'}), 400
    if not file.filename.lower().endswith('.xls'):
        return jsonify({'error': 'El archivo debe tener formato .xls'}), 400

    try:
        content = file.read()
        book = xlrd.open_workbook(file_contents=content)
        sheet = book.sheet_by_index(0)
    except Exception:
        current_app.logger.exception('No se pudo abrir la lista de precios Excel')
        return jsonify({'error': 'No se pudo abrir el archivo Excel. Verificá que sea un .xls válido.'}), 400

    header_row = None
    header_map = {}
    normalized_expected = {h.lower().strip(): h for h in EXCEL_HEADERS}
    for r in range(min(sheet.nrows, 10)):
        possible = [excel_text(sheet.cell_value(r, c)).lower().strip() for c in range(sheet.ncols)]
        if 'nombre' in possible and ('precio venta' in possible or 'código de barra' in possible):
            header_row = r
            for c, name in enumerate(possible):
                if name in normalized_expected:
                    header_map[normalized_expected[name]] = c
            break

    if header_row is None:
        return jsonify({'error': 'No se encontró la fila de encabezados. Usá el archivo exportado o la plantilla del sistema.'}), 400
    if 'Nombre' not in header_map:
        return jsonify({'error': 'La columna Nombre es obligatoria'}), 400

    db = get_db()
    created = 0
    updated = 0
    skipped = 0
    errors = []
    stamp = now_iso()
    rounding_mode, rounding_multiple = get_global_product_rounding()

    def col_value(row_index, header, default=''):
        c = header_map.get(header)
        if c is None or c >= sheet.ncols:
            return default
        return sheet.cell_value(row_index, c)

    for r in range(header_row + 1, sheet.nrows):
        try:
            raw_name = excel_text(col_value(r, 'Nombre'))
            if not raw_name:
                skipped += 1
                continue

            raw_id = excel_text(col_value(r, 'ID'))
            product_id = int(float(raw_id)) if raw_id else None
            barcode = excel_text(col_value(r, 'Código de barra')) or None
            detail = excel_text(col_value(r, 'Detalle'))
            cost = excel_number(col_value(r, 'Precio sin impuestos'))
            iva = excel_number(col_value(r, 'IVA %'))
            gross = excel_number(col_value(r, 'Ingresos brutos %'))
            margin = excel_number(col_value(r, 'Margen ganancia %'))
            total_cost_cell = col_value(r, 'Costo total')
            sale_price_cell = col_value(r, 'Precio venta')
            calc_total_cost, calc_sale_price = calculate_prices(cost, iva, gross, margin, rounding_mode, rounding_multiple)
            total_cost = excel_number(total_cost_cell) if total_cost_cell not in ('', None) else calc_total_cost
            sale_price = excel_number(sale_price_cell) if sale_price_cell not in ('', None) else calc_sale_price
            if margin == 0 and total_cost > 0 and sale_price > 0:
                margin = money(((sale_price / total_cost) - 1) * 100)
            if total_cost == 0:
                total_cost = calc_total_cost
            stock = excel_number(col_value(r, 'Stock'))
            try:
                expiry_date = read_xls_date(book, sheet, r, header_map.get('Fecha vencimiento'))
            except ValueError as exc:
                raise ValueError(f'Fecha vencimiento inválida: {exc}')

            existing = None
            if product_id:
                existing = db.execute('SELECT id FROM products WHERE id=?', (product_id,)).fetchone()
            if not existing and barcode:
                existing = db.execute('SELECT id FROM products WHERE barcode=?', (barcode,)).fetchone()

            if existing:
                db.execute("""
                    UPDATE products
                    SET barcode=?, name=?, detail=?, cost_without_tax=?, iva_percent=?, gross_income_percent=?,
                        total_cost=?, margin_percent=?, rounding_mode=?, rounding_multiple=?, sale_price=?, stock=?, expiry_date=?, updated_at=?
                    WHERE id=?
                """, (barcode, raw_name, detail, cost, iva, gross, total_cost, margin, rounding_mode, rounding_multiple, sale_price, stock, expiry_date, stamp, existing['id']))
                updated += 1
            else:
                db.execute("""
                    INSERT INTO products (
                        barcode, name, detail, cost_without_tax, iva_percent, gross_income_percent,
                        total_cost, margin_percent, rounding_mode, rounding_multiple, sale_price, stock, expiry_date, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (barcode, raw_name, detail, cost, iva, gross, total_cost, margin, rounding_mode, rounding_multiple, sale_price, stock, expiry_date, stamp, stamp))
                created += 1
        except Exception as exc:
            errors.append(f'Fila {r + 1}: {exc}')
            if len(errors) >= 10:
                break

    if errors:
        db.rollback()
        return jsonify({'error': 'No se importó nada porque hay errores en el archivo.', 'details': errors}), 400

    db.commit()
    return jsonify({'ok': True, 'created': created, 'updated': updated, 'skipped': skipped})

