"""Rutas de suppliers."""
from ..route_core import *

@bp.get('/api/suppliers')
@login_required
def api_suppliers():
    q = (request.args.get('q') or '').strip()
    if q:
        like = f'%{q}%'
        db = get_db()
        has_trigram = len(q) >= 3 and db.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='suppliers_search'"
        ).fetchone()
        if has_trigram:
            try:
                rows = db.execute('''
                    SELECT s.* FROM suppliers s
                    JOIN (
                        SELECT rowid FROM suppliers_search WHERE name LIKE ?
                        UNION
                        SELECT rowid FROM suppliers_search WHERE cuit LIKE ?
                        UNION
                        SELECT rowid FROM suppliers_search WHERE phone LIKE ?
                        UNION
                        SELECT rowid FROM suppliers_search WHERE category LIKE ?
                    ) matches ON matches.rowid=s.id
                    ORDER BY s.name ASC LIMIT 200
                ''', (like, like, like, like)).fetchall()
            except sqlite3.OperationalError:
                rows = db.execute('''
                    SELECT * FROM suppliers
                    WHERE name LIKE ? OR cuit LIKE ? OR phone LIKE ? OR category LIKE ?
                    ORDER BY name ASC LIMIT 200
                ''', (like, like, like, like)).fetchall()
        else:
            rows = db.execute('''
                SELECT * FROM suppliers
                WHERE name LIKE ? OR cuit LIKE ? OR phone LIKE ? OR category LIKE ?
                ORDER BY name ASC LIMIT 200
            ''', (like, like, like, like)).fetchall()
    else:
        rows = get_db().execute('SELECT * FROM suppliers ORDER BY name ASC LIMIT 300').fetchall()
    return jsonify([supplier_to_dict(r) for r in rows])

@bp.post('/api/suppliers')
@login_required
def api_create_supplier():
    data = request.get_json(force=True)
    name = (data.get('name') or '').strip()
    if not name:
        return jsonify({'error': 'Ingresá el nombre del proveedor'}), 400
    stamp = now_iso()
    cur = get_db().execute('''
        INSERT INTO suppliers (name, cuit, phone, address, category, notes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (name, (data.get('cuit') or '').strip(), (data.get('phone') or '').strip(),
          (data.get('address') or '').strip(), (data.get('category') or '').strip(),
          (data.get('notes') or '').strip(), stamp, stamp))
    log_audit('Crear proveedor', 'Proveedores', name)
    get_db().commit()
    return jsonify(supplier_to_dict(get_db().execute('SELECT * FROM suppliers WHERE id=?', (cur.lastrowid,)).fetchone())), 201

@bp.put('/api/suppliers/<int:supplier_id>')
@login_required
def api_update_supplier(supplier_id):
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403
    name = (data.get('name') or '').strip()
    if not name:
        return jsonify({'error': 'Ingresá el nombre del proveedor'}), 400
    get_db().execute('''
        UPDATE suppliers SET name=?, cuit=?, phone=?, address=?, category=?, notes=?, updated_at=? WHERE id=?
    ''', (name, (data.get('cuit') or '').strip(), (data.get('phone') or '').strip(),
          (data.get('address') or '').strip(), (data.get('category') or '').strip(),
          (data.get('notes') or '').strip(), now_iso(), supplier_id))
    log_audit('Editar proveedor', 'Proveedores', name)
    get_db().commit()
    row = get_db().execute('SELECT * FROM suppliers WHERE id=?', (supplier_id,)).fetchone()
    return jsonify(supplier_to_dict(row))

@bp.delete('/api/suppliers/<int:supplier_id>')
@login_required
def api_delete_supplier(supplier_id):
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403
    row = get_db().execute('SELECT * FROM suppliers WHERE id=?', (supplier_id,)).fetchone()
    try:
        get_db().execute('DELETE FROM suppliers WHERE id=?', (supplier_id,))
        log_audit('Eliminar proveedor', 'Proveedores', row['name'] if row else str(supplier_id))
        get_db().commit()
    except sqlite3.IntegrityError:
        get_db().rollback()
        return jsonify({'error': 'No se puede eliminar este proveedor porque tiene compras históricas asociadas.'}), 409
    return jsonify({'ok': True})

