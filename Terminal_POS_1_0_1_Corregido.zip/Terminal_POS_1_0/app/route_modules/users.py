"""Rutas de users."""
from ..route_core import *

@bp.get('/api/users')
@login_required
def api_list_users():
    rows = get_db().execute('''
        SELECT id, username, full_name, role, is_active, created_at, updated_at
        FROM users
        ORDER BY is_active DESC, role ASC, username ASC
    ''').fetchall()
    return jsonify([user_to_dict(r) for r in rows])

@bp.post('/api/users')
@login_required
def api_create_user():
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403

    username = (data.get('username') or '').strip()
    full_name = (data.get('full_name') or '').strip()
    role = (data.get('role') or 'Cajero').strip()
    password = (data.get('user_password') or '').strip()
    if not username:
        return jsonify({'error': 'El usuario es obligatorio'}), 400
    if len(username) < 3:
        return jsonify({'error': 'El usuario debe tener al menos 3 caracteres'}), 400
    if role not in ('Administrador', 'Cajero', 'Supervisor'):
        role = 'Cajero'
    if len(password) < 4:
        return jsonify({'error': 'La clave del usuario debe tener al menos 4 caracteres'}), 400

    stamp = now_iso()
    try:
        cur = get_db().execute('''
            INSERT INTO users (username, full_name, role, password_hash, is_active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (username, full_name, role, generate_password_hash(password), 1 if data.get('is_active', True) else 0, stamp, stamp))
        get_db().commit()
    except Exception:
        current_app.logger.exception('No se pudo crear el usuario')
        return jsonify({'error': 'No se pudo crear el usuario. Revisá si el nombre de usuario ya existe.'}), 400

    row = get_db().execute('SELECT * FROM users WHERE id=?', (cur.lastrowid,)).fetchone()
    return jsonify(user_to_dict(row)), 201

@bp.put('/api/users/<int:user_id>')
@login_required
def api_update_user(user_id):
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403

    username = (data.get('username') or '').strip()
    full_name = (data.get('full_name') or '').strip()
    role = (data.get('role') or 'Cajero').strip()
    is_active = 1 if data.get('is_active', True) else 0
    password = (data.get('user_password') or '').strip()
    if not username:
        return jsonify({'error': 'El usuario es obligatorio'}), 400
    if len(username) < 3:
        return jsonify({'error': 'El usuario debe tener al menos 3 caracteres'}), 400
    if role not in ('Administrador', 'Cajero', 'Supervisor'):
        role = 'Cajero'

    current = get_db().execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
    if not current:
        return jsonify({'error': 'Usuario no encontrado'}), 404

    if current['role'] == 'Administrador' and (role != 'Administrador' or not is_active):
        active_admins = get_db().execute(
            "SELECT COUNT(*) AS c FROM users WHERE role='Administrador' AND is_active=1 AND id<>?",
            (user_id,)
        ).fetchone()['c']
        if active_admins == 0:
            return jsonify({'error': 'Debe quedar al menos un administrador activo'}), 400

    try:
        if password:
            if len(password) < 4:
                return jsonify({'error': 'La nueva clave del usuario debe tener al menos 4 caracteres'}), 400
            get_db().execute('''
                UPDATE users
                SET username=?, full_name=?, role=?, is_active=?, password_hash=?, updated_at=?
                WHERE id=?
            ''', (username, full_name, role, is_active, generate_password_hash(password), now_iso(), user_id))
        else:
            get_db().execute('''
                UPDATE users
                SET username=?, full_name=?, role=?, is_active=?, updated_at=?
                WHERE id=?
            ''', (username, full_name, role, is_active, now_iso(), user_id))
        get_db().commit()
    except Exception:
        current_app.logger.exception('No se pudo actualizar el usuario %s', user_id)
        return jsonify({'error': 'No se pudo actualizar el usuario. Revisá los datos e intentá nuevamente.'}), 400

    row = get_db().execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
    return jsonify(user_to_dict(row))

@bp.delete('/api/users/<int:user_id>')
@login_required
def api_delete_user(user_id):
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña de seguridad incorrecta'}), 403

    current = get_db().execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
    if not current:
        return jsonify({'error': 'Usuario no encontrado'}), 404
    if current['role'] == 'Administrador':
        active_admins = get_db().execute(
            "SELECT COUNT(*) AS c FROM users WHERE role='Administrador' AND is_active=1 AND id<>?",
            (user_id,)
        ).fetchone()['c']
        if active_admins == 0:
            return jsonify({'error': 'No se puede eliminar el único administrador activo'}), 400

    get_db().execute('DELETE FROM users WHERE id=?', (user_id,))
    get_db().commit()
    return jsonify({'ok': True})

@bp.post('/api/admin-check')
@login_required
def api_admin_check():
    if current_user_is_admin():
        return jsonify({'ok': True, 'admin_bypass': True})
    data = request.get_json(force=True)
    if not require_security_password_from_payload(data):
        return jsonify({'error': 'Contraseña incorrecta'}), 403
    return jsonify({'ok': True})

