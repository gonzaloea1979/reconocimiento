from pathlib import Path
import sqlite3
import os
import tempfile
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from contextlib import closing
from datetime import datetime, date, timedelta
from flask import current_app, g

DEFAULT_SETTINGS = {
    'business_name': 'POS Local',
    'business_cuit': '',
    'business_address': '',
    'business_phone': '',
    'business_email': '',
    'ticket_footer': 'Gracias por su compra',
    'logo_path': '',
    'login_username': 'admin',
    # Usuario/cajero mostrado por defecto en tickets cuando no hay inicio de sesión.
    'default_cashier_name': 'admin',
    # Configuración visual y de contenido del ticket emitido desde Venta.
    'ticket_pdf_size': 'A5',
    'ticket_design': 'moderno',
    'ticket_title': 'TICKET DE COMPRA',
    'ticket_accent_color': '#0F172A',
    'ticket_font_scale': 'normal',
    'ticket_margin_mm': '12',
    'ticket_logo_size_mm': '22',
    'ticket_show_logo': '1',
    'ticket_show_business_name': '1',
    'ticket_show_cuit': '1',
    'ticket_show_address': '1',
    'ticket_show_phone': '1',
    'ticket_show_email': '1',
    'ticket_show_cashier': '1',
    'ticket_show_payment': '1',
    'ticket_show_received_change': '1',
    'ticket_show_footer': '1',
    'ticket_show_qr': '0',
    'ticket_qr_label': 'Escaneá para contactarnos',
    'ticket_qr_value': '',
    'fullscreen_mode': '1',
    # Redondeo general para calcular precios finales de venta en Productos.
    'product_rounding_mode': 'none',
    'product_rounding_multiple': '1',
    # 1 = controla stock; 0 = no valida ni actualiza existencias por ventas/compras.
    'stock_control_enabled': '1',
}



DEMO_PRODUCTS = [
    {
        "barcode": "7790001000011",
        "name": "Leche entera 1L",
        "detail": "Producto de prueba con vencimiento crítico",
        "cost_without_tax": 900,
        "iva_percent": 21,
        "gross_income_percent": 3,
        "margin_percent": 35,
        "stock": 24,
        "expiry_days": 15,
    },
    {
        "barcode": "7790001000028",
        "name": "Yogur bebible frutilla 1L",
        "detail": "Producto de prueba con vencimiento en atención",
        "cost_without_tax": 1100,
        "iva_percent": 21,
        "gross_income_percent": 3,
        "margin_percent": 32,
        "stock": 18,
        "expiry_days": 21,
    },
    {
        "barcode": "7790001000035",
        "name": "Queso cremoso 1kg",
        "detail": "Producto de prueba con vencimiento próximo",
        "cost_without_tax": 4200,
        "iva_percent": 21,
        "gross_income_percent": 3,
        "margin_percent": 28,
        "stock": 8,
        "expiry_days": 30,
    },
    {
        "barcode": "7790001000042",
        "name": "Arroz largo fino 1kg",
        "detail": "Producto seco de prueba",
        "cost_without_tax": 950,
        "iva_percent": 21,
        "gross_income_percent": 3,
        "margin_percent": 40,
        "stock": 50,
        "expiry_days": 180,
    },
    {
        "barcode": "7790001000059",
        "name": "Azúcar común 1kg",
        "detail": "Producto seco de prueba",
        "cost_without_tax": 800,
        "iva_percent": 21,
        "gross_income_percent": 3,
        "margin_percent": 38,
        "stock": 45,
        "expiry_days": 220,
    },
    {
        "barcode": "7790001000066",
        "name": "Yerba mate 1kg",
        "detail": "Producto de almacén de prueba",
        "cost_without_tax": 2600,
        "iva_percent": 21,
        "gross_income_percent": 3,
        "margin_percent": 30,
        "stock": 30,
        "expiry_days": 300,
    },
    {
        "barcode": "7790001000073",
        "name": "Aceite girasol 900ml",
        "detail": "Producto de almacén de prueba",
        "cost_without_tax": 1800,
        "iva_percent": 21,
        "gross_income_percent": 3,
        "margin_percent": 28,
        "stock": 22,
        "expiry_days": 240,
    },
    {
        "barcode": "7790001000080",
        "name": "Gaseosa cola 2.25L",
        "detail": "Bebida de prueba",
        "cost_without_tax": 1500,
        "iva_percent": 21,
        "gross_income_percent": 3,
        "margin_percent": 35,
        "stock": 36,
        "expiry_days": 120,
    },
    {
        "barcode": "7790001000097",
        "name": "Fideos spaghetti 500g",
        "detail": "Producto seco de prueba",
        "cost_without_tax": 650,
        "iva_percent": 21,
        "gross_income_percent": 3,
        "margin_percent": 42,
        "stock": 60,
        "expiry_days": 365,
    },
    {
        "barcode": "7790001000103",
        "name": "Jabón blanco unidad",
        "detail": "Producto de limpieza de prueba",
        "cost_without_tax": 500,
        "iva_percent": 21,
        "gross_income_percent": 3,
        "margin_percent": 45,
        "stock": 40,
        "expiry_days": None,
    },
]


def _calc_demo_prices(cost_without_tax, iva_percent, gross_income_percent, margin_percent):
    """Calcula precios de demostración con el mismo redondeo comercial HALF_UP."""
    try:
        cost = Decimal(str(cost_without_tax or 0))
        iva = Decimal(str(iva_percent or 0))
        gross = Decimal(str(gross_income_percent or 0))
        margin = Decimal(str(margin_percent or 0))
        if not all(value.is_finite() for value in (cost, iva, gross, margin)):
            raise ValueError('Los valores de demostración deben ser finitos')
    except (InvalidOperation, TypeError, ValueError, OverflowError):
        raise ValueError('Los valores de demostración deben ser números válidos')

    hundred = Decimal('100')
    total_cost_raw = cost + (cost * iva / hundred) + (cost * gross / hundred)
    sale_price_raw = total_cost_raw + (total_cost_raw * margin / hundred)
    cents = Decimal('0.01')
    total_cost = total_cost_raw.quantize(cents, rounding=ROUND_HALF_UP)
    sale_price = sale_price_raw.quantize(cents, rounding=ROUND_HALF_UP)
    return float(total_cost), float(sale_price)


def _seed_demo_products(cur):
    """Carga productos de prueba solo si se solicita explícitamente.

    En instalaciones normales no deben aparecer artículos ficticios en el POS.
    Para preparar un entorno de demostración, establecer POS_SEED_DEMO_PRODUCTS=1
    antes de iniciar la aplicación.
    """
    if os.environ.get('POS_SEED_DEMO_PRODUCTS', '').strip().lower() not in ('1', 'true', 'yes', 'si', 'sí'):
        return
    product_count = cur.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    if product_count:
        return

    stamp = datetime.now().isoformat(timespec="seconds")
    today = date.today()
    for item in DEMO_PRODUCTS:
        total_cost, sale_price = _calc_demo_prices(
            item["cost_without_tax"],
            item["iva_percent"],
            item["gross_income_percent"],
            item["margin_percent"],
        )
        expiry_days = item.get("expiry_days")
        expiry_date = (today + timedelta(days=expiry_days)).isoformat() if expiry_days is not None else None
        cur.execute("""
            INSERT OR IGNORE INTO products (
                barcode, name, detail, cost_without_tax, iva_percent, gross_income_percent,
                total_cost, margin_percent, sale_price, stock, expiry_date, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            item["barcode"], item["name"], item["detail"], item["cost_without_tax"],
            item["iva_percent"], item["gross_income_percent"], total_cost,
            item["margin_percent"], sale_price, item["stock"], expiry_date, stamp, stamp
        ))


def connect_database(database_path, timeout=15, *, row_factory=True):
    """Abre una conexión SQLite con la política única del POS.

    Mantiene las claves foráneas activas, el mismo tiempo de espera y una
    caché de páginas de 8 MiB por conexión, adecuada para el objetivo de hasta
    dos usuarios. El caché de sentencias evita recompilar SQL repetido.
    """
    timeout_seconds = max(0.0, float(timeout))
    db = sqlite3.connect(
        str(database_path),
        timeout=timeout_seconds,
        cached_statements=256,
    )
    db.execute(f'PRAGMA busy_timeout={int(timeout_seconds * 1000)}')
    db.execute('PRAGMA foreign_keys=ON')
    # POS dimensionado para un máximo de dos usuarios: 8 MiB de caché por
    # conexión reduce relecturas de páginas en reportes y rankings sin alterar
    # durabilidad, journal_mode ni la integridad transaccional.
    db.execute('PRAGMA cache_size=-8192')
    if row_factory:
        db.row_factory = sqlite3.Row
    return db


def get_db():
    if 'db' not in g:
        g.db = connect_database(current_app.config['DATABASE'], timeout=15)
    return g.db


def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def _ensure_setting(cur, key, value):
    cur.execute('INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)', (key, value))


def _enable_wal_mode(db):
    """Activa WAL cuando el almacenamiento SQLite lo permite.

    WAL mejora la convivencia entre lectores y escritores locales. Si el
    archivo está en un sistema de archivos incompatible o bloqueado, el POS
    conserva el journal_mode vigente y continúa sin fallar el arranque.
    No se reduce synchronous: se conserva la durabilidad predeterminada FULL.
    """
    try:
        row = db.execute('PRAGMA journal_mode=WAL').fetchone()
        mode = str(row[0]).lower() if row else ''
        if mode != 'wal':
            return False
        db.execute('PRAGMA wal_autocheckpoint=1000')
        db.execute('PRAGMA journal_size_limit=67108864')
        return True
    except sqlite3.Error:
        return False


def _ensure_optional_trigram_search(cur):
    """Activa búsqueda por subcadenas si SQLite ofrece FTS5 con tokenizer trigram.

    La búsqueda tradicional LIKE sigue disponible como fallback. Las tablas FTS
    son índices auxiliares externos y se mantienen con triggers transaccionales.
    """
    search_tables = {
        'products': ('barcode', 'name', 'detail'),
        'clients': ('name', 'document', 'phone'),
        'suppliers': ('name', 'cuit', 'phone', 'category'),
    }
    savepoint = 'optional_trigram_search'
    cur.execute(f'SAVEPOINT {savepoint}')
    try:
        for table, columns in search_tables.items():
            fts_table = f'{table}_search'
            existed = cur.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                (fts_table,)
            ).fetchone() is not None
            column_sql = ', '.join(columns)
            cur.execute(
                f"CREATE VIRTUAL TABLE IF NOT EXISTS {fts_table} USING "
                f"fts5({column_sql}, content='{table}', content_rowid='id', tokenize='trigram')"
            )
            cur.execute(
                f"""CREATE TRIGGER IF NOT EXISTS {fts_table}_ai AFTER INSERT ON {table} BEGIN
                    INSERT INTO {fts_table}(rowid, {column_sql})
                    VALUES (new.id, {', '.join('new.' + col for col in columns)});
                END"""
            )
            cur.execute(
                f"""CREATE TRIGGER IF NOT EXISTS {fts_table}_ad AFTER DELETE ON {table} BEGIN
                    INSERT INTO {fts_table}({fts_table}, rowid, {column_sql})
                    VALUES ('delete', old.id, {', '.join('old.' + col for col in columns)});
                END"""
            )
            cur.execute(
                f"""CREATE TRIGGER IF NOT EXISTS {fts_table}_au AFTER UPDATE ON {table} BEGIN
                    INSERT INTO {fts_table}({fts_table}, rowid, {column_sql})
                    VALUES ('delete', old.id, {', '.join('old.' + col for col in columns)});
                    INSERT INTO {fts_table}(rowid, {column_sql})
                    VALUES (new.id, {', '.join('new.' + col for col in columns)});
                END"""
            )
            if not existed:
                cur.execute(f"INSERT INTO {fts_table}({fts_table}) VALUES ('rebuild')")
        cur.execute(f'RELEASE SAVEPOINT {savepoint}')
        return True
    except sqlite3.OperationalError:
        # Algunas instalaciones de Python/SQLite no incluyen FTS5 o trigram.
        # Revertir toda la instalación opcional y mantener las búsquedas LIKE.
        cur.execute(f'ROLLBACK TO SAVEPOINT {savepoint}')
        cur.execute(f'RELEASE SAVEPOINT {savepoint}')
        return False


def init_db():
    db_path = current_app.config['DATABASE']
    db_path.parent.mkdir(exist_ok=True)
    db = connect_database(db_path, timeout=15, row_factory=False)
    try:
        # WAL es persistente en el archivo. Si el volumen no lo admite, se
        # mantiene el modo actual sin impedir que el sistema arranque.
        _enable_wal_mode(db)
        cur = db.cursor()

        cur.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                barcode TEXT UNIQUE,
                name TEXT NOT NULL,
                detail TEXT,
                cost_without_tax REAL NOT NULL DEFAULT 0,
                iva_percent REAL NOT NULL DEFAULT 0,
                gross_income_percent REAL NOT NULL DEFAULT 0,
                total_cost REAL NOT NULL DEFAULT 0,
                margin_percent REAL NOT NULL DEFAULT 0,
                rounding_mode TEXT NOT NULL DEFAULT 'none',
                rounding_multiple REAL NOT NULL DEFAULT 1,
                sale_price REAL NOT NULL DEFAULT 0,
                stock REAL NOT NULL DEFAULT 0,
                expiry_date TEXT,
                photo_path TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        ''')

        # Migración liviana para bases existentes de versiones anteriores.
        cur.execute("PRAGMA table_info(products)")
        product_columns = {row[1] for row in cur.fetchall()}
        if 'photo_path' not in product_columns:
            cur.execute("ALTER TABLE products ADD COLUMN photo_path TEXT DEFAULT ''")

        cur.execute('''
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                total REAL NOT NULL DEFAULT 0,
                payment_method TEXT NOT NULL DEFAULT 'Efectivo',
                amount_received REAL NOT NULL DEFAULT 0,
                change_amount REAL NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            )
        ''')

        # Migración liviana para bases existentes de versiones anteriores.
        cur.execute("PRAGMA table_info(sales)")
        sales_columns = {row[1] for row in cur.fetchall()}
        if 'payment_method' not in sales_columns:
            cur.execute("ALTER TABLE sales ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'Efectivo'")
        if 'amount_received' not in sales_columns:
            cur.execute("ALTER TABLE sales ADD COLUMN amount_received REAL NOT NULL DEFAULT 0")
        if 'change_amount' not in sales_columns:
            cur.execute("ALTER TABLE sales ADD COLUMN change_amount REAL NOT NULL DEFAULT 0")

        cur.execute('''
            CREATE TABLE IF NOT EXISTS sale_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sale_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL,
                unit_price REAL NOT NULL,
                quantity REAL NOT NULL,
                line_total REAL NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(sale_id) REFERENCES sales(id),
                FOREIGN KEY(product_id) REFERENCES products(id)
            )
        ''')


        # Se guarda el costo al momento de la venta; NULL identifica ventas anteriores
        # cuyo costo histórico no puede reconstruirse con exactitud.
        cur.execute('PRAGMA table_info(sale_items)')
        sale_item_columns = {row[1] for row in cur.fetchall()}
        if 'unit_cost_at_sale' not in sale_item_columns:
            cur.execute('ALTER TABLE sale_items ADD COLUMN unit_cost_at_sale REAL')

        # Columnas adicionales para gestión completa.
        cur.execute("PRAGMA table_info(products)")
        product_columns = {row[1] for row in cur.fetchall()}
        product_extra_migrations = {
            'min_stock': "ALTER TABLE products ADD COLUMN min_stock REAL NOT NULL DEFAULT 0",
            'supplier_id': "ALTER TABLE products ADD COLUMN supplier_id INTEGER",
            'rounding_mode': "ALTER TABLE products ADD COLUMN rounding_mode TEXT NOT NULL DEFAULT 'none'",
            'rounding_multiple': "ALTER TABLE products ADD COLUMN rounding_multiple REAL NOT NULL DEFAULT 1",
        }
        for col, sql in product_extra_migrations.items():
            if col not in product_columns:
                cur.execute(sql)

        cur.execute("PRAGMA table_info(sales)")
        sales_columns = {row[1] for row in cur.fetchall()}
        sales_extra_migrations = {
            'cashier_name': "ALTER TABLE sales ADD COLUMN cashier_name TEXT NOT NULL DEFAULT ''",
            'client_id': "ALTER TABLE sales ADD COLUMN client_id INTEGER",
            'cash_session_id': "ALTER TABLE sales ADD COLUMN cash_session_id INTEGER",
            'sale_type': "ALTER TABLE sales ADD COLUMN sale_type TEXT NOT NULL DEFAULT 'Contado'",
        }
        for col, sql in sales_extra_migrations.items():
            if col not in sales_columns:
                cur.execute(sql)

        cur.execute('''
            CREATE TABLE IF NOT EXISTS suppliers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                cuit TEXT DEFAULT '',
                phone TEXT DEFAULT '',
                address TEXT DEFAULT '',
                category TEXT DEFAULT '',
                notes TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        ''')

        cur.execute('''
            CREATE TABLE IF NOT EXISTS purchases (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                supplier_id INTEGER,
                supplier_name TEXT DEFAULT '',
                total REAL NOT NULL DEFAULT 0,
                notes TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                FOREIGN KEY(supplier_id) REFERENCES suppliers(id)
            )
        ''')

        cur.execute('''
            CREATE TABLE IF NOT EXISTS purchase_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                purchase_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL,
                quantity REAL NOT NULL DEFAULT 0,
                unit_cost REAL NOT NULL DEFAULT 0,
                cost_without_tax REAL NOT NULL DEFAULT 0,
                iva_percent REAL NOT NULL DEFAULT 0,
                gross_income_percent REAL NOT NULL DEFAULT 0,
                total_cost REAL NOT NULL DEFAULT 0,
                margin_percent REAL NOT NULL DEFAULT 0,
                sale_price REAL NOT NULL DEFAULT 0,
                expiry_date TEXT,
                line_total REAL NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                FOREIGN KEY(purchase_id) REFERENCES purchases(id),
                FOREIGN KEY(product_id) REFERENCES products(id)
            )
        ''')

        cur.execute("PRAGMA table_info(purchase_items)")
        purchase_item_columns = {row[1] for row in cur.fetchall()}
        purchase_item_extra_migrations = {
            'cost_without_tax': "ALTER TABLE purchase_items ADD COLUMN cost_without_tax REAL NOT NULL DEFAULT 0",
            'iva_percent': "ALTER TABLE purchase_items ADD COLUMN iva_percent REAL NOT NULL DEFAULT 0",
            'gross_income_percent': "ALTER TABLE purchase_items ADD COLUMN gross_income_percent REAL NOT NULL DEFAULT 0",
            'total_cost': "ALTER TABLE purchase_items ADD COLUMN total_cost REAL NOT NULL DEFAULT 0",
            'margin_percent': "ALTER TABLE purchase_items ADD COLUMN margin_percent REAL NOT NULL DEFAULT 0",
            'sale_price': "ALTER TABLE purchase_items ADD COLUMN sale_price REAL NOT NULL DEFAULT 0",
            'expiry_date': "ALTER TABLE purchase_items ADD COLUMN expiry_date TEXT",
        }
        for col, sql in purchase_item_extra_migrations.items():
            if col not in purchase_item_columns:
                cur.execute(sql)

        cur.execute('''
            CREATE TABLE IF NOT EXISTS product_movements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                product_name TEXT NOT NULL,
                movement_type TEXT NOT NULL,
                quantity REAL NOT NULL DEFAULT 0,
                previous_stock REAL NOT NULL DEFAULT 0,
                new_stock REAL NOT NULL DEFAULT 0,
                reference TEXT DEFAULT '',
                notes TEXT DEFAULT '',
                created_at TEXT NOT NULL,
                FOREIGN KEY(product_id) REFERENCES products(id)
            )
        ''')

        cur.execute('''
            CREATE TABLE IF NOT EXISTS cash_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                opened_at TEXT NOT NULL,
                closed_at TEXT,
                initial_amount REAL NOT NULL DEFAULT 0,
                closing_amount REAL NOT NULL DEFAULT 0,
                expected_amount REAL NOT NULL DEFAULT 0,
                difference REAL NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'abierta',
                cashier_name TEXT DEFAULT '',
                notes TEXT DEFAULT ''
            )
        ''')

        cur.execute('''
            CREATE TABLE IF NOT EXISTS cash_movements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cash_session_id INTEGER,
                movement_type TEXT NOT NULL,
                amount REAL NOT NULL DEFAULT 0,
                description TEXT DEFAULT '',
                payment_method TEXT DEFAULT 'Efectivo',
                sale_id INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY(cash_session_id) REFERENCES cash_sessions(id),
                FOREIGN KEY(sale_id) REFERENCES sales(id)
            )
        ''')

        cur.execute('''
            CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                document TEXT DEFAULT '',
                phone TEXT DEFAULT '',
                address TEXT DEFAULT '',
                notes TEXT DEFAULT '',
                balance REAL NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        ''')

        cur.execute('''
            CREATE TABLE IF NOT EXISTS client_movements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER NOT NULL,
                movement_type TEXT NOT NULL,
                amount REAL NOT NULL DEFAULT 0,
                description TEXT DEFAULT '',
                sale_id INTEGER,
                created_at TEXT NOT NULL,
                FOREIGN KEY(client_id) REFERENCES clients(id),
                FOREIGN KEY(sale_id) REFERENCES sales(id)
            )
        ''')

        cur.execute('''
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_name TEXT DEFAULT '',
                action TEXT NOT NULL,
                module TEXT DEFAULT '',
                detail TEXT DEFAULT '',
                created_at TEXT NOT NULL
            )
        ''')

        cur.execute('''
            CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL DEFAULT ''
            )
        ''')

        cur.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                full_name TEXT NOT NULL DEFAULT '',
                role TEXT NOT NULL DEFAULT 'Cajero',
                password_hash TEXT NOT NULL DEFAULT '',
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
        ''')

        # Migraciones livianas para tablas de usuarios creadas por versiones anteriores.
        cur.execute("PRAGMA table_info(users)")
        user_columns = {row[1] for row in cur.fetchall()}
        user_migrations = {
            'full_name': "ALTER TABLE users ADD COLUMN full_name TEXT NOT NULL DEFAULT ''",
            'role': "ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'Cajero'",
            'password_hash': "ALTER TABLE users ADD COLUMN password_hash TEXT NOT NULL DEFAULT ''",
            'is_active': "ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1",
            'created_at': "ALTER TABLE users ADD COLUMN created_at TEXT NOT NULL DEFAULT ''",
            'updated_at': "ALTER TABLE users ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''",
        }
        for col, sql in user_migrations.items():
            if col not in user_columns:
                cur.execute(sql)

        # Índices para filtros e historiales frecuentes, sin alterar datos ni pantallas.
        cur.execute('CREATE INDEX IF NOT EXISTS idx_sales_created_at ON sales(created_at)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_sales_client_id ON sales(client_id)')
        # Índices compuestos: además de filtrar por la clave foránea, cubren el
        # orden por id que usan los historiales. Se retiran los índices simples
        # anteriores para no duplicar almacenamiento ni costo de escritura.
        cur.execute('DROP INDEX IF EXISTS idx_purchase_items_purchase_id')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_purchase_items_purchase_id_id ON purchase_items(purchase_id, id ASC)')
        # Índice de cobertura para reportes por período: permite recorrer los
        # artículos de cada venta sin volver a la tabla para recuperar producto,
        # cantidad, importe y costo histórico. Su prefijo sale_id reemplaza al
        # índice simple anterior y también sirve para los detalles por venta.
        cur.execute('DROP INDEX IF EXISTS idx_sale_items_sale_id')
        cur.execute('''CREATE INDEX IF NOT EXISTS idx_sale_items_sale_report
                       ON sale_items(sale_id, product_id, product_name, quantity, line_total, unit_cost_at_sale)''')
        # Índice de cobertura para los dos rankings del Dashboard. Además de
        # filtrar por product_id, contiene las columnas agregadas y ordenadas,
        # evitando lecturas adicionales de la tabla para cada artículo vendido.
        # Su prefijo product_id reemplaza al índice simple anterior.
        cur.execute('DROP INDEX IF EXISTS idx_sale_items_product_id')
        cur.execute('''CREATE INDEX IF NOT EXISTS idx_sale_items_product_rollup
                       ON sale_items(product_id, product_name, quantity, line_total)''')
        cur.execute('DROP INDEX IF EXISTS idx_cash_movements_session_id')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_cash_movements_session_id_id ON cash_movements(cash_session_id, id DESC)')
        # El índice compuesto cubre el filtro por producto y el orden descendente
        # del historial, evitando un ordenamiento temporal adicional.
        cur.execute('DROP INDEX IF EXISTS idx_product_movements_product_id')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_product_movements_product_id_id ON product_movements(product_id, id DESC)')
        cur.execute('DROP INDEX IF EXISTS idx_client_movements_client_id')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_client_movements_client_id_id ON client_movements(client_id, id DESC)')

        # Índices para ordenamientos y filtros frecuentes de las pantallas existentes.
        cur.execute('CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)')
        # Índice parcial: solo contiene productos que necesitan reposición.
        # Su expresión coincide con ORDER BY de alertas de stock y reportes.
        cur.execute('''CREATE INDEX IF NOT EXISTS idx_products_low_stock_priority
                       ON products((stock - min_stock), name)
                       WHERE min_stock > 0 AND stock <= min_stock''')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_products_expiry_date ON products(date(expiry_date))')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_clients_name ON clients(name)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_clients_balance_desc ON clients(balance DESC)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_suppliers_name ON suppliers(name)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_cash_sessions_status_id ON cash_sessions(status, id DESC)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_users_active_role_lower_username ON users(is_active, role, LOWER(username))')

        # Índices trigram opcionales: aceleran búsquedas por subcadena (LIKE %texto%).
        # Si el SQLite distribuido no trae FTS5/trigram, se conserva el LIKE tradicional.
        _ensure_optional_trigram_search(cur)

        for key, value in DEFAULT_SETTINGS.items():
            _ensure_setting(cur, key, value)

        # El POS inicia localmente sin solicitar contraseña y utiliza un administrador
        # predeterminado. No se crean cajeros/supervisores adicionales automáticamente.
        _ensure_setting(cur, 'login_password_hash', '')
        _ensure_setting(cur, 'admin_password_hash', '')

        admin = cur.execute(
            "SELECT id, username FROM users WHERE role='Administrador' AND is_active=1 "
            "ORDER BY CASE WHEN LOWER(username)='admin' THEN 0 ELSE 1 END, id LIMIT 1"
        ).fetchone()

        if not admin:
            # Reutilizar el usuario "admin" existente si está presente; nunca duplicarlo.
            existing_admin_name = cur.execute(
                "SELECT id, username FROM users WHERE LOWER(username)='admin' LIMIT 1"
            ).fetchone()
            stamp = datetime.now().astimezone().isoformat(timespec='seconds')
            if existing_admin_name:
                cur.execute(
                    "UPDATE users SET full_name=CASE WHEN TRIM(full_name)='' THEN 'Administrador' ELSE full_name END, "
                    "role='Administrador', is_active=1, updated_at=? WHERE id=?",
                    (stamp, existing_admin_name[0])
                )
                admin_username = existing_admin_name[1]
            else:
                cur.execute(
                    "INSERT INTO users (username, full_name, role, password_hash, is_active, created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, 1, ?, ?)",
                    ('admin', 'Administrador', 'Administrador', '', stamp, stamp)
                )
                admin_username = 'admin'
        else:
            admin_username = admin[1]

        # La identidad de inicio predeterminada es el administrador activo.
        cur.execute("UPDATE app_settings SET value=? WHERE key='login_username'", (admin_username,))

        _seed_demo_products(cur)

        db.commit()
    finally:
        db.close()


def get_settings():
    # Las pantallas y varias rutas consultan la configuración más de una vez
    # durante la misma petición. Cachear en Flask g evita lecturas SQL repetidas
    # sin conservar valores entre peticiones.
    cached = getattr(g, '_pos_settings_cache', None)
    if cached is not None:
        return dict(cached)

    rows = get_db().execute('SELECT key, value FROM app_settings').fetchall()
    settings = dict(DEFAULT_SETTINGS)
    settings.update({row['key']: row['value'] for row in rows})
    g._pos_settings_cache = settings
    return dict(settings)


def get_setting(key, default=''):
    row = get_db().execute('SELECT value FROM app_settings WHERE key=?', (key,)).fetchone()
    return row['value'] if row else default


def set_setting(key, value):
    get_db().execute(
        'INSERT INTO app_settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
        (key, value if value is not None else '')
    )
    # Evita devolver datos viejos si la configuración cambia dentro de la petición.
    g.pop('_pos_settings_cache', None)


def update_settings(values):
    for key, value in values.items():
        set_setting(key, value)
    get_db().commit()


def public_settings(settings=None):
    settings = settings or get_settings()
    keys = [
        'business_name', 'business_cuit', 'business_address', 'business_phone',
        'business_email', 'ticket_footer', 'logo_path', 'login_username', 'default_cashier_name',
        'ticket_pdf_size', 'ticket_design', 'ticket_title', 'ticket_accent_color',
        'ticket_font_scale', 'ticket_margin_mm', 'ticket_logo_size_mm',
        'ticket_show_logo', 'ticket_show_business_name', 'ticket_show_cuit',
        'ticket_show_address', 'ticket_show_phone', 'ticket_show_email',
        'ticket_show_cashier', 'ticket_show_payment', 'ticket_show_received_change',
        'ticket_show_footer', 'ticket_show_qr', 'ticket_qr_label', 'ticket_qr_value',
        'product_rounding_mode', 'product_rounding_multiple', 'stock_control_enabled',
    ]
    public = {key: settings.get(key, DEFAULT_SETTINGS.get(key, '')) for key in keys}
    public['business_name'] = public.get('business_name') or 'POS Local'
    public['login_username'] = public.get('login_username') or 'admin'
    return public


def backup_database(max_backups=30):
    src = current_app.config['DATABASE']
    if not src.exists():
        return None
    backup_dir = current_app.config['BACKUP_DIR']
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    dst = backup_dir / f'pos_backup_{stamp}.db'

    # mkstemp reserva un nombre único para evitar choques entre respaldos.
    fd, temporary_name = tempfile.mkstemp(prefix='.pos_backup_', suffix='.tmp', dir=backup_dir)
    os.close(fd)
    temporary = backup_dir / Path(temporary_name).name
    try:
        # IMPORTANTE: sqlite3.Connection como gestor de contexto NO cierra
        # el archivo en Windows. closing() garantiza que se liberen los handles
        # antes de os.replace y de la limpieza del temporal.
        with closing(connect_database(src, timeout=15, row_factory=False)) as source:
            with closing(connect_database(temporary, timeout=15, row_factory=False)) as target:
                source.backup(target)
                result = target.execute('PRAGMA quick_check').fetchone()[0]
                if result != 'ok':
                    raise sqlite3.DatabaseError('La copia de seguridad no superó la verificación')
        os.replace(temporary, dst)
    finally:
        # No enmascarar el error original si otro proceso bloquea la limpieza.
        try:
            temporary.unlink(missing_ok=True)
        except PermissionError:
            pass

    # Conserva las copias más recientes para que la carpeta no crezca sin límite.
    try:
        backups = sorted(backup_dir.glob('pos_backup_*.db'), key=lambda path: path.stat().st_mtime, reverse=True)
        for old in backups[int(max_backups or 30):]:
            old.unlink(missing_ok=True)
    except Exception:
        pass
    return dst
