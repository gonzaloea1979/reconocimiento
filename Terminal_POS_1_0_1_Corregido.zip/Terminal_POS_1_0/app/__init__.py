from pathlib import Path
import sys
import secrets
import os

from flask import Flask, url_for, session, request, abort
from urllib.parse import urlsplit
from .db import init_db, backup_database, close_db, get_settings, public_settings, get_db


def _external_app_dir() -> Path:
    """Ubicación de templates/static cuando se ejecuta como EXE."""
    if getattr(sys, 'frozen', False):
        exe_dir = Path(sys.executable).resolve().parent
        external = exe_dir / 'app'
        if external.exists():
            return external
        # Fallback por si PyInstaller dejó datos en _MEIPASS.
        return Path(getattr(sys, '_MEIPASS', exe_dir)) / 'app'
    return Path(__file__).resolve().parent


def create_app():
    app_dir = _external_app_dir()
    if getattr(sys, 'frozen', False):
        app = Flask(
            __name__,
            static_folder=str(app_dir / 'static'),
            template_folder=str(app_dir / 'templates'),
        )
    else:
        app = Flask(__name__)

    app.config.from_object('app.config')
    app.config.setdefault('SESSION_COOKIE_HTTPONLY', True)
    app.config.setdefault('SESSION_COOKIE_SAMESITE', 'Lax')
    # El servidor se limita a 127.0.0.1 y usa HTTP local; Secure=True impediría
    # enviar la cookie en ese esquema. No exponer el servidor a la red local.
    app.config.setdefault('SESSION_COOKIE_SECURE', False)

    @app.before_request
    def enforce_local_origin():
        """Limitá el POS al loopback y rechazá solicitudes mutantes cross-origin.

        Es especialmente importante porque el modo local inicia como administrador
        sin contraseña. No reemplaza la seguridad del equipo, pero reduce exposición
        por DNS rebinding y solicitudes CSRF desde sitios externos.
        """
        try:
            host = (urlsplit('//' + request.host).hostname or '').lower()
        except ValueError:
            abort(400)
        if host not in {'127.0.0.1', 'localhost', '::1'}:
            abort(403)

        remote = request.remote_addr
        if remote and remote not in {'127.0.0.1', '::1'}:
            abort(403)

        if request.method in {'POST', 'PUT', 'PATCH', 'DELETE'}:
            origin = request.headers.get('Origin')
            if origin:
                try:
                    origin_host = urlsplit(origin).netloc.lower()
                except ValueError:
                    abort(403)
                if origin_host != request.host.lower():
                    abort(403)
            fetch_site = request.headers.get('Sec-Fetch-Site', '').lower()
            if fetch_site == 'cross-site':
                abort(403)

    @app.after_request
    def add_security_headers(response):
        # Defensa en profundidad para la interfaz local y datos comerciales.
        response.headers.setdefault('X-Content-Type-Options', 'nosniff')
        response.headers.setdefault('X-Frame-Options', 'DENY')
        response.headers.setdefault('Referrer-Policy', 'no-referrer')
        if request.path.startswith('/api/'):
            response.headers['Cache-Control'] = 'no-store, max-age=0'
            response.headers['Pragma'] = 'no-cache'
        return response

    # Clave privada persistente: no regenerar al reiniciar ni incluirla en el ZIP.
    key_file = app.config['INSTANCE_DIR'] / '.session_key'
    env_secret = os.environ.get('POS_SECRET_KEY')
    if env_secret:
        app.secret_key = env_secret
    else:
        if not key_file.exists():
            key_file.parent.mkdir(parents=True, exist_ok=True)
            key_file.write_text(secrets.token_hex(32), encoding='utf-8')
        secret_value = key_file.read_text(encoding='utf-8').strip()
        # Una interrupción durante la creación podría dejar un archivo vacío o
        # truncado. No iniciar con una clave débil: regenerar y reemplazar atómicamente.
        if len(secret_value) < 64:
            secret_value = secrets.token_hex(32)
            temporary_key = key_file.with_name(f'.session_key.{os.getpid()}.tmp')
            try:
                temporary_key.write_text(secret_value, encoding='utf-8')
                os.replace(temporary_key, key_file)
            finally:
                temporary_key.unlink(missing_ok=True)
        if os.name != 'nt':
            try:
                os.chmod(key_file, 0o600)
            except OSError:
                app.logger.warning('No se pudieron restringir los permisos de .session_key')
        app.secret_key = secret_value

    app.config['INSTANCE_DIR'].mkdir(exist_ok=True)
    app.config['BACKUP_DIR'].mkdir(exist_ok=True)
    app.config['UPLOAD_DIR'].mkdir(parents=True, exist_ok=True)
    app.config['TICKET_DIR'].mkdir(parents=True, exist_ok=True)

    with app.app_context():
        init_db()
        backup_database()

    @app.context_processor
    def inject_settings():
        try:
            settings = public_settings(get_settings())
            logo_path = settings.get('logo_path') or ''
            settings['logo_url'] = url_for('static', filename=logo_path) if logo_path else ''

            username = session.get('username') or settings.get('default_cashier_name') or settings.get('login_username') or 'Cajero'
            role = 'Cajero'
            full_name = ''
            is_admin = False
            # El arranque local no es autenticación administrativa, aunque el
            # nombre visible del cajero coincida con el usuario administrador.
            local_limited_session = bool(session.get('local_auto_login') and not session.get('authenticated_login'))
            try:
                row = None if local_limited_session else get_db().execute(
                    """
                    SELECT username, full_name, role, is_active
                    FROM users
                    WHERE is_active=1 AND LOWER(username)=LOWER(?)
                    LIMIT 1
                    """,
                    (username,)
                ).fetchone()
                if row:
                    username = row['username'] or username
                    full_name = row['full_name'] or ''
                    role = row['role'] or 'Cajero'
                    is_admin = role == 'Administrador'
            except Exception:
                pass

            current_user = {
                'username': username,
                'full_name': full_name,
                'role': role,
                'is_admin': bool(is_admin),
            }
            return {'settings': settings, 'current_user': current_user}
        except Exception:
            return {
                'settings': {'business_name': 'POS Local', 'logo_url': '', 'logo_path': ''},
                'current_user': {'username': 'admin', 'full_name': '', 'role': 'Cajero', 'is_admin': False},
            }

    app.teardown_appcontext(close_db)

    from .routes import bp
    app.register_blueprint(bp)
    return app
