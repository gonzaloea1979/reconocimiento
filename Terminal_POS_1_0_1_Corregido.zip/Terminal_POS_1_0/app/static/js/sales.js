let saleProducts = [];
let saleIndex = 0;
let cart = [];
let lastTicket = null;
let pendingProduct = null;
let isFinishingSale = false;
let isGeneratingPdf = false;
let saleResetCountdownInterval = null;
let saleResetCountdownTimeout = null;
let saleNotFoundCountdownInterval = null;
let saleNotFoundCountdownTimeout = null;
let saleClients = [];
let selectedClient = null;
let clientModalIndex = 0;
let filteredSaleClients = [];
const SALE_RESET_COUNTDOWN_SECONDS = 3;
const SALE_MAIN_WINDOW_URL = '/';
let saleRedirectingToMain = false;
let saleLiveSearchTimer = null;
let saleSearchController = null;
let saleSearchVersion = 0;
let saleScanner = null;
let activeCartProductId = null;
let salePriceEditTarget = null;

function goToMainWindow() {
  if (saleRedirectingToMain) return;
  saleRedirectingToMain = true;
  window.location.href = SALE_MAIN_WINDOW_URL;
}

function qtyLabel(value) {
  const n = Number(value || 0);
  return Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/0+$/, '').replace(/\.$/, '');
}

function getSaleElements() {
  return {
    input: document.getElementById('saleSearch'),
    list: document.getElementById('saleSelectList'),
    pending: document.getElementById('pendingProductBox'),
    qtyInput: document.getElementById('pendingQuantity'),
  };
}

async function loadSaleClients() {
  const select = document.getElementById('saleClient');
  if (!select) return;
  try {
    saleClients = await api('/api/clients');
    select.innerHTML = '<option value="">Seleccionar cliente</option>' + saleClients.map(c => `<option value="${c.id}">${escapeHTML(c.name)} · Saldo ${formatMoney(c.balance)}</option>`).join('');
  } catch (err) {}
}

function selectedClientLabel() {
  return selectedClient ? selectedClient.name : 'Consumidor final';
}

function syncSelectedClientUI() {
  const label = document.getElementById('selectedClientName');
  const ticketClient = document.getElementById('ticketClientName');
  const select = document.getElementById('saleClient');

  if (label) label.textContent = selectedClientLabel();
  if (ticketClient) ticketClient.textContent = selectedClientLabel();
  if (select) select.value = selectedClient ? String(selectedClient.id) : '';
}

function setSelectedClient(client) {
  selectedClient = client || null;
  syncSelectedClientUI();
  if (selectedClient) {
    showToast(`Cliente seleccionado: ${selectedClient.name}`);
  } else {
    showToast('Venta como consumidor final');
  }
}

function getCurrentClientId() {
  return selectedClient ? String(selectedClient.id) : '';
}

function filterSaleClients(query = '') {
  const q = String(query || '').trim().toLowerCase();
  if (!q) return saleClients.slice(0, 200);
  return saleClients.filter(c => {
    return [c.name, c.document, c.phone].some(v => String(v || '').toLowerCase().includes(q));
  }).slice(0, 200);
}

function renderClientModalList(activeIndex = 0) {
  const list = document.getElementById('saleClientList');
  if (!list) return;
  clientModalIndex = Math.max(0, Math.min(activeIndex, Math.max(filteredSaleClients.length - 1, 0)));

  if (!filteredSaleClients.length) {
    list.innerHTML = '<div class="empty-state">No hay clientes registrados que coincidan</div>';
    return;
  }

  list.innerHTML = filteredSaleClients.map((c, index) => `
    <button type="button" class="client-select-option${index === clientModalIndex ? ' active' : ''}" data-index="${index}">
      <div>
        <strong>${escapeHTML(c.name)}</strong>
        <small>${escapeHTML(c.document || 'Sin documento')} · ${escapeHTML(c.phone || 'Sin teléfono')}</small>
      </div>
      <span>Saldo ${formatMoney(c.balance)}</span>
    </button>
  `).join('');

  list.querySelectorAll('.client-select-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const index = Number(btn.dataset.index || 0);
      selectClientFromModal(index);
    });
  });

  const active = list.querySelector('.client-select-option.active');
  if (active) active.scrollIntoView({ block: 'nearest' });
}

async function openClientModal() {
  if (!saleClients.length) await loadSaleClients();

  const modal = document.getElementById('saleClientModal');
  const search = document.getElementById('saleClientSearch');
  if (!modal || !search) return;

  filteredSaleClients = filterSaleClients('');
  renderClientModalList(0);
  modal.classList.remove('hidden');
  modal.classList.add('show');
  modal.setAttribute('aria-hidden', 'false');
  search.value = '';
  setTimeout(() => search.focus(), 30);
}

function closeClientModal(focusSale = true) {
  const modal = document.getElementById('saleClientModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('show');
    modal.setAttribute('aria-hidden', 'true');
  }
  if (focusSale) {
    const input = document.getElementById('saleSearch');
    if (input) input.focus();
  }
}

function moveClientModal(delta) {
  if (!filteredSaleClients.length) return;
  clientModalIndex = Math.max(0, Math.min(filteredSaleClients.length - 1, clientModalIndex + delta));
  renderClientModalList(clientModalIndex);
}

function selectClientFromModal(index = clientModalIndex) {
  const client = filteredSaleClients[index];
  if (!client) return;
  setSelectedClient(client);
  closeClientModal(true);
}

function clearSelectedClient() {
  setSelectedClient(null);
  closeClientModal(true);
}

function updateClientSelectorVisibility() {
  const wrap = document.getElementById('clientSelectWrap');
  const method = document.getElementById('paymentMethod').value;
  if (!wrap) return;
  if (method === 'Cuenta corriente') {
    wrap.classList.remove('hidden');
    document.getElementById('amountReceived').value = '';
  } else {
    wrap.classList.add('hidden');
  }
  syncSelectedClientUI();
}

function waitForOperationModalPaint() {
  return new Promise(resolve => {
    requestAnimationFrame(() => setTimeout(resolve, 60));
  });
}

function closeNativeOperationDialog() {
  const dialog = document.getElementById('saleOperationDialog');
  if (!dialog) return;
  dialog.classList.add('hidden');
  dialog.classList.remove('show');
  dialog.setAttribute('aria-hidden', 'true');
}

function stopSaleNotFoundModal(options = {}) {
  if (saleNotFoundCountdownInterval) {
    clearInterval(saleNotFoundCountdownInterval);
    saleNotFoundCountdownInterval = null;
  }
  if (saleNotFoundCountdownTimeout) {
    clearTimeout(saleNotFoundCountdownTimeout);
    saleNotFoundCountdownTimeout = null;
  }

  const modal = document.getElementById('saleNotFoundModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('show');
    modal.setAttribute('aria-hidden', 'true');
  }

  if (options.clearInput) {
    const input = document.getElementById('saleSearch');
    if (input) {
      input.value = '';
      input.focus();
    }
  }
}

function isSaleNotFoundVisible() {
  const modal = document.getElementById('saleNotFoundModal');
  return !!modal && !modal.classList.contains('hidden');
}

function showSaleNotFoundModal(message = 'Producto no encontrado') {
  stopSaleNotFoundModal({ clearInput: false });

  const modal = document.getElementById('saleNotFoundModal');
  const title = document.getElementById('saleNotFoundTitle');
  const countdown = document.getElementById('saleNotFoundCountdown');
  const detail = document.getElementById('saleNotFoundDetail');

  if (title) title.textContent = message;
  if (countdown) countdown.textContent = '';
  if (detail) detail.textContent = 'Listo para ingresar otro código.';

  hideSaleList();
  if (modal) {
    modal.classList.remove('hidden');
    modal.classList.add('show');
    modal.setAttribute('aria-hidden', 'false');
  }

  saleNotFoundCountdownTimeout = setTimeout(() => {
    stopSaleNotFoundModal({ clearInput: true });
  }, 1000);
}

function setTicketActionButtonsEnabled(enabled) {
  const pdfBtn = document.getElementById('pdfTicketBtn');
  const pdfPrintBtn = document.getElementById('pdfPrintTicketBtn');
  if (pdfBtn) pdfBtn.disabled = !enabled;
  if (pdfPrintBtn) pdfPrintBtn.disabled = !enabled;
}

function hideSaleList() {
  const { list } = getSaleElements();
  list.classList.add('hidden');
}

function ensureActiveSaleVisible() {
  const { list } = getSaleElements();
  const active = list.querySelector('.select-option.active');
  if (active) active.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

function renderSaleList(products, activeIndex = 0) {
  const { list } = getSaleElements();
  saleProducts = products || [];
  saleIndex = Math.max(0, Math.min(activeIndex, Math.max(saleProducts.length - 1, 0)));
  list.classList.remove('hidden');
  renderSelectableList(list, saleProducts, saleIndex, prepareQuantityProduct);
  ensureActiveSaleVisible();
}

async function liveSearchSaleProducts(query, requestVersion = saleSearchVersion) {
  const normalizedQuery = (query || '').trim();
  if (!normalizedQuery || normalizedQuery.length < 2) {
    if (requestVersion === saleSearchVersion) hideSaleList();
    return;
  }
  const controller = new AbortController();
  saleSearchController = controller;
  try {
    const products = await api(`/api/product-lookup?q=${encodeURIComponent(normalizedQuery)}`, { signal: controller.signal });
    const input = getSaleElements().input;
    if (requestVersion !== saleSearchVersion || (input && input.value.trim() !== normalizedQuery)) return;
    if (!products.length) {
      hideSaleList();
      return;
    }
    renderSaleList(products, 0);
  } finally {
    if (saleSearchController === controller) saleSearchController = null;
  }
}

function scheduleSaleLiveSearch(query) {
  if (saleLiveSearchTimer) clearTimeout(saleLiveSearchTimer);
  if (saleSearchController) saleSearchController.abort();
  saleSearchController = null;
  const requestVersion = ++saleSearchVersion;
  const normalizedQuery = (query || '').trim();
  if (!normalizedQuery || normalizedQuery.length < 2) {
    hideSaleList();
    return;
  }
  saleLiveSearchTimer = setTimeout(async () => {
    try { await liveSearchSaleProducts(normalizedQuery, requestVersion); }
    catch (err) { if (err.name !== 'AbortError') { /* búsqueda rápida silenciosa */ } }
  }, 220);
}

async function handleScannedSaleCode(code) {
  const input = document.getElementById('saleSearch');
  if (input) input.value = code;
  await searchSaleProduct(code);
}

async function searchSaleProduct(query) {
  const normalizedQuery = (query || '').trim();
  if (saleLiveSearchTimer) clearTimeout(saleLiveSearchTimer);
  if (saleSearchController) saleSearchController.abort();
  const requestVersion = ++saleSearchVersion;
  const controller = new AbortController();
  saleSearchController = controller;

  let products;
  try {
    products = normalizedQuery
      ? await api(`/api/product-lookup?q=${encodeURIComponent(normalizedQuery)}`, { signal: controller.signal })
      : await api('/api/products', { signal: controller.signal });
  } catch (err) {
    if (err.name === 'AbortError') return;
    throw err;
  } finally {
    if (saleSearchController === controller) saleSearchController = null;
  }

  const input = getSaleElements().input;
  if (requestVersion !== saleSearchVersion || (input && input.value.trim() !== normalizedQuery)) return;

  if (!normalizedQuery) {
    renderSaleList(products, 0);
    return;
  }

  if (!products.length) {
    clearPendingProduct(false);
    showSaleNotFoundModal('Producto no encontrado');
    return;
  }

  const exactBarcode = products.length === 1 && String(products[0].barcode || '') === normalizedQuery;

  if (exactBarcode) {
    // Flujo rápido para lector de código de barras:
    // si el código coincide exactamente, se agrega 1 unidad sin pedir cantidad.
    hideSaleList();
    addToCart(products[0], 1);
    showToast(`${products[0].name} agregado automáticamente`);
    return;
  }

  if (products.length === 1) {
    hideSaleList();
    prepareQuantityProduct(products[0]);
    return;
  }

  renderSaleList(products, 0);
}

function selectActiveSaleProduct() {
  if (!saleProducts.length) return false;
  const product = saleProducts[saleIndex];
  if (!product) return false;
  prepareQuantityProduct(product);
  return true;
}


function parseQuantity(value) {
  const raw = String(value ?? '').trim().replace(',', '.');
  if (!raw) return 1;
  const qty = Number(raw);
  if (!Number.isFinite(qty) || qty <= 0) return null;
  return qty;
}

function parseSalePriceInput(value) {
  let raw = String(value ?? '').trim();
  if (!raw) return null;
  raw = raw.replace(/\$/g, '').replace(/\s/g, '');

  // Acepta formatos habituales: 1500, 1500.50, 1.500,50 o 1500,50.
  if (raw.includes(',') && raw.includes('.')) {
    raw = raw.replace(/\./g, '').replace(',', '.');
  } else {
    raw = raw.replace(',', '.');
  }

  const price = Number(raw);
  if (!Number.isFinite(price) || price <= 0) return null;
  // Usa el mismo redondeo comercial decimal que Productos, Compras y el servidor.
  const rounded = window.POSMoneyDecimal
    ? window.POSMoneyDecimal.roundPrice(raw, 'none', 1)
    : Math.round((price + Number.EPSILON) * 100) / 100;
  return Number.isFinite(rounded) && rounded > 0 ? rounded : null;
}

function selectCartItem(productId) {
  activeCartProductId = Number(productId);
  renderCart();
}

function getActiveCartItem() {
  if (!cart.length) return null;
  let item = cart.find(i => Number(i.product_id) === Number(activeCartProductId));
  if (!item) {
    item = cart[cart.length - 1];
    activeCartProductId = item ? item.product_id : null;
  }
  return item || null;
}

function isSalePriceModalVisible() {
  const modal = document.getElementById('salePriceModal');
  return !!modal && !modal.classList.contains('hidden');
}

function openSalePriceModal() {
  const modal = document.getElementById('salePriceModal');
  const input = document.getElementById('salePriceInput');
  const productName = document.getElementById('salePriceProductName');
  const currentPrice = document.getElementById('salePriceCurrentValue');
  const help = document.getElementById('salePriceHelp');
  if (!modal || !input || !productName || !currentPrice) return;

  let name = '';
  let price = 0;

  if (pendingProduct) {
    salePriceEditTarget = { type: 'pending', product_id: pendingProduct.id };
    name = pendingProduct.name;
    price = Number(pendingProduct.sale_price || 0);
    if (help) help.textContent = 'Este cambio se aplica al producto seleccionado antes de agregarlo a la venta.';
  } else {
    const item = getActiveCartItem();
    if (!item) {
      showToast('No hay producto cargado para cambiar precio. Agregá un producto y presioná Inicio.', true);
      return;
    }
    salePriceEditTarget = { type: 'cart', product_id: item.product_id };
    name = item.name;
    price = Number(item.unit_price || 0);
    if (help) help.textContent = 'Este cambio modifica solo el precio de este producto en la venta actual.';
  }

  productName.textContent = name;
  currentPrice.textContent = formatMoney(price);
  input.value = price ? String(price.toFixed(2)).replace('.', ',') : '';
  modal.classList.remove('hidden');
  modal.classList.add('show');
  modal.setAttribute('aria-hidden', 'false');
  setTimeout(() => {
    input.focus();
    input.select();
  }, 30);
}

function closeSalePriceModal(focusSale = true) {
  const modal = document.getElementById('salePriceModal');
  if (modal) {
    modal.classList.add('hidden');
    modal.classList.remove('show');
    modal.setAttribute('aria-hidden', 'true');
  }
  salePriceEditTarget = null;
  if (focusSale) {
    const input = document.getElementById('saleSearch');
    if (input) input.focus();
  }
}

function saveSalePriceChange() {
  const input = document.getElementById('salePriceInput');
  if (!input || !salePriceEditTarget) return;

  const price = parseSalePriceInput(input.value);
  if (price === null) {
    showToast('Ingresá un precio mayor a 0', true);
    input.focus();
    input.select();
    return;
  }

  if (salePriceEditTarget.type === 'pending' && pendingProduct && Number(pendingProduct.id) === Number(salePriceEditTarget.product_id)) {
    pendingProduct.sale_price = price;
    const pendingPrice = document.getElementById('pendingProductPrice');
    if (pendingPrice) pendingPrice.textContent = formatMoney(price);
    showToast(`Precio actualizado: ${formatMoney(price)}`);
    closeSalePriceModal(false);
    const qtyInput = document.getElementById('pendingQuantity');
    if (qtyInput) qtyInput.focus();
    return;
  }

  const item = cart.find(i => Number(i.product_id) === Number(salePriceEditTarget.product_id));
  if (!item) {
    showToast('El producto ya no está en la venta', true);
    closeSalePriceModal(true);
    return;
  }

  item.unit_price = price;
  activeCartProductId = item.product_id;
  lastTicket = null;
  setTicketActionButtonsEnabled(false);
  renderCart();
  closeSalePriceModal(true);
  showToast(`Precio de ${item.name} cambiado a ${formatMoney(price)}`);
}

function clearPendingProduct(focusSearch = true) {
  const { pending, qtyInput } = getSaleElements();
  pendingProduct = null;
  pending.classList.add('hidden');
  pending.dataset.productId = '';
  qtyInput.value = '';
  if (focusSearch) {
    const input = document.getElementById('saleSearch');
    input.value = '';
    input.focus();
  }
}

function prepareQuantityProduct(product) {
  const { pending, qtyInput } = getSaleElements();
  pendingProduct = product;
  hideSaleList();
  document.getElementById('pendingProductName').textContent = product.name;
  document.getElementById('pendingProductBarcode').textContent = product.barcode || 'Sin código';
  document.getElementById('pendingProductPrice').textContent = formatMoney(product.sale_price);
  document.getElementById('pendingProductStock').textContent = `Stock ${qtyLabel(product.stock || 0)}`;
  pending.dataset.productId = product.id;
  pending.classList.remove('hidden');
  document.getElementById('saleSearch').value = '';
  qtyInput.value = '';
  setTimeout(() => qtyInput.focus(), 30);
}

function confirmPendingQuantity() {
  if (!pendingProduct) return false;
  const { qtyInput } = getSaleElements();
  const qty = parseQuantity(qtyInput.value);
  if (qty === null) {
    showToast('La cantidad debe ser mayor a 0', true);
    qtyInput.focus();
    qtyInput.select();
    return false;
  }
  addToCart(pendingProduct, qty);
  clearPendingProduct(true);
  return true;
}

function addToCart(product, quantity = 1) {
  const qty = parseQuantity(quantity) || 1;
  const existing = cart.find(i => i.product_id === product.id);
  if (existing) {
    existing.quantity += qty;
    activeCartProductId = existing.product_id;
  } else {
    cart.push({
      product_id: product.id,
      name: product.name,
      unit_price: Number(product.sale_price),
      quantity: qty,
      barcode: product.barcode || '',
    });
    activeCartProductId = product.id;
  }
  lastTicket = null;
  setTicketActionButtonsEnabled(false);
  document.getElementById('saleSearch').value = '';
  document.getElementById('saleSearch').focus();
  hideSaleList();
  stopSaleNotFoundModal({ clearInput: false });
  beep();
  renderCart();
}

function updateQty(productId, value) {
  const item = cart.find(i => i.product_id === productId);
  if (!item) return;
  activeCartProductId = item.product_id;
  item.quantity = Math.max(0.01, Number(value || 1));
  renderCart();
}

function removeCartItem(productId) {
  cart = cart.filter(i => Number(i.product_id) !== Number(productId));
  if (Number(activeCartProductId) === Number(productId)) {
    activeCartProductId = cart.length ? cart[cart.length - 1].product_id : null;
  }
  renderCart();
}

function cartTotal() {
  return cart.reduce((sum, i) => sum + i.unit_price * i.quantity, 0);
}

function getAmountReceived(total) {
  const raw = Number(document.getElementById('amountReceived').value || 0);
  const method = document.getElementById('paymentMethod').value;
  if (method === 'Cuenta corriente') return 0;
  if (method !== 'Efectivo' && raw <= 0) return total;
  if (method === 'Efectivo' && raw <= 0) return total;
  return raw;
}

function updatePaymentSummary() {
  const total = cartTotal();
  const method = document.getElementById('paymentMethod').value;
  const received = getAmountReceived(total);
  const change = Math.max(0, received - total);

  document.getElementById('changeAmount').textContent = formatMoney(change);
  document.getElementById('ticketPaymentMethod').textContent = method;
  document.getElementById('ticketAmountReceived').textContent = formatMoney(received);
  document.getElementById('ticketChangeAmount').textContent = formatMoney(change);
  updateClientSelectorVisibility();
}

function renderTicketItems(items) {
  const ticketItems = document.getElementById('ticketItems');
  if (!items.length) {
    ticketItems.className = 'ticket-items empty-state';
    ticketItems.textContent = 'Sin productos cargados';
    return;
  }
  ticketItems.className = 'ticket-items';
  ticketItems.innerHTML = items.map(i => `
    <div class="ticket-line">
      <div>
        <span>${escapeHTML(i.name)}</span>
        <small>${escapeHTML(i.barcode || 'Sin código')}</small>
        <small>${qtyLabel(i.quantity)} x ${formatMoney(i.unit_price)}</small>
      </div>
      <strong>${formatMoney(Number(i.unit_price) * Number(i.quantity))}</strong>
    </div>
  `).join('');
}

function renderCart() {
  const tbody = document.getElementById('cartTable');
  const total = cartTotal();
  document.getElementById('saleTotal').textContent = formatMoney(total);
  updatePaymentSummary();

  if (!cart.length) {
    activeCartProductId = null;
    tbody.innerHTML = '<tr><td colspan="5" class="empty-state">Sin productos cargados</td></tr>';
    renderTicketItems([]);
    return;
  }

  if (!cart.some(i => Number(i.product_id) === Number(activeCartProductId))) {
    activeCartProductId = cart[cart.length - 1].product_id;
  }

  tbody.innerHTML = cart.map(i => {
    const isActive = Number(i.product_id) === Number(activeCartProductId);
    return `
      <tr class="cart-sale-row${isActive ? ' active' : ''}" data-product-id="${i.product_id}" tabindex="0" onclick="selectCartItem(${i.product_id})">
        <td>${escapeHTML(i.name)}<br><small>${escapeHTML(i.barcode || 'Sin código')}</small></td>
        <td><input class="qty-input" type="number" step="0.01" min="0.01" value="${i.quantity}" onchange="updateQty(${i.product_id}, this.value)" onclick="event.stopPropagation()"></td>
        <td><button type="button" class="price-edit-button" onclick="event.stopPropagation(); selectCartItem(${i.product_id}); openSalePriceModal();" title="Cambiar precio con tecla Inicio">${formatMoney(i.unit_price)}</button></td>
        <td>${formatMoney(i.unit_price * i.quantity)}</td>
        <td><button class="tiny-button delete" onclick="event.stopPropagation(); removeCartItem(${i.product_id})">×</button></td>
      </tr>
    `;
  }).join('');

  document.getElementById('ticketNumber').textContent = 'Venta nueva';
  document.getElementById('ticketDate').textContent = formatDateAR(new Date().toISOString());
  renderTicketItems(cart);

  const cartWrap = document.querySelector('.cart-table-wrap');
  if (cartWrap && cart.length > 7) {
    cartWrap.scrollTop = cartWrap.scrollHeight;
  }
}

function renderCompletedTicket(sale) {
  lastTicket = sale;
  setTicketActionButtonsEnabled(true);
  document.getElementById('ticketNumber').textContent = sale.ticket_number || `T-${String(sale.sale_id).padStart(6, '0')}`;
  document.getElementById('ticketDate').textContent = sale.created_at_formatted || formatDateAR(sale.created_at);
  document.getElementById('ticketCashier').textContent = sale.cashier || 'admin';
  const ticketClient = document.getElementById('ticketClientName');
  if (ticketClient) ticketClient.textContent = sale.client_name || 'Consumidor final';
  document.getElementById('saleTotal').textContent = formatMoney(sale.total);
  document.getElementById('ticketPaymentMethod').textContent = sale.payment_method || 'Efectivo';
  document.getElementById('ticketAmountReceived').textContent = formatMoney(sale.amount_received);
  document.getElementById('ticketChangeAmount').textContent = formatMoney(sale.change_amount);
  document.getElementById('changeAmount').textContent = formatMoney(sale.change_amount);
  renderTicketItems(sale.items || []);
}

function moveSale(delta) {
  const { list } = getSaleElements();
  if (list.classList.contains('hidden') || !saleProducts.length) return;
  saleIndex = Math.max(0, Math.min(saleProducts.length - 1, saleIndex + delta));
  renderSelectableList(list, saleProducts, saleIndex, prepareQuantityProduct);
  ensureActiveSaleVisible();
}

function stopSaleResetCountdown() {
  if (saleResetCountdownInterval) {
    clearInterval(saleResetCountdownInterval);
    saleResetCountdownInterval = null;
  }
  if (saleResetCountdownTimeout) {
    clearTimeout(saleResetCountdownTimeout);
    saleResetCountdownTimeout = null;
  }
  const overlay = document.getElementById('saleOperationDialog');
  if (overlay) overlay.classList.add('hidden');
  closeNativeOperationDialog();
}

function showSaleOperationModal(message = 'Aguarde un momento...', counterValue = SALE_RESET_COUNTDOWN_SECONDS) {
  const dialog = document.getElementById('saleOperationDialog');
  const label = document.getElementById('saleResetLabel');
  const messageBox = document.getElementById('saleResetMessage');
  const counter = document.getElementById('saleResetCountdown');

  if (label) label.textContent = 'REALIZANDO OPERACIÓN';
  if (messageBox) messageBox.textContent = message;
  if (counter) counter.textContent = String(counterValue);

  // Modal interno sobre la pantalla de Venta, no ventana nueva del navegador.
  if (dialog) {
    dialog.classList.remove('hidden');
    dialog.classList.add('show');
    dialog.setAttribute('aria-hidden', 'false');
  }
}

function updateSaleResetCountdown(seconds) {
  const counter = document.getElementById('saleResetCountdown');
  if (counter) counter.textContent = String(seconds);
}

function startSaleResetCountdown(message = 'Operación finalizada. Volviendo a la ventana principal...', options = {}) {
  stopSaleResetCountdown();
  let seconds = SALE_RESET_COUNTDOWN_SECONDS;
  const redirectToMain = options.redirectToMain === true;
  showSaleOperationModal(message, seconds);

  saleResetCountdownInterval = setInterval(() => {
    seconds -= 1;
    updateSaleResetCountdown(Math.max(seconds, 0));
  }, 1000);

  saleResetCountdownTimeout = setTimeout(() => {
    if (redirectToMain) {
      goToMainWindow();
      return;
    }
    resetSale({ silent: true, fromCountdown: true });
    showToast('Pantalla limpia. Nueva venta lista.');
  }, SALE_RESET_COUNTDOWN_SECONDS * 1000);
}

async function finishSale(options = {}) {
  if (isFinishingSale) return null;
  showSaleOperationModal('Validando venta...', SALE_RESET_COUNTDOWN_SECONDS);
  await waitForOperationModalPaint();

  if (!cart.length) {
    if (lastTicket) {
      showToast(`Venta ${lastTicket.ticket_number || ''} ya está cerrada`);
      return lastTicket;
    }
    showSaleOperationModal('No hay productos para vender.', '0');
    setTimeout(() => stopSaleResetCountdown(), 900);
    showToast('No hay productos para vender', true);
    return null;
  }

  const total = cartTotal();
  const paymentMethod = document.getElementById('paymentMethod').value;
  const clientId = getCurrentClientId();
  const amountReceived = getAmountReceived(total);
  if (paymentMethod === 'Cuenta corriente' && !clientId) {
    showSaleOperationModal('Seleccioná un cliente para cuenta corriente.', '0');
    setTimeout(() => stopSaleResetCountdown(), 1100);
    showToast('Seleccioná un cliente para cuenta corriente', true);
    document.getElementById('saleClient').focus();
    return null;
  }
  if (paymentMethod === 'Efectivo' && amountReceived < total) {
    showSaleOperationModal('El importe recibido no puede ser menor al total.', '0');
    setTimeout(() => stopSaleResetCountdown(), 1100);
    showToast('El importe recibido no puede ser menor al total', true);
    document.getElementById('amountReceived').focus();
    return null;
  }

  try {
    isFinishingSale = true;
    showSaleOperationModal('Cerrando venta...', SALE_RESET_COUNTDOWN_SECONDS);
    await waitForOperationModalPaint();
    const payload = {
      payment_method: paymentMethod,
      amount_received: amountReceived,
      client_id: clientId,
      items: cart.map(i => ({ product_id: i.product_id, quantity: i.quantity, unit_price: i.unit_price }))
    };
    const sale = await api('/api/sales', { method: 'POST', body: JSON.stringify(payload) });
    renderCompletedTicket(sale);
    cart = [];
    document.getElementById('cartTable').innerHTML = '<tr><td colspan="5" class="empty-state">Venta cerrada. Cuenta regresiva iniciada para una nueva carga.</td></tr>';
    document.getElementById('amountReceived').value = '';
    showToast(`Venta ${sale.ticket_number} cerrada sin emitir PDF: ${formatMoney(sale.total)}`);
    if (options.resetCountdown !== false) {
      startSaleResetCountdown('Venta cerrada. Volviendo a la ventana principal...', { redirectToMain: true });
    }
    return sale;
  } catch (err) {
    stopSaleResetCountdown();
    showToast(err.message, true);
    return null;
  } finally {
    isFinishingSale = false;
  }
}

async function ensureSaleClosedForTicket(options = {}) {
  if (lastTicket && lastTicket.sale_id) return lastTicket;
  if (cart.length) return await finishSale(options);
  showToast('No hay venta cerrada para emitir ticket', true);
  return null;
}

async function emitTicketPdf(shouldPrint = false) {
  if (isGeneratingPdf) return;
  showSaleOperationModal(shouldPrint ? 'Preparando ticket PDF e impresión...' : 'Preparando ticket PDF...', SALE_RESET_COUNTDOWN_SECONDS);
  await waitForOperationModalPaint();

  const sale = await ensureSaleClosedForTicket({ resetCountdown: false });
  if (!sale || !sale.sale_id) {
    showSaleOperationModal('No hay venta para emitir ticket.', '0');
    setTimeout(() => stopSaleResetCountdown(), 1000);
    return;
  }

  try {
    isGeneratingPdf = true;
    showSaleOperationModal(shouldPrint ? 'Generando ticket PDF, guardando e imprimiendo...' : 'Generando ticket PDF y guardando en TICKET...', SALE_RESET_COUNTDOWN_SECONDS);
    await waitForOperationModalPaint();
    showToast(shouldPrint ? 'Generando PDF e imprimiendo ticket...' : 'Generando ticket PDF...');
    const result = await api(`/api/sales/${sale.sale_id}/ticket-pdf`, {
      method: 'POST',
      body: JSON.stringify({ print: shouldPrint })
    });
    if (shouldPrint) {
      if (result.printed) {
        showToast(`PDF guardado e impresión enviada: ${result.filename}`);
      } else {
        showToast(result.print_message || `PDF guardado: ${result.filename}`, true);
      }
    } else {
      showToast(`Ticket PDF guardado en carpeta TICKET: ${result.filename}`);
    }
  } catch (err) {
    showToast(err.message, true);
  } finally {
    isGeneratingPdf = false;
    // La cuenta regresiva inicia recién al terminar la generación/impresión.
    if (sale && sale.sale_id) {
      startSaleResetCountdown(shouldPrint ? 'Operación finalizada. Ticket guardado e impresión enviada. Volviendo al panel principal...' : 'Operación finalizada. Ticket guardado. Volviendo al panel principal...', { redirectToMain: true });
    }
  }
}

function resetSale(options = {}) {
  if (!options.fromCountdown) {
    stopSaleResetCountdown();
    stopSaleNotFoundModal({ clearInput: false });
  } else {
    const overlay = document.getElementById('saleOperationDialog');
    if (overlay) overlay.classList.add('hidden');
    closeNativeOperationDialog();
    if (saleResetCountdownInterval) {
      clearInterval(saleResetCountdownInterval);
      saleResetCountdownInterval = null;
    }
    if (saleResetCountdownTimeout) {
      clearTimeout(saleResetCountdownTimeout);
      saleResetCountdownTimeout = null;
    }
  }

  stopSaleNotFoundModal({ clearInput: false });
  cart = [];
  lastTicket = null;
  pendingProduct = null;
  activeCartProductId = null;
  closeSalePriceModal(false);
  document.getElementById('ticketNumber').textContent = 'Venta nueva';
  document.getElementById('ticketDate').textContent = '--/--/----';
  document.getElementById('amountReceived').value = '';
  document.getElementById('paymentMethod').value = 'Efectivo';
  selectedClient = null;
  if (document.getElementById('saleClient')) document.getElementById('saleClient').value = '';
  const ticketClient = document.getElementById('ticketClientName');
  if (ticketClient) ticketClient.textContent = 'Consumidor final';
  updateClientSelectorVisibility();
  syncSelectedClientUI();
  setTicketActionButtonsEnabled(false);
  hideSaleList();
  clearPendingProduct(false);
  renderCart();
  const input = document.getElementById('saleSearch');
  if (input) {
    input.value = '';
    input.focus();
  }
  if (!options.silent) showToast('Venta limpia');
}


async function reprintLastTicket() {
  try {
    const sale = await api('/api/sales/last');
    const result = await api(`/api/sales/${sale.sale_id}/ticket-pdf`, { method: 'POST', body: JSON.stringify({ print: true }) });
    showToast(result.printed ? `Último ticket reenviado: ${sale.ticket_number}` : `Ticket guardado: ${result.filename}`);
  } catch (err) {
    showToast(err.message, true);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  document.body.classList.add('sales-modal-open');
  renderCart();
  loadSaleClients();
  updateClientSelectorVisibility();
  const input = document.getElementById('saleSearch');
  const pendingQty = document.getElementById('pendingQuantity');
  const confirmQtyBtn = document.getElementById('confirmQuantityBtn');
  const cancelQtyBtn = document.getElementById('cancelQuantityBtn');
  const clientSearchInput = document.getElementById('saleClientSearch');

  if (!input || !pendingQty || !confirmQtyBtn || !cancelQtyBtn) {
    console.error('Módulo Venta incompleto: faltan elementos principales de la pantalla.');
    showToast('Error al cargar Venta: faltan elementos de la pantalla.', true);
    return;
  }

  if (window.POSBarcodeScanner) {
    saleScanner = new POSBarcodeScanner({
      onDetected: handleScannedSaleCode,
      onClose: () => input.focus(),
    });
  }
  document.getElementById('openSaleScannerBtn')?.addEventListener('click', () => saleScanner?.open());
  document.getElementById('openSaleScannerInlineBtn')?.addEventListener('click', () => saleScanner?.open());

  document.getElementById('selectClientBtn')?.addEventListener('click', openClientModal);
  document.getElementById('selectClientHeaderBtn')?.addEventListener('click', openClientModal);
  document.getElementById('clearClientBtn')?.addEventListener('click', clearSelectedClient);
  document.getElementById('finalConsumerBtn')?.addEventListener('click', clearSelectedClient);
  document.getElementById('closeClientModalBtn')?.addEventListener('click', () => closeClientModal(true));
  document.getElementById('chooseClientBtn')?.addEventListener('click', () => selectClientFromModal(clientModalIndex));
  document.getElementById('closeSalePriceModalBtn')?.addEventListener('click', () => closeSalePriceModal(true));
  document.getElementById('cancelSalePriceBtn')?.addEventListener('click', () => closeSalePriceModal(true));
  document.getElementById('saveSalePriceBtn')?.addEventListener('click', saveSalePriceChange);
  document.getElementById('salePriceInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      saveSalePriceChange();
      return;
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      closeSalePriceModal(true);
    }
  });

  if (clientSearchInput) {
    clientSearchInput.addEventListener('input', () => {
      filteredSaleClients = filterSaleClients(clientSearchInput.value);
      renderClientModalList(0);
    });
    clientSearchInput.addEventListener('keydown', e => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        moveClientModal(1);
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        moveClientModal(-1);
        return;
      }
      if (e.key === 'Enter') {
        e.preventDefault();
        selectClientFromModal(clientModalIndex);
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        closeClientModal(true);
      }
    });
  }

  pendingQty.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      confirmPendingQuantity();
      return;
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      clearPendingProduct(true);
    }
  });

  confirmQtyBtn.addEventListener('click', confirmPendingQuantity);
  cancelQtyBtn.addEventListener('click', () => clearPendingProduct(true));

  input.addEventListener('input', () => {
    stopSaleNotFoundModal({ clearInput: false });
    scheduleSaleLiveSearch(input.value);
  });

  input.addEventListener('keydown', async e => {
    const { list } = getSaleElements();
    const listVisible = !list.classList.contains('hidden');

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (!listVisible) {
        try { await searchSaleProduct(input.value.trim()); }
        catch (err) { showToast(err.message, true); }
      } else {
        moveSale(1);
      }
      return;
    }

    if (e.key === 'ArrowUp') {
      e.preventDefault();
      moveSale(-1);
      return;
    }

    if (e.key === 'Enter') {
      e.preventDefault();
      if (isSaleNotFoundVisible()) {
        stopSaleNotFoundModal({ clearInput: true });
        return;
      }
      stopSaleNotFoundModal({ clearInput: false });
      try {
        if (listVisible && saleProducts.length) {
          selectActiveSaleProduct();
        } else {
          await searchSaleProduct(input.value.trim());
        }
      } catch (err) {
        showToast(err.message, true);
      }
      return;
    }

    if (e.key === 'Escape') {
      hideSaleList();
      stopSaleNotFoundModal({ clearInput: true });
      return;
    }
  });

  document.getElementById('paymentMethod').addEventListener('change', () => { updatePaymentSummary(); updateClientSelectorVisibility(); });
  document.getElementById('saleClient')?.addEventListener('change', (event) => {
    const selectedId = String(event.target.value || '');
    selectedClient = saleClients.find(c => String(c.id) === selectedId) || null;
    syncSelectedClientUI();
  });
  document.getElementById('amountReceived').addEventListener('input', updatePaymentSummary);
  document.getElementById('finishSaleBtn').addEventListener('click', () => finishSale());
  document.getElementById('clearSaleBtn').addEventListener('click', resetSale);
  document.getElementById('pdfTicketBtn').addEventListener('click', () => emitTicketPdf(false));
  document.getElementById('pdfPrintTicketBtn').addEventListener('click', () => emitTicketPdf(true));
  document.getElementById('reprintLastBtn').addEventListener('click', reprintLastTicket);
  document.querySelector('.sale-exit-button')?.addEventListener('click', e => {
    e.preventDefault();
    goToMainWindow();
  });

  window.addEventListener('keydown', async e => {
    if (e.ctrlKey || e.altKey || e.shiftKey || e.metaKey || e.repeat) return;
    if (e.defaultPrevented) return;
    const functionKey = (/^F(?:[1-9]|1[0-2])$/i.test(String(e.key || '')) ? String(e.key).toUpperCase() : String(e.code || '').toUpperCase());

    if (e.key === 'Home' || e.code === 'Home') {
      if (e.target && e.target.id === 'salePriceInput') return;
      e.preventDefault();
      e.stopPropagation();
      openSalePriceModal();
      return;
    }

    if (e.key === 'Insert' || e.code === 'Insert') {
      e.preventDefault();
      e.stopPropagation();
      if (saleScanner?.openAndStart) {
        saleScanner.openAndStart();
      } else if (saleScanner?.open) {
        saleScanner.open(true);
      } else {
        showToast('El escáner por cámara no está disponible en esta pantalla.', true);
      }
      return;
    }

    if (e.key === 'Escape') {
      const scannerModal = document.getElementById('barcodeScannerModal');
      if (isSalePriceModalVisible()) {
        e.preventDefault();
        e.stopPropagation();
        closeSalePriceModal(true);
        return;
      }
      if (scannerModal && !scannerModal.classList.contains('hidden')) {
        e.preventDefault();
        e.stopPropagation();
        saleScanner?.close();
        return;
      }
      e.preventDefault();
      e.stopPropagation();
      goToMainWindow();
      return;
    }

    if (functionKey === 'F9') {
      e.preventDefault();
      e.stopPropagation();
      await openClientModal();
      return;
    }

    if (functionKey === 'F6') {
      e.preventDefault();
      e.stopPropagation();
      await finishSale();
      return;
    }

    if (functionKey === 'F7') {
      e.preventDefault();
      e.stopPropagation();
      await emitTicketPdf(false);
      return;
    }

    if (functionKey === 'F8') {
      e.preventDefault();
      e.stopPropagation();
      await emitTicketPdf(true);
      return;
    }
  }, false);
});
