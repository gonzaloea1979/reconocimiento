let purchaseProducts = [];
let purchaseSuppliers = [];
let purchaseItems = [];
let selectedPurchaseProduct = null;
let purchaseSearchMatches = [];
let quickPhotoObjectUrl = null;

function purchaseSelectedSupplierId() {
  return document.getElementById('purchaseSupplier')?.value || '';
}

function roundingModeTextForPurchase(mode) {
  return {
    none: 'Sin redondeo',
    nearest: 'Al más cercano',
    up: 'Siempre hacia arriba',
    down: 'Siempre hacia abajo',
  }[mode] || 'Sin redondeo';
}

function getPurchaseGlobalRoundingSettings() {
  const settings = window.POS_SETTINGS || {};
  return {
    mode: settings.product_rounding_mode || 'none',
    multiple: Number(settings.product_rounding_multiple || 1) || 1,
  };
}

function applyPurchaseRounding(value) {
  const { mode, multiple } = getPurchaseGlobalRoundingSettings();
  return window.POSMoneyDecimal
    ? window.POSMoneyDecimal.roundPrice(value, mode, multiple)
    : value;
}

function updateQuickRoundingLabel() {
  const label = document.getElementById('quickGlobalRoundingLabel');
  if (!label) return;
  const { mode, multiple } = getPurchaseGlobalRoundingSettings();
  label.textContent = mode === 'none' ? 'Sin redondeo' : `${roundingModeTextForPurchase(mode)} a múltiplo de $${multiple}`;
}

function updateQuickProductPreview() {
  const cost = document.getElementById('quickCost')?.value || 0;
  const iva = document.getElementById('quickIva')?.value || 0;
  const gross = document.getElementById('quickGross')?.value || 0;
  const margin = document.getElementById('quickMargin')?.value || 0;
  const { mode, multiple } = getPurchaseGlobalRoundingSettings();
  const values = window.POSMoneyDecimal
    ? window.POSMoneyDecimal.calculatePriceValues(cost, iva, gross, margin, mode, multiple)
    : (() => {
        const totalCost = Number(cost) + Number(cost) * Number(iva) / 100 + Number(cost) * Number(gross) / 100;
        const rawSale = totalCost + totalCost * Number(margin) / 100;
        return { totalCost, rawSale, salePrice: applyPurchaseRounding(rawSale) };
      })();
  const totalEl = document.getElementById('quickTotalCost');
  const rawEl = document.getElementById('quickSaleRaw');
  const saleEl = document.getElementById('quickSalePrice');
  if (totalEl) totalEl.value = values.totalCost.toFixed(2);
  if (rawEl) rawEl.value = values.rawSale.toFixed(2);
  if (saleEl) saleEl.value = values.salePrice.toFixed(2);
  updateQuickRoundingLabel();
}

function purchaseCalculateValues(cost, iva, gross, margin) {
  const { mode, multiple } = getPurchaseGlobalRoundingSettings();
  if (window.POSMoneyDecimal) {
    const values = window.POSMoneyDecimal.calculatePriceValues(cost || 0, iva || 0, gross || 0, margin || 0, mode, multiple);
    return { realCost: values.totalCost, rawSale: values.rawSale, salePrice: values.salePrice };
  }
  const baseCost = Number(cost || 0);
  const ivaPercent = Number(iva || 0);
  const grossPercent = Number(gross || 0);
  const marginPercent = Number(margin || 0);
  const realCost = baseCost + (baseCost * ivaPercent / 100) + (baseCost * grossPercent / 100);
  const rawSale = realCost + (realCost * marginPercent / 100);
  return { realCost, rawSale, salePrice: applyPurchaseRounding(rawSale) };
}

function updatePurchaseCostPreview() {
  // Mantener los textos originales hasta el cálculo decimal compartido.
  const cost = document.getElementById('purchaseCost')?.value || '0';
  const iva = document.getElementById('purchaseIva')?.value || '0';
  const gross = document.getElementById('purchaseGross')?.value || '0';
  const margin = document.getElementById('purchaseMargin')?.value || '0';
  const calc = purchaseCalculateValues(cost, iva, gross, margin);
  const realEl = document.getElementById('purchaseRealCost');
  const saleEl = document.getElementById('purchaseSalePrice');
  if (realEl) realEl.value = calc.realCost.toFixed(2);
  if (saleEl) saleEl.value = calc.salePrice.toFixed(2);
  return calc;
}

function fillPurchaseCostFieldsFromProduct(product) {
  const costInput = document.getElementById('purchaseCost');
  const ivaInput = document.getElementById('purchaseIva');
  const grossInput = document.getElementById('purchaseGross');
  const marginInput = document.getElementById('purchaseMargin');
  const expiryInput = document.getElementById('purchaseExpiry');
  if (costInput) costInput.value = Number(product?.cost_without_tax || 0).toFixed(2);
  if (ivaInput) ivaInput.value = Number(product?.iva_percent || 0).toFixed(2);
  if (grossInput) grossInput.value = Number(product?.gross_income_percent || 0).toFixed(2);
  if (marginInput) marginInput.value = Number(product?.margin_percent || 0).toFixed(2);
  if (expiryInput) expiryInput.value = product?.expiry_date ? formatDateAR(product.expiry_date) : '';
  updatePurchaseCostPreview();
}

function clearPurchaseCostFields() {
  const values = {
    purchaseCost: '0',
    purchaseIva: '21',
    purchaseGross: '0',
    purchaseMargin: '30',
    purchaseExpiry: '',
  };
  Object.entries(values).forEach(([id, value]) => {
    const el = document.getElementById(id);
    if (el) el.value = value;
  });
  updatePurchaseCostPreview();
}

function setQuickPhotoPreview(url = '') {
  if (quickPhotoObjectUrl && quickPhotoObjectUrl !== url) {
    URL.revokeObjectURL(quickPhotoObjectUrl);
    quickPhotoObjectUrl = null;
  }
  if (url && String(url).startsWith('blob:')) quickPhotoObjectUrl = url;
  const preview = document.getElementById('quickPhotoPreview');
  if (!preview) return;
  if (url) preview.innerHTML = `<img src="${escapeHTML(url)}" alt="Foto del producto"><span>Foto cargada</span>`;
  else preview.innerHTML = '<span>Sin foto</span>';
}

function updatePurchaseProductSelect() {
  const select = document.getElementById('purchaseProduct');
  if (!select) return;
  select.innerHTML = purchaseProducts.length
    ? purchaseProducts.map(p => `<option value="${p.id}">${escapeHTML(p.name)} · Stock ${p.stock}</option>`).join('')
    : '<option value="">Sin productos registrados</option>';
}

function updateQuickSupplierSelect() {
  const select = document.getElementById('quickSupplier');
  if (!select) return;
  const current = select.value || purchaseSelectedSupplierId();
  select.innerHTML = '<option value="">Sin proveedor</option>' + purchaseSuppliers.map(s => `<option value="${s.id}">${escapeHTML(s.name)}</option>`).join('');
  if (current) select.value = current;
}

function purchaseProductLabel(p) {
  return `${p.name}${p.barcode ? ' · ' + p.barcode : ''}`;
}

function showPurchaseSelectedProduct(product) {
  selectedPurchaseProduct = product || null;
  const card = document.getElementById('purchaseSelectedCard');
  const name = document.getElementById('purchaseSelectedName');
  const meta = document.getElementById('purchaseSelectedMeta');
  if (!card || !name || !meta) return;
  if (!product) {
    card.classList.add('hidden');
    clearPurchaseCostFields();
    return;
  }
  name.textContent = product.name;
  meta.textContent = `${product.barcode || 'Sin código'} · Stock actual ${product.stock} · Precio venta actual ${formatMoney(product.sale_price)}`;
  fillPurchaseCostFieldsFromProduct(product);
  card.classList.remove('hidden');
}

function clearPurchaseSearchResults() {
  const list = document.getElementById('purchaseSearchResults');
  if (list) list.innerHTML = '';
  purchaseSearchMatches = [];
}

function renderPurchaseSearchResults(results) {
  const list = document.getElementById('purchaseSearchResults');
  if (!list) return;
  purchaseSearchMatches = results || [];
  if (!purchaseSearchMatches.length) {
    list.innerHTML = '<div class="empty-state compact-empty">No se encontró el producto. Presioná Enter para registrarlo con el formulario completo.</div>';
    return;
  }
  list.innerHTML = purchaseSearchMatches.map(p => `
    <button class="purchase-search-option" type="button" onclick="selectPurchaseProduct(${p.id})">
      <span><strong>${escapeHTML(p.name)}</strong><small>${escapeHTML(p.barcode || 'Sin código')} · Stock ${p.stock}</small></span>
      <b>${formatMoney(p.sale_price)}</b>
    </button>
  `).join('');
}

function searchPurchaseProducts() {
  const input = document.getElementById('purchaseSearch');
  const term = (input?.value || '').trim().toLowerCase();
  if (!term) {
    const results = purchaseProducts.slice(0, 30);
    renderPurchaseSearchResults(results);
    return results;
  }
  const results = purchaseProducts.filter(p =>
    String(p.barcode || '').toLowerCase().includes(term) ||
    String(p.name || '').toLowerCase().includes(term) ||
    String(p.detail || '').toLowerCase().includes(term)
  ).slice(0, 30);
  renderPurchaseSearchResults(results);
  return results;
}

function selectPurchaseProduct(productId) {
  const product = purchaseProducts.find(p => Number(p.id) === Number(productId));
  if (!product) return;
  const select = document.getElementById('purchaseProduct');
  const search = document.getElementById('purchaseSearch');
  if (select) select.value = product.id;
  if (search) search.value = purchaseProductLabel(product);
  showPurchaseSelectedProduct(product);
  clearPurchaseSearchResults();
  const qty = document.getElementById('purchaseQty');
  if (qty) qty.focus();
}

function selectPurchaseProductFromDropdown() {
  const select = document.getElementById('purchaseProduct');
  if (!select || !select.value) return;
  selectPurchaseProduct(select.value);
}

function resetQuickProductDefaults() {
  const defaults = {
    quickBarcode: '',
    quickName: '',
    quickDetail: '',
    quickCost: '',
    quickIva: '21',
    quickGross: '0',
    quickMargin: '30',
    quickStock: '0',
    quickMinStock: '0',
    quickExpiry: '',
  };
  Object.entries(defaults).forEach(([id, value]) => {
    const el = document.getElementById(id);
    if (el) el.value = value;
  });
  const photo = document.getElementById('quickPhoto');
  if (photo) photo.value = '';
  const quickSupplier = document.getElementById('quickSupplier');
  if (quickSupplier) quickSupplier.value = purchaseSelectedSupplierId();
  setQuickPhotoPreview('');
  updateQuickProductPreview();
}

function showQuickProductForm(prefill = '') {
  const panel = document.getElementById('quickProductPanel');
  const barcode = document.getElementById('quickBarcode');
  const name = document.getElementById('quickName');
  const cost = document.getElementById('quickCost');
  const purchaseCost = document.getElementById('purchaseCost');
  const title = document.getElementById('quickProductTitle');
  const help = document.getElementById('quickProductHelp');
  if (!panel) return;

  resetQuickProductDefaults();
  updateQuickSupplierSelect();

  const raw = String(prefill || document.getElementById('purchaseSearch')?.value || '').trim();
  if (/^\d+$/.test(raw)) {
    if (barcode) barcode.value = raw;
    if (title) title.textContent = 'Producto no registrado';
    if (help) help.textContent = `El código ${raw} no existe. Cargalo como producto nuevo, igual que desde el módulo Productos.`;
  } else if (raw) {
    if (name) name.value = raw;
    if (title) title.textContent = 'Agregar producto no registrado';
    if (help) help.textContent = 'Completá los datos como en el módulo Productos. Al guardar, queda agregado al detalle de esta compra.';
  } else {
    if (title) title.textContent = 'Agregar producto no registrado';
    if (help) help.textContent = 'Completá los datos como en el módulo Productos. Al guardar, queda agregado al detalle de esta compra.';
  }

  if (cost && purchaseCost && Number(purchaseCost.value || 0) > 0) cost.value = purchaseCost.value;
  updateQuickProductPreview();

  panel.classList.remove('hidden');
  setTimeout(() => {
    if (name && !name.value) name.focus();
    else if (barcode && !barcode.value) barcode.focus();
    else if (name) name.focus();
  }, 50);
}

function hideQuickProductForm() {
  const panel = document.getElementById('quickProductPanel');
  if (panel) panel.classList.add('hidden');
}

function clearQuickProductForm() {
  resetQuickProductDefaults();
}

async function apiPurchaseProductForm(url, method, formData) {
  const res = await fetch(url, { method, body: formData });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Ocurrió un error');
  return data;
}

async function createProductFromPurchase() {
  const barcode = (document.getElementById('quickBarcode')?.value || '').trim();
  const name = (document.getElementById('quickName')?.value || '').trim();
  const detail = (document.getElementById('quickDetail')?.value || '').trim();
  const cost = Number(document.getElementById('quickCost')?.value || document.getElementById('purchaseCost')?.value || 0);
  const qty = Number(document.getElementById('purchaseQty')?.value || 1);
  const iva = Number(document.getElementById('quickIva')?.value || 0);
  const gross = Number(document.getElementById('quickGross')?.value || 0);
  const margin = Number(document.getElementById('quickMargin')?.value || 0);
  const stock = Number(document.getElementById('quickStock')?.value || 0);
  const minStock = Number(document.getElementById('quickMinStock')?.value || 0);
  const expiryInput = (document.getElementById('quickExpiry')?.value || document.getElementById('purchaseExpiry')?.value || '').trim();
  const supplierId = document.getElementById('quickSupplier')?.value || purchaseSelectedSupplierId();

  if (!name) {
    showToast('Ingresá el nombre del producto nuevo', true);
    document.getElementById('quickName')?.focus();
    return;
  }
  if (qty <= 0) {
    showToast('La cantidad comprada debe ser mayor a cero', true);
    document.getElementById('purchaseQty')?.focus();
    return;
  }

  const normalizedExpiry = normalizeDateToISO(expiryInput);
  if (expiryInput && normalizedExpiry === null) {
    showToast('La fecha de vencimiento debe tener formato DD/MM/AAAA o DDMMAA. Ejemplo: 20/06/2026 o 200626', true);
    document.getElementById('quickExpiry')?.focus();
    return;
  }

  const formData = new FormData();
  formData.append('barcode', barcode);
  formData.append('name', name);
  formData.append('detail', detail);
  formData.append('cost_without_tax', String(cost));
  formData.append('iva_percent', String(iva));
  formData.append('gross_income_percent', String(gross));
  formData.append('margin_percent', String(margin));
  formData.append('stock', String(stock));
  formData.append('min_stock', String(minStock));
  formData.append('supplier_id', supplierId || '');
  formData.append('expiry_date', normalizedExpiry || '');

  const photoInput = document.getElementById('quickPhoto');
  if (photoInput && photoInput.files && photoInput.files[0]) {
    formData.append('photo', photoInput.files[0]);
  }

  try {
    const product = await apiPurchaseProductForm('/api/products', 'POST', formData);
    purchaseProducts.push(product);
    purchaseProducts.sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
    updatePurchaseProductSelect();
    selectPurchaseProduct(product.id);
    fillPurchaseCostFieldsFromProduct(product);
    addPurchaseItem();
    clearQuickProductForm();
    hideQuickProductForm();
    showToast('Producto registrado y agregado a la compra');
  } catch (e) {
    showToast(e.message, true);
  }
}

async function loadPurchasesModule() {
  const [suppliers, products, purchases] = await Promise.all([
    api('/api/suppliers'),
    api('/api/products'),
    api('/api/purchases')
  ]);
  purchaseSuppliers = suppliers;
  purchaseProducts = products;

  const supplierSelect = document.getElementById('purchaseSupplier');
  if (supplierSelect) {
    supplierSelect.innerHTML = '<option value="">Sin proveedor</option>' + suppliers.map(s => `<option value="${s.id}">${escapeHTML(s.name)}</option>`).join('');
  }
  updatePurchaseProductSelect();
  updateQuickSupplierSelect();

  const list = document.getElementById('purchasesList');
  if (list) {
    list.innerHTML = purchases.length ? purchases.map(p => {
      const items = p.items_summary || 'Sin detalle de productos';
      return `
        <div class="advanced-item purchase-history-item" onclick="openPurchaseDetail(${p.id})">
          <div><strong>#${p.id} · ${formatMoney(p.total)}</strong><small>${escapeHTML(items)}</small></div>
          <span>${p.created_at_formatted} · ${escapeHTML(p.supplier_display || 'Sin proveedor')}</span>
        </div>
      `;
    }).join('') : '<div class="empty-state">Sin compras</div>';
  }
}

async function openPurchaseDetail(purchaseId) {
  try {
    const data = await api(`/api/purchases/${purchaseId}`);
    const modal = document.getElementById('purchaseDetailModal');
    const body = document.getElementById('purchaseDetailBody');
    if (!modal || !body) return;
    const itemsHtml = (data.items || []).map(i => `
      <tr>
        <td>${escapeHTML(i.product_name)}</td>
        <td>${i.quantity}</td>
        <td>${formatMoney(i.cost_without_tax ?? i.unit_cost)}</td>
        <td>${formatMoney(i.total_cost ?? i.unit_cost)}</td>
        <td>${formatMoney(i.sale_price || 0)}</td>
        <td>${formatDateAR(i.expiry_date)}</td>
        <td>${formatMoney(i.line_total)}</td>
      </tr>
    `).join('');
    body.innerHTML = `
      <h3>Compra #${data.purchase.id}</h3>
      <p>${data.purchase.created_at_formatted} · ${escapeHTML(data.purchase.supplier_name || 'Sin proveedor')}</p>
      <div class="table-scroll"><table class="modern-table"><thead><tr><th>Producto</th><th>Cant.</th><th>Costo s/imp.</th><th>Costo real</th><th>Venta</th><th>Venc.</th><th>Total</th></tr></thead><tbody>${itemsHtml}</tbody></table></div>
      <div class="total-strip"><span>Total</span><strong>${formatMoney(data.purchase.total)}</strong></div>
    `;
    modal.classList.remove('hidden');
  } catch (e) {
    showToast(e.message, true);
  }
}

function closePurchaseDetail() {
  const modal = document.getElementById('purchaseDetailModal');
  if (modal) modal.classList.add('hidden');
}

function addPurchaseItem() {
  let product = selectedPurchaseProduct;
  const select = document.getElementById('purchaseProduct');
  if (!product && select?.value) product = purchaseProducts.find(x => Number(x.id) === Number(select.value));
  if (!product) {
    showToast('Seleccioná un producto o registrá uno nuevo', true);
    return;
  }
  const qty = Number(document.getElementById('purchaseQty')?.value || 1);
  const costWithoutTaxInput = document.getElementById('purchaseCost')?.value || String(product.cost_without_tax || 0);
  const ivaPercentInput = document.getElementById('purchaseIva')?.value || String(product.iva_percent || 0);
  const grossPercentInput = document.getElementById('purchaseGross')?.value || String(product.gross_income_percent || 0);
  const marginPercentInput = document.getElementById('purchaseMargin')?.value || String(product.margin_percent || 0);
  const costWithoutTax = Number(costWithoutTaxInput);
  const ivaPercent = Number(ivaPercentInput);
  const grossPercent = Number(grossPercentInput);
  const marginPercent = Number(marginPercentInput);
  const expiryInput = (document.getElementById('purchaseExpiry')?.value || '').trim();
  const normalizedExpiry = normalizeDateToISO(expiryInput);
  const calc = purchaseCalculateValues(costWithoutTaxInput, ivaPercentInput, grossPercentInput, marginPercentInput);
  if (expiryInput && normalizedExpiry === null) {
    showToast('La fecha de vencimiento debe tener formato DD/MM/AAAA o DDMMAA. Ejemplo: 20/06/2026 o 200626', true);
    document.getElementById('purchaseExpiry')?.focus();
    return;
  }
  if (qty <= 0) {
    showToast('La cantidad debe ser mayor a cero', true);
    return;
  }
  purchaseItems.push({
    product_id: product.id,
    name: product.name,
    quantity: qty,
    cost_without_tax: costWithoutTax,
    unit_cost: costWithoutTax,
    iva_percent: ivaPercent,
    gross_income_percent: grossPercent,
    total_cost: Number(calc.realCost.toFixed(2)),
    margin_percent: marginPercent,
    sale_price: Number(calc.salePrice.toFixed(2)),
    expiry_date: normalizedExpiry || '',
  });
  renderPurchaseItems();
  const search = document.getElementById('purchaseSearch');
  if (search) {
    search.value = '';
    search.focus();
  }
  showPurchaseSelectedProduct(null);
  const qtyInput = document.getElementById('purchaseQty');
  if (qtyInput) qtyInput.value = '1';
}

function renderPurchaseItems() {
  let total = 0;
  const tbody = document.getElementById('purchaseItems');
  if (!tbody) return;
  tbody.innerHTML = purchaseItems.length ? purchaseItems.map((i, idx) => {
    const realCost = Number(i.total_cost ?? i.unit_cost ?? 0);
    const line = Number(i.quantity || 0) * realCost;
    total += line;
    return `
      <tr>
        <td>${escapeHTML(i.name)}</td>
        <td>${i.quantity}</td>
        <td>${formatMoney(i.cost_without_tax ?? i.unit_cost)}</td>
        <td>${formatMoney(realCost)}</td>
        <td>${formatMoney(i.sale_price || 0)}</td>
        <td>${formatDateAR(i.expiry_date)}</td>
        <td>${formatMoney(line)}</td>
        <td><button class="tiny-button delete" onclick="purchaseItems.splice(${idx},1);renderPurchaseItems()">×</button></td>
      </tr>
    `;
  }).join('') : '<tr><td colspan="8" class="empty-state">Sin productos</td></tr>';
  const totalEl = document.getElementById('purchaseTotal');
  if (totalEl) totalEl.textContent = formatMoney(total);
}

async function savePurchase() {
  try {
    await api('/api/purchases', {
      method: 'POST',
      body: JSON.stringify({
        supplier_id: document.getElementById('purchaseSupplier')?.value || '',
        notes: document.getElementById('purchaseNotes')?.value || '',
        items: purchaseItems
      })
    });
    showToast('Compra registrada y stock actualizado');
    purchaseItems = [];
    renderPurchaseItems();
    await loadPurchasesModule();
  } catch (e) {
    showToast(e.message, true);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  renderPurchaseItems();
  updateQuickProductPreview();
  loadPurchasesModule();

  const search = document.getElementById('purchaseSearch');
  if (search) {
    search.addEventListener('input', () => searchPurchaseProducts());
    search.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      event.preventDefault();
      const term = search.value.trim();
      const results = searchPurchaseProducts();
      const exact = purchaseProducts.find(p => String(p.barcode || '') === term);
      if (exact) {
        selectPurchaseProduct(exact.id);
        return;
      }
      if (results.length === 1) {
        selectPurchaseProduct(results[0].id);
        return;
      }
      if (term) {
        showQuickProductForm(term);
      }
    });
  }

  const select = document.getElementById('purchaseProduct');
  if (select) select.addEventListener('change', selectPurchaseProductFromDropdown);

  const purchaseSupplier = document.getElementById('purchaseSupplier');
  if (purchaseSupplier) purchaseSupplier.addEventListener('change', updateQuickSupplierSelect);

  ['quickCost', 'quickIva', 'quickGross', 'quickMargin'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', updateQuickProductPreview);
  });

  ['purchaseCost', 'purchaseIva', 'purchaseGross', 'purchaseMargin'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', updatePurchaseCostPreview);
  });
  updatePurchaseCostPreview();

  const quickPhoto = document.getElementById('quickPhoto');
  if (quickPhoto) {
    quickPhoto.addEventListener('change', e => {
      const file = e.target.files && e.target.files[0];
      setQuickPhotoPreview(file ? URL.createObjectURL(file) : '');
    });
  }

  document.addEventListener('keydown', e => {
    const panel = document.getElementById('quickProductPanel');
    if (e.key === 'Escape' && panel && !panel.classList.contains('hidden')) {
      e.preventDefault();
      hideQuickProductForm();
      document.getElementById('purchaseSearch')?.focus();
    }
  });
});
