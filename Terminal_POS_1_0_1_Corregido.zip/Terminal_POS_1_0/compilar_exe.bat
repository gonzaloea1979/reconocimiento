@echo off
setlocal EnableExtensions
chcp 65001 >nul 2>nul
cd /d "%~dp0"
title Terminal POS Local - Compilar EXE

if not exist "logs" mkdir "logs"
set "LOG_FILE=%CD%\logs\compilar_exe.log"

>"%LOG_FILE%" echo [%DATE% %TIME%] ==========================================
>>"%LOG_FILE%" echo [%DATE% %TIME%] INICIO COMPILACION EXE
>>"%LOG_FILE%" echo [%DATE% %TIME%] Carpeta: %CD%
>>"%LOG_FILE%" echo [%DATE% %TIME%] ==========================================

echo.
echo ==========================================
echo      TERMINAL POS LOCAL - COMPILAR EXE
echo ==========================================
echo.
echo Este proceso genera el ejecutable en:
echo.
echo   dist\TerminalPOS\TerminalPOS.exe
echo.
echo IMPORTANTE: no cierres esta ventana.
echo Si falla, revisa: logs\compilar_exe.log
echo.

REM ============================================================
REM 1) Detectar Python 3.10 o superior.
REM ============================================================
set "PY_CMD="

call :try_python "py -3.12"
if not defined PY_CMD call :try_python "py -3.13"
if not defined PY_CMD call :try_python "py -3.11"
if not defined PY_CMD call :try_python "py -3.10"
if not defined PY_CMD call :try_python "py -3"
if not defined PY_CMD call :try_python "python"
if not defined PY_CMD call :try_python "python3"

if not defined PY_CMD (
    echo ERROR: No se encontro Python 3.10 o superior.
    echo.
    echo Solucion:
    echo 1. Instala Python desde python.org
    echo 2. Marca la opcion Add Python to PATH
    echo 3. Cerra y volve a abrir esta carpeta
    echo 4. Ejecuta nuevamente compilar_exe.bat
    echo.
    echo Detalle en: logs\compilar_exe.log
    pause
    exit /b 1
)

echo Python detectado: %PY_CMD%
>>"%LOG_FILE%" echo [%DATE% %TIME%] Python detectado: %PY_CMD%

REM ============================================================
REM 2) Verificar archivos principales.
REM ============================================================
if not exist "run.py" (
    echo ERROR: No se encontro run.py en esta carpeta.
    echo Ejecuta este BAT desde la carpeta principal del sistema POS.
    echo Detalle en: logs\compilar_exe.log
    >>"%LOG_FILE%" echo [%DATE% %TIME%] ERROR: falta run.py
    pause
    exit /b 1
)

if not exist "requirements.txt" (
    echo ERROR: No se encontro requirements.txt.
    echo Detalle en: logs\compilar_exe.log
    >>"%LOG_FILE%" echo [%DATE% %TIME%] ERROR: falta requirements.txt
    pause
    exit /b 1
)

REM ============================================================
REM 3) Crear o reparar entorno virtual de compilacion.
REM ============================================================
if exist ".venv_build\Scripts\python.exe" (
    ".venv_build\Scripts\python.exe" -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>>"%LOG_FILE%"
    if errorlevel 1 (
        echo Entorno de compilacion danado o incompatible. Se recreara...
        >>"%LOG_FILE%" echo [%DATE% %TIME%] .venv_build invalido. Eliminando...
        rmdir /s /q ".venv_build" >>"%LOG_FILE%" 2>&1
    )
)

if not exist ".venv_build\Scripts\python.exe" (
    echo.
    echo Creando entorno virtual de compilacion...
    %PY_CMD% -m venv ".venv_build" >>"%LOG_FILE%" 2>&1
    if errorlevel 1 (
        echo ERROR: No se pudo crear .venv_build
        echo.
        echo Posibles soluciones:
        echo - Instala Python nuevamente y marca Add Python to PATH.
        echo - Ejecuta este archivo como administrador.
        echo - Revisa que la carpeta no este protegida.
        echo.
        echo Detalle en: logs\compilar_exe.log
        pause
        exit /b 1
    )
)

set "BUILD_PY=%CD%\.venv_build\Scripts\python.exe"

REM ============================================================
REM 4) Instalar dependencias y PyInstaller.
REM ============================================================
echo.
echo Instalando dependencias de compilacion...
"%BUILD_PY%" -m pip install --upgrade pip setuptools wheel >>"%LOG_FILE%" 2>&1
if errorlevel 1 goto :pip_error

"%BUILD_PY%" -m pip install --upgrade -r "requirements.txt" pyinstaller >>"%LOG_FILE%" 2>&1
if errorlevel 1 goto :pip_error

"%BUILD_PY%" -c "import flask, werkzeug, reportlab, PIL, PyInstaller; print('dependencias OK')" >>"%LOG_FILE%" 2>&1
if errorlevel 1 goto :pip_error

goto :after_pip

:pip_error
echo.
echo ERROR: No se pudieron instalar las dependencias para compilar.
echo.
echo Posibles soluciones:
echo - Verifica que tengas internet.
echo - Ejecuta este archivo como administrador.
echo - Borra la carpeta .venv_build y volve a intentar.
echo - Si usas antivirus, permiti Python y PyInstaller.
echo.
echo Ultimas lineas del error:
echo ------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path '%LOG_FILE%') { Get-Content '%LOG_FILE%' -Tail 80 }" 2>nul
echo ------------------------------------------
echo.
echo Detalle completo en: logs\compilar_exe.log
pause
exit /b 1

:after_pip

REM ============================================================
REM 5) Limpiar compilaciones anteriores.
REM ============================================================
echo.
echo Limpiando compilaciones anteriores...
if exist "build" rmdir /s /q "build" >>"%LOG_FILE%" 2>&1
if exist "dist\TerminalPOS" rmdir /s /q "dist\TerminalPOS" >>"%LOG_FILE%" 2>&1
if exist "TerminalPOS.spec" del /q "TerminalPOS.spec" >>"%LOG_FILE%" 2>&1

if exist "dist\TerminalPOS" (
    echo ERROR: No se pudo borrar dist\TerminalPOS.
    echo.
    echo Causa probable: TerminalPOS.exe esta abierto o algun archivo esta bloqueado.
    echo Cerra el POS, cerra la carpeta dist si esta abierta y volve a intentar.
    echo.
    echo Detalle en: logs\compilar_exe.log
    pause
    exit /b 1
)

REM ============================================================
REM 6) Preparar recursos limpios; NO incluir uploads en datos embebidos.
REM ============================================================
if exist "build_assets" rmdir /s /q "build_assets" >>"%LOG_FILE%" 2>&1
mkdir "build_assets\app\static" 2>>"%LOG_FILE%"
robocopy "%CD%\app\static" "%CD%\build_assets\app\static" /E /XD "%CD%\app\static\uploads" >>"%LOG_FILE%" 2>&1
if errorlevel 8 (
  echo ERROR: No se pudieron preparar recursos estaticos limpios.
  pause
  exit /b 1
)

REM ============================================================
REM 6) Compilar EXE en modo carpeta.
REM ============================================================
echo.
echo Compilando EXE. Esto puede tardar varios minutos...
echo.
"%BUILD_PY%" -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onedir ^
  --windowed ^
  --name TerminalPOS ^
  --paths "%CD%" ^
  --add-data "%CD%\app\templates;app\templates" ^
  --add-data "%CD%\build_assets\app\static;app\static" ^
  --collect-data flask ^
  --collect-data werkzeug ^
  --collect-data jinja2 ^
  --collect-data reportlab ^
  --collect-data PIL ^
  --collect-submodules flask ^
  --collect-submodules werkzeug ^
  --collect-submodules jinja2 ^
  --collect-submodules reportlab ^
  --collect-submodules PIL ^
  --hidden-import app ^
  --hidden-import app.routes ^
  --hidden-import app.db ^
  --hidden-import app.config ^
  --hidden-import sqlite3 ^
  --hidden-import xlrd ^
  --hidden-import xlwt ^
  --hidden-import reportlab.pdfgen.canvas ^
  --hidden-import reportlab.lib.pagesizes ^
  --hidden-import reportlab.lib.units ^
  "%CD%\run.py" >>"%LOG_FILE%" 2>&1

if errorlevel 1 (
    echo.
    echo ERROR: Fallo la compilacion con PyInstaller.
    echo.
    echo Ultimas lineas del error:
    echo ------------------------------------------
    powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path '%LOG_FILE%') { Get-Content '%LOG_FILE%' -Tail 120 }" 2>nul
    echo ------------------------------------------
    echo.
    echo Detalle completo en: logs\compilar_exe.log
    pause
    exit /b 1
)

if not exist "dist\TerminalPOS\TerminalPOS.exe" (
    echo.
    echo ERROR: PyInstaller termino, pero no se encontro dist\TerminalPOS\TerminalPOS.exe
    echo Detalle en: logs\compilar_exe.log
    pause
    exit /b 1
)

REM ============================================================
REM 7) Preparar carpeta final con archivos editables/persistentes.
REM ============================================================
echo.
echo Preparando carpeta final del EXE...
if not exist "dist\TerminalPOS\app" mkdir "dist\TerminalPOS\app"
if exist "dist\TerminalPOS\app\templates" rmdir /s /q "dist\TerminalPOS\app\templates"
if exist "dist\TerminalPOS\app\static" rmdir /s /q "dist\TerminalPOS\app\static"

xcopy "app\templates" "dist\TerminalPOS\app\templates" /E /I /Y >>"%LOG_FILE%" 2>&1
if errorlevel 1 goto :copy_error

REM Copiar recursos estaticos, excluyendo uploads que pueden contener logos/fotos del negocio.
robocopy "%CD%\app\static" "%CD%\dist\TerminalPOS\app\static" /E /XD "%CD%\app\static\uploads" >>"%LOG_FILE%" 2>&1
if errorlevel 8 goto :copy_error

if not exist "dist\TerminalPOS\app\static\uploads" mkdir "dist\TerminalPOS\app\static\uploads"
if not exist "dist\TerminalPOS\instance" mkdir "dist\TerminalPOS\instance"
if not exist "dist\TerminalPOS\backups" mkdir "dist\TerminalPOS\backups"
if not exist "dist\TerminalPOS\TICKET" mkdir "dist\TerminalPOS\TICKET"
if not exist "dist\TerminalPOS\logs" mkdir "dist\TerminalPOS\logs"

REM No copiar automaticamente datos del negocio al paquete distribuible.
REM Para migrar datos intencionalmente, seguir MIGRAR_DATOS_EXE.txt tras compilar.
echo La base real y los archivos de usuario NO se copian automaticamente al EXE.
>>"%LOG_FILE%" echo Base de datos y uploads excluidos del paquete por seguridad.
if exist "README.md" copy /Y "README.md" "dist\TerminalPOS\README.md" >>"%LOG_FILE%" 2>&1
if exist "LEEME_COMPILAR_EXE.txt" copy /Y "LEEME_COMPILAR_EXE.txt" "dist\TerminalPOS\LEEME_COMPILAR_EXE.txt" >>"%LOG_FILE%" 2>&1
if exist "MIGRAR_DATOS_EXE.txt" copy /Y "MIGRAR_DATOS_EXE.txt" "dist\TerminalPOS\MIGRAR_DATOS_EXE.txt" >>"%LOG_FILE%" 2>&1

goto :after_copy

:copy_error
echo.
echo ERROR: No se pudieron copiar templates/static a la carpeta dist.
echo Detalle en: logs\compilar_exe.log
pause
exit /b 1

:after_copy

REM ============================================================
REM 8) Crear lanzador simple junto al EXE.
REM ============================================================
(
  echo @echo off
  echo chcp 65001 ^>nul 2^>nul
  echo cd /d "%%~dp0"
  echo title Terminal POS Local
  echo echo Iniciando Terminal POS Local...
  echo TerminalPOS.exe
  echo if errorlevel 1 ^(
  echo   echo.
  echo   echo El sistema se cerro con error.
  echo   echo Revisa la carpeta logs si aparece algun archivo de error.
  echo   pause
  echo ^)
) > "dist\TerminalPOS\INICIAR_POS.bat"

REM ============================================================
REM 9) Crear ZIP final si PowerShell esta disponible.
REM ============================================================
if exist "dist\TerminalPOS_EXE.zip" del /q "dist\TerminalPOS_EXE.zip" >>"%LOG_FILE%" 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'dist\TerminalPOS\*' -DestinationPath 'dist\TerminalPOS_EXE.zip' -Force" >>"%LOG_FILE%" 2>&1

REM ============================================================
REM 10) Verificacion de la distribucion generada.
REM ============================================================
"%BUILD_PY%" "verificar_exe_compilado.py" "dist\TerminalPOS" >>"%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo ERROR: la distribucion compilada NO aprobo la verificacion.
    echo Revisa logs\compilar_exe.log. No usar el ejecutable.
    pause
    exit /b 1
)

REM ============================================================
REM 10) Final OK.
REM ============================================================
echo.
echo ==========================================
echo      COMPILACION FINALIZADA CORRECTAMENTE
echo ==========================================
echo.
echo Ejecutable creado en:
echo.
echo   dist\TerminalPOS\TerminalPOS.exe
echo.
echo Para iniciar el sistema tambien podes abrir:
echo.
echo   dist\TerminalPOS\INICIAR_POS.bat
echo.
echo Para moverlo a otra PC, copia TODA la carpeta:
echo.
echo   dist\TerminalPOS
echo.
if exist "dist\TerminalPOS_EXE.zip" (
    echo Tambien se creo el ZIP:
    echo.
    echo   dist\TerminalPOS_EXE.zip
    echo.
)
>>"%LOG_FILE%" echo [%DATE% %TIME%] COMPILACION FINALIZADA OK
pause
exit /b 0

REM ============================================================
REM Subrutina: intenta usar un comando Python.
REM ============================================================
:try_python
set "CANDIDATE=%~1"
%CANDIDATE% -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >nul 2>>"%LOG_FILE%"
if not errorlevel 1 set "PY_CMD=%CANDIDATE%"
exit /b 0
