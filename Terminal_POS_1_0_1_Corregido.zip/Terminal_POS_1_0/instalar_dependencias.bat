@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
echo Instalando dependencias del POS...
if not exist "requirements.txt" (
    echo ERROR: No se encontro requirements.txt. Ejecuta este archivo desde la carpeta principal.
    pause
    exit /b 1
)
python -m pip install --prefer-binary -r requirements.txt
pause
