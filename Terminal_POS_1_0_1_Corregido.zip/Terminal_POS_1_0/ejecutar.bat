@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
title Terminal POS Local - Inicio

if not exist "logs" mkdir "logs"
set "LOG_FILE=logs\inicio.log"

>>"%LOG_FILE%" echo.
>>"%LOG_FILE%" echo ==========================================
>>"%LOG_FILE%" echo [%DATE% %TIME%] INICIO TERMINAL POS LOCAL
>>"%LOG_FILE%" echo Carpeta: %CD%
>>"%LOG_FILE%" echo ==========================================

cls
echo ==========================================
echo        TERMINAL POS LOCAL - INICIO
echo ==========================================
echo.
echo Preparando el sistema. No cierres esta ventana.
echo Si aparece un error, esta ventana quedara abierta.
echo.

REM Validar que el BAT se este ejecutando desde la carpeta principal del POS.
if not exist "run.py" (
    echo ERROR: No se encontro run.py en esta carpeta.
    echo.
    echo Descomprimi el ZIP completo y ejecuta ejecutar.bat desde la carpeta principal.
    echo No lo ejecutes directamente dentro del ZIP comprimido.
    >>"%LOG_FILE%" echo ERROR: run.py no encontrado.
    pause
    exit /b 1
)

if not exist "app\__init__.py" (
    echo ERROR: No se encontro la carpeta app completa.
    echo Descomprimi nuevamente el ZIP completo.
    >>"%LOG_FILE%" echo ERROR: app\__init__.py no encontrado.
    pause
    exit /b 1
)

if not exist "requirements.txt" (
    echo ERROR: No se encontro requirements.txt.
    echo Descomprimi nuevamente el ZIP completo.
    >>"%LOG_FILE%" echo ERROR: requirements.txt no encontrado.
    pause
    exit /b 1
)

REM Buscar Python 3.10 o superior. Se prueban varias opciones comunes en Windows.
set "PY_CMD="
call :check_python py -3.12
if defined PY_CMD goto :python_ok
call :check_python py -3.11
if defined PY_CMD goto :python_ok
call :check_python py -3.10
if defined PY_CMD goto :python_ok
call :check_python py -3
if defined PY_CMD goto :python_ok
call :check_python python
if defined PY_CMD goto :python_ok
call :check_python python3
if defined PY_CMD goto :python_ok

echo ERROR: No se encontro Python 3.10 o superior funcionando.
echo.
echo Solucion recomendada:
echo 1^) Instala Python desde python.org
echo 2^) En la instalacion marca: Add Python to PATH
echo 3^) Cierra esta ventana y vuelve a ejecutar ejecutar.bat
echo.
echo Tambien podes probar en CMD:
echo   py -3 --version
echo   python --version
echo.
>>"%LOG_FILE%" echo ERROR: Python 3.10+ no encontrado.
pause
exit /b 1

:python_ok
echo Python detectado: %PY_CMD%
>>"%LOG_FILE%" echo Python detectado: %PY_CMD%

REM Crear carpetas necesarias.
if not exist "instance" mkdir "instance"
if not exist "backups" mkdir "backups"
if not exist "TICKET" mkdir "TICKET"
if not exist "logs" mkdir "logs"
if not exist "app\static" mkdir "app\static"
if not exist "app\static\uploads" mkdir "app\static\uploads"

REM Si existe un entorno virtual incompleto, recrearlo.
if exist ".venv" (
    if not exist ".venv\Scripts\python.exe" (
        echo Entorno virtual incompleto. Se va a recrear...
        >>"%LOG_FILE%" echo Eliminando .venv incompleto.
        rmdir /s /q ".venv" >>"%LOG_FILE%" 2>&1
    )
)

REM Crear entorno virtual si no existe.
if not exist ".venv\Scripts\python.exe" (
    echo Creando entorno virtual local...
    >>"%LOG_FILE%" echo Creando entorno virtual local.
    call %PY_CMD% -m venv .venv >>"%LOG_FILE%" 2>&1
    if errorlevel 1 (
        echo.
        echo ERROR: No se pudo crear el entorno virtual.
        echo Revisa el detalle en: logs\inicio.log
        echo.
        call :show_log_tail
        pause
        exit /b 1
    )
)

set "VENV_PY=.venv\Scripts\python.exe"

REM Verificar pip y repararlo si hace falta.
"%VENV_PY%" -m pip --version >>"%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo Reparando pip del entorno virtual...
    >>"%LOG_FILE%" echo Ejecutando ensurepip.
    "%VENV_PY%" -m ensurepip --upgrade >>"%LOG_FILE%" 2>&1
)

"%VENV_PY%" -m pip --version >>"%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo ERROR: El entorno virtual no tiene pip funcionando.
    echo Borra la carpeta .venv y vuelve a ejecutar.
    echo Detalle: logs\inicio.log
    call :show_log_tail
    pause
    exit /b 1
)

REM Actualizar pip sin cortar si falla por falta de internet.
echo Verificando pip...
"%VENV_PY%" -m pip install --upgrade pip >>"%LOG_FILE%" 2>&1

REM Instalar/verificar dependencias.
echo Instalando o verificando dependencias necesarias...
echo La V17 abrira la interfaz con Microsoft Edge o Google Chrome en modo aplicacion.
>>"%LOG_FILE%" echo Instalando dependencias desde requirements.txt
"%VENV_PY%" -m pip install --prefer-binary -r requirements.txt >>"%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo.
    echo ERROR: No se pudieron instalar las dependencias.
    echo.
    echo Posibles soluciones:
    echo - Verifica que tengas internet.
    echo - Borra la carpeta .venv y vuelve a ejecutar.
    echo - Instala Python 3.12 si estas usando una version demasiado nueva.
    echo.
    echo Ultimas lineas del error:
    echo ------------------------------------------
    call :show_log_tail
    echo ------------------------------------------
    pause
    exit /b 1
)

REM Verificar importaciones principales antes de iniciar.
echo Verificando sistema...
"%VENV_PY%" -c "import flask, reportlab, xlrd, xlwt; from PIL import Image" >>"%LOG_FILE%" 2>&1
if errorlevel 1 (
    echo ERROR: Falta alguna dependencia necesaria.
    echo Detalle: logs\inicio.log
    call :show_log_tail
    pause
    exit /b 1
)

REM Iniciar aplicacion de escritorio en ventana propia.
echo.
echo ==========================================
echo Sistema listo. Iniciando POS...
echo ==========================================
echo.
echo Si la ventana no se abre, revisa el registro en:
echo logs\inicio.log
echo.
echo Para cerrar el sistema, usa Salir F10. Para apagar la PC, usa F12.
echo.
>>"%LOG_FILE%" echo Iniciando run.py

"%VENV_PY%" run.py
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if not "%EXIT_CODE%"=="0" (
    echo El sistema se detuvo con un error.
    echo.
    echo Ultimas lineas del registro:
    echo ------------------------------------------
    call :show_log_tail
    echo ------------------------------------------
    echo.
    echo.
    if exist "logs\inicio_error.log" (
        echo Detalle del arranque de escritorio:
        echo ------------------------------------------
        type "logs\inicio_error.log"
        echo ------------------------------------------
    )
    echo.
    echo Archivos utiles para revisar el error:
    echo   logs\inicio.log
    echo   logs\inicio_error.log
    echo   logs\desktop.log
    echo.
    echo Tambien podes ejecutar diagnostico.bat.
    pause
    exit /b %EXIT_CODE%
) else (
    echo El sistema se cerro correctamente.
    timeout /t 2 >nul
    exit /b 0
)

:check_python
%* -c "import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)" >>"%LOG_FILE%" 2>&1
if errorlevel 1 exit /b 0
set "PY_CMD=%*"
exit /b 0

:show_log_tail
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path '%LOG_FILE%') { Get-Content '%LOG_FILE%' -Tail 80 } else { Write-Host 'No se encontro logs\inicio.log' }"
exit /b 0
